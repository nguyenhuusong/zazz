import * as i0 from "@angular/core";
import * as i1 from "./currency-control.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
export declare class CurrencyControlModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyControlModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CurrencyControlModule, [typeof i1.CurrencyControlComponent], [typeof i2.CommonModule, typeof i3.FormsModule], [typeof i1.CurrencyControlComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CurrencyControlModule>;
}
