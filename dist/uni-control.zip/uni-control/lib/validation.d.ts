export declare function ValidationPhoneNumber(value: any): {
    error: boolean;
    message: string;
};
export declare function ValidationPhoneNumberEmpty(value: any): {
    error: boolean;
    message: string;
};
export declare function ValidationEmail(value: any): {
    error: boolean;
    message: string;
};
export declare function ValidationEmailEmpty(value: any): {
    error: boolean;
    message: string;
};
export declare function ValidationTaiKhoanNganHang(value: any): {
    error: boolean;
    message: string;
};
export declare function ValidationTaiKhoanNganHangEmpty(value: any): {
    error: boolean;
    message: string;
};
