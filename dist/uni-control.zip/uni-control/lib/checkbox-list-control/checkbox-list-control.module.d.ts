import * as i0 from "@angular/core";
import * as i1 from "./checkbox-list-control.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "primeng/button";
import * as i5 from "primeng/checkbox";
export declare class CheckboxListControlModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxListControlModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckboxListControlModule, [typeof i1.CheckboxListControlComponent], [typeof i2.CommonModule, typeof i3.FormsModule, typeof i4.ButtonModule, typeof i5.CheckboxModule], [typeof i1.CheckboxListControlComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckboxListControlModule>;
}
