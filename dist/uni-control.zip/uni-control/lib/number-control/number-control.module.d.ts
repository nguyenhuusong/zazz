import * as i0 from "@angular/core";
import * as i1 from "./number-control.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
export declare class NumberControlModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NumberControlModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NumberControlModule, [typeof i1.NumberControlComponent], [typeof i2.CommonModule, typeof i3.FormsModule], [typeof i1.NumberControlComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NumberControlModule>;
}
