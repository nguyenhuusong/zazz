"use strict";
(self["webpackChunkucart"] = self["webpackChunkucart"] || []).push([["src_app_pages_tuyen-dung_tuyen-dung_module_ts"],{

/***/ 48386:
/*!********************************************************!*\
  !*** ./src/app/common/hrm-steps/hrm-step.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HrmStepComponent": () => (/* binding */ HrmStepComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var primeng_steps__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/steps */ 56307);


class HrmStepComponent {
    constructor() {
        this.steps = [];
        this.flowSt = [];
        this.activeIndex = 0;
    }
    ngOnInit() {
        this.activeIndex = this.flowSt || 0;
        this.steps = this.steps.map(d => {
            return {
                label: d.flow_name,
                value: d.flow_st
            };
        });
        setTimeout(() => {
            this.stepActivated();
        }, 100);
        if (this.steps && this.steps.length > 0) {
            this.getStep();
        }
    }
    getStep() {
        this.steps = this.steps.sort((a, b) => a.value - b.value);
        this.steps = this.steps.map((d, index) => {
            return {
                label: d.label,
                value: index
            };
        });
    }
    stepActivated() {
        const stepS = document.querySelectorAll('.status-line .p-steps-item');
        if (stepS.length > 0) {
            for (let i = 0; i < this.steps.length; i++) {
                if (i < this.activeIndex) {
                    stepS[i].className += ' p-highlight active';
                }
                else if (i === this.activeIndex) {
                    stepS[i].className += ' p-highlight active p-steps-current';
                }
                else {
                    stepS[i].classList.value = `p-steps-item icon-${i}`;
                }
            }
        }
    }
}
HrmStepComponent.ɵfac = function HrmStepComponent_Factory(t) { return new (t || HrmStepComponent)(); };
HrmStepComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: HrmStepComponent, selectors: [["app-hrm-step"]], inputs: { steps: "steps", flowSt: "flowSt" }, decls: 2, vars: 3, consts: [[1, "status-line"], [3, "model", "activeIndex", "readonly", "activeIndexChange"]], template: function HrmStepComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p-steps", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("activeIndexChange", function HrmStepComponent_Template_p_steps_activeIndexChange_1_listener($event) { return ctx.activeIndex = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("model", ctx.steps)("activeIndex", ctx.activeIndex)("readonly", true);
    } }, directives: [primeng_steps__WEBPACK_IMPORTED_MODULE_1__.Steps], styles: [".title[_ngcontent-%COMP%] {\r\n    font-size: 20px;\r\n    color: #2F3E62;\r\n    font-family: 'SFProTextMedium';\r\n    font-weight: 500;\r\n}\r\n[_nghost-%COMP%]  .breadcrumb .p-breadcrumb{\r\n        margin-bottom: 0;\r\n    }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhybS1zdGVwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxlQUFlO0lBQ2YsY0FBYztJQUNkLDhCQUE4QjtJQUM5QixnQkFBZ0I7QUFDcEI7QUFDQTtRQUNRLGdCQUFnQjtJQUNwQiIsImZpbGUiOiJocm0tc3RlcC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRpdGxlIHtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGNvbG9yOiAjMkYzRTYyO1xyXG4gICAgZm9udC1mYW1pbHk6ICdTRlByb1RleHRNZWRpdW0nO1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxufVxyXG46aG9zdDo6bmctZGVlcCAuYnJlYWRjcnVtYiAucC1icmVhZGNydW1ie1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICB9XHJcbiJdfQ== */"] });


/***/ }),

/***/ 91086:
/*!*****************************************************!*\
  !*** ./src/app/common/hrm-steps/hrm-step.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HrmStepModule": () => (/* binding */ HrmStepModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_steps__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/steps */ 56307);
/* harmony import */ var _hrm_step_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./hrm-step.component */ 48386);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);





class HrmStepModule {
}
HrmStepModule.ɵfac = function HrmStepModule_Factory(t) { return new (t || HrmStepModule)(); };
HrmStepModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: HrmStepModule });
HrmStepModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            primeng_steps__WEBPACK_IMPORTED_MODULE_4__.StepsModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](HrmStepModule, { declarations: [_hrm_step_component__WEBPACK_IMPORTED_MODULE_0__.HrmStepComponent], imports: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        primeng_steps__WEBPACK_IMPORTED_MODULE_4__.StepsModule], exports: [_hrm_step_component__WEBPACK_IMPORTED_MODULE_0__.HrmStepComponent] }); })();


/***/ }),

/***/ 8415:
/*!*****************************************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/chi-tiet-linh-vuc-tuyen-dung/chi-tiet-linh-vuc-tuyen-dung.component.ts ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietLinhVucTuyenDungComponent": () => (/* binding */ ChiTietLinhVucTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);
















function ChiTietLinhVucTuyenDungComponent_app_edit_detail_7_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "app-edit-detail", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("callback", function ChiTietLinhVucTuyenDungComponent_app_edit_detail_7_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return ctx_r1.setJobInfo($event); })("callbackcancel", function ChiTietLinhVucTuyenDungComponent_app_edit_detail_7_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return ctx_r3.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
const queryString = __webpack_require__(/*! query-string */ 31808);
class ChiTietLinhVucTuyenDungComponent {
    constructor(activatedRoute, apiService, spinner, confirmationService, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.MENUACTIONROLEAPI.GetJobPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.ACTIONS.EDIT) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this.modelEdit = {
            jobId: 0,
        };
        this.titlePage = '';
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng' },
            { label: 'Chuyên môn tuyển dụng', routerLink: '/tuyen-dung/chuyen-mon' },
            { label: `${this.titlePage}` },
        ];
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this.unsubscribe$))
            .subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.modelEdit.jobId = this.paramsObject.params.jobId || null;
            this.getJobInfo();
        });
    }
    ;
    getJobInfo() {
        const queryParams = queryString.stringify(this.modelEdit);
        this.apiService.getJobInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.detailInfo = results.data;
            }
        });
    }
    setJobInfo(data) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setJobInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.router.navigate(['/tuyen-dung/chuyen-mon']);
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getJobInfo();
        }
        else {
            this.router.navigate(['/tuyen-dung/chuyen-mon']);
        }
    }
}
ChiTietLinhVucTuyenDungComponent.ɵfac = function ChiTietLinhVucTuyenDungComponent_Factory(t) { return new (t || ChiTietLinhVucTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_9__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router)); };
ChiTietLinhVucTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: ChiTietLinhVucTuyenDungComponent, selectors: [["app-chi-tiet-linh-vuc-tuyen-dung"]], decls: 8, vars: 3, consts: [[1, "main-grid", "product-detail"], [1, "breadcrumb"], [3, "model"], [1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function ChiTietLinhVucTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "p-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, ChiTietLinhVucTuyenDungComponent_app_edit_detail_7_Template, 1, 4, "app-edit-detail", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("model", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx.titlePage);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_11__.Breadcrumb, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_4__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC1saW5oLXZ1Yy10dXllbi1kdW5nLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 71398:
/*!***********************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/chi-tiet-tuyen-dung/chi-tiet-tuyen-dung.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietTuyenDungComponent": () => (/* binding */ ChiTietTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_hrm_steps_hrm_step_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../common/hrm-steps/hrm-step.component */ 48386);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);



















function ChiTietTuyenDungComponent_app_hrm_step_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-hrm-step", 8);
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("steps", ctx_r0.detailEdit == null ? null : ctx_r0.detailEdit.flowStatuses)("flowSt", ctx_r0.detailEdit == null ? null : ctx_r0.detailEdit.flow_st);
} }
function ChiTietTuyenDungComponent_app_edit_detail_7_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "app-edit-detail", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("callback", function ChiTietTuyenDungComponent_app_edit_detail_7_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r4); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return ctx_r3.setCandidateInfo($event); })("callbackcancel", function ChiTietTuyenDungComponent_app_edit_detail_7_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r4); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return ctx_r5.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("detail", ctx_r1.detailInfo)("manhinh", "Edit")("isNested", true)("optionsButtonsEdit", ctx_r1.optionsButon)("dataView", ctx_r1.listViews);
} }
function ChiTietTuyenDungComponent_section_8_app_list_grid_angular_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-list-grid-angular", 13);
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("listsData", ctx_r6.listData)("height", ctx_r6.heightGrid)("columnDefs", ctx_r6.columnDefs);
} }
function ChiTietTuyenDungComponent_section_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "section");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "h4");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](3, "L\u1ECBch s\u1EED");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](5, ChiTietTuyenDungComponent_section_8_app_list_grid_angular_5_Template, 1, 3, "app-list-grid-angular", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r2.columnDefs.length > 0);
} }
const queryString = __webpack_require__(/*! query-string */ 31808);
class ChiTietTuyenDungComponent {
    constructor(activatedRoute, apiService, spinner, confirmationService, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.MENUACTIONROLEAPI.GetCandidatePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.ACTIONS.EDIT) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_10__.Subject();
        this.modelEdit = {
            canId: null,
        };
        this.titlePage = '';
        this.isView = false;
        this.columnDefs = [];
        this.listData = [];
        this.heightGrid = 300;
        this.gridKey = '';
        this.cols = [];
        this.detailEdit = null;
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng' },
            { label: 'Danh sách tuyển dụng', routerLink: '/tuyen-dung/ds-tuyen-dung' },
            { label: `${this.titlePage}` },
        ];
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.unsubscribe$))
            .subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.modelEdit.canId = this.paramsObject.params.canId || null;
            this.isView = this.paramsObject.params.view;
            if (!this.isView) {
                this.getCandidateInfo();
            }
            else {
                this.getCandidatesViewInfo();
            }
        });
    }
    ;
    getCandidateInfo() {
        const queryParams = queryString.stringify(this.modelEdit);
        this.apiService.getCandidateInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.detailInfo = results.data;
                this.detailEdit = results.data;
            }
        });
    }
    getCandidatesViewInfo() {
        this.columnDefs = [];
        this.listData = [];
        const query = { canId: this.modelEdit.canId };
        this.apiService.getCandidatesViewInfo((0,querystring__WEBPACK_IMPORTED_MODULE_4__.stringify)(query))
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                this.cols = results.data.gridflexdetails1;
                this.listData = results.data.recruitCandidates;
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.detailInfo = results.data;
                this.initGrid();
            }
        });
        const queryParams = queryString.stringify(this.modelEdit);
        this.apiService.getCandidateInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                this.detailEdit = results.data;
            }
        });
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide))
        ];
    }
    setCandidateInfo(data) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setCandidateInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.router.navigate(['/tuyen-dung/ds-tuyen-dung']);
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getCandidateInfo();
        }
        else {
            this.router.navigate(['/tuyen-dung/ds-tuyen-dung']);
        }
    }
}
ChiTietTuyenDungComponent.ɵfac = function ChiTietTuyenDungComponent_Factory(t) { return new (t || ChiTietTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_13__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.Router)); };
ChiTietTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: ChiTietTuyenDungComponent, selectors: [["app-chi-tiet-tuyen-dung"]], decls: 9, vars: 4, consts: [[1, "main-grid", "product-detail"], [3, "items"], [1, "content"], [1, "d-flex", "center"], [1, "col-8"], [3, "steps", "flowSt", 4, "ngIf"], [3, "detail", "manhinh", "isNested", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [4, "ngIf"], [3, "steps", "flowSt"], [3, "detail", "manhinh", "isNested", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"], [1, "d-flex", "bet", "middle"], [1, "grid-default"], [3, "listsData", "height", "columnDefs", 4, "ngIf"], [3, "listsData", "height", "columnDefs"]], template: function ChiTietTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](2, "app-hrm-breadcrumb", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](6, ChiTietTuyenDungComponent_app_hrm_step_6_Template, 1, 2, "app-hrm-step", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](7, ChiTietTuyenDungComponent_app_edit_detail_7_Template, 1, 5, "app-edit-detail", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](8, ChiTietTuyenDungComponent_section_8_Template, 6, 1, "section", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.detailEdit);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.isView);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_5__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _common_hrm_steps_hrm_step_component__WEBPACK_IMPORTED_MODULE_6__.HrmStepComponent, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_7__.EditDetailComponent, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_8__.ListGridAngularComponent], styles: ["[_nghost-%COMP%]  .product-detail .row {\n  margin-left: -15px;\n  margin-right: -15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoaS10aWV0LXR1eWVuLWR1bmcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRVE7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0FBRFoiLCJmaWxlIjoiY2hpLXRpZXQtdHV5ZW4tZHVuZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0OjpuZy1kZWVwe1xyXG4gICAgLnByb2R1Y3QtZGV0YWlse1xyXG4gICAgICAgIC5yb3d7XHJcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAtMTVweDtcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAtMTVweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iXX0= */"] });


/***/ }),

/***/ 63669:
/*!*************************************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/chi-tiet-vi-tri-tuyen-dung/chi-tiet-vi-tri-tuyen-dung.component.ts ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietViTriTuyenDungComponent": () => (/* binding */ ChiTietViTriTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var src_app_utils_common_function_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/utils/common/function-common */ 79619);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_hrm_steps_hrm_step_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../common/hrm-steps/hrm-step.component */ 48386);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);




















function ChiTietViTriTuyenDungComponent_app_hrm_step_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-hrm-step", 7);
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("steps", ctx_r0.detailInfo == null ? null : ctx_r0.detailInfo.flowStatuses)("flowSt", ctx_r0.detailInfo == null ? null : ctx_r0.detailInfo.flow_st);
} }
function ChiTietViTriTuyenDungComponent_app_edit_detail_7_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "app-edit-detail", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("callback", function ChiTietViTriTuyenDungComponent_app_edit_detail_7_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return ctx_r2.setVacancyInfo($event); })("callbackcancel", function ChiTietViTriTuyenDungComponent_app_edit_detail_7_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r3); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return ctx_r4.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("detail", ctx_r1.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r1.optionsButon)("dataView", ctx_r1.listViews);
} }
const queryString = __webpack_require__(/*! query-string */ 31808);
class ChiTietViTriTuyenDungComponent {
    constructor(activatedRoute, apiService, spinner, confirmationService, messageService, organizeInfoService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.MENUACTIONROLEAPI.GetVacancyPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.ACTIONS.EDIT) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_10__.Subject();
        this.modelEdit = {
            vacancyId: null,
        };
        this.titlePage = '';
        this.isCopy = false;
        this.organIdSelected = '';
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng' },
            { label: 'Vị trí tuyển dụng', routerLink: '/tuyen-dung/vi-tri-tuyen-dung' },
            { label: `${this.titlePage}` },
        ];
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.unsubscribe$))
            .subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.modelEdit.vacancyId = this.paramsObject.params.vacancyId || null;
            this.isCopy = this.paramsObject.params.copy;
            if (this.isCopy) {
                this.getVacancyReplicationInfo();
            }
            else {
                this.organizeInfoService.organizeInfo$.subscribe((results) => {
                    if (results && results.length > 0) {
                        this.getVacancyInfo();
                        this.organIdSelected = results;
                    }
                });
            }
        });
    }
    ;
    getVacancyReplicationInfo() {
        const queryParams = queryString.stringify(this.modelEdit);
        this.apiService.getVacancyReplicationInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.detailInfo = results.data;
            }
        });
    }
    getVacancyInfo() {
        this.listViews = [];
        const queryParams = queryString.stringify(this.modelEdit);
        this.apiService.getVacancyInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.listViews = (0,src_app_utils_common_function_common__WEBPACK_IMPORTED_MODULE_5__.setOrganizeId)(this.listViews, 'organizeId', this.organIdSelected);
                this.detailInfo = results.data;
            }
        });
    }
    setVacancyInfo(data) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setVacancyInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.router.navigate(['/tuyen-dung/vi-tri-tuyen-dung']);
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getVacancyInfo();
        }
        else {
            this.router.navigate(['/tuyen-dung/vi-tri-tuyen-dung']);
        }
    }
}
ChiTietViTriTuyenDungComponent.ɵfac = function ChiTietViTriTuyenDungComponent_Factory(t) { return new (t || ChiTietViTriTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_13__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_4__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.Router)); };
ChiTietViTriTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: ChiTietViTriTuyenDungComponent, selectors: [["app-chi-tiet-vi-tri-tuyen-dung"]], decls: 8, vars: 3, consts: [[1, "main-grid", "product-detail"], [3, "items"], [1, "content"], [1, "d-flex", "center"], [1, "col-8"], [3, "steps", "flowSt", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [3, "steps", "flowSt"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function ChiTietViTriTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](2, "app-hrm-breadcrumb", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](6, ChiTietViTriTuyenDungComponent_app_hrm_step_6_Template, 1, 2, "app-hrm-step", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](7, ChiTietViTriTuyenDungComponent_app_edit_detail_7_Template, 1, 4, "app-edit-detail", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.detailInfo);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_6__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _common_hrm_steps_hrm_step_component__WEBPACK_IMPORTED_MODULE_7__.HrmStepComponent, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_8__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC12aS10cmktdHV5ZW4tZHVuZy5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 97816:
/*!*********************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/ds-tiem-nang/ds-tiem-nang.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DsTiemNangComponent": () => (/* binding */ DsTiemNangComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/radiobutton */ 95143);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/dropdown */ 45596);






























function DsTiemNangComponent_app_list_grid_angular_29_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "app-list-grid-angular", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("callback", function DsTiemNangComponent_app_list_grid_angular_29_Template_app_list_grid_angular_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r7.rowSelected($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("rowSelection", "multiple")("columnDefs", ctx_r1.columnDefs);
} }
function DsTiemNangComponent_app_config_grid_table_form_35_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "app-config-grid-table-form", 37);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r2.gridKey);
} }
function DsTiemNangComponent_ng_template_38_div_5_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "p-radioButton", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngModelChange", function DsTiemNangComponent_ng_template_38_div_5_div_1_Template_p_radioButton_ngModelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r13); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](3); return ctx_r12.recruitmentStatusSelected = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](2, "label", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const recrui_r11 = ctx.$implicit;
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngClass", recrui_r11.code === 1 ? "" : "op6");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpropertyInterpolate"]("value", recrui_r11.code);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpropertyInterpolate1"]("inputId", "recrui", recrui_r11.code, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("disabled", recrui_r11.code !== 1)("ngModel", ctx_r10.recruitmentStatusSelected);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpropertyInterpolate1"]("for", "recrui", recrui_r11.code, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](recrui_r11.label);
} }
function DsTiemNangComponent_ng_template_38_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](1, DsTiemNangComponent_ng_template_38_div_5_div_1_Template, 4, 7, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngForOf", ctx_r9.recruitmentStatus);
} }
function DsTiemNangComponent_ng_template_38_Template(rf, ctx) { if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](2, "Chuy\u1EC3n v\u00F2ng tuy\u1EC3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](4, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](5, DsTiemNangComponent_ng_template_38_div_5_Template, 2, 1, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](6, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](7, "p-button", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DsTiemNangComponent_ng_template_38_Template_p_button_click_7_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r15); _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵreference"](37); return _r3.hide(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](8, " \u00A0 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](9, "p-button", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DsTiemNangComponent_ng_template_38_Template_p_button_click_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r15); const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r16.changeRecruStatus(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r4.recruitmentStatus.length > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("disabled", ctx_r4.recruitmentStatusSelected ? false : true);
} }
function DsTiemNangComponent_ng_template_41_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](item_r21.label);
} }
function DsTiemNangComponent_ng_template_41_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r22 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"]("", car_r22.label, " ");
} }
function DsTiemNangComponent_ng_template_41_ng_template_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r23 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](item_r23.label);
} }
function DsTiemNangComponent_ng_template_41_ng_template_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r24 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"]("", car_r24.label, " ");
} }
function DsTiemNangComponent_ng_template_41_Template(rf, ctx) { if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](4, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](6, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](7, "label", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](8, "V\u00F2ng tuy\u1EC3n d\u1EE5ng");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](9, "p-dropdown", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngModelChange", function DsTiemNangComponent_ng_template_41_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r26); const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r25.query.can_st = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](10, DsTiemNangComponent_ng_template_41_ng_template_10_Template, 2, 1, "ng-template", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](11, DsTiemNangComponent_ng_template_41_ng_template_11_Template, 3, 1, "ng-template", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](12, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](13, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](14, "label", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](15, "V\u1ECB tr\u00ED tuy\u1EC3n d\u1EE5ng ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](16, "p-dropdown", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngModelChange", function DsTiemNangComponent_ng_template_41_Template_p_dropdown_ngModelChange_16_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r26); const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r27.query.vacancyId = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](17, DsTiemNangComponent_ng_template_41_ng_template_17_Template, 2, 1, "ng-template", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](18, DsTiemNangComponent_ng_template_41_ng_template_18_Template, 3, 1, "ng-template", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](19, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](20, "label", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](21, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](22, "span", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](23, "p-button", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DsTiemNangComponent_ng_template_41_Template_p_button_click_23_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r26); const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r28.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](24, "p-button", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DsTiemNangComponent_ng_template_41_Template_p_button_click_24_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r26); const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r29.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngClass", ctx_r6.query.can_st ? "valid" : "invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r6.listStatus)("ngModel", ctx_r6.query.can_st)("filter", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngClass", ctx_r6.query.vacancyId ? "valid" : "invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r6.listVacancy)("ngModel", ctx_r6.query.vacancyId)("filter", true);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { showAll: "ALL" }; };
const _c2 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c3 = function () { return { width: "50vw" }; };
const _c4 = function () { return { width: "400px" }; };
const _c5 = function () { return { width: "700px" }; };
const MAX_SIZE = 100000000;
class DsTiemNangComponent {
    constructor(apiService, route, confirmationService, messageService, spinner, changeDetector, organizeInfoService, router) {
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.listsData = [];
        this.items = [];
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS;
        this.pagingComponent = {
            total: 0
        };
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn;
        this.columnDefs = [];
        this.query = {
            vacancyId: 0,
            can_st: null,
            organizeId: null,
            positionCd: null,
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
            fromDate: '',
            toDate: '',
        };
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.loading = false;
        this.listVacancy = [];
        this.recruitmentStatus = [];
        this.recruitmentStatusSelected = '1';
        this.dataRowSelected = [];
        this.isSendMail = false;
        this.mailInputValue = [];
        this.buttonTiemNang = [];
        this.loadjs = 0;
        this.heightGrid = 450;
        // the value for check disabled 'Chuyển vòng radio'
        this.canSttValue = null;
        this.organizeIdSelected = '';
        this.displaySetting = false;
        this.gridKey = '';
        this.listOrgRoots = [];
        this.positiontypes = [];
        this.listJobTitles = [];
        this.positions = [{ label: 'Tất cả', value: null }];
        this.listStatus = [];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_2__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__.AvatarFullComponent,
        };
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cancel() {
        this.query = {
            vacancyId: 0,
            can_st: null,
            organizeId: null,
            positionCd: null,
            filter: '',
            offSet: 0,
            pageSize: 15,
            fromDate: '',
            toDate: '',
            organizeIds: this.query.organizeIds,
        };
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.dataRowSelected = [];
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getCandidatePotentialPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.viewRow.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetCandidatePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.VIEW)
                },
                {
                    onClick: this.xoatuyendung.bind(this),
                    label: 'Xóa ',
                    icon: 'pi pi-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetCandidatePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.DELETE)
                },
            ]
        };
    }
    viewRow(event) {
        const params = {
            canId: event.rowData.canId,
            view: true
        };
        this.router.navigate(['/tuyen-dung/ds-tuyen-dung/chi-tiet-tuyen-dung'], { queryParams: params });
    }
    xoatuyendung(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa tuyển dụng?',
            accept: () => {
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ canId: event.rowData.canId });
                this.apiService.delCandidateInfo(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa tuyển dụng thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: '',
                filter: '',
                width: 60,
                pinned: 'left',
                cellClass: ['border-right', 'no-auto'],
                field: 'checkbox2',
                headerCheckboxSelection: false,
                suppressSizeToFit: true,
                suppressRowClickSelection: true,
                showDisabledCheckboxes: true,
                checkboxSelection: true,
                // rowSelection: 'single'
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn)(this.cols.filter((d) => !d.isHide)), {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    rowSelected(event) {
        this.dataRowSelected = event;
        this.recruitmentStatusSelected = this.dataRowSelected.map(d => d.can_st).toString();
        this.canSttValue = this.dataRowSelected.sort((a, b) => a.can_st - b.can_st)[this.dataRowSelected.length - 1];
        // check role for set tiem nang
    }
    getOrgPositions() {
        this.positions = [];
        let items = this.listOrgRoots.filter(d => d.value === this.query.organizeId);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ orgId: items[0].code });
        this.apiService.getOrgPositions(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.positions = results.data.map(d => {
                    return { label: d.positionName, value: d.positionCd };
                });
                this.positions = [{ label: 'Tất cả', value: '' }, ...this.positions];
            }
        });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows === 4 ? 100000000 : event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.organizeIdSelected = results;
                this.getReRound();
                this.listsData = [];
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Nhân sự' },
            { label: 'Danh sách tuyển dụng', routerLink: '/tuyen-dung/ds-tuyen-dung' },
            { label: 'Danh sách tiềm năng' },
        ];
        this.getJobTitles();
        this.getOrgRoots();
        this.getObjectList();
        this.getStatus();
        this.getVacancyPage();
    }
    getOrgRoots() {
        this.apiService.getOrgRoots().subscribe(results => {
            if (results.status === 'success') {
                this.listOrgRoots = results.data.map(d => {
                    return {
                        label: d.org_name + '-' + d.org_cd,
                        value: `${d.orgId}`,
                        code: `${d.orgId}`,
                    };
                });
                this.listOrgRoots = [{ label: 'Tất cả', value: null }, ...this.listOrgRoots];
            }
        });
    }
    getObjectList() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ objKey: 'positiontype_group' });
        this.apiService.getCustObjectListNew(false, queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.positiontypes = results.data.map(d => {
                    return {
                        label: d.objName,
                        value: d.objCode
                    };
                });
                this.positiontypes = [{ label: 'Tất cả', value: null }, ...this.positiontypes];
            }
        });
    }
    getJobTitles() {
        this.apiService.getJobTitles().subscribe(results => {
            if (results.status === 'success') {
                this.listJobTitles = results.data.map(d => {
                    return {
                        label: d.job_name,
                        value: d.jobId
                    };
                });
                this.listJobTitles = [{ label: 'Tất cả', value: null }, ...this.listJobTitles];
            }
        });
    }
    getStatus() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ objKey: 'recruitment_round' });
        this.apiService.getCustObjectListNew(false, queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.listStatus = results.data.map(d => {
                    return {
                        label: d.objName,
                        value: d.objValue
                    };
                });
                this.listStatus = [{ label: 'Tất cả', value: null }, ...this.listStatus];
            }
        });
    }
    getReRound() {
        this.recruitmentStatus = [];
        this.apiService.getRecruitRoundTitles(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ organizeIds: this.organizeIdSelected })).subscribe(results => {
            if (results.status === 'success') {
                this.recruitmentStatus = results.data.map(d => {
                    return {
                        label: d.name,
                        code: d.value
                    };
                });
            }
        });
    }
    getVacancyPage() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({
            // jobId: this.query.jobId,
            active_st: 1
        });
        this.apiService.getVacancyPage(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.listVacancy = results.data.dataList.data.map(d => {
                    return {
                        label: d.job_name,
                        value: d.vacancyId
                    };
                });
            }
        });
    }
    changeRecruStatus() {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn chuyển vòng?',
            accept: () => {
                let dataUpdateStatus = this.dataRowSelected.map(d => d.canId).toString();
                let vacancyId = this.dataRowSelected.map(d => d.vacancyId).toString();
                const query = {
                    canId: dataUpdateStatus,
                    can_st: this.recruitmentStatusSelected,
                    vacancyId: vacancyId
                };
                this.apiService.recruiUpdateStatus(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query)).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Chuyển thành công!' });
                        this.dataRowSelected = [];
                        this.load();
                        this.recruitmentStatusSelected = null;
                        this.isSendMail = true;
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            },
        });
    }
}
DsTiemNangComponent.ɵfac = function DsTiemNangComponent_Factory(t) { return new (t || DsTiemNangComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_15__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_12__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.Router)); };
DsTiemNangComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({ type: DsTiemNangComponent, selectors: [["app-ds-tiem-nang"]], decls: 42, vars: 35, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [1, "col-4", "pd-0"], [3, "items"], [1, "d-flex", "gap-16", "col-8", "pd-0", "end"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "V\u1ECB tr\u00ED, chuy\u00EAn m\u00F4n ...", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", "label", "Chuy\u1EC3n v\u00F2ng", 3, "disabled", "CheckHideActions", "click"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "20", "height", "17", "viewBox", "0 0 20 17", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M19.5 17V0H0.50855L0.5 17H19.5ZM6.675 15.3187H2.21V6.81868H6.675V15.3187ZM8.575 15.3187V6.81868H17.79V15.3187H8.575ZM2.21 1.68132V5.13736H17.79V1.68132H2.21Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "rowSelection", "columnDefs", "callback", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "advance-seach"], ["recru", ""], ["pTemplate", ""], ["op", ""], [3, "listsData", "height", "rowSelection", "columnDefs", "callback"], [3, "typeConfig", "gridKey"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "mt-1"], [1, "icon", "col-12", "pl-0"], ["class", "radios grid", 4, "ngIf"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["label", "H\u1EE7y", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], ["label", "Chuy\u1EC3n", "icon", "pi pi-times", "styleClass", "", 3, "disabled", "click"], [1, "radios", "grid"], ["class", "p-field-radiobutton col-6", "style", "margin-bottom: 5px;", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "p-field-radiobutton", "col-6", 2, "margin-bottom", "5px", 3, "ngClass"], ["name", "recrui", 3, "disabled", "value", "ngModel", "inputId", "ngModelChange"], [2, "margin-left", "5px", 3, "for"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", 3, "ngClass"], ["for", ""], ["appendTo", "body", "name", "can_st", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], ["appendTo", "body", "name", "vacancyId", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"]], template: function DsTiemNangComponent_Template(rf, ctx) { if (rf & 1) {
        const _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("keydown.enter", function DsTiemNangComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function DsTiemNangComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DsTiemNangComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DsTiemNangComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DsTiemNangComponent_Template_p_button_click_15_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r30); const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵreference"](40); return _r5.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](21, "p-button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DsTiemNangComponent_Template_p_button_click_21_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r30); const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵreference"](37); return _r3.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](22, "p-button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DsTiemNangComponent_Template_p_button_click_22_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](23, "svg", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](24, "path", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](25, " \u00A0 C\u1EA5u h\u00ECnh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](26, "section", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](27, "div", 25, 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](29, DsTiemNangComponent_app_list_grid_angular_29_Template, 1, 4, "app-list-grid-angular", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](30, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](31, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](32);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](33, "p-paginator", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("onPageChange", function DsTiemNangComponent_Template_p_paginator_onPageChange_33_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](34, "p-dialog", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("visibleChange", function DsTiemNangComponent_Template_p_dialog_visibleChange_34_listener($event) { return ctx.displaySetting = $event; })("onHide", function DsTiemNangComponent_Template_p_dialog_onHide_34_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](35, DsTiemNangComponent_app_config_grid_table_form_35_Template, 1, 2, "app-config-grid-table-form", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](36, "p-overlayPanel", 32, 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](38, DsTiemNangComponent_ng_template_38_Template, 10, 2, "ng-template", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](39, "p-overlayPanel", 32, 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](41, DsTiemNangComponent_ng_template_41_Template, 25, 12, "ng-template", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("disabled", ctx.dataRowSelected.length > 0 ? false : true)("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction2"](26, _c0, ctx.MENUACTIONROLEAPI.GetCandidatePage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](30, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](29, _c1)));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](32, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](33, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](34, _c5));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_18__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_9__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_19__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_20__.Dialog, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_21__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_14__.PrimeTemplate, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_11__.ConfigGridTableFormComponent, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgForOf, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_22__.RadioButton, primeng_dropdown__WEBPACK_IMPORTED_MODULE_23__.Dropdown], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkcy10aWVtLW5hbmcuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 16285:
/*!*******************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/import-tuyen-dung/import-tuyen-dung.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ImportTuyenDungComponent": () => (/* binding */ ImportTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/tooltip */ 39243);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/fileupload */ 83735);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);



















function ImportTuyenDungComponent_p_button_8_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportTuyenDungComponent_p_button_8_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r5.getTemfileImport(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportTuyenDungComponent_p_fileUpload_9_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-fileUpload", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onSelect", function ImportTuyenDungComponent_p_fileUpload_9_Template_p_fileUpload_onSelect_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r7.onSelectFile($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("showCancelButton", true);
} }
function ImportTuyenDungComponent_p_button_10_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportTuyenDungComponent_p_button_10_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r9.back(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportTuyenDungComponent_p_button_11_Template(rf, ctx) { if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportTuyenDungComponent_p_button_11_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r12); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r11.refetchFile(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportTuyenDungComponent_div_13_app_list_grid_angular_2_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "app-list-grid-angular", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("firstDataRendered", function ImportTuyenDungComponent_div_13_app_list_grid_angular_2_Template_app_list_grid_angular_firstDataRendered_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2); return ctx_r15.onFirstDataRendered($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("listsData", ctx_r14.listsData)("height", ctx_r14.heightGrid)("getContextMenuItems", ctx_r14.getContextMenuItems)("columnDefs", ctx_r14.columnDefs);
} }
function ImportTuyenDungComponent_div_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 17, 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, ImportTuyenDungComponent_div_13_app_list_grid_angular_2_Template, 1, 4, "app-list-grid-angular", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r4.columnDefs.length > 0 && ctx_r4.heightGrid > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" T\u1ED5ng s\u1ED1 ", ctx_r4.listsData.length, " ");
} }
class ImportTuyenDungComponent {
    constructor(spinner, apiService, changeDetector, router, messageService) {
        this.spinner = spinner;
        this.apiService = apiService;
        this.changeDetector = changeDetector;
        this.router = router;
        this.messageService = messageService;
        this.items = [];
        this.isFullScreen = false;
        this.heightGrid = 0;
        this.isShowUpload = true;
        this.listsData = [];
        this.columnDefs = [];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Danh sách tuyển dụng', routerLink: '/tuyen-dung/ds-tuyen-dung' },
            { label: 'Import tuyển dụng' },
        ];
    }
    toggleGrid() {
        this.isFullScreen = !this.isFullScreen;
        if (this.isFullScreen) {
            this.heightGrid = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.ShowFullScreen)();
        }
        else {
            this.heightGrid = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.HideFullScreen)();
        }
    }
    onSelectFile(event) {
        if (event.currentFiles.length > 0) {
            this.spinner.show();
            this.isShowUpload = false;
            let fomrData = new FormData();
            fomrData.append('formFile', event.currentFiles[0]);
            this.apiService.importCandidates(fomrData)
                .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.takeUntil)(this.unsubscribe$))
                .subscribe(results => {
                if (results.status === 'success') {
                    if (results.data && results.data.dataList && results.data.dataList.data) {
                        this.cols = results.data.gridflexs;
                        this.initGrid();
                        const a = document.querySelector(".header");
                        const b = document.querySelector(".sidebarBody");
                        const c = document.querySelector(".bread-filter");
                        // const d: any = document.querySelector(".filterInput");
                        const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + 80;
                        this.heightGrid = window.innerHeight - totalHeight;
                        this.changeDetector.detectChanges();
                        // this.onInitAgGrid();
                        this.listsData = results.data.dataList.data;
                    }
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                    this.spinner.hide();
                }
                else {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    this.spinner.hide();
                }
            });
        }
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.AgGridFn)(this.cols.filter((d) => !d.isHide))
        ];
    }
    back() {
        const main = document.querySelector(".main");
        main.className = 'main';
        this.router.navigate(['/tuyen-dung/ds-tuyen-dung']);
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    getContextMenuItems(params) {
        var result = [
            'copy',
            'paste',
            'separator',
            'excelExport'
        ];
        return result;
    }
    refetchFile() {
        this.isShowUpload = true;
        this.listsData = [];
        this.columnDefs = [];
    }
    getTemfileImport() {
        this.apiService.exportReportLocalhost('assets/tpl-import-file/file_mau_import_tuyen_dung.xlsx').subscribe((data) => {
            this.createImageFromBlob(data);
        });
    }
    createImageFromBlob(image) {
        var blob = new Blob([image]);
        var url = window.URL.createObjectURL(blob);
        var anchor = document.createElement("a");
        anchor.download = "file_mau_import_tuyen_dung.xlsx";
        anchor.href = url;
        anchor.click();
    }
    onFirstDataRendered(params) {
        params.api.sizeColumnsToFit();
    }
}
ImportTuyenDungComponent.ɵfac = function ImportTuyenDungComponent_Factory(t) { return new (t || ImportTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_7__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService)); };
ImportTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: ImportTuyenDungComponent, selectors: [["app-import-tuyen-dung"]], decls: 14, vars: 7, consts: [[1, "main-grid"], [1, "bread-crumb"], [3, "items"], [1, "bread-filter"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "col-item"], [1, "d-flex", "align-items-center", "gap-16"], ["type", "button", "icon", "pi pi-th-large", "tooltipPosition", "top", 1, "p-button-sm", 3, "pTooltip", "click"], ["styleClass", "p-button-sm", "icon", "pi pi-download", "label", "T\u1EA3i file m\u1EABu", 3, "click", 4, "ngIf"], ["mode", "basic", "name", "demo[]", "chooseLabel", "T\u1EA1o m\u1EDBi import", "accept", ".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel", 3, "showCancelButton", "onSelect", 4, "ngIf"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "Quay l\u1EA1i", 3, "click", 4, "ngIf"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "l\u00E0m m\u1EDBi", 3, "click", 4, "ngIf"], ["class", "grid-default", 4, "ngIf"], ["styleClass", "p-button-sm", "icon", "pi pi-download", "label", "T\u1EA3i file m\u1EABu", 3, "click"], ["mode", "basic", "name", "demo[]", "chooseLabel", "T\u1EA1o m\u1EDBi import", "accept", ".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel", 3, "showCancelButton", "onSelect"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "Quay l\u1EA1i", 3, "click"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "l\u00E0m m\u1EDBi", 3, "click"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "getContextMenuItems", "columnDefs", "firstDataRendered", 4, "ngIf"], [1, "paginator", 2, "margin-top", "10px", "text-align", "right", "margin-right", "25px", "font-weight", "600"], [3, "listsData", "height", "getContextMenuItems", "columnDefs", "firstDataRendered"]], template: function ImportTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "app-hrm-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "section", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "p-button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportTuyenDungComponent_Template_p_button_click_7_listener() { return ctx.toggleGrid(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, ImportTuyenDungComponent_p_button_8_Template, 1, 0, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, ImportTuyenDungComponent_p_fileUpload_9_Template, 1, 1, "p-fileUpload", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, ImportTuyenDungComponent_p_button_10_Template, 1, 0, "p-button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, ImportTuyenDungComponent_p_button_11_Template, 1, 0, "p-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, ImportTuyenDungComponent_div_13_Template, 5, 2, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("pTooltip", ctx.isFullScreen ? "\u1EA8n to\u00E0n m\u00E0n h\u00ECnh" : "Hi\u1EC3n th\u1ECB to\u00E0n m\u00E0n h\u00ECnh");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_2__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_10__.Button, primeng_tooltip__WEBPACK_IMPORTED_MODULE_11__.Tooltip, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, primeng_fileupload__WEBPACK_IMPORTED_MODULE_13__.FileUpload, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_3__.ListGridAngularComponent], styles: ["[_nghost-%COMP%]  .bg-red {\n  background: red;\n  color: #fff;\n  padding: 4px;\n  overflow: auto;\n  display: block;\n}\n[_nghost-%COMP%]  p-fileupload .p-messages {\n  position: fixed;\n  top: auto;\n  margin-top: 30px;\n  left: 50%;\n  transform: translateX(-50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImltcG9ydC10dXllbi1kdW5nLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7QUFBUjtBQUlRO0VBQ0ksZUFBQTtFQUNBLFNBQUE7RUFDQSxnQkFBQTtFQUNBLFNBQUE7RUFDQSwyQkFBQTtBQUZaIiwiZmlsZSI6ImltcG9ydC10dXllbi1kdW5nLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Q6Om5nLWRlZXB7XHJcbiAgICAuYmctcmVke1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHJlZDtcclxuICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICBwYWRkaW5nOiA0cHg7XHJcbiAgICAgICAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB9XHJcblxyXG4gICAgcC1maWxldXBsb2Fke1xyXG4gICAgICAgIC5wLW1lc3NhZ2Vze1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICAgICAgICAgIHRvcDogYXV0bztcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMzBweDtcclxuICAgICAgICAgICAgbGVmdDogNTAlO1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */"] });


/***/ }),

/***/ 56546:
/*!***********************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/linh-vuc-tuyen-dung/linh-vuc-tuyen-dung.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LinhVucTuyenDungComponent": () => (/* binding */ LinhVucTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);





























function LinhVucTuyenDungComponent_ng_template_35_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "span", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](item_r7.label);
} }
function LinhVucTuyenDungComponent_ng_template_35_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "div", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](car_r8.label);
} }
function LinhVucTuyenDungComponent_ng_template_35_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](4, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](6, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](7, "label", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](8, " C\u1EA5p b\u1EADc: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](9, "p-dropdown", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngModelChange", function LinhVucTuyenDungComponent_ng_template_35_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r9.query.positionTypeCd = $event; })("onChange", function LinhVucTuyenDungComponent_ng_template_35_Template_p_dropdown_onChange_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r10); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r11.find(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](10, LinhVucTuyenDungComponent_ng_template_35_ng_template_10_Template, 2, 1, "ng-template", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](11, LinhVucTuyenDungComponent_ng_template_35_ng_template_11_Template, 3, 1, "ng-template", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](12, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](13, "label", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](14, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](15, "span", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](16, "p-button", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function LinhVucTuyenDungComponent_ng_template_35_Template_p_button_click_16_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r10); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r12.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](17, "p-button", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function LinhVucTuyenDungComponent_ng_template_35_Template_p_button_click_17_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r10); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r13.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r1.positiontypes)("ngModel", ctx_r1.query.positionTypeCd);
} }
function LinhVucTuyenDungComponent_app_list_grid_angular_39_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "app-list-grid-angular", 56);
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("listsData", ctx_r3.listsData)("height", ctx_r3.heightGrid)("columnDefs", ctx_r3.columnDefs);
} }
function LinhVucTuyenDungComponent_app_config_grid_table_form_45_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "app-config-grid-table-form", 57);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r4.gridKey);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { width: "700px" }; };
const _c2 = function () { return { showAll: "ALL" }; };
const _c3 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c4 = function () { return { width: "50vw" }; };
const MAX_SIZE = 100000000;
class LinhVucTuyenDungComponent {
    constructor(apiService, route, confirmationService, spinner, changeDetector, messageService, organizeInfoService, router) {
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS;
        this.pagingComponent = {
            total: 0
        };
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.orgRoots = [];
        this.positiontypes = [];
        this.listJobTitles = [];
        this.query = {
            jobId: -1,
            filter: '',
            offSet: 0,
            pageSize: 15,
            gridWidth: 1300,
            organizeId: null,
            positionTypeCd: null,
            organizeIds: '',
        };
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.loading = false;
        this.loadjs = 0;
        this.heightGrid = 0;
        this.displaySetting = false;
        this.gridKey = '';
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: [],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_2__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__.AvatarFullComponent,
        };
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const c = document.querySelector(".bread-filter");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    cancel() {
        this.query = {
            jobId: -1,
            positionTypeCd: null,
            filter: '',
            offSet: 0,
            pageSize: 15,
            gridWidth: 1300,
            organizeId: null,
            organizeIds: this.query.organizeIds,
        };
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows === 4 ? 100000000 : event.rows;
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getJobPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            if (this.query.pageSize === MAX_SIZE) {
                this.query.pageSize = this.countRecord.totalRecord;
            }
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.XemChiTiet.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetJobPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.VIEW)
                },
                {
                    onClick: this.xoalinhvuc.bind(this),
                    label: 'Xóa ',
                    icon: 'pi pi-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetJobPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.DELETE)
                },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    xoalinhvuc(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện xóa Chuyên môn này !',
            accept: () => {
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ jobId: event.rowData.jobId });
                this.apiService.delJobInfo(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa Chuyên môn thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    XemChiTiet(event) {
        const params = {
            jobId: event.rowData.jobId
        };
        this.router.navigate(['/tuyen-dung/chuyen-mon/chi-tiet-linh-vuc-tuyen-dung'], { queryParams: params });
    }
    addJob() {
        const params = {
            jobId: 0
        };
        this.router.navigate(['/tuyen-dung/chuyen-mon/them-moi-linh-vuc-tuyen-dung'], { queryParams: params });
    }
    find() {
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng', },
            { label: 'Danh sách Chuyên môn tuyển dụng' },
        ];
        this.getJobTitles();
        this.getObjectList();
        this.getOrgRoots();
    }
    getOrgRoots() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.orgRoots = results.data.map(d => {
                    return {
                        label: d.organizationName + '-' + d.organizationCd,
                        value: `${d.organizeId}`
                    };
                });
                this.orgRoots = [{ label: 'Tất cả', value: null }, ...this.orgRoots];
            }
        });
    }
    getObjectList() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ objKey: 'positiontype_group' });
        this.apiService.getCustObjectListNew(false, queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.positiontypes = results.data.map(d => {
                    return {
                        label: d.objName,
                        value: d.objCode
                    };
                });
                this.positiontypes = [{ label: 'Tất cả', value: null }, ...this.positiontypes];
            }
        });
    }
    getJobTitles() {
        this.apiService.getJobTitles().subscribe(results => {
            if (results.status === 'success') {
                this.listJobTitles = results.data.map(d => {
                    return {
                        label: d.job_name,
                        value: d.jobId
                    };
                });
                this.listJobTitles = [{ label: 'Tất cả', value: -1 }, ...this.listJobTitles];
            }
        });
    }
}
LinhVucTuyenDungComponent.ɵfac = function LinhVucTuyenDungComponent_Factory(t) { return new (t || LinhVucTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_15__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_12__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.Router)); };
LinhVucTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({ type: LinhVucTuyenDungComponent, selectors: [["app-linh-vuc-tuyen-dung"]], decls: 46, vars: 31, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [3, "items"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "20", "height", "17", "viewBox", "0 0 20 17", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M19.5 17V0H0.50855L0.5 17H19.5ZM6.675 15.3187H2.21V6.81868H6.675V15.3187ZM8.575 15.3187V6.81868H17.79V15.3187H8.575ZM2.21 1.68132V5.13736H17.79V1.68132H2.21Z", "fill", "#F3F8FF"], [1, "bread-filter"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "col-item"], [1, "d-flex", "align-items-center"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "V\u1ECB tr\u00ED, chuy\u1EC3n m\u00F4n ...", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], [1, "d-flex", "align-items-center", "gap-16"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", 3, "CheckHideActions", "click"], ["d", "M11 5H9V9H5V11H9V15H11V11H15V9H11V5ZM10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM10 18C5.59 18 2 14.41 2 10C2 5.59 5.59 2 10 2C14.41 2 18 5.59 18 10C18 14.41 14.41 18 10 18Z", "fill", "#F3F8FF"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", "label-8", "valid"], ["for", ""], ["appendTo", "body", "name", "positionTypeCd", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [2, "vertical-align", "middle"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"], [3, "listsData", "height", "columnDefs"], [3, "typeConfig", "gridKey"]], template: function LinhVucTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](4, "p-button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function LinhVucTuyenDungComponent_Template_p_button_click_4_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "svg", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](6, "path", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](7, " \u00A0 C\u1EA5u h\u00ECnh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "section", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](9, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](10, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](11, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](12, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](13, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](14, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("keydown.enter", function LinhVucTuyenDungComponent_Template_input_keydown_enter_14_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function LinhVucTuyenDungComponent_Template_input_ngModelChange_14_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](15, "span", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function LinhVucTuyenDungComponent_Template_span_click_15_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](16, "svg", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](17, "path", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](18, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](19, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](20, "p-button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function LinhVucTuyenDungComponent_Template_p_button_click_20_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](21, "svg", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](22, "path", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](23, "p-button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function LinhVucTuyenDungComponent_Template_p_button_click_23_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r14); const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵreference"](34); return _r0.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](24, "svg", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](25, "path", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](26, "path", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](27, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](28, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](29, "p-button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function LinhVucTuyenDungComponent_Template_p_button_click_29_listener() { return ctx.addJob(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](30, "svg", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](31, "path", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](32, " \u00A0 Th\u00EAm m\u1EDBi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](33, "p-overlayPanel", 28, 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](35, LinhVucTuyenDungComponent_ng_template_35_Template, 18, 4, "ng-template", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](36, "section", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](37, "div", 32, 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](39, LinhVucTuyenDungComponent_app_list_grid_angular_39_Template, 1, 3, "app-list-grid-angular", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](40, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](41, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](42);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](43, "p-paginator", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("onPageChange", function LinhVucTuyenDungComponent_Template_p_paginator_onPageChange_43_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](44, "p-dialog", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("visibleChange", function LinhVucTuyenDungComponent_Template_p_dialog_visibleChange_44_listener($event) { return ctx.displaySetting = $event; })("onHide", function LinhVucTuyenDungComponent_Template_p_dialog_onHide_44_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](45, LinhVucTuyenDungComponent_app_config_grid_table_form_45_Template, 1, 2, "app-config-grid-table-form", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction2"](23, _c0, ctx.MENUACTIONROLEAPI.GetJobPage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](26, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](28, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](27, _c2)));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](30, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_16__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgModel, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_9__.CheckHideActionsDirective, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_19__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_14__.PrimeTemplate, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_20__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.Dialog, primeng_dropdown__WEBPACK_IMPORTED_MODULE_22__.Dropdown, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_11__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsaW5oLXZ1Yy10dXllbi1kdW5nLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 30361:
/*!*******************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/mail-da-gui/mail-da-gui.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MailDaGuiComponent": () => (/* binding */ MailDaGuiComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/calendar */ 6582);






























function MailDaGuiComponent_app_list_grid_angular_24_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-list-grid-angular", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("showConfig", function MailDaGuiComponent_app_list_grid_angular_24_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r5.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function MailDaGuiComponent_app_config_grid_table_form_30_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-config-grid-table-form", 32);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r2.gridKey);
} }
function MailDaGuiComponent_ng_template_33_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](8, "T\u1EEB ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "p-calendar", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function MailDaGuiComponent_ng_template_33_Template_p_calendar_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r7.query.fromDate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](11, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](13, "\u0110\u1EBFn ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](14, "p-calendar", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function MailDaGuiComponent_ng_template_33_Template_p_calendar_ngModelChange_14_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r8); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r9.query.toDate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](16, "p-button", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MailDaGuiComponent_ng_template_33_Template_p_button_click_16_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r8); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r10.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "p-button", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MailDaGuiComponent_ng_template_33_Template_p_button_click_17_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r8); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r11.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r4.query.fromDate)("monthNavigator", true)("yearNavigator", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r4.query.toDate)("monthNavigator", true);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "50vw" }; };
const _c3 = function () { return { width: "700px" }; };
const MAX_SIZE = 100000000;
class MailDaGuiComponent {
    constructor(apiService, route, confirmationService, messageService, spinner, changeDetector, organizeInfoService, router) {
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.listsData = [];
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS;
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.query = {
            organizeId: '',
            fromDate: new Date(moment__WEBPACK_IMPORTED_MODULE_9__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            toDate: new Date(moment__WEBPACK_IMPORTED_MODULE_9__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.totalRecord = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.loading = false;
        this.loadjs = 0;
        this.heightGrid = 0;
        this.displaySetting = false;
        this.gridKey = '';
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_2__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_4__.AvatarFullComponent,
        };
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cancel() {
        this.query = {
            organizeId: '',
            fromDate: new Date(moment__WEBPACK_IMPORTED_MODULE_9__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            toDate: new Date(moment__WEBPACK_IMPORTED_MODULE_9__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds,
        };
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows === 4 ? 100000000 : event.rows;
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        let params = Object.assign({}, this.query);
        delete params.fromDate;
        delete params.toDate;
        params.FromDate = moment__WEBPACK_IMPORTED_MODULE_9__(new Date(this.query.fromDate)).format('YYYY-MM-DD');
        params.ToDate = moment__WEBPACK_IMPORTED_MODULE_9__(new Date(this.query.toDate)).format('YYYY-MM-DD');
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.apiService.getRecruitSendMailPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            if (this.query.pageSize === MAX_SIZE) {
                this.query.pageSize = this.countRecord.totalRecord;
            }
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: []
        };
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.AgGridFn)(this.cols.filter((d) => !d.isHide))
            // {
            //   headerName: 'Thao tác',
            //   filter: '',
            //   width: 100,
            //   pinned: 'right',
            //   cellRenderer: 'buttonAgGridComponent',
            //   cellClass: ['border-right', 'no-auto'],
            //   cellRendererParams: (params: any) => this.showButtons(params),
            //   checkboxSelection: false,
            //   field: 'checkbox'
            // }
        ];
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng' },
            { label: 'Mail đã gửi' },
        ];
    }
}
MailDaGuiComponent.ɵfac = function MailDaGuiComponent_Factory(t) { return new (t || MailDaGuiComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_16__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.Router)); };
MailDaGuiComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({ type: MailDaGuiComponent, selectors: [["app-mail-da-gui"]], decls: 34, vars: 27, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-3", "pd-0"], [3, "items"], [1, "col-9", "gap-16", "end", "pd-0", "wrap", "d-flex"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "V\u1ECB tr\u00ED, chuy\u1EC3n m\u00F4n ...", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [3, "listsData", "height", "columnDefs", "showConfig"], [3, "typeConfig", "gridKey"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "date", "valid"], ["panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "fromdate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "yearNavigator", "ngModelChange"], ["panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "todate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "ngModelChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"]], template: function MailDaGuiComponent_Template(rf, ctx) { if (rf & 1) {
        const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("keydown.enter", function MailDaGuiComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function MailDaGuiComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MailDaGuiComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MailDaGuiComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MailDaGuiComponent_Template_p_button_click_15_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r12); const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](32); return _r3.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](21, "section", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](22, "div", 21, 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](24, MailDaGuiComponent_app_list_grid_angular_24_Template, 1, 3, "app-list-grid-angular", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](25, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](26, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](27);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](28, "p-paginator", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onPageChange", function MailDaGuiComponent_Template_p_paginator_onPageChange_28_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](29, "p-dialog", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("visibleChange", function MailDaGuiComponent_Template_p_dialog_visibleChange_29_listener($event) { return ctx.displaySetting = $event; })("onHide", function MailDaGuiComponent_Template_p_dialog_onHide_29_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](30, MailDaGuiComponent_app_config_grid_table_form_30_Template, 1, 2, "app-config-grid-table-form", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](31, "p-overlayPanel", 28, 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](33, MailDaGuiComponent_ng_template_33_Template, 18, 9, "ng-template", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](23, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](22, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](25, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](26, _c3));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_10__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_19__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_20__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.Dialog, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_22__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_15__.PrimeTemplate, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__.ConfigGridTableFormComponent, primeng_calendar__WEBPACK_IMPORTED_MODULE_23__.Calendar], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtYWlsLWRhLWd1aS5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 34278:
/*!*************************************************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/mail-tuyen-dung/chi-tiet-mail-tuyen-dung/chi-tiet-mail-tuyen-dung.component.ts ***!
  \*************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietMailTuyenDungComponent": () => (/* binding */ ChiTietMailTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var showdown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! showdown */ 323);
/* harmony import */ var showdown__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(showdown__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/tooltip */ 39243);


















function ChiTietMailTuyenDungComponent_app_edit_detail_9_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "app-edit-detail", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("callback", function ChiTietMailTuyenDungComponent_app_edit_detail_9_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r2.setRecruitMailInfo($event); })("callback1", function ChiTietMailTuyenDungComponent_app_edit_detail_9_Template_app_edit_detail_callback1_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r3); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r4.getChipsValue($event); })("callbackcancel", function ChiTietMailTuyenDungComponent_app_edit_detail_9_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r3); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r5.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
function ChiTietMailTuyenDungComponent_ul_12_li_1_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ChiTietMailTuyenDungComponent_ul_12_li_1_Template_span_click_1_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r9); const config_r7 = restoredCtx.$implicit; const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2); return ctx_r8.getTextConfig(config_r7); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, "[");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](6, "]");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const config_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"]("", config_r7, " ");
} }
function ChiTietMailTuyenDungComponent_ul_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ul", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, ChiTietMailTuyenDungComponent_ul_12_li_1_Template, 7, 1, "li", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r1.configData);
} }
const queryString = __webpack_require__(/*! query-string */ 31808);
class ChiTietMailTuyenDungComponent {
    constructor(activatedRoute, apiService, spinner, confirmationService, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.router = router;
        this.converter = new (showdown__WEBPACK_IMPORTED_MODULE_4___default().Converter)();
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.MENUACTIONROLEAPI.GetVacancyPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.ACTIONS.EDIT) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
        this.modelEdit = {
            mail_Id: null,
        };
        this.titlePage = '';
        this.configData = [];
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng' },
            { label: 'Mail tuyển dụng', routerLink: '/tuyen-dung/mail-tuyen-dung' },
            { label: `${this.titlePage}` },
        ];
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.modelEdit.mail_Id = this.paramsObject.params.mail_Id || null;
            this.getRecruitMailInfo();
        });
    }
    ;
    getRecruitMailInfo() {
        const queryParams = queryString.stringify(this.modelEdit);
        this.apiService.getRecruitMailInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.detailInfo = results.data;
                this.getConfigData();
            }
        });
    }
    getConfigData() {
        if (this.listViews && this.listViews.length > 0) {
            this.listViews.forEach(field => {
                field.fields.forEach(element => {
                    if (element.field_name === 'info_field') {
                        if (element.columnValue) {
                            this.configData = element.columnValue.split(',');
                        }
                    }
                });
            });
        }
    }
    getChipsValue(event) {
        this.configData = event;
    }
    setRecruitMailInfo(data) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setRecruitMailInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.router.navigate(['/tuyen-dung/mail-tuyen-dung']);
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getRecruitMailInfo();
        }
        else {
            this.router.navigate(['/tuyen-dung/mail-tuyen-dung']);
        }
    }
    getTextConfig(text) {
        navigator.clipboard.writeText('[' + text + ']').then(d => {
            this.messageService.add({ key: 'bc', severity: 'success', summary: 'Thông báo', detail: 'Đã copy' });
        }, function (err) {
            console.error('Async: Could not copy text: ', err);
        });
    }
}
ChiTietMailTuyenDungComponent.ɵfac = function ChiTietMailTuyenDungComponent_Factory(t) { return new (t || ChiTietMailTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router)); };
ChiTietMailTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: ChiTietMailTuyenDungComponent, selectors: [["app-chi-tiet-mail-tuyen-dung"]], decls: 13, vars: 4, consts: [[1, "main-grid", "product-detail"], [1, "breadcrumb"], [3, "model"], [1, "content"], [1, "grid"], [1, "col-10"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callback1", "callbackcancel", 4, "ngIf"], [1, "col-2"], [1, "sidebar-config"], ["class", "d-flex wrap configs gap-16", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callback1", "callbackcancel"], [1, "d-flex", "wrap", "configs", "gap-16"], [4, "ngFor", "ngForOf"], ["pTooltip", "Copy", "tooltipPosition", "top", 3, "click"], [2, "color", "#4C97E4"]], template: function ChiTietMailTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "p-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](8, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](9, ChiTietMailTuyenDungComponent_app_edit_detail_9_Template, 1, 4, "app-edit-detail", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](12, ChiTietMailTuyenDungComponent_ul_12_Template, 2, 1, "ul", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("model", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.titlePage);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.configData);
    } }, directives: [primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_12__.Breadcrumb, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__.EditDetailComponent, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgForOf, primeng_tooltip__WEBPACK_IMPORTED_MODULE_14__.Tooltip], styles: ["[_nghost-%COMP%]  .p-chips-token {\n  cursor: pointer;\n}\n\n.sidebar-config[_ngcontent-%COMP%] {\n  background: #fbfbfb;\n  padding: 15px;\n  border: 1px solid #ebebeb;\n  border-radius: 2px;\n  height: 100%;\n}\n\n.sidebar-config[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin-top: 0px;\n}\n\n.sidebar-config[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  cursor: pointer;\n  font-size: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoaS10aWV0LW1haWwtdHV5ZW4tZHVuZy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLGVBQUE7QUFBUjs7QUFHQTtFQUNJLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBQUo7O0FBQ0k7RUFDSSxlQUFBO0FBQ1I7O0FBR1k7RUFDSSxlQUFBO0VBQ0EsZUFBQTtBQURoQiIsImZpbGUiOiJjaGktdGlldC1tYWlsLXR1eWVuLWR1bmcuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdDo6bmctZGVlcHtcclxuICAgIC5wLWNoaXBzLXRva2Vue1xyXG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIH1cclxufVxyXG4uc2lkZWJhci1jb25maWd7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmJmYmZiO1xyXG4gICAgcGFkZGluZzogMTVweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlYmViZWI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAycHg7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBoM3tcclxuICAgICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICB9XHJcbiAgICB1bHtcclxuICAgICAgICBsaXtcclxuICAgICAgICAgICAgc3BhbntcclxuICAgICAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */"] });


/***/ }),

/***/ 47642:
/*!***************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/mail-tuyen-dung/mail-tuyen-dung.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MailTuyenDungComponent": () => (/* binding */ MailTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);




























function MailTuyenDungComponent_app_list_grid_angular_26_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-list-grid-angular", 29);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function MailTuyenDungComponent_app_config_grid_table_form_32_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-config-grid-table-form", 30);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r2.gridKey);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { showAll: "ALL" }; };
const _c2 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c3 = function () { return { width: "50vw" }; };
const MAX_SIZE = 100000000;
class MailTuyenDungComponent {
    constructor(apiService, route, confirmationService, messageService, spinner, changeDetector, organizeInfoService, router) {
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.listsData = [];
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS;
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.hiringMans = [];
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.loading = false;
        this.selectedValue = '';
        this.loadjs = 0;
        this.heightGrid = 0;
        this.displaySetting = false;
        this.gridKey = '';
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_2__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_4__.AvatarFullComponent,
        };
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cancel() {
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds,
        };
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows === 4 ? 100000000 : event.rows;
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getRecruitMailPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            if (this.query.pageSize === MAX_SIZE) {
                this.query.pageSize = this.countRecord.totalRecord;
            }
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.XemChiTiet.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetRecruitMailPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.VIEW)
                },
                {
                    onClick: this.deleteRow.bind(this),
                    label: 'Xóa',
                    icon: 'pi pi-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetRecruitMailPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.DELETE)
                },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    deleteRow(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa?',
            accept: () => {
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ mail_Id: event.rowData.mail_Id });
                this.apiService.delRecruitMailInfo(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    XemChiTiet(event) {
        const params = {
            mail_Id: event.rowData.mail_Id
        };
        this.router.navigate(['/tuyen-dung/mail-tuyen-dung/chi-tiet-mail-tuyen-dung'], { queryParams: params });
    }
    create() {
        const params = {
            mail_Id: null
        };
        this.router.navigate(['/tuyen-dung/mail-tuyen-dung/them-moi-mail-tuyen-dung'], { queryParams: params });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
                this.selectedValue = results;
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng' },
            { label: 'Mail tuyển dụng' },
        ];
    }
}
MailTuyenDungComponent.ɵfac = function MailTuyenDungComponent_Factory(t) { return new (t || MailTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_16__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.Router)); };
MailTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({ type: MailTuyenDungComponent, selectors: [["app-mail-tuyen-dung"]], decls: 33, vars: 28, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-3", "pd-0"], [3, "items"], [1, "col-9", "gap-16", "end", "pd-0", "wrap", "d-flex"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "V\u1ECB tr\u00ED, chuy\u1EC3n m\u00F4n ...", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56", 3, "CheckHideActions", "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M11 5H9V9H5V11H9V15H11V11H15V9H11V5ZM10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM10 18C5.59 18 2 14.41 2 10C2 5.59 5.59 2 10 2C14.41 2 18 5.59 18 10C18 14.41 14.41 18 10 18Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "20", "height", "17", "viewBox", "0 0 20 17", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M19.5 17V0H0.50855L0.5 17H19.5ZM6.675 15.3187H2.21V6.81868H6.675V15.3187ZM8.575 15.3187V6.81868H17.79V15.3187H8.575ZM2.21 1.68132V5.13736H17.79V1.68132H2.21Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "listsData", "height", "columnDefs"], [3, "typeConfig", "gridKey"]], template: function MailTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("keydown.enter", function MailTuyenDungComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function MailTuyenDungComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MailTuyenDungComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MailTuyenDungComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MailTuyenDungComponent_Template_p_button_click_15_listener() { return ctx.create(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](18, " \u00A0 Th\u00EAm m\u1EDBi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "p-button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MailTuyenDungComponent_Template_p_button_click_19_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](20, "svg", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](21, "path", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](22, " \u00A0 C\u1EA5u h\u00ECnh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](23, "section", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](24, "div", 22, 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](26, MailTuyenDungComponent_app_list_grid_angular_26_Template, 1, 3, "app-list-grid-angular", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](27, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](28, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](30, "p-paginator", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onPageChange", function MailTuyenDungComponent_Template_p_paginator_onPageChange_30_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](31, "p-dialog", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("visibleChange", function MailTuyenDungComponent_Template_p_dialog_visibleChange_31_listener($event) { return ctx.displaySetting = $event; })("onHide", function MailTuyenDungComponent_Template_p_dialog_onHide_31_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](32, MailTuyenDungComponent_app_config_grid_table_form_32_Template, 1, 2, "app-config-grid-table-form", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](21, _c0, ctx.MENUACTIONROLEAPI.GetRecruitMailPage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](25, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](24, _c1)));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](27, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_19__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_10__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_20__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.Dialog, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtYWlsLXR1eWVuLWR1bmcuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 82063:
/*!***************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/nghi-viec/nghi-viec.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NghiViecComponent": () => (/* binding */ NghiViecComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);





























function NghiViecComponent_app_list_grid_angular_24_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-list-grid-angular", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("showConfig", function NghiViecComponent_app_list_grid_angular_24_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r5.cauhinh(); })("callback", function NghiViecComponent_app_list_grid_angular_24_Template_app_list_grid_angular_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r6); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r7.rowSelected($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("rowSelection", "multiple")("columnDefs", ctx_r1.columnDefs);
} }
function NghiViecComponent_app_config_grid_table_form_30_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-config-grid-table-form", 32);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r2.gridKey);
} }
function NghiViecComponent_ng_template_33_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "label", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](6, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](7, "span", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "p-button", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function NghiViecComponent_ng_template_33_Template_p_button_click_8_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r8.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "p-button", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function NghiViecComponent_ng_template_33_Template_p_button_click_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r9); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r10.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function (a0) { return { "active": a0 }; };
const _c2 = function () { return { showAll: "ALL" }; };
const _c3 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c4 = function () { return { width: "50vw" }; };
const _c5 = function () { return { width: "700px" }; };
const MAX_SIZE = 100000000;
class NghiViecComponent {
    constructor(apiService, route, confirmationService, messageService, spinner, changeDetector, organizeInfoService, router) {
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.listsData = [];
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS;
        this.organs = [];
        this.organizeList = [];
        this.detailOrganizeMap = null;
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.isHrDiagram = false;
        this.query = {
            filter: '',
            reason_id: null,
            orgId: null,
            offSet: 0,
            pageSize: 15,
            status: -1,
            organizeIds: '',
        };
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.loading = false;
        this.loadjs = 0;
        this.heightGrid = 0;
        this.displaySetting = false;
        this.gridKey = '';
        this.listDataSelect = [];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_2__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_4__.AvatarFullComponent,
        };
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cancel() {
        this.query = {
            filter: '',
            reason_id: null,
            orgId: null,
            offSet: 0,
            pageSize: 15,
            status: -1,
            organizeIds: this.query.organizeIds
        };
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows === 4 ? 100000000 : event.rows;
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.employeeGetTerminatePage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            if (this.query.pageSize === MAX_SIZE) {
                this.query.pageSize = this.countRecord.totalRecord;
            }
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
        // buttons: [
        //   {
        //     onClick: this.tuyenDungLai.bind(this),
        //     label: 'Tuyển dụng lại',
        //     icon: 'fa fa-eye',
        //     class: 'btn-primary mr5',
        //     hide: CheckHideAction(MENUACTIONROLEAPI.GetTerminatePage.url, ACTIONS.TUYEN_DUNG_LAI)
        //   },
        // ]
        };
    }
    tuyenDungLai() {
        if (this.listDataSelect.length > 0) {
            let userIds = String(this.listDataSelect);
            const params = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ UserId: userIds });
            this.confirmationService.confirm({
                message: 'Bạn có chắc chắn muốn tuyển dụng lại?',
                accept: () => {
                    this.apiService.recruitAgain(params).subscribe((results) => {
                        if (results.status === 'success') {
                            this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                            this.spinner.hide();
                        }
                        else {
                            this.messageService.add({
                                severity: 'error', summary: 'Thông báo',
                                detail: results.message
                            });
                            this.spinner.hide();
                        }
                    }), error => {
                        console.error('Error:', error);
                        this.spinner.hide();
                    };
                }
            });
        }
    }
    initGrid() {
        this.columnDefs = [
            {
                field: '',
                checkboxSelection: true,
                showDisabledCheckboxes: true,
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng' },
            { label: 'Tuyển dụng lại' },
        ];
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
            }
        });
        this.getOrgan();
    }
    hrDiagram() {
        this.selectedNode = null;
        this.listAgencyMap = [];
        this.getAgencyOrganizeMap(true);
    }
    selected(datas = [], orgId = '') {
        datas.forEach(d => {
            if (d.orgId == orgId) {
                this.selectedNode = d;
                this.detailOrganizeMap = d;
            }
            else {
                if (d.children.length > 0)
                    this.selected(d.children, this.selectedNode.orgId);
            }
        });
    }
    expanded(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                d.expanded = true;
            }
            else {
                if (d.children.length > 0)
                    this.expanded(d.children, this.selectedNode.parentId);
            }
            d.children.forEach((elm) => {
                elm.children.forEach((e) => {
                    if (e.expanded === true) {
                        elm.expanded = true;
                    }
                });
            });
        });
        return datas;
    }
    getOrgan() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.organs = results.data.map(d => {
                    return {
                        label: d.organizationName,
                        value: `${d.organizeId}`
                    };
                });
                this.organs = [...this.organs];
            }
        });
    }
    getAgencyOrganizeMap(type = false) {
        this.apiService.getAgencyOrganizeMap().subscribe(results => {
            if (results.status === 'success') {
                this.listAgencyMap = [...results.data.root];
                if (localStorage.getItem("organize") === null || localStorage.getItem("organize") === 'undefined') {
                    this.selectedNode = this.listAgencyMap[0];
                    localStorage.setItem('organize', JSON.stringify(this.listAgencyMap[0]));
                    // this.query.organizeId = this.selectedNode.orgId;
                    this.load();
                }
                else {
                    this.selectedNode = JSON.parse(localStorage.getItem("organize"));
                    // this.query.organizeId = this.selectedNode?.orgId;
                    this.listAgencyMap = this.expanded(this.listAgencyMap, this.selectedNode.parentId);
                    this.selected(this.listAgencyMap, this.query.orgId);
                    if (type) {
                        this.isHrDiagram = true;
                    }
                    this.load();
                }
            }
        });
    }
    rowSelected(data) {
        this.listDataSelect = [];
        data.forEach(element => {
            this.listDataSelect.push(element.CustId);
        });
    }
}
NghiViecComponent.ɵfac = function NghiViecComponent_Factory(t) { return new (t || NghiViecComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_16__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.Router)); };
NghiViecComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({ type: NghiViecComponent, selectors: [["app-nghi-viec"]], decls: 34, vars: 34, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom", "middle"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "gap12", "col-9", "pd-0", "end"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "V\u1ECB tr\u00ED, chuy\u1EC3n m\u00F4n ...", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], [1, "d-flex", "align-items-center", "gap-16"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "height-56 btn-active-on-off", 3, "CheckHideActions", "ngClass", "click"], ["width", "14", "height", "20", "viewBox", "0 0 14 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M0.333008 18.333C0.333008 18.7932 0.706104 19.1663 1.16634 19.1663H12.833C13.2932 19.1663 13.6663 18.7932 13.6663 18.333V1.66634C13.6663 1.2061 13.2932 0.833008 12.833 0.833008H1.16634C0.706104 0.833008 0.333008 1.2061 0.333008 1.66634V18.333ZM1.99967 2.49967H11.9997V17.4997H1.99967V2.49967Z", "fill", "#F6FBFF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M4.49982 15.3097C4.49982 14.9083 4.82181 14.583 5.219 14.583H8.78064C9.17783 14.583 9.49982 14.9083 9.49982 15.3097C9.49982 15.711 9.17783 16.0364 8.78064 16.0364H5.219C4.82181 16.0364 4.49982 15.711 4.49982 15.3097Z", "fill", "#F6FBFF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "rowSelection", "columnDefs", "showConfig", "callback", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [3, "listsData", "height", "rowSelection", "columnDefs", "showConfig", "callback"], [3, "typeConfig", "gridKey"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"]], template: function NghiViecComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("keydown.enter", function NghiViecComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function NghiViecComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function NghiViecComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "p-button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function NghiViecComponent_Template_p_button_click_13_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](14, "svg", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](15, "path", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](16, "p-button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function NghiViecComponent_Template_p_button_click_16_listener() { return ctx.tuyenDungLai(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "svg", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](20, "\u00A0\u00A0 Tuy\u1EC3n d\u1EE5ng l\u1EA1i ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](21, "section", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](22, "div", 21, 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](24, NghiViecComponent_app_list_grid_angular_24_Template, 1, 4, "app-list-grid-angular", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](25, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](26, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](27);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](28, "p-paginator", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onPageChange", function NghiViecComponent_Template_p_paginator_onPageChange_28_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](29, "p-dialog", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("visibleChange", function NghiViecComponent_Template_p_dialog_visibleChange_29_listener($event) { return ctx.displaySetting = $event; })("onHide", function NghiViecComponent_Template_p_dialog_onHide_29_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](30, NghiViecComponent_app_config_grid_table_form_30_Template, 1, 2, "app-config-grid-table-form", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](31, "p-overlayPanel", 28, 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](33, NghiViecComponent_ng_template_33_Template, 10, 0, "ng-template", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](24, _c0, ctx.MENUACTIONROLEAPI.GetTerminatePage2.url, ctx.ACTIONS.TUYEN_DUNG_LAI))("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](27, _c1, ctx.listDataSelect.length > 0));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](30, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](29, _c2)));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](32, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](33, _c5));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_19__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_10__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_20__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.Dialog, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_22__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_15__.PrimeTemplate, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJuZ2hpLXZpZWMuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 84203:
/*!****************************************************************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/ns-cau-hinh/nguon-tuyen-dung/chi-tiet-nguon-tuyen-dung/chi-tiet-nguon-tuyen-dung.component.ts ***!
  \****************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietNguonTuyenDungComponent": () => (/* binding */ ChiTietNguonTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var src_app_utils_common_function_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/utils/common/function-common */ 79619);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../common/edit-detail/edit-detail.component */ 58638);




















function ChiTietNguonTuyenDungComponent_app_edit_detail_1_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-edit-detail", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("callback", function ChiTietNguonTuyenDungComponent_app_edit_detail_1_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return ctx_r1.handleSave($event); })("callbackcancel", function ChiTietNguonTuyenDungComponent_app_edit_detail_1_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return ctx_r3.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
class ChiTietNguonTuyenDungComponent {
    constructor(activatedRoute, apiService, spinner, messageService, organizeInfoService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS.EDIT_TINH_LUONG_THANH_PHAN_LUONG) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.titlePage = '';
        this.organIdSelected = '';
        this.idForm = null;
        this.detailOut = new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subject();
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.organIdSelected = results;
                this.getDetail();
            }
        });
    }
    getDetail() {
        this.listViews = [];
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ sourceId: this.idForm });
        this.apiService.getRecruitSourceInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(listViews);
                this.listViews = (0,src_app_utils_common_function_common__WEBPACK_IMPORTED_MODULE_6__.setOrganizeId)(this.listViews, 'organizeid', this.organIdSelected);
                this.detailInfo = results.data;
            }
        });
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getDetail();
        }
        else {
            this.detailOut.emit();
        }
    }
    handleSave(event) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: event });
        this.apiService.setRecruitSourceInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.detailOut.emit();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
}
ChiTietNguonTuyenDungComponent.ɵfac = function ChiTietNguonTuyenDungComponent_Factory(t) { return new (t || ChiTietNguonTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_12__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_13__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_5__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.Router)); };
ChiTietNguonTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({ type: ChiTietNguonTuyenDungComponent, selectors: [["app-chi-tiet-nguon-tuyen-dung"]], inputs: { idForm: "idForm" }, outputs: { detailOut: "detailOut" }, decls: 2, vars: 1, consts: [[1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function ChiTietNguonTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](1, ChiTietNguonTuyenDungComponent_app_edit_detail_1_Template, 1, 4, "app-edit-detail", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_7__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC1uZ3Vvbi10dXllbi1kdW5nLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 27074:
/*!*****************************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/ns-cau-hinh/nguon-tuyen-dung/nguon-tuyen-dung.component.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NguonTuyenDungComponent": () => (/* binding */ NguonTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);























function NguonTuyenDungComponent_app_list_grid_angular_12_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "app-list-grid-angular", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("showConfig", function NguonTuyenDungComponent_app_list_grid_angular_12_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return ctx_r2.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("height", ctx_r0.heightGrid)("columnDefs", ctx_r0.columnDefs)("rowSelection", "multiple")("listsData", ctx_r0.listsData)("height", ctx_r0.heightGrid);
} }
function NguonTuyenDungComponent_app_config_grid_table_form_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-config-grid-table-form", 18);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r1.gridKey);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "50vw" }; };
class NguonTuyenDungComponent {
    constructor(apiService, spinner, confirmationService, messageService, fileService, organizeInfoService, changeDetector) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.organizeInfoService = organizeInfoService;
        this.changeDetector = changeDetector;
        this.idOutPut = new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter();
        this.pagingComponent = {
            total: 0
        };
        this.projects = [];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.listsData = null;
        this.totalRecord = 0;
        this.first = 0;
        this.gridKey = '';
        this.displaySetting = false;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.query = {
            organizeId: '',
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.loadjs = 0;
        this.heightGrid = 300;
    }
    cancel() {
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeId: this.query.organizeIds,
            organizeIds: this.query.organizeIds
        };
        this.load();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getRecruitSourcePage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editRow.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    // hide: CheckHideAction(MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, ACTIONS.VIEW_TINH_LUONG_THANH_PHAN_LUONG)
                },
                {
                    onClick: this.deleteRow.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    // hide: CheckHideAction(MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, ACTIONS.DELETE_TINH_LUONG_THANH_PHAN_LUONG)
                },
            ]
        };
    }
    editRow(event) {
        this.idOutPut.emit(event);
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    deleteRow(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa?',
            accept: () => {
                const query = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ sourceId: event.rowData.source_Id });
                this.apiService.delRecruitSourceInfo(query).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeId = results;
                this.query.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng' },
            { label: 'Nguồn tuyển dụng' },
        ];
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 75;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cauhinh() {
        this.displaySetting = true;
    }
}
NguonTuyenDungComponent.ɵfac = function NguonTuyenDungComponent_Factory(t) { return new (t || NguonTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef)); };
NguonTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: NguonTuyenDungComponent, selectors: [["app-nguon-tuyen-dung"]], outputs: { idOutPut: "idOutPut" }, decls: 19, vars: 23, consts: [[1, "bread-filter", "d-flex", "end", "bottom"], [1, "d-flex", "end", "middle", "gap-16"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], [1, "pt-0", "pb-0"], [3, "height", "columnDefs", "rowSelection", "listsData", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "height", "columnDefs", "rowSelection", "listsData", "showConfig"], [3, "typeConfig", "gridKey"]], template: function NguonTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "input", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("keydown.enter", function NguonTuyenDungComponent_Template_input_keydown_enter_4_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function NguonTuyenDungComponent_Template_input_ngModelChange_4_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function NguonTuyenDungComponent_Template_span_click_5_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "svg", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](7, "path", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function NguonTuyenDungComponent_Template_p_button_click_8_listener() { ctx.query.offSet = 0; ctx.query.filter = ""; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "svg", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](10, "path", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](11, "section", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](12, NguonTuyenDungComponent_app_list_grid_angular_12_Template, 1, 5, "app-list-grid-angular", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](13, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](14, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](16, "p-paginator", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("onPageChange", function NguonTuyenDungComponent_Template_p_paginator_onPageChange_16_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](17, "p-dialog", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("visibleChange", function NguonTuyenDungComponent_Template_p_dialog_visibleChange_17_listener($event) { return ctx.displaySetting = $event; })("onHide", function NguonTuyenDungComponent_Template_p_dialog_onHide_17_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](18, NguonTuyenDungComponent_app_config_grid_table_form_18_Template, 1, 2, "app-config-grid-table-form", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction1"](20, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](19, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](22, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_14__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_15__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_16__.Dialog, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJuZ3Vvbi10dXllbi1kdW5nLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 34918:
/*!*************************************************************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/ns-cau-hinh/ns-cau-hinh-mail/chi-tiet-cau-hinh-mail/chi-tiet-ns-cau-hinh-mail.component.ts ***!
  \*************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NsChiTietCauHinhMailComponent": () => (/* binding */ NsChiTietCauHinhMailComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var src_app_utils_common_function_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/utils/common/function-common */ 79619);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/tooltip */ 39243);





















function NsChiTietCauHinhMailComponent_app_edit_detail_4_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-edit-detail", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("callback", function NsChiTietCauHinhMailComponent_app_edit_detail_4_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return ctx_r2.handleSave($event); })("callback1", function NsChiTietCauHinhMailComponent_app_edit_detail_4_Template_app_edit_detail_callback1_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r3); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return ctx_r4.getChipsValue($event); })("callbackcancel", function NsChiTietCauHinhMailComponent_app_edit_detail_4_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r3); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return ctx_r5.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
function NsChiTietCauHinhMailComponent_ul_7_li_1_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "span", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function NsChiTietCauHinhMailComponent_ul_7_li_1_Template_span_click_1_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r9); const config_r7 = restoredCtx.$implicit; const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2); return ctx_r8.getTextConfig(config_r7); });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3, "[");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](6, "]");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const config_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"]("", config_r7, " ");
} }
function NsChiTietCauHinhMailComponent_ul_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ul", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](1, NsChiTietCauHinhMailComponent_ul_7_li_1_Template, 7, 1, "li", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx_r1.configData);
} }
class NsChiTietCauHinhMailComponent {
    constructor(activatedRoute, apiService, spinner, messageService, organizeInfoService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS.EDIT_TINH_LUONG_THIET_LAP_THAM_SO) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.titlePage = '';
        this.configData = [];
        this.organIdSelected = '';
        this.idForm = null;
        this.detailOut = new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subject();
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.organIdSelected = results;
                this.getDetail();
            }
        });
    }
    getDetail() {
        this.listViews = [];
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ mail_Id: this.idForm });
        this.apiService.getRecruitMailInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(listViews);
                this.detailInfo = results.data;
                this.getConfigData();
                this.listViews = (0,src_app_utils_common_function_common__WEBPACK_IMPORTED_MODULE_6__.setOrganizeId)(this.listViews, 'organizeId', this.organIdSelected);
            }
        });
    }
    getConfigData() {
        if (this.listViews && this.listViews.length > 0) {
            this.listViews.forEach(field => {
                field.fields.forEach(element => {
                    if (element.field_name === 'info_field') {
                        if (element.columnValue) {
                            this.configData = element.columnValue.split(',');
                        }
                    }
                });
            });
        }
    }
    getChipsValue(event) {
        this.configData = event;
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getDetail();
        }
        else {
            this.detailOut.emit();
        }
    }
    handleSave(event) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: event });
        this.apiService.setRecruitMailInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.detailOut.emit();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
    getTextConfig(text) {
        navigator.clipboard.writeText('[' + text + ']').then(d => {
            this.messageService.add({ key: 'bc', severity: 'success', summary: 'Thông báo', detail: 'Đã copy' });
        }, function (err) {
            console.error('Async: Could not copy text: ', err);
        });
    }
}
NsChiTietCauHinhMailComponent.ɵfac = function NsChiTietCauHinhMailComponent_Factory(t) { return new (t || NsChiTietCauHinhMailComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_12__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_13__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_5__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.Router)); };
NsChiTietCauHinhMailComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({ type: NsChiTietCauHinhMailComponent, selectors: [["app-chi-tiet-ns-cau-hinh-mail"]], inputs: { idForm: "idForm" }, outputs: { detailOut: "detailOut" }, decls: 8, vars: 2, consts: [[1, "main-grid", "product-detail"], [1, "content"], [1, "grid"], [1, "col-10"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callback1", "callbackcancel", 4, "ngIf"], [1, "col-2"], [1, "sidebar-config"], ["class", "d-flex wrap configs gap-16", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callback1", "callbackcancel"], [1, "d-flex", "wrap", "configs", "gap-16"], [4, "ngFor", "ngForOf"], ["pTooltip", "Copy", "tooltipPosition", "top", 3, "click"], [2, "color", "#4C97E4"]], template: function NsChiTietCauHinhMailComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](4, NsChiTietCauHinhMailComponent_app_edit_detail_4_Template, 1, 4, "app-edit-detail", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](7, NsChiTietCauHinhMailComponent_ul_7_Template, 2, 1, "ul", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.configData);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_7__.EditDetailComponent, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgForOf, primeng_tooltip__WEBPACK_IMPORTED_MODULE_15__.Tooltip], styles: ["[_nghost-%COMP%]  .p-chips-token {\n  cursor: pointer;\n}\n\n.sidebar-config[_ngcontent-%COMP%] {\n  background: #fbfbfb;\n  padding: 15px;\n  border: 1px solid #ebebeb;\n  border-radius: 2px;\n  height: 100%;\n}\n\n.sidebar-config[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin-top: 0px;\n}\n\n.sidebar-config[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  cursor: pointer;\n  font-size: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoaS10aWV0LW5zLWNhdS1oaW5oLW1haWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxlQUFBO0FBQVI7O0FBR0E7RUFDSSxtQkFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQUFKOztBQUNJO0VBQ0ksZUFBQTtBQUNSOztBQUdZO0VBQ0ksZUFBQTtFQUNBLGVBQUE7QUFEaEIiLCJmaWxlIjoiY2hpLXRpZXQtbnMtY2F1LWhpbmgtbWFpbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0OjpuZy1kZWVwe1xyXG4gICAgLnAtY2hpcHMtdG9rZW57XHJcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgfVxyXG59XHJcbi5zaWRlYmFyLWNvbmZpZ3tcclxuICAgIGJhY2tncm91bmQ6ICNmYmZiZmI7XHJcbiAgICBwYWRkaW5nOiAxNXB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2ViZWJlYjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDJweDtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGgze1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDBweDtcclxuICAgIH1cclxuICAgIHVse1xyXG4gICAgICAgIGxpe1xyXG4gICAgICAgICAgICBzcGFue1xyXG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */"] });


/***/ }),

/***/ 4985:
/*!*****************************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/ns-cau-hinh/ns-cau-hinh-mail/ns-cau-hinh-mail.component.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NsCauHinhMailComponent": () => (/* binding */ NsCauHinhMailComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);

























function NsCauHinhMailComponent_app_list_grid_angular_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-list-grid-angular", 21);
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("height", ctx_r0.heightGrid)("columnDefs", ctx_r0.columnDefs)("rowSelection", "multiple")("listsData", ctx_r0.listsData)("height", ctx_r0.heightGrid);
} }
function NsCauHinhMailComponent_app_config_grid_table_form_23_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-config-grid-table-form", 22);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r1.gridKey);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "50vw" }; };
class NsCauHinhMailComponent {
    constructor(apiService, spinner, route, confirmationService, messageService, fileService, changeDetector, organizeInfoService, router) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.idOutPut = new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter();
        this.pagingComponent = {
            total: 0
        };
        this.gridKey = '';
        this.displaySetting = false;
        this.projects = [];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.listsData = null;
        this.totalRecord = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.modelTM = {};
        this.itemsToolOfGrid = [];
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS;
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.employeeStatus = [];
        this.loadjs = 0;
        this.heightGrid = 300;
    }
    cancel() {
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds
        };
        this.load();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getRecruitMailPage(queryParams).subscribe((results) => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
            this.listsData = (_b = (_a = results === null || results === void 0 ? void 0 : results.data) === null || _a === void 0 ? void 0 : _a.dataList) === null || _b === void 0 ? void 0 : _b.data;
            this.gridKey = (_d = (_c = results === null || results === void 0 ? void 0 : results.data) === null || _c === void 0 ? void 0 : _c.dataList) === null || _d === void 0 ? void 0 : _d.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = (_f = (_e = results === null || results === void 0 ? void 0 : results.data) === null || _e === void 0 ? void 0 : _e.dataList) === null || _f === void 0 ? void 0 : _f.recordsTotal;
            this.countRecord.totalRecord = (_h = (_g = results === null || results === void 0 ? void 0 : results.data) === null || _g === void 0 ? void 0 : _g.dataList) === null || _h === void 0 ? void 0 : _h.recordsTotal;
            this.countRecord.currentRecordStart = ((_k = (_j = results === null || results === void 0 ? void 0 : results.data) === null || _j === void 0 ? void 0 : _j.dataList) === null || _k === void 0 ? void 0 : _k.recordsTotal) === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = (_m = (_l = results === null || results === void 0 ? void 0 : results.data) === null || _l === void 0 ? void 0 : _l.dataList) === null || _m === void 0 ? void 0 : _m.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editRow.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'pi pi-tablet',
                    class: 'btn-primary mr5',
                },
                {
                    onClick: this.deleteRow.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                },
            ]
        };
    }
    editRow(event) {
        this.idOutPut.emit(event);
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    deleteRow(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa?',
            accept: () => {
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ mail_Id: event.rowData.mail_Id });
                this.apiService.delRecruitMailInfo(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng' },
            { label: 'Cấu hình' },
        ];
        this.getEmployeeStatus();
    }
    getEmployeeStatus() {
        this.apiService.getEmployeeStatus().subscribe(results => {
            if (results.status === 'success') {
                this.employeeStatus = [];
                results.data.forEach(s => {
                    if (s.value != "3") {
                        this.employeeStatus.push({
                            label: s.name,
                            value: s.value
                        });
                    }
                });
                this.employeeStatus = [{ label: '---Chọn mã chỉ tiêu---', value: -1 }, ...this.employeeStatus];
            }
        });
    }
    exportExel() {
        this.spinner.show();
        this.query.pageSize = 1000000;
        const query = Object.assign({}, this.query);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query);
        this.apiService.getEmployeePage(queryParams).subscribe((results) => {
            const dataExport = [];
            let gridflexs = results.data.gridflexs;
            let arrKey = gridflexs.map(elementName => elementName.columnField);
            let dataList = results.data.dataList.data;
            for (let elementValue of dataList) {
                const data = {};
                for (let elementName of gridflexs) {
                    if (arrKey.indexOf(elementName.columnField) > -1 && !elementName.isHide && elementName.columnField !== 'statusName') {
                        let valueColumn = elementValue[elementName.columnField];
                        if (elementName.columnField == 'status_name' || elementName.columnField == 'isContacted' || elementName.columnField == 'isProfileFull' || elementName.columnField == 'lockName') {
                            valueColumn = this.replaceHtmlToText(valueColumn);
                        }
                        data[elementName.columnCaption] = valueColumn || '';
                    }
                }
                dataExport.push(data);
            }
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách hồ sơ nhân sự ' + new Date());
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 75;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cauhinh() {
        this.displaySetting = true;
    }
}
NsCauHinhMailComponent.ɵfac = function NsCauHinhMailComponent_Factory(t) { return new (t || NsCauHinhMailComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_12__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_12__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.Router)); };
NsCauHinhMailComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: NsCauHinhMailComponent, selectors: [["app-ns-cau-hinh-mail"]], outputs: { idOutPut: "idOutPut" }, decls: 24, vars: 23, consts: [[1, "bread-filter", "d-flex", "end", "bottom"], [1, "d-flex", "end", "bottom", "gap-16"], [1, "d-flex", "end", "middle", "gap-16"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "20", "height", "17", "viewBox", "0 0 20 17", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M19.5 17V0H0.50855L0.5 17H19.5ZM6.675 15.3187H2.21V6.81868H6.675V15.3187ZM8.575 15.3187V6.81868H17.79V15.3187H8.575ZM2.21 1.68132V5.13736H17.79V1.68132H2.21Z", "fill", "#F3F8FF"], [1, "pb-0", "pt-0"], [3, "height", "columnDefs", "rowSelection", "listsData", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "height", "columnDefs", "rowSelection", "listsData"], [3, "typeConfig", "gridKey"]], template: function NsCauHinhMailComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "input", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("keydown.enter", function NsCauHinhMailComponent_Template_input_keydown_enter_5_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function NsCauHinhMailComponent_Template_input_ngModelChange_5_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function NsCauHinhMailComponent_Template_span_click_6_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](7, "svg", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](8, "path", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "p-button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function NsCauHinhMailComponent_Template_p_button_click_9_listener() { ctx.query.offSet = 0; ctx.query.filter = ""; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function NsCauHinhMailComponent_Template_p_button_click_12_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](15, " \u00A0 C\u1EA5u h\u00ECnh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](16, "section", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](17, NsCauHinhMailComponent_app_list_grid_angular_17_Template, 1, 5, "app-list-grid-angular", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](18, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](19, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](21, "p-paginator", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("onPageChange", function NsCauHinhMailComponent_Template_p_paginator_onPageChange_21_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](22, "p-dialog", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("visibleChange", function NsCauHinhMailComponent_Template_p_dialog_visibleChange_22_listener($event) { return ctx.displaySetting = $event; })("onHide", function NsCauHinhMailComponent_Template_p_dialog_onHide_22_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](23, NsCauHinhMailComponent_app_config_grid_table_form_23_Template, 1, 2, "app-config-grid-table-form", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction1"](20, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](19, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](22, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_15__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_16__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_17__.Dialog, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJucy1jYXUtaGluaC1tYWlsLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 12413:
/*!*******************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/ns-cau-hinh/ns-cau-hinh.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NsCauHinhComponent": () => (/* binding */ NsCauHinhComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _vong_tuyen_dung_vong_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/vong-tuyen-dung/vong-tuyen-dung.component */ 92488);
/* harmony import */ var _ns_cau_hinh_mail_ns_cau_hinh_mail_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/ns-cau-hinh-mail/ns-cau-hinh-mail.component */ 4985);
/* harmony import */ var _nguon_tuyen_dung_nguon_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/nguon-tuyen-dung/nguon-tuyen-dung.component */ 27074);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_cau_hinh_ns_cau_hinh_mail_chi_tiet_cau_hinh_mail_chi_tiet_ns_cau_hinh_mail_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/ns-cau-hinh-mail/chi-tiet-cau-hinh-mail/chi-tiet-ns-cau-hinh-mail.component */ 34918);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_cau_hinh_vong_tuyen_dung_chi_tiet_vong_tuyen_dung_chi_tiet_vong_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/vong-tuyen-dung/chi-tiet-vong-tuyen-dung/chi-tiet-vong-tuyen-dung.component */ 28885);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_cau_hinh_nguon_tuyen_dung_chi_tiet_nguon_tuyen_dung_chi_tiet_nguon_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/nguon-tuyen-dung/chi-tiet-nguon-tuyen-dung/chi-tiet-nguon-tuyen-dung.component */ 84203);
































const _c0 = ["nsCauHinhMail"];
const _c1 = ["vongTuyenDung"];
const _c2 = ["nguonTuyenDung"];
function NsCauHinhComponent_app_ns_cau_hinh_mail_12_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-ns-cau-hinh-mail", 16, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("idOutPut", function NsCauHinhComponent_app_ns_cau_hinh_mail_12_Template_app_ns_cau_hinh_mail_idOutPut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r7.editEvent($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} }
function NsCauHinhComponent_app_vong_tuyen_dung_14_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-vong-tuyen-dung", 16, 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("idOutPut", function NsCauHinhComponent_app_vong_tuyen_dung_14_Template_app_vong_tuyen_dung_idOutPut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r11); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r10.editEvent($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} }
function NsCauHinhComponent_app_nguon_tuyen_dung_16_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-nguon-tuyen-dung", 16, 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("idOutPut", function NsCauHinhComponent_app_nguon_tuyen_dung_16_Template_app_nguon_tuyen_dung_idOutPut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r14); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r13.editEvent($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} }
function NsCauHinhComponent_app_chi_tiet_ns_cau_hinh_mail_18_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-chi-tiet-ns-cau-hinh-mail", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("detailOut", function NsCauHinhComponent_app_chi_tiet_ns_cau_hinh_mail_18_Template_app_chi_tiet_ns_cau_hinh_mail_detailOut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r15.theEventDetail($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("idForm", ctx_r3.idForm);
} }
function NsCauHinhComponent_app_chi_tiet_vong_tuyen_dung_19_Template(rf, ctx) { if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-chi-tiet-vong-tuyen-dung", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("detailOut", function NsCauHinhComponent_app_chi_tiet_vong_tuyen_dung_19_Template_app_chi_tiet_vong_tuyen_dung_detailOut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r18); const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r17.theEventDetail($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("idForm", ctx_r4.idForm);
} }
function NsCauHinhComponent_app_chi_tiet_nguon_tuyen_dung_20_Template(rf, ctx) { if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-chi-tiet-nguon-tuyen-dung", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("detailOut", function NsCauHinhComponent_app_chi_tiet_nguon_tuyen_dung_20_Template_app_chi_tiet_nguon_tuyen_dung_detailOut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r20); const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r19.theEventDetail($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("idForm", ctx_r5.idForm);
} }
const _c3 = function (a0) { return { width: a0 }; };
class NsCauHinhComponent {
    constructor(apiService, spinner, route, confirmationService, messageService, fileService, changeDetector, organizeInfoService, router) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.tabsItem = [];
        this.pagingComponent = {
            total: 0
        };
        this.items = [];
        this.organs = [];
        this.itemsToolOfGrid = [];
        this.titleAddnew = '';
        this.listViews = [];
        this.detailInfo = [];
        this.isFormDetail = false;
        this.idForm = null;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_14__.Subject();
        this.displayOrganize = false;
        this.displayButton = false;
        this.detailOrganizeMap = null;
        this.isHrDiagram = false;
        this.displaySetting = false;
        this.gridKey = '';
        this.tabIndex = 0;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS;
        this.isAddNewButton = false;
        this.isNew = false;
        this.popupWidth = 1800;
        this.loadjs = 0;
        this.heightGrid = 0;
    }
    cauhinh() {
        this.displaySetting = true;
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe(({}));
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng' },
            { label: 'Cấu hình' },
        ];
        this.itemsToolOfGrid = [
            {
                label: 'Export file',
                code: 'Import',
                icon: 'pi pi-download',
                disabled: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS.IMPORT),
                command: () => {
                    // this.exportExel();
                }
            },
        ];
    }
    editEvent(event) {
        let id = null;
        if (this.tabIndex === 0) {
            this.idForm = event.rowData.mail_Id;
        }
        else if (this.tabIndex === 1) {
            this.idForm = event.rowData.Id;
        }
        else if (this.tabIndex === 2) {
            this.idForm = event.rowData.source_Id;
        }
        this.isFormDetail = true;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ recordId: event.rowData.id });
        // this.apiService.getPayrollAppInfo(queryParams).subscribe(results => {
        //   if (results.status === 'success') {
        //     this.listViews = cloneDeep(results.data.group_fields);
        //     this.detailInfo = results.data;
        //   }
        // })
    }
    addNew() {
        if (this.tabIndex === 0) {
            this.isFormDetail = true;
            this.idForm = null;
        }
        else if (this.tabIndex === 1) {
            this.popupWidth = 1200;
            this.isFormDetail = true;
            this.idForm = null;
        }
        else if (this.tabIndex === 2) {
            this.popupWidth = 1200;
            this.isFormDetail = true;
            this.idForm = null;
        }
    }
    checkTitleAddNew() {
        if (this.tabIndex === 0) {
            this.titleAddnew = 'Cấu hình mail';
            this.items[this.items.length - 1] = 'Cấu hình mail';
            this.popupWidth = 1800;
        }
        else if (this.tabIndex === 1) {
            this.titleAddnew = 'Vòng tuyển dụng';
            this.items[this.items.length - 1] = 'Vòng tuyển dụng';
            this.popupWidth = 1200;
        }
        else if (this.tabIndex === 2) {
            this.titleAddnew = 'Nguồn tuyển dụng';
            this.items[this.items.length - 1] = 'Nguồn tuyển dụng';
            this.popupWidth = 1200;
        }
    }
    Back() {
        this.router.navigate(['/page-agency']);
    }
    Close() {
        this.displayOrganize = false;
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    ngAfterViewChecked() {
        // const a: any = document.querySelector(".header");
        // const b: any = document.querySelector(".sidebarBody");
        // const c: any = document.querySelector(".bread-filter");
        // const d: any = document.querySelector(".bread-crumb");
        // const e: any = document.querySelector(".paginator");
        // this.loadjs++
        // if (this.loadjs === 5) {
        //   if (b && b.clientHeight) {
        //     const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 25;
        //     this.heightGrid = window.innerHeight - totalHeight
        //     this.changeDetector.detectChanges();
        //   } else {
        //     this.loadjs = 0;
        //   }
        // }
    }
    handleChange(e) {
        this.tabIndex = e;
        this.checkTitleAddNew();
    }
    ngOnDestroy() {
        if (this.unsubscribe$) {
            this.unsubscribe$.unsubscribe();
        }
    }
    // from detail
    theEventDetail(event) {
        this.isFormDetail = false;
        if (this.tabIndex === 0) {
            this.tabNsCauHinhMail.load();
        }
        if (this.tabIndex === 1) {
            this.tabVongTuyenDung.load();
        }
        if (this.tabIndex === 2) {
            this.tabNguonTuyenDung.load();
        }
    }
}
NsCauHinhComponent.ɵfac = function NsCauHinhComponent_Factory(t) { return new (t || NsCauHinhComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_15__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_16__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_17__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_17__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_3__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_16__.Router)); };
NsCauHinhComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({ type: NsCauHinhComponent, selectors: [["app-ns-cau-hinh"]], viewQuery: function NsCauHinhComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵviewQuery"](_c2, 5);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵloadQuery"]()) && (ctx.tabNsCauHinhMail = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵloadQuery"]()) && (ctx.tabVongTuyenDung = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵloadQuery"]()) && (ctx.tabNguonTuyenDung = _t.first);
    } }, decls: 21, vars: 19, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [3, "displayTitle", "items"], [1, "d-flex", "bet", "mid", "bottom", "gap-12"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M13.6668 8.08835H8.0886V13.6666H5.91173V8.08835H0.333496V5.91148H5.91173V0.333252H8.0886V5.91148H13.6668V8.08835Z", "fill", "#F6FBFF"], [1, "pb-0"], [3, "activeIndex", "onChange", "activeIndexChange"], ["header", "C\u1EA5u h\u00ECnh mail"], [3, "idOutPut", 4, "ngIf"], ["header", "V\u00F2ng tuy\u1EC3n d\u1EE5ng"], ["header", "Ngu\u1ED3n tuy\u1EC3n d\u1EE5ng"], [3, "header", "visible", "modal", "draggable", "resizable", "focusTrap", "visibleChange"], [3, "idForm", "detailOut", 4, "ngIf"], [3, "idOutPut"], ["nsCauHinhMail", ""], ["vongTuyenDung", ""], ["nguonTuyenDung", ""], [3, "idForm", "detailOut"]], template: function NsCauHinhComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function NsCauHinhComponent_Template_p_button_click_5_listener() { return ctx.addNew(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "svg", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](7, "path", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](8, " \u00A0 Th\u00EAm m\u01A1\u0301i ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "section", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "p-tabView", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onChange", function NsCauHinhComponent_Template_p_tabView_onChange_10_listener($event) { return ctx.handleChange($event.index); })("activeIndexChange", function NsCauHinhComponent_Template_p_tabView_activeIndexChange_10_listener($event) { return ctx.tabIndex = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](11, "p-tabPanel", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](12, NsCauHinhComponent_app_ns_cau_hinh_mail_12_Template, 2, 0, "app-ns-cau-hinh-mail", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "p-tabPanel", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](14, NsCauHinhComponent_app_vong_tuyen_dung_14_Template, 2, 0, "app-vong-tuyen-dung", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "p-tabPanel", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](16, NsCauHinhComponent_app_nguon_tuyen_dung_16_Template, 2, 0, "app-nguon-tuyen-dung", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "p-dialog", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("visibleChange", function NsCauHinhComponent_Template_p_dialog_visibleChange_17_listener($event) { return ctx.isFormDetail = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](18, NsCauHinhComponent_app_chi_tiet_ns_cau_hinh_mail_18_Template, 1, 1, "app-chi-tiet-ns-cau-hinh-mail", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](19, NsCauHinhComponent_app_chi_tiet_vong_tuyen_dung_19_Template, 1, 1, "app-chi-tiet-vong-tuyen-dung", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](20, NsCauHinhComponent_app_chi_tiet_nguon_tuyen_dung_20_Template, 1, 1, "app-chi-tiet-nguon-tuyen-dung", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("displayTitle", true)("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("activeIndex", ctx.tabIndex);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.tabIndex === 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.tabIndex === 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.tabIndex === 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](17, _c3, ctx.popupWidth + "px"));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpropertyInterpolate"]("header", ctx.titleAddnew);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("visible", ctx.isFormDetail)("modal", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.isFormDetail && ctx.tabIndex === 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.isFormDetail && ctx.tabIndex === 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.isFormDetail && ctx.tabIndex === 2);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_18__.Button, primeng_tabview__WEBPACK_IMPORTED_MODULE_19__.TabView, primeng_tabview__WEBPACK_IMPORTED_MODULE_19__.TabPanel, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgIf, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.Dialog, _ns_cau_hinh_mail_ns_cau_hinh_mail_component__WEBPACK_IMPORTED_MODULE_6__.NsCauHinhMailComponent, _vong_tuyen_dung_vong_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_5__.VongTuyenDungComponent, _nguon_tuyen_dung_nguon_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_7__.NguonTuyenDungComponent, src_app_components_ns_tuyen_dung_ns_cau_hinh_ns_cau_hinh_mail_chi_tiet_cau_hinh_mail_chi_tiet_ns_cau_hinh_mail_component__WEBPACK_IMPORTED_MODULE_10__.NsChiTietCauHinhMailComponent, src_app_components_ns_tuyen_dung_ns_cau_hinh_vong_tuyen_dung_chi_tiet_vong_tuyen_dung_chi_tiet_vong_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_11__.ChiTietVongTuyenDungComponent, src_app_components_ns_tuyen_dung_ns_cau_hinh_nguon_tuyen_dung_chi_tiet_nguon_tuyen_dung_chi_tiet_nguon_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_12__.ChiTietNguonTuyenDungComponent], styles: [".select-default[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  text-align: left;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .p-person {\n  padding: 0;\n  border: 0 none;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-header, [_nghost-%COMP%]     .p-organizationchart .node-content {\n  padding: 0.5em 0.7rem;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-header {\n  background-color: #495ebb;\n  color: #ffffff;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-content {\n  text-align: center;\n  border: 1px solid #495ebb;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-content img {\n  border-radius: 50%;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .department-cfo {\n  background-color: #7247bc;\n  color: #ffffff;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .department-coo {\n  background-color: #a534b6;\n  color: #ffffff;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .department-cto {\n  background-color: #e9286f;\n  color: #ffffff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5zLWNhdS1oaW5oLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7QUFDSjs7QUFFSTtFQUNJLFVBQUE7RUFDQSxjQUFBO0FBQ1I7O0FBRUk7RUFDSSxxQkFBQTtBQUFSOztBQUdJO0VBQ0kseUJBQUE7RUFDQSxjQUFBO0FBRFI7O0FBSUk7RUFDSSxrQkFBQTtFQUNBLHlCQUFBO0FBRlI7O0FBS0k7RUFDSSxrQkFBQTtBQUhSOztBQU1JO0VBQ0kseUJBQUE7RUFDQSxjQUFBO0FBSlI7O0FBT0k7RUFDSSx5QkFBQTtFQUNBLGNBQUE7QUFMUjs7QUFRSTtFQUNJLHlCQUFBO0VBQ0EsY0FBQTtBQU5SIiwiZmlsZSI6Im5zLWNhdS1oaW5oLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlbGVjdC1kZWZhdWx0IGxhYmVse1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxufVxyXG46aG9zdCA6Om5nLWRlZXAgLnAtb3JnYW5pemF0aW9uY2hhcnQge1xyXG4gICAgLnAtcGVyc29uIHtcclxuICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgIGJvcmRlcjogMCBub25lO1xyXG4gICAgfVxyXG5cclxuICAgIC5ub2RlLWhlYWRlciwgLm5vZGUtY29udGVudCB7XHJcbiAgICAgICAgcGFkZGluZzogLjVlbSAuN3JlbTtcclxuICAgIH1cclxuXHJcbiAgICAubm9kZS1oZWFkZXIge1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICM0OTVlYmI7XHJcbiAgICAgICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICB9XHJcblxyXG4gICAgLm5vZGUtY29udGVudCB7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICM0OTVlYmI7XHJcbiAgICB9XHJcblxyXG4gICAgLm5vZGUtY29udGVudCBpbWcge1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIH1cclxuXHJcbiAgICAuZGVwYXJ0bWVudC1jZm8ge1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICM3MjQ3YmM7XHJcbiAgICAgICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICB9XHJcblxyXG4gICAgLmRlcGFydG1lbnQtY29vIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYTUzNGI2O1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgfVxyXG5cclxuICAgIC5kZXBhcnRtZW50LWN0byB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2U5Mjg2ZjtcclxuICAgICAgICBjb2xvcjogI2ZmZmZmZjtcclxuICAgIH1cclxufSJdfQ== */"] });


/***/ }),

/***/ 28885:
/*!*************************************************************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/ns-cau-hinh/vong-tuyen-dung/chi-tiet-vong-tuyen-dung/chi-tiet-vong-tuyen-dung.component.ts ***!
  \*************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietVongTuyenDungComponent": () => (/* binding */ ChiTietVongTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var src_app_utils_common_function_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/utils/common/function-common */ 79619);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../common/edit-detail/edit-detail.component */ 58638);




















function ChiTietVongTuyenDungComponent_app_edit_detail_1_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-edit-detail", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("callback", function ChiTietVongTuyenDungComponent_app_edit_detail_1_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return ctx_r1.handleSave($event); })("callbackcancel", function ChiTietVongTuyenDungComponent_app_edit_detail_1_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return ctx_r3.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
class ChiTietVongTuyenDungComponent {
    constructor(activatedRoute, apiService, spinner, messageService, organizeInfoService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS.EDIT_TINH_LUONG_CAP_BAC_LUONG) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.titlePage = '';
        this.organIdSelected = '';
        this.idForm = null;
        this.detailOut = new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subject();
        this.tabIndex = 0;
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.organIdSelected = results;
                this.getDetail();
            }
        });
    }
    getDetail() {
        this.listViews = [];
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ roundId: this.idForm });
        this.apiService.getRecruitRoundInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(listViews);
                this.listViews = (0,src_app_utils_common_function_common__WEBPACK_IMPORTED_MODULE_6__.setOrganizeId)(this.listViews, 'organizeId', this.organIdSelected);
                this.detailInfo = results.data;
            }
        });
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getDetail();
        }
        else {
            this.detailOut.emit();
        }
    }
    handleSave(event) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: event });
        this.apiService.setRecruitRoundInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.detailOut.emit();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
    handleChange(e) {
        this.tabIndex = e;
    }
}
ChiTietVongTuyenDungComponent.ɵfac = function ChiTietVongTuyenDungComponent_Factory(t) { return new (t || ChiTietVongTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_12__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_13__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_5__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.Router)); };
ChiTietVongTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({ type: ChiTietVongTuyenDungComponent, selectors: [["app-chi-tiet-vong-tuyen-dung"]], inputs: { idForm: "idForm" }, outputs: { detailOut: "detailOut" }, decls: 2, vars: 1, consts: [[1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function ChiTietVongTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](1, ChiTietVongTuyenDungComponent_app_edit_detail_1_Template, 1, 4, "app-edit-detail", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_7__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC12b25nLXR1eWVuLWR1bmcuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 92488:
/*!***************************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/ns-cau-hinh/vong-tuyen-dung/vong-tuyen-dung.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VongTuyenDungComponent": () => (/* binding */ VongTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);























function VongTuyenDungComponent_app_list_grid_angular_12_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "app-list-grid-angular", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("showConfig", function VongTuyenDungComponent_app_list_grid_angular_12_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return ctx_r2.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("height", ctx_r0.heightGrid)("columnDefs", ctx_r0.columnDefs)("rowSelection", "multiple")("listsData", ctx_r0.listsData)("height", ctx_r0.heightGrid);
} }
function VongTuyenDungComponent_app_config_grid_table_form_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-config-grid-table-form", 18);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r1.gridKey);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "50vw" }; };
class VongTuyenDungComponent {
    constructor(apiService, spinner, confirmationService, messageService, fileService, organizeInfoService, changeDetector) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.organizeInfoService = organizeInfoService;
        this.changeDetector = changeDetector;
        this.idOutPut = new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter();
        this.pagingComponent = {
            total: 0
        };
        this.projects = [];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.listsData = null;
        this.totalRecord = 0;
        this.first = 0;
        this.gridKey = '';
        this.displaySetting = false;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.query = {
            organizeId: '',
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.loadjs = 0;
        this.heightGrid = 300;
    }
    cancel() {
        this.query = {
            organizeId: this.query.organizeIds,
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds
        };
        this.load();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getRecruitRoundPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editRow.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'pi pi-tablet',
                    class: 'btn-primary mr5',
                    // hide: CheckHideAction(MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, ACTIONS.VIEW_TINH_LUONG_CAP_BAC_LUONG)
                },
                {
                    onClick: this.deleteRow.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    // hide: CheckHideAction(MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, ACTIONS.DELETE_TINH_LUONG_CAP_BAC_LUONG)
                },
            ]
        };
    }
    editRow(event) {
        this.idOutPut.emit(event);
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    deleteRow(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa?',
            accept: () => {
                const query = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ roundId: event.rowData.roundId });
                this.apiService.delRecruitRoundInfo(query).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.query.organizeId = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Lương - thuế' },
        ];
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 75;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cauhinh() {
        this.displaySetting = true;
    }
}
VongTuyenDungComponent.ɵfac = function VongTuyenDungComponent_Factory(t) { return new (t || VongTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef)); };
VongTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: VongTuyenDungComponent, selectors: [["app-vong-tuyen-dung"]], outputs: { idOutPut: "idOutPut" }, decls: 19, vars: 23, consts: [[1, "bread-filter", "d-flex", "end", "bottom"], [1, "d-flex", "end", "middle", "gap-16"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], [1, "pt-0", "pb-0"], [3, "height", "columnDefs", "rowSelection", "listsData", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "height", "columnDefs", "rowSelection", "listsData", "showConfig"], [3, "typeConfig", "gridKey"]], template: function VongTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "input", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("keydown.enter", function VongTuyenDungComponent_Template_input_keydown_enter_4_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function VongTuyenDungComponent_Template_input_ngModelChange_4_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function VongTuyenDungComponent_Template_span_click_5_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "svg", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](7, "path", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function VongTuyenDungComponent_Template_p_button_click_8_listener() { ctx.query.offSet = 0; ctx.query.filter = ""; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "svg", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](10, "path", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](11, "section", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](12, VongTuyenDungComponent_app_list_grid_angular_12_Template, 1, 5, "app-list-grid-angular", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](13, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](14, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](16, "p-paginator", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("onPageChange", function VongTuyenDungComponent_Template_p_paginator_onPageChange_16_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](17, "p-dialog", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("visibleChange", function VongTuyenDungComponent_Template_p_dialog_visibleChange_17_listener($event) { return ctx.displaySetting = $event; })("onHide", function VongTuyenDungComponent_Template_p_dialog_onHide_17_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](18, VongTuyenDungComponent_app_config_grid_table_form_18_Template, 1, 2, "app-config-grid-table-form", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction1"](20, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](19, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](22, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_14__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_15__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_16__.Dialog, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ2b25nLXR1eWVuLWR1bmcuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 31028:
/*!*********************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/ns-tuyen-dung.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NsTuyenDungComponent": () => (/* binding */ NsTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/common/form-filter/form-filter.component */ 83844);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/dynamicdialog */ 56427);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/radiobutton */ 95143);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);



































function NsTuyenDungComponent_app_list_grid_angular_39_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "app-list-grid-angular", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("callback", function NsTuyenDungComponent_app_list_grid_angular_39_Template_app_list_grid_angular_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r15.rowSelected($event); })("showConfig", function NsTuyenDungComponent_app_list_grid_angular_39_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r16); const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r17.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("rowSelection", "multiple")("columnDefs", ctx_r1.columnDefs);
} }
function NsTuyenDungComponent_app_config_grid_table_form_45_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "app-config-grid-table-form", 66);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r2.gridKey);
} }
function NsTuyenDungComponent_ng_template_48_div_5_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "p-radioButton", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function NsTuyenDungComponent_ng_template_48_div_5_div_1_Template_p_radioButton_ngModelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r22); const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](3); return ctx_r21.recruitmentStatusSelected = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](2, "label", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const recrui_r20 = ctx.$implicit;
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngClass", ctx_r19.canSttValue.can_st > recrui_r20.code ? "op6" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpropertyInterpolate"]("value", recrui_r20.code);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpropertyInterpolate1"]("inputId", "recrui", recrui_r20.code, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("disabled", ctx_r19.canSttValue.can_st > recrui_r20.code)("ngModel", ctx_r19.recruitmentStatusSelected);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpropertyInterpolate1"]("for", "recrui", recrui_r20.code, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](recrui_r20.label);
} }
function NsTuyenDungComponent_ng_template_48_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](1, NsTuyenDungComponent_ng_template_48_div_5_div_1_Template, 4, 7, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx_r18.recruitmentStatus);
} }
function NsTuyenDungComponent_ng_template_48_Template(rf, ctx) { if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2, "Chuy\u1EC3n v\u00F2ng tuy\u1EC3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "div", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](4, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](5, NsTuyenDungComponent_ng_template_48_div_5_Template, 2, 1, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](6, "div", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](7, "p-button", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_ng_template_48_Template_p_button_click_7_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r24); _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](47); return _r3.hide(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](8, " \u00A0 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](9, "p-button", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_ng_template_48_Template_p_button_click_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r24); const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r25.changeRecruStatus(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx_r4.recruitmentStatus.length > 0 && ctx_r4.canSttValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("disabled", ctx_r4.recruitmentStatusSelected ? false : true);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
function NsTuyenDungComponent_ng_template_56_Template(rf, ctx) { if (rf & 1) {
    const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "p-button", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_ng_template_56_Template_p_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r27); const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r26.cancelSendEmail(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2, "\u00A0 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "p-button", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_ng_template_56_Template_p_button_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r27); const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r28.sendEmail(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](4, "G\u1EEDi email");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction2"](1, _c0, ctx_r5.MENUACTIONROLEAPI.GetCandidatePage.url, ctx_r5.ACTIONS.SEND_EMAIL));
} }
function NsTuyenDungComponent_div_68_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1, " Vui l\u00F2ng ch\u1ECDn \u0111\u00E1nh gi\u00E1 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} }
function NsTuyenDungComponent_ng_template_69_Template(rf, ctx) { if (rf & 1) {
    const _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "p-button", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_ng_template_69_Template_p_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r30); const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r29.cancelRate(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2, "\u00A0 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "p-button", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_ng_template_69_Template_p_button_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r30); const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r31.sendRate(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](4, "G\u1EEDi \u0110\u00E1nh gi\u00E1");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} }
function NsTuyenDungComponent_div_74_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1, " Vui l\u00F2ng nh\u1EADp l\u00FD do ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} }
function NsTuyenDungComponent_ng_template_75_Template(rf, ctx) { if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "p-button", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_ng_template_75_Template_p_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r33); const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r32.canSetTiemNang(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2, "\u00A0 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "p-button", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_ng_template_75_Template_p_button_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r33); const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r34.setTiemNang(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](4, "G\u1EEDi");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} }
function NsTuyenDungComponent_div_79_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "p-radioButton", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function NsTuyenDungComponent_div_79_div_1_Template_p_radioButton_ngModelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r38); const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2); return ctx_r37.recruitmentStatusSelected = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](2, "label", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const recrui_r36 = ctx.$implicit;
    const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngClass", ctx_r35.canSttValue.can_st > recrui_r36.code ? "op6" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpropertyInterpolate"]("value", recrui_r36.code);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpropertyInterpolate1"]("inputId", "recrui", recrui_r36.code, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("disabled", ctx_r35.canSttValue.can_st > recrui_r36.code)("ngModel", ctx_r35.recruitmentStatusSelected);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpropertyInterpolate1"]("for", "recrui", recrui_r36.code, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](recrui_r36.label);
} }
function NsTuyenDungComponent_div_79_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](1, NsTuyenDungComponent_div_79_div_1_Template, 4, 7, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx_r10.recruitmentStatus);
} }
function NsTuyenDungComponent_ng_template_90_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r43 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](item_r43.label);
} }
function NsTuyenDungComponent_ng_template_90_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r44 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"]("", car_r44.label, " ");
} }
function NsTuyenDungComponent_ng_template_90_ng_template_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r45 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](item_r45.label);
} }
function NsTuyenDungComponent_ng_template_90_ng_template_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r46 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"]("", car_r46.label, " ");
} }
function NsTuyenDungComponent_ng_template_90_Template(rf, ctx) { if (rf & 1) {
    const _r48 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](4, "div", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "div", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](6, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](7, "label", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](8, "V\u00F2ng tuy\u1EC3n d\u1EE5ng");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](9, "p-dropdown", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function NsTuyenDungComponent_ng_template_90_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r48); const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r47.query.can_st = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](10, NsTuyenDungComponent_ng_template_90_ng_template_10_Template, 2, 1, "ng-template", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](11, NsTuyenDungComponent_ng_template_90_ng_template_11_Template, 3, 1, "ng-template", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](12, "div", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](13, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](14, "label", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](15, "V\u1ECB tr\u00ED tuy\u1EC3n d\u1EE5ng ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](16, "p-dropdown", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function NsTuyenDungComponent_ng_template_90_Template_p_dropdown_ngModelChange_16_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r48); const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r49.query.vacancyId = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](17, NsTuyenDungComponent_ng_template_90_ng_template_17_Template, 2, 1, "ng-template", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](18, NsTuyenDungComponent_ng_template_90_ng_template_18_Template, 3, 1, "ng-template", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](19, "div", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](20, "label", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](21, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](22, "span", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](23, "p-button", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_ng_template_90_Template_p_button_click_23_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r48); const ctx_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r50.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](24, "p-button", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_ng_template_90_Template_p_button_click_24_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r48); const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r51.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngClass", ctx_r14.query.can_st ? "valid" : "invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r14.recruitmentStatus)("ngModel", ctx_r14.query.can_st)("filter", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngClass", ctx_r14.query.vacancyId ? "valid" : "invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r14.listVacancy)("ngModel", ctx_r14.query.vacancyId)("filter", true);
} }
const _c1 = function () { return { showAll: "ALL" }; };
const _c2 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c3 = function () { return { width: "50vw" }; };
const _c4 = function () { return { width: "400px" }; };
const _c5 = function () { return { width: "600px" }; };
const _c6 = function () { return { width: "700px" }; };
const MAX_SIZE = 100000000;
class NsTuyenDungComponent {
    constructor(apiService, route, confirmationService, messageService, spinner, dialogService, changeDetector, organizeInfoService, router) {
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.spinner = spinner;
        this.dialogService = dialogService;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.listsData = [];
        this.items = [];
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS;
        this.pagingComponent = {
            total: 0
        };
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn;
        this.columnDefs = [];
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            jobId: null,
            organizeId: null,
            positionCd: null,
            vacancyId: 0,
            can_st: null,
            organizeIds: '',
        };
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.loading = false;
        this.listVacancy = [];
        this.recruitmentStatus = [];
        this.recruitmentStatusSelected = '1';
        this.dataRowSelected = [];
        this.isSendMail = false;
        this.mailsInput = [];
        this.mailInputValue = [];
        this.buttonTiemNang = [];
        this.optionsButtonDB = [];
        this.loadjs = 0;
        this.heightGrid = 450;
        // the value for check disabled 'Chuyển vòng radio'
        this.canSttValue = null;
        this.displaySetting = false;
        this.gridKey = '';
        this.organizeIdSelected = '';
        this.isChuyenVong = false;
        // positiontypes = [];
        // getObjectList() {
        //   const queryParams = queryString.stringify({ objKey: 'positiontype_group' });
        //   this.apiService.getCustObjectListNew(false, queryParams).subscribe(results => {
        //     if (results.status === 'success') {
        //       this.positiontypes = results.data.map(d => {
        //         return {
        //           label: d.objName,
        //           value: d.objCode
        //         }
        //       });
        //       this.positiontypes = [{ label: 'Tất cả', value: null }, ...this.positiontypes]
        //     }
        //   })
        // }
        this.listOrgRoots = [];
        this.listJobTitles = [];
        this.positions = [{ label: 'Tất cả', value: null }];
        this.listStatus = [];
        this.isRateRecui = false;
        this.rateStatus = null;
        this.queryRate = {
            canId: '',
            InterviewResult: '',
        };
        this.isSubmitRate = false;
        this.isSubmitTiemNang = false;
        this.isTiemNang = false;
        this.queryTiemNang = {
            canId: '',
            reason_rejiect: '',
        };
        this.listViewsFilter = [];
        this.detailInfoFilter = null;
        this.optionsButonFilter = [
            { label: 'Tìm kiếm', value: 'Search', class: 'p-button-sm ml-2 height-56 addNew', icon: 'pi pi-plus' },
            { label: 'Làm mới', value: 'Reset', class: 'p-button-sm p-button-danger ml-2 height-56 addNew', icon: 'pi pi-times' },
        ];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_2__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__.AvatarFullComponent,
        };
        this.getCandidateFilter();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cancel() {
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeId: '',
            positionCd: '',
            jobId: null,
            vacancyId: 0,
            can_st: null,
            organizeIds: this.query.organizeIds,
        };
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.dataRowSelected = [];
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getCandidatePage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editRow.bind(this),
                    label: 'Chỉnh sửa',
                    icon: 'fa fa-edit',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetCandidatePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.EDIT)
                },
                {
                    onClick: this.viewRow.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetCandidatePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.VIEW)
                },
                {
                    onClick: this.rateRecui.bind(this),
                    label: 'Đánh giá kết quả',
                    icon: 'pi pi-star-fill',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetCandidatePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.DANH_GIA_KET_QUA)
                },
                {
                    onClick: this.xoatuyendung.bind(this),
                    label: 'Xóa ',
                    icon: 'pi pi-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetCandidatePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.DELETE)
                },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: '',
                filter: '',
                width: 60,
                pinned: 'left',
                cellClass: ['border-right', 'no-auto'],
                field: 'checkbox2',
                headerCheckboxSelection: false,
                suppressSizeToFit: true,
                suppressRowClickSelection: true,
                showDisabledCheckboxes: true,
                checkboxSelection: true,
                // rowSelection: 'single'
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
        this.detailCellRendererParams = {
            detailGridOptions: {
                frameworkComponents: {},
                getRowHeight: (params) => {
                    return 40;
                },
                columnDefs: [
                    ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn)(this.colsDetail),
                ],
                enableCellTextSelection: true,
                onFirstDataRendered(params) {
                    let allColumnIds = [];
                    params.columnApi.getAllColumns()
                        .forEach((column) => {
                        if (column.colDef.cellClass.indexOf('auto') < 0) {
                            allColumnIds.push(column);
                        }
                        else {
                            column.colDef.suppressSizeToFit = true;
                            allColumnIds.push(column);
                        }
                    });
                    params.api.sizeColumnsToFit(allColumnIds);
                },
            },
            getDetailRowData(params) {
                params.successCallback(params.data.Owns);
            },
            excelStyles: [
                {
                    id: 'stringType',
                    dataType: 'string'
                }
            ],
            template: function (params) {
                var personName = params.data.theme;
                return ('<div style="height: 100%; background-color: #EDF6FF; padding: 20px; box-sizing: border-box;">' +
                    `  <div style="height: 10%; padding: 2px; font-weight: bold;">###### Danh sách (${params.data.Owns.length}) : [` +
                    personName + ']' +
                    '</div>' +
                    '  <div ref="eDetailGrid" style="height: 90%;"></div>' +
                    '</div>');
            },
        };
    }
    rowSelected(event) {
        this.dataRowSelected = event;
        this.recruitmentStatusSelected = this.dataRowSelected.map(d => d.can_st).toString();
        this.canSttValue = this.dataRowSelected.sort((a, b) => a.can_st - b.can_st)[this.dataRowSelected.length - 1];
        // check role for set tiem nang && check for tuy chon
        this.buttonTiemNang[1].disabled = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetCandidatePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.TIEM_NANG) && this.dataRowSelected.length > 0;
        // chuyen vong
        this.optionsButtonDB[0].disabled = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetCandidatePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.CHUYEN_VONG) && this.dataRowSelected.length > 0;
        this.optionsButtonDB[1].disabled = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetCandidatePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.SEND_EMAIL);
        let checkCreateAccount = this.dataRowSelected.some(d => d.can_st !== 10 || d.status_account === 1);
        this.optionsButtonDB[2].disabled = checkCreateAccount ? true : this.dataRowSelected.length < 1 ? true : false;
    }
    xoatuyendung(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa tuyển dụng?',
            accept: () => {
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ canId: event.rowData.canId });
                this.apiService.delCandidateInfo(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa tuyển dụng thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    editRow(event) {
        const params = {
            canId: event.rowData.canId
        };
        this.router.navigate(['/tuyen-dung/ds-tuyen-dung/chi-tiet-tuyen-dung'], { queryParams: params });
    }
    viewRow(event) {
        const params = {
            canId: event.rowData.canId,
            view: true
        };
        this.router.navigate(['/tuyen-dung/ds-tuyen-dung/chi-tiet-tuyen-dung'], { queryParams: params });
    }
    addTuyenDung() {
        const params = {
            canId: null
        };
        this.router.navigate(['/tuyen-dung/ds-tuyen-dung/them-moi-tuyen-dung'], { queryParams: params });
    }
    getOrgPositions() {
        this.positions = [];
        let items = this.listOrgRoots.filter(d => d.value === this.query.organizeId);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ orgId: items[0].code });
        this.apiService.getOrgPositions(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.positions = results.data.map(d => {
                    return { label: d.positionName, value: d.positionCd };
                });
                this.positions = [{ label: 'Tất cả', value: '' }, ...this.positions];
            }
        });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows === 4 ? 100000000 : event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.organizeIdSelected = results;
                this.listsData = [];
                this.load();
                this.getReRound();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Nhân sự' },
            { label: 'Danh sách tuyển dụng' },
        ];
        this.getJobTitles();
        this.getOrgRoots();
        // this.getObjectList();
        // this.getStatus();
        this.getVacancyPage();
        this.buttonTiemNang = [
            {
                label: 'Danh sách tiềm năng',
                code: 'Import',
                icon: 'pi pi-list',
                // disabled: CheckHideAction(MENUACTIONROLEAPI.GetEmployeePage.url, ACTIONS.IMPORT),
                command: () => {
                    this.dsTiemNang();
                }
            },
            {
                label: 'Tiềm năng',
                code: 'tiemnang',
                icon: 'pi pi-send',
                disabled: true,
                command: () => {
                    this.tiemNang();
                }
            },
        ];
        this.optionsButtonDB = [
            {
                label: 'Chuyển vòng',
                code: 'chuyenVong',
                icon: 'pi pi-reply',
                disabled: true,
                command: () => {
                    this.chuyenVong();
                }
            },
            {
                label: 'Gửi email',
                code: 'guiemail',
                icon: 'pi pi-envelope',
                disabled: true,
                command: () => {
                    this.getRecruitMailInput();
                }
            },
            {
                label: 'Tạo tài khoản',
                code: 'guiemail',
                icon: 'pi pi-plus',
                disabled: true,
                command: () => {
                    this.setCandidateRegisters();
                }
            },
            {
                label: 'Import',
                code: 'import',
                icon: 'pi pi-file-excel',
                disabled: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetCandidatePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.IMPORT),
                command: () => {
                    this.importFileExel();
                }
            },
        ];
    }
    chuyenVong() {
        this.isChuyenVong = true;
    }
    setCandidateRegisters() {
        const data = this.dataRowSelected.map(d => {
            return {
                "fullName": d.fullName,
                "phone": d.phone,
                "email": d.email,
                "loginName": d.phone,
                "verifyType": 0,
                "referral_by": d.canId
            };
        });
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn tạo tài khoản?',
            accept: () => {
                this.apiService.setCandidateRegisters(data).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Cập nhật thành công' });
                        this.isSendMail = true;
                        this.getRecruitMailInput();
                        this.spinner.hide();
                    }
                    else {
                        this.spinner.hide();
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message ? results.message : 'Không thành công' });
                    }
                });
            }
        });
    }
    getOrgRoots() {
        this.apiService.getOrgRoots().subscribe(results => {
            if (results.status === 'success') {
                this.listOrgRoots = results.data.map(d => {
                    return {
                        label: d.org_name + '-' + d.org_cd,
                        value: `${d.orgId}`,
                        code: `${d.orgId}`,
                    };
                });
                this.listOrgRoots = [{ label: 'Tất cả', value: null }, ...this.listOrgRoots];
            }
        });
    }
    getJobTitles() {
        this.apiService.getJobTitles().subscribe(results => {
            if (results.status === 'success') {
                this.listJobTitles = results.data.map(d => {
                    return {
                        label: d.job_name,
                        value: d.jobId
                    };
                });
                this.listJobTitles = [{ label: 'Tất cả', value: null }, ...this.listJobTitles];
            }
        });
    }
    getStatus() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ objKey: 'recruitment_round' });
        this.apiService.getCustObjectListNew(false, queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.listStatus = results.data.map(d => {
                    return {
                        label: d.objName,
                        value: d.objValue
                    };
                });
                this.listStatus = [{ label: 'Tất cả', value: null }, ...this.listStatus];
            }
        });
    }
    getReRound() {
        this.recruitmentStatus = [];
        this.apiService.getRecruitRoundTitles(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ organizeIds: this.organizeIdSelected })).subscribe(results => {
            if (results.status === 'success') {
                this.recruitmentStatus = results.data.map(d => {
                    return {
                        label: d.name,
                        code: d.value
                    };
                });
            }
        });
    }
    getVacancyPage() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({
            jobId: this.query.jobId,
            active_st: 1
        });
        this.apiService.getVacancyPage(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.listVacancy = results.data.dataList.data.map(d => {
                    return {
                        label: d.job_name,
                        value: d.vacancyId
                    };
                });
            }
        });
    }
    getRecruitMailInput() {
        this.isSendMail = true;
        this.apiService.getRecruitMailInput(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ organizeIds: this.organizeIdSelected })).subscribe(results => {
            if (results.status === 'success') {
                this.mailsInput = results.data.recruitmentMail.map(d => {
                    return {
                        label: d.mail_name,
                        value: d.mail_Id
                    };
                });
            }
        });
    }
    changeRecruStatus() {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn chuyển vòng?',
            accept: () => {
                let dataUpdateStatus = this.dataRowSelected.map(d => d.canId).toString();
                let vacancyId = this.dataRowSelected.map(d => d.vacancyId).toString();
                const query = {
                    canId: dataUpdateStatus,
                    can_st: this.recruitmentStatusSelected,
                    vacancyId: vacancyId
                };
                this.apiService.recruiUpdateStatus(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query)).subscribe((results) => {
                    if (results.status === 'success') {
                        this.getRecruitMailInput();
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Chuyển thành công!' });
                        // this.dataRowSelected = [];
                        this.recruitmentStatusSelected = null;
                        this.isSendMail = true;
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            },
        });
    }
    rateRecui(event) {
        this.isRateRecui = true;
        this.queryRate.canId = event.rowData.canId;
    }
    cancelRate() {
        this.isRateRecui = false;
    }
    sendRate() {
        this.isSubmitRate = true;
        if (this.queryRate.canId && this.queryRate.InterviewResult) {
            this.apiService.updateInterviewResult(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.queryRate), null).subscribe(results => {
                if (results.status === 'success') {
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Gửi thành công' });
                    this.isRateRecui = false;
                    this.isSubmitRate = false;
                    this.spinner.hide();
                }
                else {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.data : null });
                }
            });
        }
        else if (!this.queryRate.InterviewResult) {
            return;
        }
    }
    cancelSendEmail() {
        this.isSendMail = false;
        this.load();
    }
    sendEmail() {
        if (!this.mailInputValue) {
            this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Chưa chọn nội dung gửi' });
            return;
        }
        let canId = this.dataRowSelected.map(d => d.canId).toString();
        const data = {
            mail_Id: this.mailInputValue,
            can_Id: canId
        };
        this.spinner.show();
        this.apiService.sendRecruitMail(data).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Gửi thành công' });
                this.mailInputValue = '';
                this.dataRowSelected = [];
                // this.isSendMail = false;
                // this.load();
                const params = {
                    meet_ud: null
                };
                this.spinner.hide();
                return this.router.navigate(['/cai-dat/cai-dat-lich-hop/them-moi-lich-hop'], { queryParams: params });
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.data : null });
            }
        });
    }
    tiemNang() {
        this.isTiemNang = true;
        this.queryTiemNang.canId = this.dataRowSelected.map(d => d.canId).toString();
    }
    setTiemNang() {
        this.isSubmitTiemNang = true;
        if (!this.queryTiemNang.reason_rejiect) {
            return;
        }
        this.apiService.updateCandidatesPotential(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.queryTiemNang), null).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Cập nhật thành công' });
                this.load();
                this.isTiemNang = false;
                this.spinner.hide();
            }
            else {
                this.spinner.hide();
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.data : null });
            }
        });
    }
    canSetTiemNang() {
        this.isTiemNang = false;
    }
    dsTiemNang() {
        this.router.navigate(['/tuyen-dung/ds-tuyen-dung//ds-tiem-nang']);
    }
    // vitrituyendung() {
    //   this.router.navigate(['/tuyen-dung/danh-sach-tuyen-dung/vi-tri-tuyen-dung']);
    // }
    // linhvuctuyendung() {
    //   this.router.navigate(['/tuyen-dung/danh-sach-tuyen-dung/linh-vuc-tuyen-dung']);
    // }
    onHideSendEmail(event) {
        this.isSendMail = false;
        this.dataRowSelected = [];
        this.load();
    }
    importFileExel() {
        this.router.navigate(['/tuyen-dung/ds-tuyen-dung/import']);
    }
    getCandidateFilter() {
        this.apiService.getCandidateFilter().subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_8__.cloneDeep)(results.data.group_fields);
                this.listViewsFilter = [...listViews];
                this.detailInfoFilter = results.data;
            }
        });
    }
    showFilter() {
        const ref = this.dialogService.open(src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_9__.FormFilterComponent, {
            header: 'Tìm kiếm nâng cao',
            width: '40%',
            contentStyle: "",
            data: {
                listViews: this.listViewsFilter,
                detailInfoFilter: this.detailInfoFilter,
                buttons: this.optionsButonFilter
            }
        });
        ref.onClose.subscribe((event) => {
            if (event) {
                this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_8__.cloneDeep)(event.listViewsFilter);
                if (event.type === 'Search') {
                    this.query = Object.assign(Object.assign({}, this.query), event.data);
                    this.load();
                }
                else if (event.type === 'CauHinh') {
                    this.apiService.getCandidateFilter().subscribe(results => {
                        if (results.status === 'success') {
                            const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_8__.cloneDeep)(results.data.group_fields);
                            this.listViewsFilter = [...listViews];
                            this.detailInfoFilter = results.data;
                            this.showFilter();
                        }
                    });
                }
                else if (event.type === 'Reset') {
                    const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_8__.cloneDeep)(this.detailInfoFilter.group_fields);
                    this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_8__.cloneDeep)(listViews);
                    this.cancel();
                }
            }
        });
    }
}
NsTuyenDungComponent.ɵfac = function NsTuyenDungComponent_Factory(t) { return new (t || NsTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_15__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_16__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_16__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_17__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_18__.DialogService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_14__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_15__.Router)); };
NsTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({ type: NsTuyenDungComponent, selectors: [["app-ns-tuyen-dung"]], decls: 91, vars: 83, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle", "wrap"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "col-9", "gap-16", "end", "pd-0", "wrap"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "V\u1ECB tr\u00ED, chuy\u00EAn m\u00F4n ...", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", "label", "Th\u00EAm m\u1EDBi", "icon", "pi pi-plus", 3, "CheckHideActions", "click"], ["width", "18", "height", "18", "viewBox", "0 0 18 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M10.2002 13.2H13.2002V10.2H14.8002V13.2H17.8002V14.8H14.8002V17.7999H13.2002V14.8H10.2002V13.2Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 0.199951H7.8002V7.79995H0.200195V0.199951ZM6.2002 1.79995H1.8002V6.19995H6.2002V1.79995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.8002 7.79995H10.2002V0.199951H17.8002V7.79995ZM11.8002 6.19995H16.2002V1.79995H11.8002V6.19995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 10.2H7.8002V17.7999H0.200195V10.2ZM6.2002 11.8H1.8002V16.2H6.2002V11.8Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "rowSelection", "columnDefs", "callback", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "advance-seach"], ["recru", ""], ["pTemplate", ""], ["styleClass", "hideHeaderForm", "header", "G\u1EEDi mail", 3, "visible", "modal", "draggable", "resizable", "focusTrap", "onHide", "visibleChange"], [1, "field-group", "select"], [2, "color", "red"], ["appendTo", "body", "placeholder", "Ch\u1ECDn n\u1ED9i dung g\u1EEDi", "name", "mailInputValue", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange"], ["pTemplate", "footer"], ["styleClass", "hideHeaderForm", "header", "\u0110\u00E1nh gi\u00E1", 3, "visible", "modal", "draggable", "resizable", "focusTrap", "visibleChange"], [1, "d-flex", "gap16", "mb-3"], [1, "fields", "radio"], ["name", "recrui", "value", "1", "inputId", "rate-good", 3, "ngModel", "ngModelChange"], ["for", "rate-good"], ["name", "recrui", "value", "2", "inputId", "rate-bad", 3, "ngModel", "ngModelChange"], ["for", "rate-bad"], [1, "field-group"], ["class", "alert-validation alert-danger", 4, "ngIf"], ["styleClass", "hideHeaderForm", "header", "Ti\u1EC1m n\u0103ng", 3, "visible", "modal", "draggable", "resizable", "focusTrap", "visibleChange"], [1, "field-group", "textarea"], ["placeholder", "Nh\u1EADp l\u00FD do", "required", "", 3, "ngModel", "ngModelChange"], ["styleClass", "hideHeaderForm", "header", "Chuy\u1EC3n v\u00F2ng tuy\u1EC3n", 3, "visible", "modal", "draggable", "resizable", "focusTrap", "visibleChange"], [1, "header-filter-search", "mt-1"], [1, "icon", "col-12", "pl-0"], ["class", "radios grid", 4, "ngIf"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["label", "H\u1EE7y", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], ["label", "Chuy\u1EC3n", "icon", "pi pi-times", "styleClass", "", 3, "disabled", "click"], ["styleClass", "menu-option-right", 3, "model", "appendTo", "popup"], ["tiemnangButton", ""], ["optionsButton", ""], ["op", ""], [3, "listsData", "height", "rowSelection", "columnDefs", "callback", "showConfig"], [3, "typeConfig", "gridKey"], [1, "header-filter-search", "grid"], [1, "radios", "grid"], ["class", "p-field-radiobutton col-6", "style", "margin-bottom: 5px;", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "p-field-radiobutton", "col-6", 2, "margin-bottom", "5px", 3, "ngClass"], ["name", "recrui", 3, "disabled", "value", "ngModel", "inputId", "ngModelChange"], [2, "margin-left", "5px", 3, "for"], [1, "d-flex", "end"], ["styleClass", "p-button-sm p-button-secondary", "label", "Bo\u0309 qua", "icon", "pi pi-times-circle", 3, "click"], [3, "CheckHideActions", "click"], [1, "alert-validation", "alert-danger"], [3, "click"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", 3, "ngClass"], ["for", ""], ["appendTo", "body", "name", "can_st", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], ["appendTo", "body", "name", "vacancyId", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"]], template: function NsTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        const _r52 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("keydown.enter", function NsTuyenDungComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function NsTuyenDungComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_Template_p_button_click_15_listener() { return ctx.showFilter(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](21, "p-button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_Template_p_button_click_21_listener() { return ctx.addTuyenDung(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](22, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_Template_p_button_click_22_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r52); const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](85); return _r11.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](23, "svg", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](24, "path", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](25, "path", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](26, "path", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](27, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](28, " \u00A0 T\u00F9y ch\u1ECDn ti\u1EC1m n\u0103ng ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](29, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_Template_p_button_click_29_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r52); const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](87); return _r12.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](30, "svg", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](31, "path", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](32, "path", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](33, "path", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](34, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](35, " \u00A0 Ti\u1EC7n \u00EDch ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](36, "section", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](37, "div", 27, 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](39, NsTuyenDungComponent_app_list_grid_angular_39_Template, 1, 4, "app-list-grid-angular", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](40, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](41, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](42);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](43, "p-paginator", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("onPageChange", function NsTuyenDungComponent_Template_p_paginator_onPageChange_43_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](44, "p-dialog", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("visibleChange", function NsTuyenDungComponent_Template_p_dialog_visibleChange_44_listener($event) { return ctx.displaySetting = $event; })("onHide", function NsTuyenDungComponent_Template_p_dialog_onHide_44_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](45, NsTuyenDungComponent_app_config_grid_table_form_45_Template, 1, 2, "app-config-grid-table-form", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](46, "p-overlayPanel", 34, 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](48, NsTuyenDungComponent_ng_template_48_Template, 10, 2, "ng-template", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](49, "p-dialog", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("onHide", function NsTuyenDungComponent_Template_p_dialog_onHide_49_listener($event) { return ctx.onHideSendEmail($event); })("visibleChange", function NsTuyenDungComponent_Template_p_dialog_visibleChange_49_listener($event) { return ctx.isSendMail = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](50, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](51, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](52, "N\u1ED9i dung g\u1EEDi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](53, "span", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](54, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](55, "p-dropdown", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function NsTuyenDungComponent_Template_p_dropdown_ngModelChange_55_listener($event) { return ctx.mailInputValue = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](56, NsTuyenDungComponent_ng_template_56_Template, 5, 4, "ng-template", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](57, "p-dialog", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("visibleChange", function NsTuyenDungComponent_Template_p_dialog_visibleChange_57_listener($event) { return ctx.isRateRecui = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](58, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](59, "div", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](60, "p-radioButton", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function NsTuyenDungComponent_Template_p_radioButton_ngModelChange_60_listener($event) { return ctx.queryRate.InterviewResult = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](61, "label", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](62, " \u00A0T\u1ED1t");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](63, "div", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](64, "p-radioButton", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function NsTuyenDungComponent_Template_p_radioButton_ngModelChange_64_listener($event) { return ctx.queryRate.InterviewResult = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](65, "label", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](66, " \u00A0Kh\u00F4ng t\u1ED1t");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](67, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](68, NsTuyenDungComponent_div_68_Template, 2, 0, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](69, NsTuyenDungComponent_ng_template_69_Template, 5, 0, "ng-template", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](70, "p-dialog", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("visibleChange", function NsTuyenDungComponent_Template_p_dialog_visibleChange_70_listener($event) { return ctx.isTiemNang = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](71, "div", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](72, "textarea", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function NsTuyenDungComponent_Template_textarea_ngModelChange_72_listener($event) { return ctx.queryTiemNang.reason_rejiect = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](73, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](74, NsTuyenDungComponent_div_74_Template, 2, 0, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](75, NsTuyenDungComponent_ng_template_75_Template, 5, 0, "ng-template", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](76, "p-dialog", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("visibleChange", function NsTuyenDungComponent_Template_p_dialog_visibleChange_76_listener($event) { return ctx.isChuyenVong = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](77, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](78, "div", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](79, NsTuyenDungComponent_div_79_Template, 2, 1, "div", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](80, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](81, "p-button", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_Template_p_button_click_81_listener() { return ctx.isChuyenVong = false; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](82, " \u00A0 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](83, "p-button", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function NsTuyenDungComponent_Template_p_button_click_83_listener() { return ctx.changeRecruStatus(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](84, "p-menu", 61, 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](86, "p-menu", 61, 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](88, "p-overlayPanel", 34, 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](90, NsTuyenDungComponent_ng_template_90_Template, 25, 12, "ng-template", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction2"](70, _c0, ctx.MENUACTIONROLEAPI.GetCandidatePage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](74, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](73, _c1)));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](76, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](77, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](78, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("visible", ctx.isSendMail)("modal", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.mailsInput)("ngModel", ctx.mailInputValue);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](79, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("visible", ctx.isRateRecui)("modal", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.queryRate.InterviewResult);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.queryRate.InterviewResult);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", !ctx.rateStatus && ctx.isSubmitRate);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](80, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("visible", ctx.isTiemNang)("modal", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.queryTiemNang.reason_rejiect);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", !ctx.queryTiemNang.reason_rejiect && ctx.isSubmitTiemNang);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](81, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("visible", ctx.isChuyenVong)("modal", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.recruitmentStatus.length > 0 && ctx.canSttValue);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("disabled", ctx.recruitmentStatusSelected ? false : true);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("model", ctx.buttonTiemNang)("appendTo", "body")("popup", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("model", ctx.optionsButtonDB)("appendTo", "body")("popup", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](82, _c6));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_10__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_21__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_11__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_22__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_23__.Dialog, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_24__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_16__.PrimeTemplate, primeng_dropdown__WEBPACK_IMPORTED_MODULE_25__.Dropdown, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_26__.RadioButton, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.RequiredValidator, primeng_menu__WEBPACK_IMPORTED_MODULE_27__.Menu, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_12__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_13__.ConfigGridTableFormComponent, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgForOf], styles: [".select-default[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  text-align: left;\n  margin-top: 10px;\n}\n\n.p-radiobutton[_ngcontent-%COMP%]   .p-radiobutton-box[_ngcontent-%COMP%]   .p-radiobutton-icon[_ngcontent-%COMP%] {\n  background: #4C97E4 !important;\n}\n\n.p-radiobutton[_ngcontent-%COMP%]   .p-radiobutton-box.p-highlight[_ngcontent-%COMP%]:not(.p-disabled):hover {\n  border-color: #4C97E4 !important;\n  background: #ffffff;\n  color: #4C97E4 !important;\n}\n\n.op6[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  opacity: 0.6;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5zLXR1eWVuLWR1bmcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBQ0E7RUFDSSw4QkFBQTtBQUVKOztBQUFBO0VBQ0ksZ0NBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FBR0o7O0FBQVE7RUFDSSxZQUFBO0FBR1oiLCJmaWxlIjoibnMtdHV5ZW4tZHVuZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZWxlY3QtZGVmYXVsdCBsYWJlbHtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcbi5wLXJhZGlvYnV0dG9uIC5wLXJhZGlvYnV0dG9uLWJveCAucC1yYWRpb2J1dHRvbi1pY29ue1xyXG4gICAgYmFja2dyb3VuZDogIzRDOTdFNCAhaW1wb3J0YW50O1xyXG59XHJcbi5wLXJhZGlvYnV0dG9uIC5wLXJhZGlvYnV0dG9uLWJveC5wLWhpZ2hsaWdodDpub3QoLnAtZGlzYWJsZWQpOmhvdmVyIHtcclxuICAgIGJvcmRlci1jb2xvcjogIzRDOTdFNCAhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZmZmZjtcclxuICAgIGNvbG9yOiAjNEM5N0U0ICFpbXBvcnRhbnQ7XHJcbn1cclxuICAgIC5vcDZ7XHJcbiAgICAgICAgbGFiZWx7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDAuNjtcclxuICAgICAgICB9XHJcbiAgICB9Il19 */"] });


/***/ }),

/***/ 72185:
/*!*******************************************************************************************!*\
  !*** ./src/app/components/ns-tuyen-dung/vi-tri-tuyen-dung/vi-tri-tuyen-dung.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViTriTuyenDungComponent": () => (/* binding */ ViTriTuyenDungComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! file-saver */ 68178);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/common/form-filter/form-filter.component */ 83844);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dynamicdialog */ 56427);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! primeng/treeselect */ 90238);







































function ViTriTuyenDungComponent_app_list_grid_angular_35_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "app-list-grid-angular", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("callback", function ViTriTuyenDungComponent_app_list_grid_angular_35_Template_app_list_grid_angular_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r6.rowSelected($event); })("showConfig", function ViTriTuyenDungComponent_app_list_grid_angular_35_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r7); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r8.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function ViTriTuyenDungComponent_app_config_grid_table_form_41_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](0, "app-config-grid-table-form", 41);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r2.gridKey);
} }
function ViTriTuyenDungComponent_ng_template_44_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "span", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](item_r13.label);
} }
function ViTriTuyenDungComponent_ng_template_44_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r14 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](car_r14.label);
} }
function ViTriTuyenDungComponent_ng_template_44_ng_template_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "span", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](item_r15.label);
} }
function ViTriTuyenDungComponent_ng_template_44_ng_template_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](car_r16.label);
} }
const _c0 = function (a0) { return [a0]; };
function ViTriTuyenDungComponent_ng_template_44_Template(rf, ctx) { if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](4, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](5, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](6, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](7, "label", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](8, "V\u1ECB tr\u00ED tuy\u1EC3n d\u1EE5ng: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](9, "p-dropdown", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("ngModelChange", function ViTriTuyenDungComponent_ng_template_44_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r18); const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r17.query.jobId = $event; })("onChange", function ViTriTuyenDungComponent_ng_template_44_Template_p_dropdown_onChange_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r18); const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r19.find(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](10, ViTriTuyenDungComponent_ng_template_44_ng_template_10_Template, 2, 1, "ng-template", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](11, ViTriTuyenDungComponent_ng_template_44_ng_template_11_Template, 3, 1, "ng-template", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](12, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](13, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](14, "label", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](15, "Chuy\u00EAn vi\u00EAn tuy\u1EC3n d\u1EE5ng: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](16, "p-dropdown", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("ngModelChange", function ViTriTuyenDungComponent_ng_template_44_Template_p_dropdown_ngModelChange_16_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r18); const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r20.query.hiringManId = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](17, ViTriTuyenDungComponent_ng_template_44_ng_template_17_Template, 2, 1, "ng-template", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](18, ViTriTuyenDungComponent_ng_template_44_ng_template_18_Template, 3, 1, "ng-template", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](19, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](20, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](21, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](22, "T\u1EEB ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](23, "p-calendar", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("ngModelChange", function ViTriTuyenDungComponent_ng_template_44_Template_p_calendar_ngModelChange_23_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r18); const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r21.query.fromDate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](24, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](25, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](26, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](27, "\u0110\u1EBFn ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](28, "p-calendar", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("ngModelChange", function ViTriTuyenDungComponent_ng_template_44_Template_p_calendar_ngModelChange_28_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r18); const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r22.query.toDate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](29, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](30, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](31, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](32, "Ph\u00F2ng ban");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](33, "p-treeSelect", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("ngModelChange", function ViTriTuyenDungComponent_ng_template_44_Template_p_treeSelect_ngModelChange_33_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r18); const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r23.query.orgId = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](34, "div", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](35, "label", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](36, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](37, "span", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](38, "p-button", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function ViTriTuyenDungComponent_ng_template_44_Template_p_button_click_38_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r18); const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r24.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](39, "p-button", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function ViTriTuyenDungComponent_ng_template_44_Template_p_button_click_39_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r18); const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r25.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("filter", true)("options", ctx_r4.listJobTitles)("ngModel", ctx_r4.query.jobId);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("filter", true)("options", ctx_r4.hiringMans)("ngModel", ctx_r4.query.hiringManId);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r4.query.fromDate)("monthNavigator", true)("yearNavigator", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r4.query.toDate)("monthNavigator", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngModel", ctx_r4.query.orgId)("filterInputAutoFocus", true)("metaKeySelection", true)("filter", true)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](25, _c0, ctx_r4.departmentFiltes.length <= 0 ? "tree-empty" : ""))("options", ctx_r4.departmentFiltes);
} }
const _c1 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c2 = function () { return { showAll: "ALL" }; };
const _c3 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c4 = function () { return { width: "50vw" }; };
const _c5 = function () { return { width: "700px" }; };
const MAX_SIZE = 100000000;
class ViTriTuyenDungComponent {
    constructor(apiService, route, confirmationService, messageService, spinner, changeDetector, dialogService, organizeInfoService, router) {
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.dialogService = dialogService;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.listsData = [];
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS;
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.query = {
            jobId: 0,
            active_st: 0,
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
            orgId: '',
            hiringManId: '',
            fromDate: new Date(moment__WEBPACK_IMPORTED_MODULE_9__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            toDate: new Date(moment__WEBPACK_IMPORTED_MODULE_9__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
        };
        this.hiringMans = [];
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.loading = false;
        this.selectedValue = '';
        this.loadjs = 0;
        this.heightGrid = 0;
        this.dataRowSelected = [];
        this.optionsButtonDB = [];
        this.displaySetting = false;
        this.gridKey = '';
        this.listJobTitles = [];
        this.departmentFiltes = [];
        this.listViewsFilter = [];
        this.detailInfoFilter = null;
        this.optionsButonFilter = [
            { label: 'Tìm kiếm', value: 'Search', class: 'p-button-sm ml-2 height-56 addNew', icon: 'pi pi-plus' },
            { label: 'Làm mới', value: 'Reset', class: 'p-button-sm p-button-danger ml-2 height-56 addNew', icon: 'pi pi-times' },
        ];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_2__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_4__.AvatarFullComponent,
        };
        this.getVacancyFilter();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cancel() {
        this.query = {
            jobId: 0,
            active_st: 0,
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds,
            orgId: '',
            hiringManId: '',
            fromDate: new Date(moment__WEBPACK_IMPORTED_MODULE_9__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            toDate: new Date(moment__WEBPACK_IMPORTED_MODULE_9__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
        };
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows === 4 ? 100000000 : event.rows;
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        let params = Object.assign({}, this.query);
        delete params.fromDate;
        delete params.toDate;
        params.orgId = typeof params.orgId === 'string' ? params.orgId : params.orgId.orgId;
        params.FromDate = moment__WEBPACK_IMPORTED_MODULE_9__(new Date(this.query.fromDate)).format('YYYY-MM-DD');
        params.ToDate = moment__WEBPACK_IMPORTED_MODULE_9__(new Date(this.query.toDate)).format('YYYY-MM-DD');
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.apiService.getVacancyPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            if (this.query.pageSize === MAX_SIZE) {
                this.query.pageSize = this.countRecord.totalRecord;
            }
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.XemChiTiet.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetVacancyPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.VIEW)
                },
                {
                    onClick: this.xoavitri.bind(this),
                    label: 'Xóa',
                    icon: 'pi pi-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetVacancyPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.DELETE)
                },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    xoavitri(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa vị trí tuyển dụng?',
            accept: () => {
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ vacancyId: event.rowData.vacancyId });
                this.apiService.delVacancyInfo(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa vị trí tuyển dụng thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    XemChiTiet(event) {
        const params = {
            vacancyId: event.rowData.vacancyId
        };
        this.router.navigate(['/tuyen-dung/vi-tri-tuyen-dung/chi-tiet-vi-tri-tuyen-dung'], { queryParams: params });
    }
    create() {
        const params = {
            vacancyId: null
        };
        this.router.navigate(['/tuyen-dung/vi-tri-tuyen-dung/them-moi-vi-tri-tuyen-dung'], { queryParams: params });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
                this.selectedValue = results;
                this.getBoPhan();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Tuyển dụng' },
            { label: 'Danh sách vị trí tuyển dụng' },
        ];
        this.optionsButtonDB = [
            {
                label: 'Export',
                code: 'export',
                icon: 'fa fa-download',
                disabled: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetVacancyPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.EXPORT),
                command: () => {
                    this.export();
                }
            },
            {
                label: 'Nhân bản',
                code: 'export',
                icon: 'pi pi-copy',
                disabled: true,
                command: () => {
                    this.copyRequi();
                }
            },
        ];
        this.getJobTitles();
        this.getHiringMans();
    }
    getJobTitles() {
        this.apiService.getJobTitles().subscribe(results => {
            if (results.status === 'success') {
                this.listJobTitles = results.data.map(d => {
                    return {
                        label: d.name,
                        value: d.value
                    };
                });
                this.listJobTitles = [{ label: 'Tất cả', value: 0 }, ...this.listJobTitles];
            }
        });
    }
    getHiringMans() {
        this.apiService.getUsersByAdmin(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ admin_st: 0 })).subscribe(results => {
            if (results.status === 'success') {
                this.hiringMans = results.data.map(d => {
                    return {
                        label: `${d.fullName} [${d.loginName}]`,
                        value: d.userId
                    };
                });
                this.hiringMans = [{ label: 'Tất cả', value: '' }, ...this.hiringMans];
            }
        });
    }
    getBoPhan() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ parentId: this.selectedValue });
        this.apiService.getOrganizeTree(queryParams)
            .subscribe((results) => {
            if (results && results.status === 'success') {
                this.departmentFiltes = results.data;
            }
        }, error => { });
    }
    export() {
        let params = Object.assign({}, this.query);
        delete params.fromDate;
        delete params.toDate;
        params.FromDate = moment__WEBPACK_IMPORTED_MODULE_9__(new Date(this.query.fromDate)).format('YYYY-MM-DD');
        params.ToDate = moment__WEBPACK_IMPORTED_MODULE_9__(new Date(this.query.toDate)).format('YYYY-MM-DD');
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.apiService.exportVacancy(queryParams).subscribe(results => {
            if (results.type === 'application/json') {
                this.spinner.hide();
            }
            else {
                var blob = new Blob([results], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                file_saver__WEBPACK_IMPORTED_MODULE_10__.saveAs(blob, `Danh sách vị trí tuyển dụng ${params.FromDate} - ${params.ToDate}` + ".xlsx");
                this.spinner.hide();
            }
        });
    }
    rowSelected(data) {
        this.dataRowSelected = data;
        this.optionsButtonDB[1].disabled = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetVacancyPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.COPY_ROW);
    }
    copyRequi() {
        const params = {
            vacancyId: this.dataRowSelected[0].vacancyId,
            copy: true,
        };
        this.router.navigate(['/tuyen-dung/vi-tri-tuyen-dung/chi-tiet-vi-tri-tuyen-dung'], { queryParams: params });
    }
    getVacancyFilter() {
        this.apiService.getVacancyFilter().subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_12__.cloneDeep)(results.data.group_fields);
                this.listViewsFilter = [...listViews];
                this.detailInfoFilter = results.data;
            }
        });
    }
    showFilter() {
        const ref = this.dialogService.open(src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_11__.FormFilterComponent, {
            header: 'Tìm kiếm nâng cao',
            width: '40%',
            contentStyle: "",
            data: {
                listViews: this.listViewsFilter,
                detailInfoFilter: this.detailInfoFilter,
                buttons: this.optionsButonFilter
            }
        });
        ref.onClose.subscribe((event) => {
            if (event) {
                this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_12__.cloneDeep)(event.listViewsFilter);
                if (event.type === 'Search') {
                    this.query = Object.assign(Object.assign({}, this.query), event.data);
                    this.load();
                }
                else if (event.type === 'CauHinh') {
                    this.apiService.getVacancyFilter().subscribe(results => {
                        if (results.status === 'success') {
                            const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_12__.cloneDeep)(results.data.group_fields);
                            this.listViewsFilter = [...listViews];
                            this.detailInfoFilter = results.data;
                            this.showFilter();
                        }
                    });
                }
                else if (event.type === 'Reset') {
                    const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_12__.cloneDeep)(this.detailInfoFilter.group_fields);
                    this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_12__.cloneDeep)(listViews);
                    this.cancel();
                }
            }
        });
    }
}
ViTriTuyenDungComponent.ɵfac = function ViTriTuyenDungComponent_Factory(t) { return new (t || ViTriTuyenDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_18__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_19__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_19__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_20__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_17__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_21__.DialogService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_18__.Router)); };
ViTriTuyenDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdefineComponent"]({ type: ViTriTuyenDungComponent, selectors: [["app-vi-tri-tuyen-dung"]], decls: 47, vars: 34, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "gap-16", "col-9", "end", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "V\u1ECB tr\u00ED, chuy\u1EC3n m\u00F4n ...", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", 3, "CheckHideActions", "click"], ["d", "M11 5H9V9H5V11H9V15H11V11H15V9H11V5ZM10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM10 18C5.59 18 2 14.41 2 10C2 5.59 5.59 2 10 2C14.41 2 18 5.59 18 10C18 14.41 14.41 18 10 18Z", "fill", "#F3F8FF"], ["width", "18", "height", "18", "viewBox", "0 0 18 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M10.2002 13.2H13.2002V10.2H14.8002V13.2H17.8002V14.8H14.8002V17.7999H13.2002V14.8H10.2002V13.2Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 0.199951H7.8002V7.79995H0.200195V0.199951ZM6.2002 1.79995H1.8002V6.19995H6.2002V1.79995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.8002 7.79995H10.2002V0.199951H17.8002V7.79995ZM11.8002 6.19995H16.2002V1.79995H11.8002V6.19995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 10.2H7.8002V17.7999H0.200195V10.2ZM6.2002 11.8H1.8002V16.2H6.2002V11.8Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "callback", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], ["styleClass", "menu-option-right", 3, "model", "appendTo", "popup"], ["optionsButton", ""], [3, "listsData", "height", "columnDefs", "callback", "showConfig"], [3, "typeConfig", "gridKey"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", "valid"], ["for", ""], ["appendTo", "body", "name", "jobId", 3, "baseZIndex", "autoDisplayFirst", "filter", "options", "ngModel", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], ["appendTo", "body", "name", "hiringManId", 3, "baseZIndex", "autoDisplayFirst", "filter", "options", "ngModel", "ngModelChange"], [1, "field-group", "date", "mb-0", "valid"], ["panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "fromDate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "yearNavigator", "ngModelChange"], [1, "field-group", "date", "valid"], ["panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "toDate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "ngModelChange"], [1, "field-group", "select", "label-8"], ["selectionMode", "single", "name", "orgId", "placeholder", "Ch\u1ECDn ph\u00F2ng ban", 3, "ngModel", "filterInputAutoFocus", "metaKeySelection", "filter", "ngClass", "options", "ngModelChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [2, "vertical-align", "middle"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"]], template: function ViTriTuyenDungComponent_Template(rf, ctx) { if (rf & 1) {
        const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("keydown.enter", function ViTriTuyenDungComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function ViTriTuyenDungComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function ViTriTuyenDungComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function ViTriTuyenDungComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function ViTriTuyenDungComponent_Template_p_button_click_15_listener() { return ctx.showFilter(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](21, "p-button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function ViTriTuyenDungComponent_Template_p_button_click_21_listener() { return ctx.create(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](22, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](23, "path", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](24, " \u00A0 Th\u00EAm m\u1EDBi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](25, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function ViTriTuyenDungComponent_Template_p_button_click_25_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r26); const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵreference"](46); return _r5.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](26, "svg", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](27, "path", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](28, "path", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](29, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](30, "path", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](31, " \u00A0 Ti\u1EC7n \u00EDch ");
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](32, "section", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](33, "div", 28, 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](35, ViTriTuyenDungComponent_app_list_grid_angular_35_Template, 1, 3, "app-list-grid-angular", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](36, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](37, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](38);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](39, "p-paginator", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("onPageChange", function ViTriTuyenDungComponent_Template_p_paginator_onPageChange_39_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](40, "p-dialog", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("visibleChange", function ViTriTuyenDungComponent_Template_p_dialog_visibleChange_40_listener($event) { return ctx.displaySetting = $event; })("onHide", function ViTriTuyenDungComponent_Template_p_dialog_onHide_40_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](41, ViTriTuyenDungComponent_app_config_grid_table_form_41_Template, 1, 2, "app-config-grid-table-form", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](42, "p-overlayPanel", 35, 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](44, ViTriTuyenDungComponent_ng_template_44_Template, 40, 27, "ng-template", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](45, "p-menu", 38, 39);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction2"](26, _c1, ctx.MENUACTIONROLEAPI.GetVacancyPage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](30, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](29, _c2)));
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](32, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](33, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("model", ctx.optionsButtonDB)("appendTo", "body")("popup", true);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_13__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_24__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_14__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_25__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_26__.Dialog, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_27__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_19__.PrimeTemplate, primeng_menu__WEBPACK_IMPORTED_MODULE_28__.Menu, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_15__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_16__.ConfigGridTableFormComponent, primeng_dropdown__WEBPACK_IMPORTED_MODULE_29__.Dropdown, primeng_calendar__WEBPACK_IMPORTED_MODULE_30__.Calendar, primeng_treeselect__WEBPACK_IMPORTED_MODULE_31__.TreeSelect], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ2aS10cmktdHV5ZW4tZHVuZy5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 28630:
/*!***************************************************************!*\
  !*** ./src/app/pages/tuyen-dung/tuyen-dung-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TuyenDungRoutingModule": () => (/* binding */ TuyenDungRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-tuyen-dung.component */ 31028);
/* harmony import */ var src_app_components_ns_tuyen_dung_vi_tri_tuyen_dung_vi_tri_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/vi-tri-tuyen-dung/vi-tri-tuyen-dung.component */ 72185);
/* harmony import */ var src_app_components_ns_tuyen_dung_chi_tiet_vi_tri_tuyen_dung_chi_tiet_vi_tri_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/chi-tiet-vi-tri-tuyen-dung/chi-tiet-vi-tri-tuyen-dung.component */ 63669);
/* harmony import */ var src_app_components_ns_tuyen_dung_chi_tiet_linh_vuc_tuyen_dung_chi_tiet_linh_vuc_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/chi-tiet-linh-vuc-tuyen-dung/chi-tiet-linh-vuc-tuyen-dung.component */ 8415);
/* harmony import */ var src_app_components_ns_tuyen_dung_chi_tiet_tuyen_dung_chi_tiet_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/chi-tiet-tuyen-dung/chi-tiet-tuyen-dung.component */ 71398);
/* harmony import */ var src_app_components_ns_tuyen_dung_linh_vuc_tuyen_dung_linh_vuc_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/linh-vuc-tuyen-dung/linh-vuc-tuyen-dung.component */ 56546);
/* harmony import */ var src_app_components_ns_tuyen_dung_nghi_viec_nghi_viec_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/nghi-viec/nghi-viec.component */ 82063);
/* harmony import */ var src_app_components_ns_tuyen_dung_mail_tuyen_dung_mail_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/mail-tuyen-dung/mail-tuyen-dung.component */ 47642);
/* harmony import */ var src_app_components_ns_tuyen_dung_mail_tuyen_dung_chi_tiet_mail_tuyen_dung_chi_tiet_mail_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/mail-tuyen-dung/chi-tiet-mail-tuyen-dung/chi-tiet-mail-tuyen-dung.component */ 34278);
/* harmony import */ var src_app_components_ns_tuyen_dung_import_tuyen_dung_import_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/import-tuyen-dung/import-tuyen-dung.component */ 16285);
/* harmony import */ var src_app_components_ns_tuyen_dung_ds_tiem_nang_ds_tiem_nang_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ds-tiem-nang/ds-tiem-nang.component */ 97816);
/* harmony import */ var src_app_components_ns_tuyen_dung_mail_da_gui_mail_da_gui_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/mail-da-gui/mail-da-gui.component */ 30361);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_cau_hinh_ns_cau_hinh_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/ns-cau-hinh.component */ 12413);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 14001);
















const routes = [
    {
        path: "",
        redirectTo: "ds-tuyen-dung",
        pathMatch: 'full'
    },
    //Tuyển dụng
    {
        path: 'ds-tuyen-dung',
        component: src_app_components_ns_tuyen_dung_ns_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_0__.NsTuyenDungComponent,
        data: {
            title: 'Danh sách tuyển dụng',
            url: 'ds-tuyen-dung',
        },
    },
    {
        path: 'ds-tuyen-dung/ds-tiem-nang',
        component: src_app_components_ns_tuyen_dung_ds_tiem_nang_ds_tiem_nang_component__WEBPACK_IMPORTED_MODULE_10__.DsTiemNangComponent,
        data: {
            title: 'Danh sách tiềm năng',
            url: 'ds-tiem-nang',
        },
    },
    {
        path: 'ds-tuyen-dung/import',
        component: src_app_components_ns_tuyen_dung_import_tuyen_dung_import_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_9__.ImportTuyenDungComponent,
        data: {
            title: 'Import tuyển dụng',
            url: 'import-tuyen-dung',
        },
    },
    {
        path: 'ds-tuyen-dung/them-moi-tuyen-dung',
        component: src_app_components_ns_tuyen_dung_chi_tiet_tuyen_dung_chi_tiet_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_4__.ChiTietTuyenDungComponent,
        data: {
            title: 'Thêm mới tuyển dụng',
            url: 'them-moi-tuyen-dung',
        },
    },
    {
        path: 'ds-tuyen-dung/chi-tiet-tuyen-dung',
        component: src_app_components_ns_tuyen_dung_chi_tiet_tuyen_dung_chi_tiet_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_4__.ChiTietTuyenDungComponent,
        data: {
            title: 'Chi tiết tuyển dụng ',
            url: 'chi-tiet-tuyen-dung',
        },
    },
    {
        path: 'vi-tri-tuyen-dung',
        component: src_app_components_ns_tuyen_dung_vi_tri_tuyen_dung_vi_tri_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_1__.ViTriTuyenDungComponent,
        data: {
            title: 'Danh sách vị trí tuyển dụng',
            url: 'vi-tri-tuyen-dung',
        },
    },
    {
        path: 'vi-tri-tuyen-dung/them-moi-vi-tri-tuyen-dung',
        component: src_app_components_ns_tuyen_dung_chi_tiet_vi_tri_tuyen_dung_chi_tiet_vi_tri_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_2__.ChiTietViTriTuyenDungComponent,
        data: {
            title: 'Thêm mới vị trí tuyển dụng',
            url: 'them-moi-vi-tri-tuyen-dung',
        },
    },
    {
        path: 'vi-tri-tuyen-dung/chi-tiet-vi-tri-tuyen-dung',
        component: src_app_components_ns_tuyen_dung_chi_tiet_vi_tri_tuyen_dung_chi_tiet_vi_tri_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_2__.ChiTietViTriTuyenDungComponent,
        data: {
            title: 'Chi tiết vị trí tuyển dụng',
            url: 'chi-tiet-vi-tri-tuyen-dung',
        },
    },
    {
        path: 'danh-sach-nghi-viec',
        component: src_app_components_ns_tuyen_dung_nghi_viec_nghi_viec_component__WEBPACK_IMPORTED_MODULE_6__.NghiViecComponent,
        data: {
            title: 'Danh sách nghỉ việc',
            url: 'danh-sach-nghi-viec',
        },
    },
    //Chuyên môn
    {
        path: 'chuyen-mon',
        component: src_app_components_ns_tuyen_dung_linh_vuc_tuyen_dung_linh_vuc_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_5__.LinhVucTuyenDungComponent,
        data: {
            title: 'Danh sách Chuyên môn tuyển dụng',
            url: 'chuyen-mon',
        },
    },
    {
        path: 'chuyen-mon/them-moi-linh-vuc-tuyen-dung',
        component: src_app_components_ns_tuyen_dung_chi_tiet_linh_vuc_tuyen_dung_chi_tiet_linh_vuc_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_3__.ChiTietLinhVucTuyenDungComponent,
        data: {
            title: 'Thêm mới Chuyên môn tuyển dụng',
            url: 'them-moi-linh-vuc-tuyen-dung',
        },
    },
    {
        path: 'chuyen-mon/chi-tiet-linh-vuc-tuyen-dung',
        component: src_app_components_ns_tuyen_dung_chi_tiet_linh_vuc_tuyen_dung_chi_tiet_linh_vuc_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_3__.ChiTietLinhVucTuyenDungComponent,
        data: {
            title: 'Chi tiết Chuyên môn tuyển dụng',
            url: 'chi-tiet-linh-vuc-tuyen-dung',
        },
    },
    // mail da gui
    {
        path: 'mail-da-gui',
        component: src_app_components_ns_tuyen_dung_mail_da_gui_mail_da_gui_component__WEBPACK_IMPORTED_MODULE_11__.MailDaGuiComponent,
        data: {
            title: 'Danh sách mail đã gửi',
            url: 'mail-da-gui',
        },
    },
    // mail tuyen dung
    {
        path: 'mail-tuyen-dung',
        component: src_app_components_ns_tuyen_dung_mail_tuyen_dung_mail_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_7__.MailTuyenDungComponent,
        data: {
            title: 'Danh sách mail tuyển dụng',
            url: 'mail-tuyen-dung',
        },
    },
    {
        path: 'mail-tuyen-dung/them-moi-mail-tuyen-dung',
        component: src_app_components_ns_tuyen_dung_mail_tuyen_dung_chi_tiet_mail_tuyen_dung_chi_tiet_mail_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_8__.ChiTietMailTuyenDungComponent,
        data: {
            title: 'Thêm mới mail tuyển dụng',
            url: 'them-moi-mail-tuyen-dung',
        },
    },
    {
        path: 'mail-tuyen-dung/chi-tiet-mail-tuyen-dung',
        component: src_app_components_ns_tuyen_dung_mail_tuyen_dung_chi_tiet_mail_tuyen_dung_chi_tiet_mail_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_8__.ChiTietMailTuyenDungComponent,
        data: {
            title: 'Chi tiết mail',
            url: 'chi-tiet-mail-tuyen-dung',
        },
    },
    // cau hinh
    {
        path: 'cau-hinh',
        component: src_app_components_ns_tuyen_dung_ns_cau_hinh_ns_cau_hinh_component__WEBPACK_IMPORTED_MODULE_12__.NsCauHinhComponent,
        data: {
            title: 'Cấu hình',
            url: 'cau-hinh',
        },
    },
];
class TuyenDungRoutingModule {
}
TuyenDungRoutingModule.ɵfac = function TuyenDungRoutingModule_Factory(t) { return new (t || TuyenDungRoutingModule)(); };
TuyenDungRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineNgModule"]({ type: TuyenDungRoutingModule });
TuyenDungRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsetNgModuleScope"](TuyenDungRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule] }); })();


/***/ }),

/***/ 68171:
/*!*******************************************************!*\
  !*** ./src/app/pages/tuyen-dung/tuyen-dung.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TuyenDungModule": () => (/* binding */ TuyenDungModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_tree__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! primeng/tree */ 35295);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! primeng/table */ 43750);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! primeng/multiselect */ 92487);
/* harmony import */ var src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/list-grid-angular/list-grid-angular.module */ 8145);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! primeng/splitbutton */ 71494);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! primeng/autocomplete */ 17611);
/* harmony import */ var src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/edit-detail/edit-detail.module */ 38160);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! primeng/fileupload */ 83735);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_card__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! primeng/card */ 33506);
/* harmony import */ var primeng_badge__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! primeng/badge */ 62051);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! primeng/tooltip */ 39243);
/* harmony import */ var primeng_slider__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! primeng/slider */ 52340);
/* harmony import */ var src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/pipe/currency-pipe.module */ 44093);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_67__ = __webpack_require__(/*! @ag-grid-community/angular */ 11775);
/* harmony import */ var src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component */ 75137);
/* harmony import */ var src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component-1 */ 90457);
/* harmony import */ var primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(/*! primeng/confirmdialog */ 71849);
/* harmony import */ var primeng_sidebar__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! primeng/sidebar */ 65357);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var primeng_messages__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! primeng/messages */ 93713);
/* harmony import */ var primeng_message__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! primeng/message */ 15357);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-tuyen-dung.component */ 31028);
/* harmony import */ var src_app_components_ns_tuyen_dung_vi_tri_tuyen_dung_vi_tri_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/vi-tri-tuyen-dung/vi-tri-tuyen-dung.component */ 72185);
/* harmony import */ var src_app_components_ns_tuyen_dung_linh_vuc_tuyen_dung_linh_vuc_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/linh-vuc-tuyen-dung/linh-vuc-tuyen-dung.component */ 56546);
/* harmony import */ var src_app_components_ns_tuyen_dung_chi_tiet_tuyen_dung_chi_tiet_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/chi-tiet-tuyen-dung/chi-tiet-tuyen-dung.component */ 71398);
/* harmony import */ var src_app_components_ns_tuyen_dung_chi_tiet_vi_tri_tuyen_dung_chi_tiet_vi_tri_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/chi-tiet-vi-tri-tuyen-dung/chi-tiet-vi-tri-tuyen-dung.component */ 63669);
/* harmony import */ var src_app_components_ns_tuyen_dung_chi_tiet_linh_vuc_tuyen_dung_chi_tiet_linh_vuc_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/chi-tiet-linh-vuc-tuyen-dung/chi-tiet-linh-vuc-tuyen-dung.component */ 8415);
/* harmony import */ var primeng_image__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(/*! primeng/image */ 98907);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! primeng/organizationchart */ 87051);
/* harmony import */ var primeng_listbox__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! primeng/listbox */ 61529);
/* harmony import */ var primeng_panel__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! primeng/panel */ 53581);
/* harmony import */ var primeng_selectbutton__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! primeng/selectbutton */ 22798);
/* harmony import */ var primeng_timeline__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! primeng/timeline */ 4679);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var src_app_components_ns_ho_so_nhan_su_user_detail_user_detail_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/components/ns-ho-so-nhan-su/user-detail/user-detail.module */ 41112);
/* harmony import */ var src_app_components_ns_ho_so_nhan_su_detail_account_detail_account_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/components/ns-ho-so-nhan-su/detail-account/detail-account.module */ 26153);
/* harmony import */ var src_app_common_upload_file_upload_file_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/common/upload-file/upload-file.module */ 48290);
/* harmony import */ var src_app_components_ns_ho_so_nhan_su_emp_attach_file_emp_attach_file_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/components/ns-ho-so-nhan-su/emp-attach-file/emp-attach-file.module */ 40242);
/* harmony import */ var _tuyen_dung_routing_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./tuyen-dung-routing.module */ 28630);
/* harmony import */ var src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/common/hrm-breadcrumb/hrm-breadcrumb.module */ 38040);
/* harmony import */ var src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/common/config-grid-table-form/config-grid-table-form.module */ 45092);
/* harmony import */ var src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/directive/check-action.module */ 69389);
/* harmony import */ var src_app_components_ns_tuyen_dung_nghi_viec_nghi_viec_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/nghi-viec/nghi-viec.component */ 82063);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_65__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_66__ = __webpack_require__(/*! primeng/radiobutton */ 95143);
/* harmony import */ var src_app_components_ns_tuyen_dung_mail_tuyen_dung_mail_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/mail-tuyen-dung/mail-tuyen-dung.component */ 47642);
/* harmony import */ var src_app_components_ns_tuyen_dung_mail_tuyen_dung_chi_tiet_mail_tuyen_dung_chi_tiet_mail_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/mail-tuyen-dung/chi-tiet-mail-tuyen-dung/chi-tiet-mail-tuyen-dung.component */ 34278);
/* harmony import */ var src_app_components_ns_tuyen_dung_import_tuyen_dung_import_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/import-tuyen-dung/import-tuyen-dung.component */ 16285);
/* harmony import */ var src_app_components_ns_tuyen_dung_ds_tiem_nang_ds_tiem_nang_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ds-tiem-nang/ds-tiem-nang.component */ 97816);
/* harmony import */ var src_app_components_ns_tuyen_dung_mail_da_gui_mail_da_gui_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/mail-da-gui/mail-da-gui.component */ 30361);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_cau_hinh_ns_cau_hinh_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/ns-cau-hinh.component */ 12413);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_cau_hinh_vong_tuyen_dung_vong_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/vong-tuyen-dung/vong-tuyen-dung.component */ 92488);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_cau_hinh_vong_tuyen_dung_chi_tiet_vong_tuyen_dung_chi_tiet_vong_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/vong-tuyen-dung/chi-tiet-vong-tuyen-dung/chi-tiet-vong-tuyen-dung.component */ 28885);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_cau_hinh_ns_cau_hinh_mail_ns_cau_hinh_mail_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/ns-cau-hinh-mail/ns-cau-hinh-mail.component */ 4985);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_cau_hinh_nguon_tuyen_dung_nguon_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/nguon-tuyen-dung/nguon-tuyen-dung.component */ 27074);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_cau_hinh_nguon_tuyen_dung_chi_tiet_nguon_tuyen_dung_chi_tiet_nguon_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/nguon-tuyen-dung/chi-tiet-nguon-tuyen-dung/chi-tiet-nguon-tuyen-dung.component */ 84203);
/* harmony import */ var src_app_components_ns_tuyen_dung_ns_cau_hinh_ns_cau_hinh_mail_chi_tiet_cau_hinh_mail_chi_tiet_ns_cau_hinh_mail_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! src/app/components/ns-tuyen-dung/ns-cau-hinh/ns-cau-hinh-mail/chi-tiet-cau-hinh-mail/chi-tiet-ns-cau-hinh-mail.component */ 34918);
/* harmony import */ var src_app_common_hrm_steps_hrm_step_module__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! src/app/common/hrm-steps/hrm-step.module */ 91086);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/core */ 14001);





































































class TuyenDungModule {
}
TuyenDungModule.ɵfac = function TuyenDungModule_Factory(t) { return new (t || TuyenDungModule)(); };
TuyenDungModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_33__["ɵɵdefineNgModule"]({ type: TuyenDungModule });
TuyenDungModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_33__["ɵɵdefineInjector"]({ providers: [], imports: [[
            primeng_messages__WEBPACK_IMPORTED_MODULE_34__.MessagesModule,
            primeng_message__WEBPACK_IMPORTED_MODULE_35__.MessageModule,
            primeng_selectbutton__WEBPACK_IMPORTED_MODULE_36__.SelectButtonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_37__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_37__.ReactiveFormsModule,
            primeng_panel__WEBPACK_IMPORTED_MODULE_38__.PanelModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_39__.CommonModule,
            primeng_tree__WEBPACK_IMPORTED_MODULE_40__.TreeModule,
            primeng_timeline__WEBPACK_IMPORTED_MODULE_41__.TimelineModule,
            primeng_table__WEBPACK_IMPORTED_MODULE_42__.TableModule,
            primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_43__.OverlayPanelModule,
            primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_44__.BreadcrumbModule,
            src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_17__.ConfigGridTableFormModule,
            src_app_components_ns_ho_so_nhan_su_detail_account_detail_account_module__WEBPACK_IMPORTED_MODULE_12__.DetailAccountModule,
            primeng_listbox__WEBPACK_IMPORTED_MODULE_45__.ListboxModule,
            src_app_components_ns_ho_so_nhan_su_user_detail_user_detail_module__WEBPACK_IMPORTED_MODULE_11__.UserDetailModule,
            primeng_multiselect__WEBPACK_IMPORTED_MODULE_46__.MultiSelectModule,
            src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularModule,
            primeng_paginator__WEBPACK_IMPORTED_MODULE_47__.PaginatorModule,
            primeng_button__WEBPACK_IMPORTED_MODULE_48__.ButtonModule,
            primeng_splitbutton__WEBPACK_IMPORTED_MODULE_49__.SplitButtonModule,
            primeng_calendar__WEBPACK_IMPORTED_MODULE_50__.CalendarModule,
            primeng_autocomplete__WEBPACK_IMPORTED_MODULE_51__.AutoCompleteModule,
            src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__.EditDetailModule,
            primeng_fileupload__WEBPACK_IMPORTED_MODULE_52__.FileUploadModule,
            primeng_menu__WEBPACK_IMPORTED_MODULE_53__.MenuModule,
            primeng_card__WEBPACK_IMPORTED_MODULE_54__.CardModule,
            primeng_organizationchart__WEBPACK_IMPORTED_MODULE_55__.OrganizationChartModule,
            primeng_badge__WEBPACK_IMPORTED_MODULE_56__.BadgeModule,
            primeng_tooltip__WEBPACK_IMPORTED_MODULE_57__.TooltipModule,
            primeng_slider__WEBPACK_IMPORTED_MODULE_58__.SliderModule,
            primeng_sidebar__WEBPACK_IMPORTED_MODULE_59__.SidebarModule,
            _tuyen_dung_routing_module__WEBPACK_IMPORTED_MODULE_15__.TuyenDungRoutingModule,
            src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__.CurrencyFormatPipeModule,
            primeng_dialog__WEBPACK_IMPORTED_MODULE_60__.DialogModule,
            primeng_image__WEBPACK_IMPORTED_MODULE_61__.ImageModule,
            primeng_dropdown__WEBPACK_IMPORTED_MODULE_62__.DropdownModule,
            primeng_tabview__WEBPACK_IMPORTED_MODULE_63__.TabViewModule,
            primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_64__.ConfirmDialogModule,
            src_app_common_upload_file_upload_file_module__WEBPACK_IMPORTED_MODULE_13__.UploadFileModule,
            src_app_components_ns_ho_so_nhan_su_emp_attach_file_emp_attach_file_module__WEBPACK_IMPORTED_MODULE_14__.EmpAttachFileModule,
            src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_16__.HrmBreadCrumbModule,
            src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_18__.CheckHideActionsDirectiveModule,
            primeng_treeselect__WEBPACK_IMPORTED_MODULE_65__.TreeSelectModule,
            primeng_radiobutton__WEBPACK_IMPORTED_MODULE_66__.RadioButtonModule,
            _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_67__.AgGridModule.withComponents([
                src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_3__.ButtonRendererComponent,
                src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_4__.ButtonRendererComponent1
            ]),
            src_app_common_hrm_steps_hrm_step_module__WEBPACK_IMPORTED_MODULE_32__.HrmStepModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_33__["ɵɵsetNgModuleScope"](TuyenDungModule, { declarations: [src_app_components_ns_tuyen_dung_ns_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_5__.NsTuyenDungComponent,
        src_app_components_ns_tuyen_dung_vi_tri_tuyen_dung_vi_tri_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_6__.ViTriTuyenDungComponent,
        src_app_components_ns_tuyen_dung_linh_vuc_tuyen_dung_linh_vuc_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_7__.LinhVucTuyenDungComponent,
        src_app_components_ns_tuyen_dung_chi_tiet_linh_vuc_tuyen_dung_chi_tiet_linh_vuc_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_10__.ChiTietLinhVucTuyenDungComponent,
        src_app_components_ns_tuyen_dung_chi_tiet_tuyen_dung_chi_tiet_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_8__.ChiTietTuyenDungComponent,
        src_app_components_ns_tuyen_dung_chi_tiet_vi_tri_tuyen_dung_chi_tiet_vi_tri_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_9__.ChiTietViTriTuyenDungComponent,
        src_app_components_ns_tuyen_dung_nghi_viec_nghi_viec_component__WEBPACK_IMPORTED_MODULE_19__.NghiViecComponent,
        src_app_components_ns_tuyen_dung_mail_tuyen_dung_mail_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_20__.MailTuyenDungComponent,
        src_app_components_ns_tuyen_dung_mail_tuyen_dung_chi_tiet_mail_tuyen_dung_chi_tiet_mail_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_21__.ChiTietMailTuyenDungComponent,
        src_app_components_ns_tuyen_dung_import_tuyen_dung_import_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_22__.ImportTuyenDungComponent,
        src_app_components_ns_tuyen_dung_ds_tiem_nang_ds_tiem_nang_component__WEBPACK_IMPORTED_MODULE_23__.DsTiemNangComponent,
        src_app_components_ns_tuyen_dung_mail_da_gui_mail_da_gui_component__WEBPACK_IMPORTED_MODULE_24__.MailDaGuiComponent,
        src_app_components_ns_tuyen_dung_ns_cau_hinh_ns_cau_hinh_component__WEBPACK_IMPORTED_MODULE_25__.NsCauHinhComponent,
        src_app_components_ns_tuyen_dung_ns_cau_hinh_vong_tuyen_dung_vong_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_26__.VongTuyenDungComponent,
        src_app_components_ns_tuyen_dung_ns_cau_hinh_vong_tuyen_dung_chi_tiet_vong_tuyen_dung_chi_tiet_vong_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_27__.ChiTietVongTuyenDungComponent,
        src_app_components_ns_tuyen_dung_ns_cau_hinh_ns_cau_hinh_mail_ns_cau_hinh_mail_component__WEBPACK_IMPORTED_MODULE_28__.NsCauHinhMailComponent,
        src_app_components_ns_tuyen_dung_ns_cau_hinh_nguon_tuyen_dung_nguon_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_29__.NguonTuyenDungComponent,
        src_app_components_ns_tuyen_dung_ns_cau_hinh_nguon_tuyen_dung_chi_tiet_nguon_tuyen_dung_chi_tiet_nguon_tuyen_dung_component__WEBPACK_IMPORTED_MODULE_30__.ChiTietNguonTuyenDungComponent,
        src_app_components_ns_tuyen_dung_ns_cau_hinh_ns_cau_hinh_mail_chi_tiet_cau_hinh_mail_chi_tiet_ns_cau_hinh_mail_component__WEBPACK_IMPORTED_MODULE_31__.NsChiTietCauHinhMailComponent], imports: [primeng_messages__WEBPACK_IMPORTED_MODULE_34__.MessagesModule,
        primeng_message__WEBPACK_IMPORTED_MODULE_35__.MessageModule,
        primeng_selectbutton__WEBPACK_IMPORTED_MODULE_36__.SelectButtonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_37__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_37__.ReactiveFormsModule,
        primeng_panel__WEBPACK_IMPORTED_MODULE_38__.PanelModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_39__.CommonModule,
        primeng_tree__WEBPACK_IMPORTED_MODULE_40__.TreeModule,
        primeng_timeline__WEBPACK_IMPORTED_MODULE_41__.TimelineModule,
        primeng_table__WEBPACK_IMPORTED_MODULE_42__.TableModule,
        primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_43__.OverlayPanelModule,
        primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_44__.BreadcrumbModule,
        src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_17__.ConfigGridTableFormModule,
        src_app_components_ns_ho_so_nhan_su_detail_account_detail_account_module__WEBPACK_IMPORTED_MODULE_12__.DetailAccountModule,
        primeng_listbox__WEBPACK_IMPORTED_MODULE_45__.ListboxModule,
        src_app_components_ns_ho_so_nhan_su_user_detail_user_detail_module__WEBPACK_IMPORTED_MODULE_11__.UserDetailModule,
        primeng_multiselect__WEBPACK_IMPORTED_MODULE_46__.MultiSelectModule,
        src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularModule,
        primeng_paginator__WEBPACK_IMPORTED_MODULE_47__.PaginatorModule,
        primeng_button__WEBPACK_IMPORTED_MODULE_48__.ButtonModule,
        primeng_splitbutton__WEBPACK_IMPORTED_MODULE_49__.SplitButtonModule,
        primeng_calendar__WEBPACK_IMPORTED_MODULE_50__.CalendarModule,
        primeng_autocomplete__WEBPACK_IMPORTED_MODULE_51__.AutoCompleteModule,
        src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__.EditDetailModule,
        primeng_fileupload__WEBPACK_IMPORTED_MODULE_52__.FileUploadModule,
        primeng_menu__WEBPACK_IMPORTED_MODULE_53__.MenuModule,
        primeng_card__WEBPACK_IMPORTED_MODULE_54__.CardModule,
        primeng_organizationchart__WEBPACK_IMPORTED_MODULE_55__.OrganizationChartModule,
        primeng_badge__WEBPACK_IMPORTED_MODULE_56__.BadgeModule,
        primeng_tooltip__WEBPACK_IMPORTED_MODULE_57__.TooltipModule,
        primeng_slider__WEBPACK_IMPORTED_MODULE_58__.SliderModule,
        primeng_sidebar__WEBPACK_IMPORTED_MODULE_59__.SidebarModule,
        _tuyen_dung_routing_module__WEBPACK_IMPORTED_MODULE_15__.TuyenDungRoutingModule,
        src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__.CurrencyFormatPipeModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_60__.DialogModule,
        primeng_image__WEBPACK_IMPORTED_MODULE_61__.ImageModule,
        primeng_dropdown__WEBPACK_IMPORTED_MODULE_62__.DropdownModule,
        primeng_tabview__WEBPACK_IMPORTED_MODULE_63__.TabViewModule,
        primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_64__.ConfirmDialogModule,
        src_app_common_upload_file_upload_file_module__WEBPACK_IMPORTED_MODULE_13__.UploadFileModule,
        src_app_components_ns_ho_so_nhan_su_emp_attach_file_emp_attach_file_module__WEBPACK_IMPORTED_MODULE_14__.EmpAttachFileModule,
        src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_16__.HrmBreadCrumbModule,
        src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_18__.CheckHideActionsDirectiveModule,
        primeng_treeselect__WEBPACK_IMPORTED_MODULE_65__.TreeSelectModule,
        primeng_radiobutton__WEBPACK_IMPORTED_MODULE_66__.RadioButtonModule, _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_67__.AgGridModule, src_app_common_hrm_steps_hrm_step_module__WEBPACK_IMPORTED_MODULE_32__.HrmStepModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_pages_tuyen-dung_tuyen-dung_module_ts.fdd107a770d215b3.js.map