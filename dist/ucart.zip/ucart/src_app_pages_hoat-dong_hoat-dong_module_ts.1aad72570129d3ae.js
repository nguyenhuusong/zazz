"use strict";
(self["webpackChunkucart"] = self["webpackChunkucart"] || []).push([["src_app_pages_hoat-dong_hoat-dong_module_ts"],{

/***/ 19589:
/*!*************************************************************!*\
  !*** ./src/app/pages/hoat-dong/hoat-dong-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HoatDongRoutingModule": () => (/* binding */ HoatDongRoutingModule)
/* harmony export */ });
/* harmony import */ var _components_bieu_mau_bieu_mau_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../components/bieu-mau/bieu-mau.component */ 4795);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var src_app_components_bieu_mau_loai_bieu_mau_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/components/bieu-mau/loai-bieu-mau/loai-bieu-mau.component */ 72521);
/* harmony import */ var src_app_components_cai_dat_lich_hop_cai_dat_lich_hop_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/cai-dat-lich-hop/cai-dat-lich-hop.component */ 25726);
/* harmony import */ var src_app_components_cai_dat_lich_hop_danh_sach_phong_hop_danh_sach_phong_hop_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/components/cai-dat-lich-hop/danh-sach-phong-hop/danh-sach-phong-hop.component */ 74973);
/* harmony import */ var src_app_components_cai_dat_lich_hop_danh_sach_phong_hop_chi_tiet_phong_hop_chi_tiet_phong_hop_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/components/cai-dat-lich-hop/danh-sach-phong-hop/chi-tiet-phong-hop/chi-tiet-phong-hop.component */ 57365);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 14001);








const routes = [
    {
        path: "",
        redirectTo: "",
        pathMatch: 'full'
    },
    {
        path: 'tai-lieu-chung',
        component: _components_bieu_mau_bieu_mau_component__WEBPACK_IMPORTED_MODULE_0__.BieuMauComponent,
        data: {
            title: 'Tài liệu chung',
            url: 'tai-lieu-chung',
        },
    },
    {
        path: 'loai-tai-lieu',
        component: src_app_components_bieu_mau_loai_bieu_mau_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_1__.LoaiBieuMauComponent,
        data: {
            title: 'Loại tài liệu',
            url: 'loai-tai-lieu',
        },
    },
    {
        path: 'lich-hop',
        component: src_app_components_cai_dat_lich_hop_cai_dat_lich_hop_component__WEBPACK_IMPORTED_MODULE_2__.CaiDatLichHopComponent,
        data: {
            title: 'Quản lý lịch họp',
            url: 'lich-hop',
        },
    },
    {
        path: 'lich-hop/danh-sach-phong-hop',
        component: src_app_components_cai_dat_lich_hop_danh_sach_phong_hop_danh_sach_phong_hop_component__WEBPACK_IMPORTED_MODULE_3__.DanhSachPhongHopComponent,
        data: {
            title: 'Phòng họp',
            url: 'danh-sach-phong-hop',
        },
    },
    {
        path: 'lich-hop/danh-sach-phong-hop/them-moi-phong-hop',
        component: src_app_components_cai_dat_lich_hop_danh_sach_phong_hop_chi_tiet_phong_hop_chi_tiet_phong_hop_component__WEBPACK_IMPORTED_MODULE_4__.ChiTietPhongHopComponent,
        data: {
            title: 'Thêm mới phòng họp',
            url: 'them-moi-phong-hop',
        },
    },
    {
        path: 'lich-hop/danh-sach-phong-hop/chi-tiet-phong-hop',
        component: src_app_components_cai_dat_lich_hop_danh_sach_phong_hop_chi_tiet_phong_hop_chi_tiet_phong_hop_component__WEBPACK_IMPORTED_MODULE_4__.ChiTietPhongHopComponent,
        data: {
            title: 'Chi tiết phòng họp',
            url: 'chi-tiet-phong-hop',
        },
    },
];
class HoatDongRoutingModule {
}
HoatDongRoutingModule.ɵfac = function HoatDongRoutingModule_Factory(t) { return new (t || HoatDongRoutingModule)(); };
HoatDongRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({ type: HoatDongRoutingModule });
HoatDongRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](HoatDongRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule] }); })();


/***/ }),

/***/ 49084:
/*!*****************************************************!*\
  !*** ./src/app/pages/hoat-dong/hoat-dong.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HoatDongModule": () => (/* binding */ HoatDongModule)
/* harmony export */ });
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! primeng/organizationchart */ 87051);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_tree__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/tree */ 35295);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/table */ 43750);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/multiselect */ 92487);
/* harmony import */ var src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/list-grid-angular/list-grid-angular.module */ 8145);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/splitbutton */ 71494);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/autocomplete */ 17611);
/* harmony import */ var src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/edit-detail/edit-detail.module */ 38160);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/fileupload */ 83735);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_card__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/card */ 33506);
/* harmony import */ var primeng_badge__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/badge */ 62051);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/tooltip */ 39243);
/* harmony import */ var primeng_slider__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/slider */ 52340);
/* harmony import */ var src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/pipe/currency-pipe.module */ 44093);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @ag-grid-community/angular */ 11775);
/* harmony import */ var src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component */ 75137);
/* harmony import */ var src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component-1 */ 90457);
/* harmony import */ var primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! primeng/confirmdialog */ 71849);
/* harmony import */ var primeng_sidebar__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/sidebar */ 65357);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var primeng_messages__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/messages */ 93713);
/* harmony import */ var primeng_message__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/message */ 15357);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/hrm-breadcrumb/hrm-breadcrumb.module */ 38040);
/* harmony import */ var primeng_checkbox__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/checkbox */ 77588);
/* harmony import */ var src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/config-grid-table-form/config-grid-table-form.module */ 45092);
/* harmony import */ var _hoat_dong_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./hoat-dong-routing.module */ 19589);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 14001);







































class HoatDongModule {
}
HoatDongModule.ɵfac = function HoatDongModule_Factory(t) { return new (t || HoatDongModule)(); };
HoatDongModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({ type: HoatDongModule });
HoatDongModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({ providers: [], imports: [[
            primeng_messages__WEBPACK_IMPORTED_MODULE_9__.MessagesModule,
            primeng_message__WEBPACK_IMPORTED_MODULE_10__.MessageModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.ReactiveFormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule,
            primeng_tree__WEBPACK_IMPORTED_MODULE_13__.TreeModule,
            primeng_table__WEBPACK_IMPORTED_MODULE_14__.TableModule,
            primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_15__.BreadcrumbModule,
            primeng_checkbox__WEBPACK_IMPORTED_MODULE_16__.CheckboxModule,
            primeng_multiselect__WEBPACK_IMPORTED_MODULE_17__.MultiSelectModule,
            src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularModule,
            primeng_paginator__WEBPACK_IMPORTED_MODULE_18__.PaginatorModule,
            primeng_button__WEBPACK_IMPORTED_MODULE_19__.ButtonModule,
            primeng_splitbutton__WEBPACK_IMPORTED_MODULE_20__.SplitButtonModule,
            primeng_calendar__WEBPACK_IMPORTED_MODULE_21__.CalendarModule,
            primeng_autocomplete__WEBPACK_IMPORTED_MODULE_22__.AutoCompleteModule,
            src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__.EditDetailModule,
            primeng_fileupload__WEBPACK_IMPORTED_MODULE_23__.FileUploadModule,
            primeng_menu__WEBPACK_IMPORTED_MODULE_24__.MenuModule,
            primeng_card__WEBPACK_IMPORTED_MODULE_25__.CardModule,
            primeng_badge__WEBPACK_IMPORTED_MODULE_26__.BadgeModule,
            primeng_tooltip__WEBPACK_IMPORTED_MODULE_27__.TooltipModule,
            primeng_slider__WEBPACK_IMPORTED_MODULE_28__.SliderModule,
            primeng_sidebar__WEBPACK_IMPORTED_MODULE_29__.SidebarModule,
            src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__.CurrencyFormatPipeModule,
            primeng_dialog__WEBPACK_IMPORTED_MODULE_30__.DialogModule,
            primeng_dropdown__WEBPACK_IMPORTED_MODULE_31__.DropdownModule,
            primeng_tabview__WEBPACK_IMPORTED_MODULE_32__.TabViewModule,
            primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_33__.ConfirmDialogModule,
            primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_34__.OverlayPanelModule,
            primeng_treeselect__WEBPACK_IMPORTED_MODULE_35__.TreeSelectModule,
            src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_5__.HrmBreadCrumbModule,
            primeng_organizationchart__WEBPACK_IMPORTED_MODULE_36__.OrganizationChartModule,
            src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_6__.ConfigGridTableFormModule,
            _hoat_dong_routing_module__WEBPACK_IMPORTED_MODULE_7__.HoatDongRoutingModule,
            _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_37__.AgGridModule.withComponents([
                src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_3__.ButtonRendererComponent,
                src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_4__.ButtonRendererComponent1,
            ]),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](HoatDongModule, { imports: [primeng_messages__WEBPACK_IMPORTED_MODULE_9__.MessagesModule,
        primeng_message__WEBPACK_IMPORTED_MODULE_10__.MessageModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_11__.ReactiveFormsModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule,
        primeng_tree__WEBPACK_IMPORTED_MODULE_13__.TreeModule,
        primeng_table__WEBPACK_IMPORTED_MODULE_14__.TableModule,
        primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_15__.BreadcrumbModule,
        primeng_checkbox__WEBPACK_IMPORTED_MODULE_16__.CheckboxModule,
        primeng_multiselect__WEBPACK_IMPORTED_MODULE_17__.MultiSelectModule,
        src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularModule,
        primeng_paginator__WEBPACK_IMPORTED_MODULE_18__.PaginatorModule,
        primeng_button__WEBPACK_IMPORTED_MODULE_19__.ButtonModule,
        primeng_splitbutton__WEBPACK_IMPORTED_MODULE_20__.SplitButtonModule,
        primeng_calendar__WEBPACK_IMPORTED_MODULE_21__.CalendarModule,
        primeng_autocomplete__WEBPACK_IMPORTED_MODULE_22__.AutoCompleteModule,
        src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__.EditDetailModule,
        primeng_fileupload__WEBPACK_IMPORTED_MODULE_23__.FileUploadModule,
        primeng_menu__WEBPACK_IMPORTED_MODULE_24__.MenuModule,
        primeng_card__WEBPACK_IMPORTED_MODULE_25__.CardModule,
        primeng_badge__WEBPACK_IMPORTED_MODULE_26__.BadgeModule,
        primeng_tooltip__WEBPACK_IMPORTED_MODULE_27__.TooltipModule,
        primeng_slider__WEBPACK_IMPORTED_MODULE_28__.SliderModule,
        primeng_sidebar__WEBPACK_IMPORTED_MODULE_29__.SidebarModule,
        src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__.CurrencyFormatPipeModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_30__.DialogModule,
        primeng_dropdown__WEBPACK_IMPORTED_MODULE_31__.DropdownModule,
        primeng_tabview__WEBPACK_IMPORTED_MODULE_32__.TabViewModule,
        primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_33__.ConfirmDialogModule,
        primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_34__.OverlayPanelModule,
        primeng_treeselect__WEBPACK_IMPORTED_MODULE_35__.TreeSelectModule,
        src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_5__.HrmBreadCrumbModule,
        primeng_organizationchart__WEBPACK_IMPORTED_MODULE_36__.OrganizationChartModule,
        src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_6__.ConfigGridTableFormModule,
        _hoat_dong_routing_module__WEBPACK_IMPORTED_MODULE_7__.HoatDongRoutingModule, _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_37__.AgGridModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_pages_hoat-dong_hoat-dong_module_ts.1aad72570129d3ae.js.map