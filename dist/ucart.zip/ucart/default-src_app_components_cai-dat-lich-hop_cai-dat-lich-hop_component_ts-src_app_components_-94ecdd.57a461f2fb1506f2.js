"use strict";
(self["webpackChunkucart"] = self["webpackChunkucart"] || []).push([["default-src_app_components_cai-dat-lich-hop_cai-dat-lich-hop_component_ts-src_app_components_-94ecdd"],{

/***/ 25726:
/*!***************************************************************************!*\
  !*** ./src/app/components/cai-dat-lich-hop/cai-dat-lich-hop.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CaiDatLichHopComponent": () => (/* binding */ CaiDatLichHopComponent)
/* harmony export */ });
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/calendar */ 6582);































function CaiDatLichHopComponent_ng_template_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](item_r8.label);
} }
function CaiDatLichHopComponent_ng_template_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](car_r9.label);
} }
function CaiDatLichHopComponent_app_list_grid_angular_37_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-list-grid-angular", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("showConfig", function CaiDatLichHopComponent_app_list_grid_angular_37_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r11); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r10.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("listsData", ctx_r3.listsData)("height", ctx_r3.heightGrid)("columnDefs", ctx_r3.columnDefs);
} }
function CaiDatLichHopComponent_app_config_grid_table_form_43_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-config-grid-table-form", 48);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r4.gridKey);
} }
function CaiDatLichHopComponent_ng_template_54_Template(rf, ctx) { if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "button", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function CaiDatLichHopComponent_ng_template_54_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r13); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r12.isReasonDelete = !ctx_r12.isReasonDelete; });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "p-button", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function CaiDatLichHopComponent_ng_template_54_Template_p_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r13); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r14.deleteLichHop(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2, " Th\u1EF1c hi\u1EC7n ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} }
function CaiDatLichHopComponent_ng_template_57_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](item_r17.label);
} }
function CaiDatLichHopComponent_ng_template_57_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r18 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](car_r18.label);
} }
function CaiDatLichHopComponent_ng_template_57_Template(rf, ctx) { if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](8, "T\u1EA7ng l\u00E0m vi\u1EC7c");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "p-dropdown", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function CaiDatLichHopComponent_ng_template_57_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r20); const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r19.model.Floor_No = $event; })("onChange", function CaiDatLichHopComponent_ng_template_57_Template_p_dropdown_onChange_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r20); const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r21.find(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](10, CaiDatLichHopComponent_ng_template_57_ng_template_10_Template, 2, 1, "ng-template", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](11, CaiDatLichHopComponent_ng_template_57_ng_template_11_Template, 3, 1, "ng-template", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](14, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](15, "T\u1EEB ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](16, "p-calendar", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function CaiDatLichHopComponent_ng_template_57_Template_p_calendar_ngModelChange_16_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r20); const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r22.model.fromDate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](18, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](20, "\u0110\u1EBFn ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](21, "p-calendar", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function CaiDatLichHopComponent_ng_template_57_Template_p_calendar_ngModelChange_21_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r20); const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r23.model.toDate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](22, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](23, "label", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](24, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](25, "span", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](26, "p-button", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function CaiDatLichHopComponent_ng_template_57_Template_p_button_click_26_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r20); const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r24.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](27, "p-button", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function CaiDatLichHopComponent_ng_template_57_Template_p_button_click_27_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r20); const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r25.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r7.floors)("ngModel", ctx_r7.model.Floor_No);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r7.model.fromDate)("monthNavigator", true)("yearNavigator", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r7.model.toDate)("monthNavigator", true)("yearNavigator", true);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { showAll: "ALL" }; };
const _c2 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c3 = function () { return { width: "50vw" }; };
const _c4 = function () { return { width: "600px" }; };
const _c5 = function () { return { width: "500px" }; };
class CaiDatLichHopComponent {
    constructor(apiService, router, messageService, confirmationService, spinner, changeDetector, organizeInfoService) {
        this.apiService = apiService;
        this.router = router;
        this.messageService = messageService;
        this.confirmationService = confirmationService;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_0__.AllModules;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.loading = false;
        this.cards = [];
        this.first = 0;
        this.organs = [];
        this.isHrDiagram = false;
        this.detailOrganizeMap = null;
        this.model = {
            filter: '',
            gridWidth: '',
            offSet: 0,
            pageSize: 15,
            Floor_No: '',
            Meet_status: '',
            Time: null,
            organization: '',
            fromDate: new Date(moment__WEBPACK_IMPORTED_MODULE_6__(new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate())).format("YYYY-MM-DD")),
            toDate: new Date(moment__WEBPACK_IMPORTED_MODULE_6__(new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate())).format("YYYY-MM-DD")),
            organizeIds: '',
        };
        this.statusRoom = [
            {
                label: 'Đã họp',
                value: "Đã họp",
            },
            {
                label: 'Đang họp',
                value: "Đang họp"
            },
            {
                label: 'Sắp họp',
                value: "Sắp họp"
            },
            {
                label: 'Đã lên lịch',
                value: "Đã lên lịch"
            },
        ];
        this.totalRecord = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.companies = [];
        this.pagingComponent = {
            total: 0
        };
        this.showDeleteTax = false;
        this.showImportExcel = false;
        this.items = [];
        this.loadjs = 0;
        this.heightGrid = 0;
        this.displaySetting = false;
        this.gridKey = '';
        this.listsData = [];
        this.floors = [];
        this.isReasonDelete = false;
        this.queryDeleteLichHop = {
            meet_ud: '',
            reason_cancel: ''
        };
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 38;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__.ButtonAgGridComponent,
        };
        this.initFilter();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.model.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Hoạt động' },
            { label: 'Lịch họp' },
        ];
        this.getFloor();
        this.getOrgan();
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                const totalHeight = a.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
                this.loadjs = 0;
            }
        }
    }
    initFilter() {
        this.model = {
            filter: '',
            gridWidth: '',
            offSet: 0,
            pageSize: 15,
            Floor_No: '',
            Meet_status: '',
            Time: '',
            organization: '',
            fromDate: new Date(moment__WEBPACK_IMPORTED_MODULE_6__(new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate())).format("YYYY-MM-DD")),
            toDate: new Date(moment__WEBPACK_IMPORTED_MODULE_6__(new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate())).format("YYYY-MM-DD")),
            organizeIds: this.model.organizeIds,
        };
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        // this.model.Time = moment(this.model.Time).format('HH:mm')
        let params = Object.assign({}, this.model);
        params.fromDate = typeof this.model.fromDate === 'object' ? moment__WEBPACK_IMPORTED_MODULE_6__(new Date(this.model.fromDate)).format('YYYY-MM-DD') : this.model.fromDate;
        params.toDate = typeof this.model.toDate === 'object' ? moment__WEBPACK_IMPORTED_MODULE_6__(new Date(this.model.toDate)).format('YYYY-MM-DD') : this.model.toDate;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify(params);
        this.apiService.getMeetingPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.model.offSet === 0) {
                this.gridflexs = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.model.offSet = 0 : this.model.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.model.offSet) > this.model.pageSize) {
                this.countRecord.currentRecordEnd = this.model.offSet + Number(this.model.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            // đã họp và đang họp
            buttons: [
                {
                    onClick: this.handleEdit.bind(this),
                    label: 'Sửa',
                    icon: 'fa fa-pencil-square-o',
                    class: 'btn-primary mr5',
                    hide: this.CheckHideSua(event)
                },
                {
                    onClick: this.handleDelete.bind(this),
                    label: 'Hủy',
                    icon: 'pi pi-times',
                    class: 'btn-danger mr5',
                    hide: this.CheckHideDele(event)
                },
            ]
        };
    }
    CheckHideSua(event) {
        let checkValue = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetMeetingPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.VIEW);
        if (checkValue) {
            return true;
        }
        else {
            if (event.data.is_edit !== 1) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    CheckHideDele(event) {
        if ((0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetMeetingPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.HUY_LICH_HOP)) {
            return true;
        }
        else {
            if (event.data.is_edit !== 1) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: 'STT',
                filter: '',
                maxWidth: 70,
                pinned: 'left',
                cellRenderer: params => {
                    return params.rowIndex + 1;
                },
                cellClass: ['border-right', 'no-auto', 'cell-options'],
                field: 'checkbox2',
                suppressSizeToFit: true,
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.gridflexs.filter((d) => !d.isHide)),
            {
                headerName: '    ...',
                filter: '',
                width: 80,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto', 'text-center', 'cell-options'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    getFloor() {
        this.apiService.getFloorNo().subscribe(results => {
            if (results.status === 'success') {
                this.floors = (results.data).map(d => {
                    return {
                        label: 'Tầng' + ' ' + d.name,
                        value: d.value
                    };
                });
            }
        });
    }
    handleDelete(e) {
        this.isReasonDelete = true;
        this.queryDeleteLichHop.meet_ud = e.rowData.meet_ud;
    }
    deleteLichHop() {
        if (!this.queryDeleteLichHop.reason_cancel) {
            this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: `Vui lòng điền lý do hủy` });
            return;
        }
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn hủy lịch họp không?',
            accept: () => {
                this.apiService.delMeetingInfo(querystring__WEBPACK_IMPORTED_MODULE_1__.stringify(this.queryDeleteLichHop))
                    .subscribe(response => {
                    if (response.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: `Hủy lịch họp thành công` });
                        this.load();
                        this.isReasonDelete = false;
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: `Hủy lịch họp thất bại` });
                    }
                }, error => {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: `Hủy lịch họp thất bại` });
                    this.isReasonDelete = false;
                });
            }
        });
    }
    getOrgan() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.organs = results.data.map(d => {
                    return {
                        label: d.organizationName,
                        value: `${d.organizeId}`
                    };
                });
                this.organs = [...this.organs];
            }
        });
    }
    hrDiagram() {
        this.selectedNode = null;
        this.listAgencyMap = [];
        this.getAgencyOrganizeMap(true);
    }
    selected(datas = [], orgId = '') {
        datas.forEach(d => {
            if (d.orgId == orgId) {
                this.selectedNode = d;
                this.detailOrganizeMap = d;
            }
            else {
                if (d.children.length > 0)
                    this.selected(d.children, this.selectedNode.orgId);
            }
        });
    }
    expanded(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                d.expanded = true;
            }
            else {
                if (d.children.length > 0)
                    this.expanded(d.children, this.selectedNode.parentId);
            }
            d.children.forEach((elm) => {
                elm.children.forEach((e) => {
                    if (e.expanded === true) {
                        elm.expanded = true;
                    }
                });
            });
        });
        return datas;
    }
    getAgencyOrganizeMap(type = false) {
        this.apiService.getAgencyOrganizeMap().subscribe(results => {
            if (results.status === 'success') {
                this.listAgencyMap = [...results.data.root];
                if (localStorage.getItem("organize") === null || localStorage.getItem("organize") === 'undefined') {
                    this.selectedNode = this.listAgencyMap[0];
                    localStorage.setItem('organize', JSON.stringify(this.listAgencyMap[0]));
                    // this.query.organizeId = this.selectedNode.orgId;
                    this.load();
                }
                else {
                    this.selectedNode = JSON.parse(localStorage.getItem("organize"));
                    // this.query.organizeId = this.selectedNode?.orgId;
                    this.listAgencyMap = this.expanded(this.listAgencyMap, this.selectedNode.parentId);
                    this.selected(this.listAgencyMap, this.model.organization);
                    if (type) {
                        this.isHrDiagram = true;
                    }
                    this.load();
                }
            }
        });
    }
    manageBuilding() {
        this.router.navigate(['/cai-dat/cai-dat-lich-hop/danh-sach-phong-hop']);
    }
    handleEdit(e) {
        const params = {
            meet_ud: e.rowData.meet_ud
        };
        this.router.navigate(['/cai-dat/cai-dat-lich-hop/chi-tiet-lich-hop'], { queryParams: params });
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    paginate(event) {
        this.model.offSet = event.first;
        this.first = event.first;
        this.model.pageSize = event.rows;
        this.load();
    }
    handlerError(error) {
        console.log(error);
        if (error.status === 401) {
            this.router.navigate(['/home']);
        }
    }
    find() {
        this.load();
    }
    cancel() {
        this.initFilter();
        this.load();
    }
    changePageSize() {
        this.load();
    }
    handleAdd() {
        const params = {
            meet_ud: ''
        };
        this.router.navigate(['/cai-dat/cai-dat-lich-hop/them-moi-lich-hop'], { queryParams: params });
    }
    toManagerRoom() {
        this.router.navigate(['/hoat-dong/lich-hop/danh-sach-phong-hop']);
    }
    importSuccess() {
        this.load();
        this.showImportExcel = false;
    }
}
CaiDatLichHopComponent.ɵfac = function CaiDatLichHopComponent_Factory(t) { return new (t || CaiDatLichHopComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_16__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__.OrganizeInfoService)); };
CaiDatLichHopComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({ type: CaiDatLichHopComponent, selectors: [["app-cai-dat-lich-hop"]], decls: 58, vars: 50, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-3", "pd-0"], [3, "items", "title"], [1, "d-flex", "end", "mid", "bottom", "gap-12", "col-9", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], [1, "field-group", "select", "mb-0"], ["appendTo", "body", "placeholder", "Ch\u1ECDn tr\u1EA1ng th\u00E1i", "name", "Meet_status", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm mr-1 height-56", 3, "CheckHideActions", "click"], ["d", "M12.4997 8.74441C11.8093 8.74441 11.2497 9.30534 11.2497 9.99729C11.2497 10.6892 11.8093 11.2502 12.4997 11.2502C13.19 11.2502 13.7497 10.6892 13.7497 9.99729C13.7497 9.30534 13.19 8.74441 12.4997 8.74441Z", "fill", "#F6FBFF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M3.33301 0.833496V17.5002H0.833008V19.1668H19.1663V17.5002H16.6663V0.833496H3.33301ZM14.9997 17.5002V2.50016H4.99967V17.5002H14.9997Z", "fill", "#F6FBFF"], ["d", "M11 5H9V9H5V11H9V15H11V11H15V9H11V5ZM10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM10 18C5.59 18 2 14.41 2 10C2 5.59 5.59 2 10 2C14.41 2 18 5.59 18 10C18 14.41 14.41 18 10 18Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["header", "L\u00FD do h\u1EE7y l\u1ECBch h\u1ECDp", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange"], [1, "warm-cool", "d-flex"], [1, "pi", "pi-bookmark-fill"], [1, ""], [1, "field-group", "textarea"], ["placeholder", "L\u00FD do h\u1EE7y l\u1ECBch h\u1ECDp", "required", "", 3, "ngModel", "ngModelChange"], ["pTemplate", "footer"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [3, "listsData", "height", "columnDefs", "showConfig"], [3, "typeConfig", "gridKey"], ["type", "button", "pButton", "", "icon", "pi pi-times", "label", "H\u1EE7y b\u1ECF", 1, "p-button-secondary", "btn-cancel", 3, "click"], ["styleClass", "p-button-sm mr-1 height-56", 3, "click"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-12"], ["appendTo", "body", "placeholder", "---Ch\u1ECDn---", "name", "Floor_No", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange", "onChange"], [1, "field-group", "date", "mb-0", "valid"], ["dateFormat", "dd/mm/yy", "panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "yearRange", "2010:2030", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "fromDate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "yearNavigator", "ngModelChange"], ["dateFormat", "dd/mm/yy", "panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "yearRange", "2010:2030", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "toDate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "yearNavigator", "ngModelChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"]], template: function CaiDatLichHopComponent_Template(rf, ctx) { if (rf & 1) {
        const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("keydown.enter", function CaiDatLichHopComponent_Template_input_keydown_enter_8_listener() { ctx.model.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function CaiDatLichHopComponent_Template_input_ngModelChange_8_listener($event) { return ctx.model.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function CaiDatLichHopComponent_Template_span_click_9_listener() { ctx.model.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function CaiDatLichHopComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](16, "p-dropdown", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function CaiDatLichHopComponent_Template_p_dropdown_ngModelChange_16_listener($event) { return ctx.model.Meet_status = $event; })("onChange", function CaiDatLichHopComponent_Template_p_dropdown_onChange_16_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](17, CaiDatLichHopComponent_ng_template_17_Template, 2, 1, "ng-template", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](18, CaiDatLichHopComponent_ng_template_18_Template, 3, 1, "ng-template", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "p-button", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function CaiDatLichHopComponent_Template_p_button_click_19_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r26); const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](56); return _r6.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](20, "svg", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](21, "path", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](22, "path", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](23, "path", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](24, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](25, "p-button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function CaiDatLichHopComponent_Template_p_button_click_25_listener() { return ctx.toManagerRoom(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](26, "svg", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](27, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](28, "path", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](29, " \u00A0 Qua\u0309n ly\u0301 pho\u0300ng ho\u0323p ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](30, "p-button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function CaiDatLichHopComponent_Template_p_button_click_30_listener() { return ctx.handleAdd(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](31, "svg", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](32, "path", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](33, " \u00A0 Th\u00EAm li\u0323ch ho\u0323p ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](34, "section", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](35, "div", 29, 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](37, CaiDatLichHopComponent_app_list_grid_angular_37_Template, 1, 3, "app-list-grid-angular", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](38, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](39, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](41, "p-paginator", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onPageChange", function CaiDatLichHopComponent_Template_p_paginator_onPageChange_41_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](42, "p-dialog", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("visibleChange", function CaiDatLichHopComponent_Template_p_dialog_visibleChange_42_listener($event) { return ctx.displaySetting = $event; })("onHide", function CaiDatLichHopComponent_Template_p_dialog_onHide_42_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](43, CaiDatLichHopComponent_app_config_grid_table_form_43_Template, 1, 2, "app-config-grid-table-form", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](44, "p-dialog", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("visibleChange", function CaiDatLichHopComponent_Template_p_dialog_visibleChange_44_listener($event) { return ctx.isReasonDelete = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](45, "div", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](46, "span", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](47, "div", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](48, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](49, "Cho bi\u1EBFt l\u00FD do b\u1EA1n mu\u1ED1n h\u1EE7y");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](50, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](51, " L\u00FD do n\u00E0y s\u1EBD \u0111\u01B0\u1EE3c g\u1EEDi \u0111\u1EBFn ng\u01B0\u1EDDi tham gia cu\u1ED9c h\u1ECDp \u0111\u1EC3 n\u1EAFm \u0111\u01B0\u1EE3c \u0111\u1EA7y \u0111\u1EE7 th\u00F4ng tin ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](52, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](53, "textarea", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function CaiDatLichHopComponent_Template_textarea_ngModelChange_53_listener($event) { return ctx.queryDeleteLichHop.reason_cancel = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](54, CaiDatLichHopComponent_ng_template_54_Template, 3, 0, "ng-template", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](55, "p-overlayPanel", 43, 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](57, CaiDatLichHopComponent_ng_template_57_Template, 28, 14, "ng-template", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("items", ctx.items)("title", "Qua\u0309n ly\u0301 li\u0323ch ho\u0323p");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", ctx.model.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.model.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.statusRoom)("ngModel", ctx.model.Meet_status);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](38, _c0, ctx.MENUACTIONROLEAPI.GetMeetingPage.url, ctx.ACTIONS.QUAN_LY_PHONG_HOP));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](41, _c0, ctx.MENUACTIONROLEAPI.GetMeetingPage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.columnDefs && ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("rows", ctx.model.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](45, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](44, _c1)));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](47, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](48, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("visible", ctx.isReasonDelete)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.queryDeleteLichHop.reason_cancel);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](49, _c5));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_19__.Button, primeng_dropdown__WEBPACK_IMPORTED_MODULE_20__.Dropdown, primeng_api__WEBPACK_IMPORTED_MODULE_15__.PrimeTemplate, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_10__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_21__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_22__.Dialog, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.RequiredValidator, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_23__.OverlayPanel, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__.ConfigGridTableFormComponent, primeng_button__WEBPACK_IMPORTED_MODULE_19__.ButtonDirective, primeng_calendar__WEBPACK_IMPORTED_MODULE_24__.Calendar], styles: ["[_nghost-%COMP%]  .noti-number {\n  background: #FF3B49;\n  border-radius: 2px;\n  color: #F3F4F6;\n  padding: 2px 4px;\n}\n[_nghost-%COMP%]  .noti-number::after {\n  display: none;\n}\n[_nghost-%COMP%]  .noti-number.bg-success {\n  background: #FEC318;\n}\n[_nghost-%COMP%]  [col-id=meet_status] {\n  justify-content: center;\n}\n[_nghost-%COMP%]  [col-id=meet_status] .ag-cell-label-container .ag-header-cell-menu-button {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhaS1kYXQtbGljaC1ob3AuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBQVI7QUFDUTtFQUNJLGFBQUE7QUFDWjtBQUNRO0VBQ0ksbUJBQUE7QUFDWjtBQUdJO0VBQ1EsdUJBQUE7QUFEWjtBQUdZO0VBQ0ksYUFBQTtBQURoQiIsImZpbGUiOiJjYWktZGF0LWxpY2gtaG9wLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Q6Om5nLWRlZXB7XHJcbiAgICAubm90aS1udW1iZXJ7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI0ZGM0I0OTtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAycHg7XHJcbiAgICAgICAgY29sb3I6ICNGM0Y0RjY7XHJcbiAgICAgICAgcGFkZGluZzogMnB4IDRweDtcclxuICAgICAgICAmOjphZnRlcntcclxuICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgJi5iZy1zdWNjZXNze1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjRkVDMzE4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBbY29sLWlkPVwibWVldF9zdGF0dXNcIl17XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIC5hZy1jZWxsLWxhYmVsLWNvbnRhaW5lcntcclxuICAgICAgICAgICAgLmFnLWhlYWRlci1jZWxsLW1lbnUtYnV0dG9ue1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */"] });


/***/ }),

/***/ 57365:
/*!********************************************************************************************************************!*\
  !*** ./src/app/components/cai-dat-lich-hop/danh-sach-phong-hop/chi-tiet-phong-hop/chi-tiet-phong-hop.component.ts ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietPhongHopComponent": () => (/* binding */ ChiTietPhongHopComponent)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../common/edit-detail/edit-detail.component */ 58638);
















function ChiTietPhongHopComponent_app_edit_detail_7_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "app-edit-detail", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("callback", function ChiTietPhongHopComponent_app_edit_detail_7_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return ctx_r1.setMeetRoomInfo($event); })("callbackcancel", function ChiTietPhongHopComponent_app_edit_detail_7_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return ctx_r3.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
const queryString = __webpack_require__(/*! query-string */ 31808);
class ChiTietPhongHopComponent {
    constructor(activatedRoute, apiService, spinner, confirmationService, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.MENUACTIONROLEAPI.GetMeetRoomPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.ACTIONS.EDIT) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.url = '';
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this.roomId = null;
        this.titlePage = '';
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Cài đặt' },
            { label: 'Danh sách lịch họp', routerLink: '/cai-dat/cai-dat-lich-hop' },
            { label: 'Danh sách phòng họp', routerLink: '/cai-dat/cai-dat-lich-hop/danh-sach-phong-hop' },
            { label: `${this.titlePage}` },
        ];
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this.unsubscribe$))
            .subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.roomId = this.paramsObject.params.roomId;
            this.getMeetRoomInfo();
        });
    }
    ;
    getMeetRoomInfo() {
        const queryParams = queryString.stringify({ roomId: this.roomId });
        this.apiService.getMeetRoomInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.detailInfo = results.data;
            }
        });
    }
    setMeetRoomInfo(data) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setMeetRoomInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.router.navigate(['/cai-dat/cai-dat-lich-hop/danh-sach-phong-hop']);
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getMeetRoomInfo();
        }
        else {
            this.router.navigate(['hoat-dong/lich-hop/danh-sach-phong-hop']);
        }
    }
}
ChiTietPhongHopComponent.ɵfac = function ChiTietPhongHopComponent_Factory(t) { return new (t || ChiTietPhongHopComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_9__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router)); };
ChiTietPhongHopComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: ChiTietPhongHopComponent, selectors: [["app-chi-tiet-phong-hop"]], decls: 8, vars: 3, consts: [[1, "main-grid", "product-detail"], [1, "breadcrumb"], [3, "model"], [1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function ChiTietPhongHopComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "p-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, ChiTietPhongHopComponent_app_edit_detail_7_Template, 1, 4, "app-edit-detail", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("model", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx.titlePage);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_11__.Breadcrumb, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_4__.EditDetailComponent], styles: ["[_nghost-%COMP%]  .content {\n  max-width: 1204px;\n  margin: auto;\n}\n[_nghost-%COMP%]  .main {\n  background: #fff;\n}\n[_nghost-%COMP%]  .product-detail {\n  background: #fff;\n}\n[_nghost-%COMP%]  .p-panel-header {\n  display: none;\n}\n[_nghost-%COMP%]  .content .p-panel .p-panel-content {\n  padding-left: 200px;\n}\n[_nghost-%COMP%]  .content .p-panel .p-panel-content .row > div:first-child {\n  position: absolute;\n  width: 200px;\n  height: 176px;\n  left: 0px;\n}\n[_nghost-%COMP%]  .delete-image {\n  width: 42px;\n  height: 41px;\n  position: absolute;\n  top: 0px;\n  right: 0px;\n  background: #fff;\n  line-height: 41px;\n  color: red;\n  z-index: 7;\n  cursor: pointer;\n  border-radius: 4px;\n  border: 1px solid #ccc;\n  box-shadow: 1px 1px 3px #ccc;\n  text-align: center;\n}\n[_nghost-%COMP%]  .field-group.checkbox {\n  display: flex;\n  align-items: center;\n  min-height: 0px;\n  flex-direction: row-reverse;\n  justify-content: flex-end;\n  grid-gap: 12px;\n  gap: 12px;\n  padding-left: 18px;\n}\n[_nghost-%COMP%]  .field-group.checkbox label {\n  position: static;\n  margin-bottom: 0px;\n}\n[_nghost-%COMP%]  .field-group.checkbox .p-checkbox {\n  position: static;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoaS10aWV0LXBob25nLWhvcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtBQUFSO0FBRUk7RUFDSSxnQkFBQTtBQUFSO0FBRUk7RUFDSSxnQkFBQTtBQUFSO0FBRUk7RUFDSSxhQUFBO0FBQVI7QUFFSTtFQUNJLG1CQUFBO0FBQVI7QUFHZ0I7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsU0FBQTtBQURwQjtBQVVJO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFVBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSw0QkFBQTtFQUNBLGtCQUFBO0FBUFI7QUFVUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSwyQkFBQTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUFBLFNBQUE7RUFDQSxrQkFBQTtBQVJaO0FBU1k7RUFDSSxnQkFBQTtFQUNBLGtCQUFBO0FBUGhCO0FBU1k7RUFDSSxnQkFBQTtBQVBoQiIsImZpbGUiOiJjaGktdGlldC1waG9uZy1ob3AuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdDo6bmctZGVlcHtcclxuICAgIC5jb250ZW50e1xyXG4gICAgICAgIG1heC13aWR0aDogMTIwNHB4O1xyXG4gICAgICAgIG1hcmdpbjogYXV0bzsgICBcclxuICAgIH1cclxuICAgIC5tYWlue1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICB9XHJcbiAgICAucHJvZHVjdC1kZXRhaWx7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIH1cclxuICAgIC5wLXBhbmVsLWhlYWRlcntcclxuICAgICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgfVxyXG4gICAgLmNvbnRlbnQgLnAtcGFuZWwgLnAtcGFuZWwtY29udGVudHtcclxuICAgICAgICBwYWRkaW5nLWxlZnQ6IDIwMHB4O1xyXG4gICAgICAgIC5yb3d7XHJcbiAgICAgICAgICAgICY+ZGl2e1xyXG4gICAgICAgICAgICAgICAgJjpmaXJzdC1jaGlsZHtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDIwMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTc2cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgbGVmdDogMHB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIFxyXG59XHJcbjpob3N0OjpuZy1kZWVwe1xyXG4gICAgLmRlbGV0ZS1pbWFnZXtcclxuICAgICAgICB3aWR0aDogNDJweDtcclxuICAgICAgICBoZWlnaHQ6IDQxcHg7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIHRvcDogMHB4O1xyXG4gICAgICAgIHJpZ2h0OiAwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICBsaW5lLWhlaWdodDogNDFweDtcclxuICAgICAgICBjb2xvcjogcmVkO1xyXG4gICAgICAgIHotaW5kZXg6IDc7XHJcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDFweCAxcHggM3B4ICNjY2M7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLmZpZWxkLWdyb3Vwe1xyXG4gICAgICAgICYuY2hlY2tib3h7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDBweDtcclxuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdy1yZXZlcnNlO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xyXG4gICAgICAgICAgICBnYXA6IDEycHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMThweDtcclxuICAgICAgICAgICAgbGFiZWx7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogc3RhdGljO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5wLWNoZWNrYm94e1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246IHN0YXRpYztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */"] });


/***/ }),

/***/ 74973:
/*!**************************************************************************************************!*\
  !*** ./src/app/components/cai-dat-lich-hop/danh-sach-phong-hop/danh-sach-phong-hop.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DanhSachPhongHopComponent": () => (/* binding */ DanhSachPhongHopComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);





























function DanhSachPhongHopComponent_ng_template_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](item_r7.label);
} }
function DanhSachPhongHopComponent_ng_template_15_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](car_r8.label);
} }
function DanhSachPhongHopComponent_app_list_grid_angular_36_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "app-list-grid-angular", 41);
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("listsData", ctx_r3.listsData)("height", ctx_r3.heightGrid)("columnDefs", ctx_r3.columnDefs);
} }
function DanhSachPhongHopComponent_app_config_grid_table_form_42_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "app-config-grid-table-form", 42);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r4.gridKey);
} }
function DanhSachPhongHopComponent_ng_template_45_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](item_r13.label);
} }
function DanhSachPhongHopComponent_ng_template_45_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r14 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](car_r14.label);
} }
function DanhSachPhongHopComponent_ng_template_45_ng_template_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](item_r15.label);
} }
function DanhSachPhongHopComponent_ng_template_45_ng_template_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](car_r16.label);
} }
function DanhSachPhongHopComponent_ng_template_45_Template(rf, ctx) { if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](4, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](6, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](8, "N\u01A1i l\u00E0m vi\u1EC7c");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](9, "p-dropdown", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngModelChange", function DanhSachPhongHopComponent_ng_template_45_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r18); const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r17.model.floor_No = $event; })("onChange", function DanhSachPhongHopComponent_ng_template_45_Template_p_dropdown_onChange_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r18); const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r19.changeFloor(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](10, DanhSachPhongHopComponent_ng_template_45_ng_template_10_Template, 2, 1, "ng-template", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](11, DanhSachPhongHopComponent_ng_template_45_ng_template_11_Template, 3, 1, "ng-template", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](12, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](13, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](14, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](15, "Ph\u00F2ng h\u1ECDp");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](16, "p-dropdown", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngModelChange", function DanhSachPhongHopComponent_ng_template_45_Template_p_dropdown_ngModelChange_16_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r18); const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r20.model.roomId = $event; })("onChange", function DanhSachPhongHopComponent_ng_template_45_Template_p_dropdown_onChange_16_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r18); const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r21.changeFloor(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](17, DanhSachPhongHopComponent_ng_template_45_ng_template_17_Template, 2, 1, "ng-template", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](18, DanhSachPhongHopComponent_ng_template_45_ng_template_18_Template, 3, 1, "ng-template", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](19, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](20, "label", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](21, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](22, "span", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](23, "p-button", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DanhSachPhongHopComponent_ng_template_45_Template_p_button_click_23_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r18); const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r22.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](24, "p-button", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DanhSachPhongHopComponent_ng_template_45_Template_p_button_click_24_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r18); const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r23.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r6.floors)("ngModel", ctx_r6.model.floor_No);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r6.rooms)("ngModel", ctx_r6.model.roomId);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { showAll: "ALL" }; };
const _c2 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c3 = function () { return { width: "50vw" }; };
const _c4 = function () { return { width: "700px" }; };
class DanhSachPhongHopComponent {
    constructor(apiService, router, messageService, spinner, confirmationService, changeDetector, organizeInfoService) {
        this.apiService = apiService;
        this.router = router;
        this.messageService = messageService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS;
        this.loading = false;
        this.cards = [];
        this.first = 0;
        this.model = {
            filter: '',
            gridWidth: '',
            offSet: 0,
            pageSize: 15,
            floor_No: '',
            workplaceId: '',
            roomId: '',
            status_meet: '',
            orgIds: '',
        };
        this.totalRecord = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.companies = [];
        this.pagingComponent = {
            total: 0
        };
        this.showDeleteTax = false;
        this.showImportExcel = false;
        this.statusRoom = [
            {
                label: 'Đang trống',
                value: "Đang trống",
            },
            {
                label: 'Đang họp',
                value: "Đang họp"
            },
            {
                label: 'Sắp họp',
                value: "Sắp họp"
            }
        ];
        this.items = [];
        this.loadjs = 0;
        this.heightGrid = 0;
        this.displaySetting = false;
        this.gridKey = '';
        this.listsData = [];
        this.floors = [];
        this.rooms = [];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 38;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__.ButtonAgGridComponent,
        };
        this.initFilter();
    }
    ngOnInit() {
        this.model.orgIds = localStorage.getItem("organizes");
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.model.orgIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Hoạt động' },
            { label: 'Lịch họp', routerLink: '/hoat-dong/lich-hop' },
            { label: 'Quản lý phòng họp' },
        ];
        this.getFloor();
    }
    initFilter() {
        this.model = {
            filter: '',
            gridWidth: '',
            offSet: 0,
            pageSize: 15,
            floor_No: '',
            workplaceId: '',
            roomId: '',
            status_meet: '',
            orgIds: localStorage.getItem("organizes")
        };
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.model);
        this.apiService.getMeetRoomPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.model.offSet === 0) {
                this.gridflexs = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.model.offSet = 0 : this.model.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.model.offSet) > this.model.pageSize) {
                this.countRecord.currentRecordEnd = this.model.offSet + Number(this.model.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    getFloor() {
        this.apiService.getFloorNo().subscribe(results => {
            if (results.status === 'success') {
                this.floors = (results.data).map(d => {
                    return {
                        label: 'Tầng' + ' ' + d.name,
                        value: d.value
                    };
                });
            }
        });
    }
    changeFloor() {
        this.getRooms();
    }
    getRooms() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '', floor_No: this.model.floor_No });
        this.apiService.getMeetRooms(queryParams)
            .subscribe(results => {
            if (results.status === 'success') {
                if (this.model.floor_No) {
                    this.rooms = results.data.map(d => {
                        return {
                            label: d.name,
                            value: d.value,
                        };
                    });
                }
                else {
                    this.rooms = [];
                }
                this.load();
            }
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.handleEdit.bind(this),
                    label: 'Sửa',
                    icon: 'fa fa-pencil-square-o',
                    class: 'btn-primary mr5',
                    hide: this.CheckHideXem(event)
                },
                {
                    onClick: this.handleDelete.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-danger mr5',
                    hide: this.CheckHideXoa(event)
                },
            ]
        };
    }
    CheckHideXem(event) {
        if ((0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetMeetRoomPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.VIEW)) {
            return true;
        }
        else {
            if (event.data.status === 3) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    CheckHideXoa(event) {
        if ((0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetMeetRoomPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.DELETE)) {
            return true;
        }
        else {
            if (event.data.status === 3) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: 'STT',
                filter: '',
                maxWidth: 70,
                pinned: 'left',
                cellRenderer: params => {
                    return params.rowIndex + 1;
                },
                cellClass: ['border-right', 'no-auto', 'text-center'],
                field: 'checkbox2',
                suppressSizeToFit: true,
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.gridflexs.filter((d) => !d.isHide)),
            {
                headerName: '   ...',
                filter: '',
                width: 70,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto', 'cell-options'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    handleDelete(e) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa không?',
            accept: () => {
                this.apiService.delMeetRoomInfo(e.rowData.roomId)
                    .subscribe(response => {
                    if (response.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: `Xóa thành công` });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: `Xóa thất bại` });
                    }
                }, error => {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: `Xóa thất bại` });
                });
            }
        });
    }
    handleEdit(e) {
        const params = {
            roomId: e.rowData.roomId
        };
        this.router.navigate(['hoat-dong/lich-hop/danh-sach-phong-hop/chi-tiet-phong-hop'], { queryParams: params });
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    paginate(event) {
        this.model.offSet = event.first;
        this.first = event.first;
        this.model.pageSize = event.rows;
        this.load();
    }
    handlerError(error) {
        console.log(error);
        if (error.status === 401) {
            this.router.navigate(['/home']);
        }
    }
    find() {
        this.load();
    }
    cancel() {
        this.initFilter();
        this.load();
    }
    changePageSize() {
        this.load();
    }
    handleAdd() {
        const params = {
            roomId: ''
        };
        this.router.navigate(['hoat-dong/lich-hop/danh-sach-phong-hop/them-moi-phong-hop'], { queryParams: params });
    }
}
DanhSachPhongHopComponent.ɵfac = function DanhSachPhongHopComponent_Factory(t) { return new (t || DanhSachPhongHopComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_15__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_12__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__.OrganizeInfoService)); };
DanhSachPhongHopComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({ type: DanhSachPhongHopComponent, selectors: [["app-danh-sach-phong-hop"]], decls: 46, vars: 35, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "end", "mid", "bottom", "gap-12", "col-9", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], [1, "field-group", "select", "mb-0"], ["appendTo", "body", "placeholder", "Ch\u1ECDn tr\u1EA1ng th\u00E1i", "name", "status_meet", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", 3, "CheckHideActions", "click"], ["d", "M11 5H9V9H5V11H9V15H11V11H15V9H11V5ZM10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM10 18C5.59 18 2 14.41 2 10C2 5.59 5.59 2 10 2C14.41 2 18 5.59 18 10C18 14.41 14.41 18 10 18Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "20", "height", "17", "viewBox", "0 0 20 17", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M19.5 17V0H0.50855L0.5 17H19.5ZM6.675 15.3187H2.21V6.81868H6.675V15.3187ZM8.575 15.3187V6.81868H17.79V15.3187H8.575ZM2.21 1.68132V5.13736H17.79V1.68132H2.21Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [3, "listsData", "height", "columnDefs"], [3, "typeConfig", "gridKey"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", "valid"], ["appendTo", "body", "placeholder", "---Ch\u1ECDn---", "name", "floor_No", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange", "onChange"], ["appendTo", "body", "placeholder", "---Ch\u1ECDn---", "name", "roomId", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange", "onChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"]], template: function DanhSachPhongHopComponent_Template(rf, ctx) { if (rf & 1) {
        const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("keydown.enter", function DanhSachPhongHopComponent_Template_input_keydown_enter_8_listener() { ctx.model.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function DanhSachPhongHopComponent_Template_input_ngModelChange_8_listener($event) { return ctx.model.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DanhSachPhongHopComponent_Template_span_click_9_listener() { ctx.model.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](12, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](13, "p-dropdown", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngModelChange", function DanhSachPhongHopComponent_Template_p_dropdown_ngModelChange_13_listener($event) { return ctx.model.status_meet = $event; })("onChange", function DanhSachPhongHopComponent_Template_p_dropdown_onChange_13_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](14, DanhSachPhongHopComponent_ng_template_14_Template, 2, 1, "ng-template", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](15, DanhSachPhongHopComponent_ng_template_15_Template, 3, 1, "ng-template", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](16, "p-button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DanhSachPhongHopComponent_Template_p_button_click_16_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](17, "svg", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](19, "p-button", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DanhSachPhongHopComponent_Template_p_button_click_19_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r24); const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵreference"](44); return _r5.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](20, "svg", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](21, "path", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](22, "path", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](23, "path", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](24, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](25, "p-button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DanhSachPhongHopComponent_Template_p_button_click_25_listener() { return ctx.handleAdd(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](26, "svg", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](27, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](28, " \u00A0 Th\u00EAm pho\u0300ng ho\u0323p ");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](29, "p-button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function DanhSachPhongHopComponent_Template_p_button_click_29_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](30, "svg", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](31, "path", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](32, " \u00A0 C\u1EA5u h\u00ECnh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](33, "section", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](34, "div", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](36, DanhSachPhongHopComponent_app_list_grid_angular_36_Template, 1, 3, "app-list-grid-angular", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](37, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](38, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](39);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](40, "p-paginator", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("onPageChange", function DanhSachPhongHopComponent_Template_p_paginator_onPageChange_40_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](41, "p-dialog", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("visibleChange", function DanhSachPhongHopComponent_Template_p_dialog_visibleChange_41_listener($event) { return ctx.displaySetting = $event; })("onHide", function DanhSachPhongHopComponent_Template_p_dialog_onHide_41_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](42, DanhSachPhongHopComponent_app_config_grid_table_form_42_Template, 1, 2, "app-config-grid-table-form", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](43, "p-overlayPanel", 37, 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](45, DanhSachPhongHopComponent_ng_template_45_Template, 25, 8, "ng-template", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngClass", ctx.model.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngModel", ctx.model.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.statusRoom)("ngModel", ctx.model.status_meet);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction2"](27, _c0, ctx.MENUACTIONROLEAPI.GetMeetRoomPage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("rows", ctx.model.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](31, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](30, _c1)));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](33, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](34, _c4));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgModel, primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__.Dropdown, primeng_api__WEBPACK_IMPORTED_MODULE_14__.PrimeTemplate, primeng_button__WEBPACK_IMPORTED_MODULE_19__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_9__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_20__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.Dialog, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_22__.OverlayPanel, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_11__.ConfigGridTableFormComponent], styles: ["[_nghost-%COMP%]  #myGrid .avatar-wrap {\n  border-radius: 0px !important;\n}\n[_nghost-%COMP%]  #myGrid .avatar-wrap img {\n  border-radius: 0px !important;\n}\n[_nghost-%COMP%]  .noti-number {\n  background: #FF3B49;\n  border-radius: 2px;\n  color: #F3F4F6;\n  padding: 2px 4px;\n}\n[_nghost-%COMP%]  .noti-number::after {\n  display: none;\n}\n[_nghost-%COMP%]  .noti-number.bg-success {\n  background: #FEC318;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRhbmgtc2FjaC1waG9uZy1ob3AuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSw2QkFBQTtBQUFSO0FBQ087RUFDSyw2QkFBQTtBQUNaO0FBS0k7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBRlI7QUFHUTtFQUNJLGFBQUE7QUFEWjtBQUdRO0VBQ0ksbUJBQUE7QUFEWiIsImZpbGUiOiJkYW5oLXNhY2gtcGhvbmctaG9wLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Q6Om5nLWRlZXB7XHJcbiAgICAjbXlHcmlkIC5hdmF0YXItd3JhcHtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAwcHggIWltcG9ydGFudDtcclxuICAgICAgIGltZ3tcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbjpob3N0OjpuZy1kZWVwe1xyXG4gICAgLm5vdGktbnVtYmVye1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNGRjNCNDk7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMnB4O1xyXG4gICAgICAgIGNvbG9yOiAjRjNGNEY2O1xyXG4gICAgICAgIHBhZGRpbmc6IDJweCA0cHg7XHJcbiAgICAgICAgJjo6YWZ0ZXJ7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICYuYmctc3VjY2Vzc3tcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogI0ZFQzMxODtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iXX0= */"] });


/***/ })

}]);
//# sourceMappingURL=default-src_app_components_cai-dat-lich-hop_cai-dat-lich-hop_component_ts-src_app_components_-94ecdd.57a461f2fb1506f2.js.map