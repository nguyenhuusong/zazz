"use strict";
(self["webpackChunkucart"] = self["webpackChunkucart"] || []).push([["src_app_pages_luong-thue_luong-thue_module_ts"],{

/***/ 39995:
/*!**************************************************************************!*\
  !*** ./src/app/components/luong-thue/bang-luong/bang-luong.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BangLuongComponent": () => (/* binding */ BangLuongComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/organizationchart */ 87051);





























function BangLuongComponent_ng_template_22_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](item_r10.label);
} }
function BangLuongComponent_ng_template_23_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](car_r11.label);
} }
function BangLuongComponent_app_list_grid_angular_52_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "app-list-grid-angular", 60);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("listsData", ctx_r4.listsData)("height", ctx_r4.heightGrid)("columnDefs", ctx_r4.columnDefs)("rowSelection", "multiple")("floatingFilter", true);
} }
function BangLuongComponent_ng_template_64_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](item_r12 == null ? null : item_r12.label);
} }
function BangLuongComponent_ng_template_65_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](car_r13 == null ? null : car_r13.label);
} }
function BangLuongComponent_app_list_grid_angular_73_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "app-list-grid-angular", 63);
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("listsData", ctx_r7.theOrganToMoveData)("height", 500)("idGrid", "theOrganToMoveData")("domLayout", "autoHeight")("columnDefs", ctx_r7.columnDefsMoveOrgan)("rowSelection", "multiple");
} }
function BangLuongComponent_ng_template_75_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](0, " L\u1ECDc nh\u00E2n s\u1EF1 theo s\u01A1 \u0111\u1ED3 t\u1ED5 ch\u1EE9c ");
} }
function BangLuongComponent_p_organizationChart_76_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](3, "img", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const node_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"]("", node_r16.data.position ? node_r16.data.position : "No position", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpropertyInterpolate"]("src", node_r16.data.avatarUrl ? node_r16.data.avatarUrl : "../../../../../assets/images/img_avatar.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](node_r16.data.full_name ? node_r16.data.full_name : "No name");
} }
function BangLuongComponent_p_organizationChart_76_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](0);
} if (rf & 2) {
    const node_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", node_r17.label, " ");
} }
function BangLuongComponent_p_organizationChart_76_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "p-organizationChart", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("selectionChange", function BangLuongComponent_p_organizationChart_76_Template_p_organizationChart_selectionChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r19); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r18.selectedNode = $event; })("onNodeSelect", function BangLuongComponent_p_organizationChart_76_Template_p_organizationChart_onNodeSelect_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r19); const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r20.onNodeSelect($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, BangLuongComponent_p_organizationChart_76_ng_template_1_Template, 6, 3, "ng-template", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, BangLuongComponent_p_organizationChart_76_ng_template_2_Template, 1, 1, "ng-template", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", ctx_r9.listAgencyMap)("preserveSpace", false)("selection", ctx_r9.selectedNode);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "60vw" }; };
const _c3 = function (a0) { return [a0]; };
const _c4 = function () { return { width: "90vw" }; };
const _c5 = function () { return { "1024": "95vw", "640px": "100vw" }; };
class BangLuongComponent {
    constructor(apiService, spinner, route, confirmationService, messageService, fileService, changeDetector, router) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.changeDetector = changeDetector;
        this.router = router;
        this.excelStyles = [
            {
                id: 'stringType',
                dataType: 'string'
            },
            {
                id: 'dateType',
                dataType: 'dateTime'
            },
            {
                id: 'numberType',
                dataType: 'number'
            }
        ];
        this.pagingComponent = {
            total: 0
        };
        this.projects = [];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.listsData = null;
        this.capaStatus = [
            { label: 'Tất cả', value: -1 },
            { label: 'Chưa duyệt', value: 0 },
            { label: 'Đã duyệt', value: 1 },
            { label: 'Từ chối', value: 2 },
            { label: 'Khởi tạo', value: null },
        ];
        this.totalRecord = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.isShowAvatar = false;
        this.imgAvatar = '';
        this.modelTM = {};
        this.displayEmployee = false;
        // for the move organ
        this.departmentFiltes = [];
        this.organizeId = '';
        this.theOrganToMoveData = [];
        this.isTheOrganToMove = false;
        this.queryStaffToMove = {
            organizeId: '',
            orgId: '',
            members: []
        };
        this.organs = [];
        this.isButtonmoveOrganNow = true;
        this.itemsToolOfGrid = [];
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            orgId: 0,
            isLock: -1,
            isApprove: -1,
            emp_st: -1
        };
        this.titleForm = {
            label: 'Thêm mới phòng ban',
            value: 'Add'
        };
        this.displayOrganize = false;
        this.displayButton = false;
        this.detailOrganizeMap = null;
        this.departments = [];
        this.isHrDiagram = false;
        this.displaySetting = false;
        this.gridKey = '';
        this.employeeStatus = [];
        this.organizeList = [];
        this.columnDefsMoveOrgan = [];
        this.loadjs = 0;
        this.heightGrid = 0;
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            tooltipComponentParams: { color: '#ececec' },
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 50;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__.AvatarFullComponent,
        };
    }
    onmouseenter(event) {
        console.log(event);
    }
    cancel() {
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            orgId: 0,
            isLock: -1,
            isApprove: -1,
            emp_st: -1
        };
        this.load();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    getAgencyOrganizeMap(type = false) {
        this.apiService.getAgencyOrganizeMap().subscribe(results => {
            var _a;
            if (results.status === 'success') {
                this.listAgencyMap = [...results.data.root];
                if (localStorage.getItem("organize") === null) {
                    this.selectedNode = this.listAgencyMap[0];
                    localStorage.setItem('organize', JSON.stringify(this.listAgencyMap[0]));
                    this.query.orgId = this.selectedNode.orgId;
                    this.load();
                }
                else {
                    this.selectedNode = JSON.parse(localStorage.getItem("organize"));
                    this.query.orgId = (_a = this.selectedNode) === null || _a === void 0 ? void 0 : _a.orgId;
                    this.listAgencyMap = this.expanded(this.listAgencyMap, this.selectedNode.parentId);
                    this.selected(this.listAgencyMap, this.query.orgId);
                    if (type) {
                        this.isHrDiagram = true;
                    }
                    this.load();
                }
            }
        });
    }
    expanded(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                d.expanded = true;
            }
            else {
                if (d.children.length > 0)
                    this.expanded(d.children, this.selectedNode.parentId);
            }
            d.children.forEach((elm) => {
                elm.children.forEach((e) => {
                    if (e.expanded === true) {
                        elm.expanded = true;
                    }
                });
            });
        });
        return datas;
    }
    selected(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                this.selectedNode = d;
                this.detailOrganizeMap = d;
            }
            else {
                if (d.children.length > 0)
                    this.selected(d.children, this.selectedNode.orgId);
            }
        });
    }
    themnhanvien() {
        const params = {
            empId: 0
        };
        this.router.navigate(['/ho-so-nhan-su/them-moi-nhan-vien'], { queryParams: params });
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getEmployeePage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.EditEmployee.bind(this),
                    label: 'Thông tin chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                },
                {
                    onClick: this.xoanhanvien.bind(this),
                    label: 'Xóa nhân viên này',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: '',
                filter: false,
                maxWidth: 50,
                pinned: 'left',
                cellRenderer: params => {
                    // return params.rowIndex + 1
                },
                cellClass: ['border-right', 'no-auto'],
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: false,
                field: 'checkbox2',
                suppressSizeToFit: false,
                suppressColumnsToolPanel: false,
                checkboxSelection: (params) => {
                    return !!params.data && params.data.emp_st === 0;
                },
                showDisabledCheckboxes: true,
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: '...',
                filter: '',
                maxWidth: 64,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right cell-action', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                field: 'checkbox'
            }
        ];
        this.detailCellRendererParams = {
            detailGridOptions: {
                frameworkComponents: {},
                getRowHeight: (params) => {
                    return 40;
                },
                columnDefs: [
                    ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.colsDetail),
                ],
                enableCellTextSelection: true,
                onFirstDataRendered(params) {
                    let allColumnIds = [];
                    params.columnApi.getAllColumns()
                        .forEach((column) => {
                        if (column.colDef.cellClass.indexOf('auto') < 0) {
                            allColumnIds.push(column);
                        }
                        else {
                            column.colDef.suppressSizeToFit = true;
                            allColumnIds.push(column);
                        }
                    });
                    params.api.sizeColumnsToFit(allColumnIds);
                },
            },
            getDetailRowData(params) {
                params.successCallback(params.data.AgencyGenerals);
            },
            excelStyles: [
                {
                    id: 'stringType',
                    dataType: 'string'
                }
            ],
            template: function (params) {
                var personName = params.data.theme;
                return ('<div style="height: 100%; background-color: #EDF6FF; padding: 20px; box-sizing: border-box;">' +
                    `  <div style="height: 10%; padding: 2px; font-weight: bold;">###### Danh sách (${params.data.AgencyGenerals.length}) : [` +
                    personName + ']' +
                    '</div>' +
                    '  <div ref="eDetailGrid" style="height: 90%;"></div>' +
                    '</div>');
            },
        };
    }
    xoanhanvien(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa nhân viên?',
            accept: () => {
                this.apiService.deleteEmployee(event.rowData.empId).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa nhân viên thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    staffActivity(event) {
        this.confirmationService.confirm({
            target: event.target,
            message: "Quản trị cần xác nhận nhân viên trong ngày làm việc đầu tiên là 'Xác nhận làm việc'. Ngày làm việc cuối cùng là 'Chấm dứt hợp đồng'",
            icon: 'pi pi-exclamation-triangle',
            rejectLabel: 'Chấm dứt hợp đồng',
            acceptLabel: 'Xác nhận làm việc',
            key: 'hosonhansu',
            acceptButtonStyleClass: 'p-button-sm',
            rejectButtonStyleClass: 'p-button-sm p-button-secondary',
            accept: () => {
                this.unLockEmployee({
                    empId: event.rowData.empId
                });
            },
            reject: () => {
                this.setEmployeeClose({
                    empId: event.rowData.empId
                });
            }
        });
    }
    unLockEmployee(params) {
        this.apiService.setEmployeeOpenhrm(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Xác nhận làm việc thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    setEmployeeClose(params) {
        this.apiService.setEmployeeClose(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Xác nhận nghỉ việc thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    staffApprove(event) {
        this.confirmationService.confirm({
            target: event.target,
            message: 'Bạn có muốn phê duyệt/hủy phê duyệt nhân viên này không?',
            icon: 'pi pi-exclamation-triangle',
            rejectLabel: 'Hủy phê duyệt',
            acceptLabel: 'Phê duyệt',
            key: 'hosonhansu',
            acceptButtonStyleClass: 'p-button-sm',
            rejectButtonStyleClass: 'p-button-sm p-button-secondary',
            accept: () => {
                this.setAccountStatus({
                    empId: event.rowData.empId,
                    status: true
                });
            },
            reject: () => {
                this.setAccountStatus({
                    empId: event.rowData.empId,
                    status: false
                });
            }
        });
    }
    setAccountStatus(params) {
        this.apiService.setEmployeeApprovehrm(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: params.status ? 'Phê duyệt thành công' : 'Hủy phê duyệt thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    EditEmployee(event) {
        const params = {
            empId: event.rowData.empId
        };
        this.router.navigate(['/nhan-su/ho-so-nhan-su/chi-tiet-ho-so-nhan-su'], { queryParams: params });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Lương - thuế' },
        ];
        this.getAgencyOrganizeMap();
        this.getEmployeeStatus();
        this.getOrgan();
        this.itemsToolOfGrid = [
            {
                label: 'Import file',
                code: 'Import',
                icon: 'pi pi-upload',
                command: () => {
                    this.importFileExel();
                }
            },
            {
                label: 'Export file',
                code: 'Import',
                icon: 'pi pi-download',
                command: () => {
                    this.exportExel();
                }
            },
        ];
    }
    getEmployeeStatus() {
        this.apiService.getEmployeeStatus().subscribe(results => {
            if (results.status === 'success') {
                this.employeeStatus = [];
                results.data.forEach(s => {
                    if (s.value != "3") {
                        this.employeeStatus.push({
                            label: s.name,
                            value: s.value
                        });
                    }
                });
                this.employeeStatus = [{ label: 'Chọn trạng thái', value: -1 }, ...this.employeeStatus];
            }
        });
    }
    onNodeSelect(event) {
        var _a;
        this.detailOrganizeMap = event.node;
        localStorage.setItem('organize', JSON.stringify(event.node));
        // this.query.orgId = this.selectedNode?.orgId;
        this.query.orgId = (_a = this.detailOrganizeMap) === null || _a === void 0 ? void 0 : _a.orgId;
        this.isHrDiagram = false;
        this.load();
    }
    hrDiagram() {
        this.selectedNode = null;
        this.listAgencyMap = [];
        this.getAgencyOrganizeMap(true);
    }
    Back() {
        this.router.navigate(['/page-agency']);
    }
    Close() {
        this.displayOrganize = false;
    }
    onCellClicked(event) {
        if (event.column.colId == "avatar_url") {
            this.isShowAvatar = true;
            this.imgAvatar = event.value;
        }
    }
    exportGrid() {
        this.gridApi.exportDataAsExcel();
    }
    getContextMenuItems(params) {
        var result = [
            'copy',
            'paste',
            'separator',
        ];
        return result;
    }
    exportExel() {
        this.spinner.show();
        this.query.pageSize = 1000000;
        const query = Object.assign({}, this.query);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query);
        this.apiService.getEmployeePage(queryParams).subscribe((results) => {
            const dataExport = [];
            let gridflexs = results.data.gridflexs;
            let arrKey = gridflexs.map(elementName => elementName.columnField);
            let dataList = results.data.dataList.data;
            for (let elementValue of dataList) {
                const data = {};
                for (let elementName of gridflexs) {
                    if (arrKey.indexOf(elementName.columnField) > -1 && !elementName.isHide && elementName.columnField !== 'statusName') {
                        let valueColumn = elementValue[elementName.columnField];
                        if (elementName.columnField == 'status_name' || elementName.columnField == 'isContacted' || elementName.columnField == 'isProfileFull' || elementName.columnField == 'lockName') {
                            valueColumn = this.replaceHtmlToText(valueColumn);
                        }
                        data[elementName.columnCaption] = valueColumn || '';
                    }
                }
                dataExport.push(data);
            }
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách hồ sơ nhân sự ' + new Date());
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    getColumnDefsMoveOrgan() {
        this.columnDefsMoveOrgan = [
            {
                headerName: 'Stt',
                filter: '',
                maxWidth: 90,
                pinned: 'left',
                cellRenderer: params => {
                    return params.rowIndex + 1;
                },
                cellClass: ['border-right', 'no-auto'],
            },
            {
                headerName: 'Mã NV',
                filter: '',
                cellClass: ['border-right', 'yellow-bg'],
                field: 'code',
                editable: true
            },
            {
                headerName: 'Họ tên',
                filter: '',
                cellClass: ['border-right'],
                field: 'full_name',
            },
            {
                headerName: 'Số ĐT',
                filter: '',
                cellClass: ['border-right'],
                field: 'phone1',
            },
            {
                headerName: 'Tổ chức',
                filter: '',
                cellClass: ['border-right'],
                field: 'organization',
            },
            {
                headerName: 'Thao tác',
                filter: '',
                maxWidth: 120,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons2(params),
                field: 'button'
            }
        ];
    }
    showButtons2(params) {
        return {
            buttons: [
                {
                    onClick: this.delStaffinDataOraMove.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                },
            ]
        };
    }
    delStaffinDataOraMove(data) {
        this.theOrganToMoveData = this.theOrganToMoveData.filter(a => a.CustId != data.rowData.CustId);
        if (this.theOrganToMoveData.length < 1) {
            this.isButtonmoveOrganNow = true;
        }
    }
    getOrgan() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.organs = results.data.map(d => {
                    return {
                        label: d.organizationName,
                        value: `${d.organizeId}`
                    };
                });
                this.organs = [...this.organs];
            }
        });
    }
    getOrganizeTree() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ parentId: this.organizeId });
        this.apiService.getOrganizeTree(queryParams)
            .subscribe((results) => {
            if (results && results.status === 'success') {
                this.departmentFiltes = results.data;
            }
        }, error => { });
        this.queryStaffToMove.orgId = '';
        this.aDepartment = '';
        if (this.organizeId && this.queryStaffToMove.orgId) {
            this.isButtonmoveOrganNow = false;
        }
        else {
            this.isButtonmoveOrganNow = true;
        }
    }
    // handleChangeOrganize() {
    //   this.getOrganizeTree();
    // }
    onChangeTreeDepart(event) {
        this.queryStaffToMove.orgId = event.node.orgId;
        // if(this.organizeId && event.node.orgId){
        //   this.isButtonmoveOrganNow = false;
        // }
        // else {
        //   this.isButtonmoveOrganNow = true;
        // }
        //MS-773
        this.isButtonmoveOrganNow = false;
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    importFileExel() {
        this.router.navigate(['/nhan-su/ho-so-nhan-su/import']);
    }
}
BangLuongComponent.ɵfac = function BangLuongComponent_Factory(t) { return new (t || BangLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_11__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_13__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_13__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_7__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.Router)); };
BangLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({ type: BangLuongComponent, selectors: [["app-bang-luong"]], decls: 77, vars: 54, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [3, "displayTitle", "items", "title"], [1, "d-flex", "bet", "mid", "bottom", "gap-12"], ["styleClass", "p-button-sm height-56"], ["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M13.6663 8.08835H8.08811V13.6666H5.91124V8.08835H0.333008V5.91148H5.91124V0.333252H8.08811V5.91148H13.6663V8.08835Z", "fill", "#F6FBFF"], [1, "bread-filter", "d-flex", "bet", "bottom"], [1, "col-item"], [1, "d-flex", "align-items-center"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "field-group", "select", "mb-0"], ["appendTo", "body", "name", "emp_st", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "d-flex", "end", "middle", "gap-16"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 "], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "18", "height", "18", "viewBox", "0 0 18 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M10.2002 13.2H13.2002V10.2H14.8002V13.2H17.8002V14.8H14.8002V17.7999H13.2002V14.8H10.2002V13.2Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 0.199951H7.8002V7.79995H0.200195V0.199951ZM6.2002 1.79995H1.8002V6.19995H6.2002V1.79995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.8002 7.79995H10.2002V0.199951H17.8002V7.79995ZM11.8002 6.19995H16.2002V1.79995H11.8002V6.19995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 10.2H7.8002V17.7999H0.200195V10.2ZM6.2002 11.8H1.8002V16.2H6.2002V11.8Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M6.10199 10.0001C6.10199 7.84533 7.84722 6.1001 10.002 6.1001C12.1568 6.1001 13.902 7.84533 13.902 10.0001C13.902 12.1549 12.1568 13.9001 10.002 13.9001C7.84722 13.9001 6.10199 12.1549 6.10199 10.0001ZM7.90199 10.0001C7.90199 11.1553 8.84676 12.1001 10.002 12.1001C11.1572 12.1001 12.102 11.1553 12.102 10.0001C12.102 8.84487 11.1572 7.9001 10.002 7.9001C8.84676 7.9001 7.90199 8.84487 7.90199 10.0001Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.3328 10.9677L17.3257 11.0239L19.4802 12.7087C19.6292 12.8265 19.6721 13.0416 19.5748 13.2212L17.5754 16.68L17.5748 16.6811C17.5036 16.8078 17.368 16.8801 17.232 16.8801C17.1842 16.8801 17.1358 16.8723 17.0864 16.8561L14.547 15.8363L14.502 15.8701C13.9872 16.2562 13.4345 16.5915 12.8341 16.8376L12.7811 16.8593L12.393 19.5659L12.3928 19.5677C12.3693 19.7551 12.2042 19.9001 12.002 19.9001H8.00199C7.79981 19.9001 7.63464 19.7551 7.61124 19.5677L7.22286 16.8593L7.16991 16.8376C6.56875 16.5912 6.01644 16.2658 5.50296 15.8708L5.45771 15.836L2.91485 16.8573C2.87884 16.8717 2.83184 16.8801 2.78199 16.8801C2.63486 16.8801 2.4999 16.8068 2.42916 16.6811L0.429221 13.2212C0.331903 13.0416 0.37495 12.8264 0.523956 12.7086L2.67825 11.0239L2.67122 10.9677C2.63148 10.6497 2.60199 10.3243 2.60199 10.0001C2.60199 9.67591 2.63148 9.35045 2.67122 9.0325L2.67825 8.97625L0.523811 7.29149C0.371682 7.17128 0.32503 6.95535 0.428568 6.78014L2.42857 3.32015L2.42915 3.31912C2.50042 3.19243 2.63599 3.1201 2.77199 3.1201C2.81979 3.1201 2.86823 3.12789 2.91764 3.14406L5.45696 4.16387L5.50199 4.1301C6.01682 3.74398 6.56946 3.40872 7.16991 3.16263L7.22286 3.14093L7.611 0.434295L7.61122 0.432501C7.63464 0.245098 7.79981 0.100098 8.00199 0.100098H12.002C12.2042 0.100098 12.3693 0.2451 12.3927 0.432503L12.7811 3.14093L12.8341 3.16263C13.4352 3.40901 13.9875 3.73438 14.501 4.12936L14.5463 4.16417L17.0891 3.14295C17.1251 3.12854 17.1721 3.1201 17.222 3.1201C17.3691 3.1201 17.5041 3.19335 17.5748 3.31913L19.5748 6.779C19.6721 6.95858 19.6291 7.17383 19.48 7.29161L17.3257 8.97625L17.3328 9.0325C17.3725 9.35055 17.402 9.66597 17.402 10.0001C17.402 10.3342 17.3725 10.6496 17.3328 10.9677ZM15.2644 5.79743L14.2575 6.20588L13.393 5.54083L13.392 5.5401C12.9857 5.23541 12.5786 5.0012 12.1406 4.81785L11.133 4.40909L10.7789 1.9001H9.21572L9.00298 3.33608L8.85105 4.40907L7.84369 4.81772C7.42462 4.99148 7.00691 5.23644 6.57171 5.56031L5.71691 6.20616L4.72926 5.8073L3.37883 5.265L2.59177 6.6255L3.7406 7.51903L4.58581 8.18381L4.45272 9.2578L4.45249 9.26015C4.42253 9.5597 4.40199 9.79442 4.40199 10.0001C4.40199 10.2057 4.42249 10.4405 4.45242 10.7497L4.58581 11.8264L3.74017 12.4915L2.59177 13.3847L3.37883 14.7452L4.72958 14.2028L5.73646 13.7943L6.60102 14.4594L6.60199 14.4601C7.00825 14.7648 7.41539 14.999 7.85338 15.1823L8.86102 15.5911L9.21511 18.1001H10.7883L11.001 16.6641L11.1529 15.5911L12.1603 15.1825C12.5794 15.0087 12.9971 14.7638 13.4323 14.4399L14.2871 13.794L15.2747 14.1929L16.6252 14.7352L17.4122 13.3747L16.2634 12.4812L15.4182 11.8164L15.5513 10.7424L15.5515 10.74C15.5814 10.4406 15.602 10.2158 15.602 10.0001C15.602 9.78595 15.5917 9.57141 15.5512 9.2573L15.4182 8.18381L16.2642 7.5184L17.4018 6.61472L16.6152 5.255L15.2644 5.79743Z", "fill", "#F3F8FF"], ["styleClass", "menu-option-right", 3, "model", "appendTo", "popup"], ["menuButton", ""], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "rowSelection", "floatingFilter", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "Chuy\u1EC3n t\u1ED5 ch\u1EE9c", 3, "modal", "visible", "visibleChange"], [1, "grid"], [1, "col-4"], [1, "field-group", "select", "mb-0", "label-8", 3, "ngClass"], ["appendTo", "body", "name", "organizeId", "placeholder", "Ch\u1ECDn t\u1ED5 ch\u1EE9c", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "onChange", "ngModelChange"], [1, "field-group", "select", "mb-0", "label-8"], ["selectionMode", "single", "name", "aDepartment", "placeholder", "Ch\u1ECDn ph\u00F2ng ban", 3, "filterInputAutoFocus", "filter", "metaKeySelection", "ngModel", "ngClass", "options", "ngModelChange", "onNodeSelect"], [1, "col-12"], [3, "listsData", "height", "idGrid", "domLayout", "columnDefs", "rowSelection", 4, "ngIf"], ["styleClass", "hr-diagram", 3, "appendTo", "autoZIndex", "visible", "modal", "breakpoints", "visibleChange"], ["pTemplate", "header"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect", 4, "ngIf"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [3, "listsData", "height", "columnDefs", "rowSelection", "floatingFilter"], [2, "vertical-align", "middle"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"], [3, "listsData", "height", "idGrid", "domLayout", "columnDefs", "rowSelection"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect"], ["pTemplate", "person"], ["pTemplate", "department"], [1, "node-header", "p-corner-top"], [1, "node-content"], ["width", "32", 3, "src"]], template: function BangLuongComponent_Template(rf, ctx) { if (rf & 1) {
        const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](6, "svg", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](7, "path", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](8, " \u00A0 Th\u00EAm m\u01A1\u0301i ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "section", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](11, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](12, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](13, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](14, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("keydown.enter", function BangLuongComponent_Template_input_keydown_enter_14_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function BangLuongComponent_Template_input_ngModelChange_14_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](15, "span", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function BangLuongComponent_Template_span_click_15_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](16, "svg", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](17, "path", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](18, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](19, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](20, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](21, "p-dropdown", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function BangLuongComponent_Template_p_dropdown_ngModelChange_21_listener($event) { return ctx.query.emp_st = $event; })("onChange", function BangLuongComponent_Template_p_dropdown_onChange_21_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](22, BangLuongComponent_ng_template_22_Template, 2, 1, "ng-template", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](23, BangLuongComponent_ng_template_23_Template, 3, 1, "ng-template", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](24, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](25, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](26, "p-button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function BangLuongComponent_Template_p_button_click_26_listener() { ctx.query.offSet = 0; ctx.query.filter = ""; ctx.query.emp_st = -1; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](27, "svg", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](28, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](29, "p-button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](30, "svg", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](31, "path", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](32, "path", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](33, "path", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](34, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](35, "p-button", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function BangLuongComponent_Template_p_button_click_35_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r21); const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](48); return _r2.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](36, "svg", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](37, "path", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](38, "path", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](39, "path", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](40, "path", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](41, " \u00A0 Ti\u1EC7n \u00EDch ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](42, "p-button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](43, "svg", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](44, "path", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](45, "path", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](46, " \u00A0 T\u00F9y ch\u1EC9nh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](47, "p-menu", 39, 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](49, "section", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](50, "div", 42, 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](52, BangLuongComponent_app_list_grid_angular_52_Template, 1, 5, "app-list-grid-angular", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](53, "div", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](54, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](55);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](56, "p-paginator", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("onPageChange", function BangLuongComponent_Template_p_paginator_onPageChange_56_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](57, "p-dialog", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("visibleChange", function BangLuongComponent_Template_p_dialog_visibleChange_57_listener($event) { return ctx.isTheOrganToMove = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](58, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](59, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](60, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](61, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](62, "T\u1ED5 ch\u1EE9c");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](63, "p-dropdown", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("onChange", function BangLuongComponent_Template_p_dropdown_onChange_63_listener() { return ctx.getOrganizeTree(); })("ngModelChange", function BangLuongComponent_Template_p_dropdown_ngModelChange_63_listener($event) { return ctx.organizeId = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](64, BangLuongComponent_ng_template_64_Template, 2, 1, "ng-template", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](65, BangLuongComponent_ng_template_65_Template, 3, 1, "ng-template", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](66, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](67, "div", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](68, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](69, "B\u1ED9 ph\u1EADn");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](70, "p-treeSelect", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function BangLuongComponent_Template_p_treeSelect_ngModelChange_70_listener($event) { return ctx.aDepartment = $event; })("onNodeSelect", function BangLuongComponent_Template_p_treeSelect_onNodeSelect_70_listener($event) { return ctx.onChangeTreeDepart($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](71, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](72, "div", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](73, BangLuongComponent_app_list_grid_angular_73_Template, 1, 6, "app-list-grid-angular", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](74, "p-dialog", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("visibleChange", function BangLuongComponent_Template_p_dialog_visibleChange_74_listener($event) { return ctx.isHrDiagram = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](75, BangLuongComponent_ng_template_75_Template, 1, 0, "ng-template", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](76, BangLuongComponent_p_organizationChart_76_Template, 3, 3, "p-organizationChart", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("displayTitle", true)("items", ctx.items)("title", "Danh sa\u0301ch ba\u0309ng l\u01B0\u01A1ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.employeeStatus)("ngModel", ctx.query.emp_st)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("model", ctx.itemsToolOfGrid)("appendTo", "body")("popup", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](47, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](46, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](49, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("modal", true)("visible", ctx.isTheOrganToMove);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", ctx.organizeId ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.organs)("ngModel", ctx.organizeId)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("filterInputAutoFocus", true)("filter", true)("metaKeySelection", false)("ngModel", ctx.aDepartment)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](50, _c3, ctx.departmentFiltes.length <= 0 ? "tree-empty" : ""))("options", ctx.departmentFiltes);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.columnDefsMoveOrgan.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](52, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("appendTo", "body")("autoZIndex", true)("visible", ctx.isHrDiagram)("modal", true)("breakpoints", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](53, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.isHrDiagram);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_14__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgModel, primeng_dropdown__WEBPACK_IMPORTED_MODULE_17__.Dropdown, primeng_api__WEBPACK_IMPORTED_MODULE_13__.PrimeTemplate, primeng_menu__WEBPACK_IMPORTED_MODULE_18__.Menu, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_19__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_20__.Dialog, primeng_treeselect__WEBPACK_IMPORTED_MODULE_21__.TreeSelect, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_9__.ListGridAngularComponent, primeng_organizationchart__WEBPACK_IMPORTED_MODULE_22__.OrganizationChart], styles: [".select-default[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  text-align: left;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .p-person {\n  padding: 0;\n  border: 0 none;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-header, [_nghost-%COMP%]     .p-organizationchart .node-content {\n  padding: 0.5em 0.7rem;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-header {\n  background-color: #495ebb;\n  color: #ffffff;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-content {\n  text-align: center;\n  border: 1px solid #495ebb;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-content img {\n  border-radius: 50%;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .department-cfo {\n  background-color: #7247bc;\n  color: #ffffff;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .department-coo {\n  background-color: #a534b6;\n  color: #ffffff;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .department-cto {\n  background-color: #e9286f;\n  color: #ffffff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhbmctbHVvbmcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtBQUNKOztBQUVJO0VBQ0ksVUFBQTtFQUNBLGNBQUE7QUFDUjs7QUFFSTtFQUNJLHFCQUFBO0FBQVI7O0FBR0k7RUFDSSx5QkFBQTtFQUNBLGNBQUE7QUFEUjs7QUFJSTtFQUNJLGtCQUFBO0VBQ0EseUJBQUE7QUFGUjs7QUFLSTtFQUNJLGtCQUFBO0FBSFI7O0FBTUk7RUFDSSx5QkFBQTtFQUNBLGNBQUE7QUFKUjs7QUFPSTtFQUNJLHlCQUFBO0VBQ0EsY0FBQTtBQUxSOztBQVFJO0VBQ0kseUJBQUE7RUFDQSxjQUFBO0FBTlIiLCJmaWxlIjoiYmFuZy1sdW9uZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZWxlY3QtZGVmYXVsdCBsYWJlbHtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbn1cclxuOmhvc3QgOjpuZy1kZWVwIC5wLW9yZ2FuaXphdGlvbmNoYXJ0IHtcclxuICAgIC5wLXBlcnNvbiB7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICBib3JkZXI6IDAgbm9uZTtcclxuICAgIH1cclxuXHJcbiAgICAubm9kZS1oZWFkZXIsIC5ub2RlLWNvbnRlbnQge1xyXG4gICAgICAgIHBhZGRpbmc6IC41ZW0gLjdyZW07XHJcbiAgICB9XHJcblxyXG4gICAgLm5vZGUtaGVhZGVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDk1ZWJiO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgfVxyXG5cclxuICAgIC5ub2RlLWNvbnRlbnQge1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjNDk1ZWJiO1xyXG4gICAgfVxyXG5cclxuICAgIC5ub2RlLWNvbnRlbnQgaW1nIHtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICB9XHJcblxyXG4gICAgLmRlcGFydG1lbnQtY2ZvIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNzI0N2JjO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgfVxyXG5cclxuICAgIC5kZXBhcnRtZW50LWNvbyB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2E1MzRiNjtcclxuICAgICAgICBjb2xvcjogI2ZmZmZmZjtcclxuICAgIH1cclxuXHJcbiAgICAuZGVwYXJ0bWVudC1jdG8ge1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNlOTI4NmY7XHJcbiAgICAgICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICB9XHJcbn0iXX0= */"] });


/***/ }),

/***/ 66538:
/*!*******************************************************************************************************!*\
  !*** ./src/app/components/luong-thue/bang-luong/cau-truc-bang-luong/cau-truc-bang-luong.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CauTrucBangLuongComponent": () => (/* binding */ CauTrucBangLuongComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/organizationchart */ 87051);






























function CauTrucBangLuongComponent_ng_template_36_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](item_r10.label);
} }
function CauTrucBangLuongComponent_ng_template_37_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](car_r11.label);
} }
function CauTrucBangLuongComponent_app_list_grid_angular_66_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-list-grid-angular", 69);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("listsData", ctx_r4.listsData)("height", ctx_r4.heightGrid)("columnDefs", ctx_r4.columnDefs)("rowSelection", "multiple")("floatingFilter", true);
} }
function CauTrucBangLuongComponent_ng_template_78_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "span", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](item_r12 == null ? null : item_r12.label);
} }
function CauTrucBangLuongComponent_ng_template_79_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](car_r13 == null ? null : car_r13.label);
} }
function CauTrucBangLuongComponent_app_list_grid_angular_87_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-list-grid-angular", 72);
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("listsData", ctx_r7.theOrganToMoveData)("height", 500)("idGrid", "theOrganToMoveData")("domLayout", "autoHeight")("columnDefs", ctx_r7.columnDefsMoveOrgan)("rowSelection", "multiple");
} }
function CauTrucBangLuongComponent_ng_template_89_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](0, " L\u1ECDc nh\u00E2n s\u1EF1 theo s\u01A1 \u0111\u1ED3 t\u1ED5 ch\u1EE9c\n");
} }
function CauTrucBangLuongComponent_p_organizationChart_90_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "img", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const node_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"]("", node_r16.data.position ? node_r16.data.position : "No position", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpropertyInterpolate"]("src", node_r16.data.avatarUrl ? node_r16.data.avatarUrl : "../../../../../assets/images/img_avatar.png", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](node_r16.data.full_name ? node_r16.data.full_name : "No name");
} }
function CauTrucBangLuongComponent_p_organizationChart_90_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](0);
} if (rf & 2) {
    const node_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", node_r17.label, " ");
} }
function CauTrucBangLuongComponent_p_organizationChart_90_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "p-organizationChart", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("selectionChange", function CauTrucBangLuongComponent_p_organizationChart_90_Template_p_organizationChart_selectionChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r19); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](); return ctx_r18.selectedNode = $event; })("onNodeSelect", function CauTrucBangLuongComponent_p_organizationChart_90_Template_p_organizationChart_onNodeSelect_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r19); const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](); return ctx_r20.onNodeSelect($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, CauTrucBangLuongComponent_p_organizationChart_90_ng_template_1_Template, 6, 3, "ng-template", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, CauTrucBangLuongComponent_p_organizationChart_90_ng_template_2_Template, 1, 1, "ng-template", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", ctx_r9.listAgencyMap)("preserveSpace", false)("selection", ctx_r9.selectedNode);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "60vw" }; };
const _c3 = function (a0) { return [a0]; };
const _c4 = function () { return { width: "90vw" }; };
const _c5 = function () { return { "1024": "95vw", "640px": "100vw" }; };
class CauTrucBangLuongComponent {
    constructor(apiService, spinner, route, confirmationService, messageService, fileService, changeDetector, router) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.changeDetector = changeDetector;
        this.router = router;
        this.tabsItem = [];
        this.excelStyles = [
            {
                id: 'stringType',
                dataType: 'string'
            },
            {
                id: 'dateType',
                dataType: 'dateTime'
            },
            {
                id: 'numberType',
                dataType: 'number'
            }
        ];
        this.pagingComponent = {
            total: 0
        };
        this.projects = [];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.listsData = null;
        this.capaStatus = [
            { label: 'Tất cả', value: -1 },
            { label: 'Chưa duyệt', value: 0 },
            { label: 'Đã duyệt', value: 1 },
            { label: 'Từ chối', value: 2 },
            { label: 'Khởi tạo', value: null },
        ];
        this.totalRecord = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.isShowAvatar = false;
        this.imgAvatar = '';
        this.modelTM = {};
        this.displayEmployee = false;
        // for the move organ
        this.departmentFiltes = [];
        this.organizeId = '';
        this.theOrganToMoveData = [];
        this.isTheOrganToMove = false;
        this.queryStaffToMove = {
            organizeId: '',
            orgId: '',
            members: []
        };
        this.organs = [];
        this.isButtonmoveOrganNow = true;
        this.itemsToolOfGrid = [];
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            orgId: 0,
            isLock: -1,
            isApprove: -1,
            emp_st: -1
        };
        this.titleForm = {
            label: 'Thêm mới phòng ban',
            value: 'Add'
        };
        this.displayOrganize = false;
        this.displayButton = false;
        this.detailOrganizeMap = null;
        this.departments = [];
        this.isHrDiagram = false;
        this.displaySetting = false;
        this.gridKey = '';
        this.employeeStatus = [];
        this.organizeList = [];
        this.columnDefsMoveOrgan = [];
        this.listDataSelect = [];
        this.loadjs = 0;
        this.heightGrid = 0;
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            tooltipComponentParams: { color: '#ececec' },
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 50;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__.AvatarFullComponent,
        };
    }
    onmouseenter(event) {
        console.log(event);
    }
    cancel() {
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            orgId: 0,
            isLock: -1,
            isApprove: -1,
            emp_st: -1
        };
        this.load();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    getAgencyOrganizeMap(type = false) {
        this.apiService.getAgencyOrganizeMap().subscribe(results => {
            var _a;
            if (results.status === 'success') {
                this.listAgencyMap = [...results.data.root];
                if (localStorage.getItem("organize") === null) {
                    this.selectedNode = this.listAgencyMap[0];
                    localStorage.setItem('organize', JSON.stringify(this.listAgencyMap[0]));
                    this.query.orgId = this.selectedNode.orgId;
                    this.load();
                }
                else {
                    this.selectedNode = JSON.parse(localStorage.getItem("organize"));
                    this.query.orgId = (_a = this.selectedNode) === null || _a === void 0 ? void 0 : _a.orgId;
                    this.listAgencyMap = this.expanded(this.listAgencyMap, this.selectedNode.parentId);
                    this.selected(this.listAgencyMap, this.query.orgId);
                    if (type) {
                        this.isHrDiagram = true;
                    }
                    this.load();
                }
            }
        });
    }
    expanded(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                d.expanded = true;
            }
            else {
                if (d.children.length > 0)
                    this.expanded(d.children, this.selectedNode.parentId);
            }
            d.children.forEach((elm) => {
                elm.children.forEach((e) => {
                    if (e.expanded === true) {
                        elm.expanded = true;
                    }
                });
            });
        });
        return datas;
    }
    selected(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                this.selectedNode = d;
                this.detailOrganizeMap = d;
            }
            else {
                if (d.children.length > 0)
                    this.selected(d.children, this.selectedNode.orgId);
            }
        });
    }
    themnhanvien() {
        const params = {
            empId: 0
        };
        this.router.navigate(['/ho-so-nhan-su/them-moi-nhan-vien'], { queryParams: params });
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getEmployeePage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.EditEmployee.bind(this),
                    label: 'Thông tin chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                },
                {
                    onClick: this.xoanhanvien.bind(this),
                    label: 'Xóa nhân viên này',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: '',
                filter: false,
                maxWidth: 50,
                pinned: 'left',
                cellRenderer: params => {
                    // return params.rowIndex + 1
                },
                cellClass: ['border-right', 'no-auto'],
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: false,
                field: 'checkbox2',
                suppressSizeToFit: false,
                suppressColumnsToolPanel: false,
                checkboxSelection: (params) => {
                    return !!params.data && params.data.emp_st === 0;
                },
                showDisabledCheckboxes: true,
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: '...',
                filter: '',
                maxWidth: 64,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right cell-action', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                field: 'checkbox'
            }
        ];
        this.detailCellRendererParams = {
            detailGridOptions: {
                frameworkComponents: {},
                getRowHeight: (params) => {
                    return 40;
                },
                columnDefs: [
                    ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.colsDetail),
                ],
                enableCellTextSelection: true,
                onFirstDataRendered(params) {
                    let allColumnIds = [];
                    params.columnApi.getAllColumns()
                        .forEach((column) => {
                        if (column.colDef.cellClass.indexOf('auto') < 0) {
                            allColumnIds.push(column);
                        }
                        else {
                            column.colDef.suppressSizeToFit = true;
                            allColumnIds.push(column);
                        }
                    });
                    params.api.sizeColumnsToFit(allColumnIds);
                },
            },
            getDetailRowData(params) {
                params.successCallback(params.data.AgencyGenerals);
            },
            excelStyles: [
                {
                    id: 'stringType',
                    dataType: 'string'
                }
            ],
            template: function (params) {
                var personName = params.data.theme;
                return ('<div style="height: 100%; background-color: #EDF6FF; padding: 20px; box-sizing: border-box;">' +
                    `  <div style="height: 10%; padding: 2px; font-weight: bold;">###### Danh sách (${params.data.AgencyGenerals.length}) : [` +
                    personName + ']' +
                    '</div>' +
                    '  <div ref="eDetailGrid" style="height: 90%;"></div>' +
                    '</div>');
            },
        };
    }
    xoanhanvien(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa nhân viên?',
            accept: () => {
                this.apiService.deleteEmployee(event.rowData.empId).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa nhân viên thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    staffActivity(event) {
        this.confirmationService.confirm({
            target: event.target,
            message: "Quản trị cần xác nhận nhân viên trong ngày làm việc đầu tiên là 'Xác nhận làm việc'. Ngày làm việc cuối cùng là 'Chấm dứt hợp đồng'",
            icon: 'pi pi-exclamation-triangle',
            rejectLabel: 'Chấm dứt hợp đồng',
            acceptLabel: 'Xác nhận làm việc',
            key: 'hosonhansu',
            acceptButtonStyleClass: 'p-button-sm',
            rejectButtonStyleClass: 'p-button-sm p-button-secondary',
            accept: () => {
                this.unLockEmployee({
                    empId: event.rowData.empId
                });
            },
            reject: () => {
                this.setEmployeeClose({
                    empId: event.rowData.empId
                });
            }
        });
    }
    unLockEmployee(params) {
        this.apiService.setEmployeeOpenhrm(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Xác nhận làm việc thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    setEmployeeClose(params) {
        this.apiService.setEmployeeClose(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Xác nhận nghỉ việc thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    staffApprove(event) {
        this.confirmationService.confirm({
            target: event.target,
            message: 'Bạn có muốn phê duyệt/hủy phê duyệt nhân viên này không?',
            icon: 'pi pi-exclamation-triangle',
            rejectLabel: 'Hủy phê duyệt',
            acceptLabel: 'Phê duyệt',
            key: 'hosonhansu',
            acceptButtonStyleClass: 'p-button-sm',
            rejectButtonStyleClass: 'p-button-sm p-button-secondary',
            accept: () => {
                this.setAccountStatus({
                    empId: event.rowData.empId,
                    status: true
                });
            },
            reject: () => {
                this.setAccountStatus({
                    empId: event.rowData.empId,
                    status: false
                });
            }
        });
    }
    setAccountStatus(params) {
        this.apiService.setEmployeeApprovehrm(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: params.status ? 'Phê duyệt thành công' : 'Hủy phê duyệt thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    EditEmployee(event) {
        const params = {
            empId: event.rowData.empId
        };
        this.router.navigate(['/nhan-su/ho-so-nhan-su/chi-tiet-ho-so-nhan-su'], { queryParams: params });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Lương - thuế' },
            { label: 'Bảng lương' },
            { label: 'Cấu trúc bảng lương' },
        ];
        this.getAgencyOrganizeMap();
        this.getEmployeeStatus();
        this.getOrgan();
        this.itemsToolOfGrid = [
            {
                label: 'Import file',
                code: 'Import',
                icon: 'pi pi-upload',
                command: () => {
                    this.importFileExel();
                }
            },
            {
                label: 'Export file',
                code: 'Import',
                icon: 'pi pi-download',
                command: () => {
                    this.exportExel();
                }
            },
        ];
        this.tabsItem = [
            { name: 'New York', code: 'NY' },
            { name: 'Rome', code: 'RM' },
            { name: 'London', code: 'LDN' },
            { name: 'Istanbul', code: 'IST' },
            { name: 'Paris', code: 'PRS' }
        ];
    }
    getEmployeeStatus() {
        this.apiService.getEmployeeStatus().subscribe(results => {
            if (results.status === 'success') {
                this.employeeStatus = [];
                results.data.forEach(s => {
                    if (s.value != "3") {
                        this.employeeStatus.push({
                            label: s.name,
                            value: s.value
                        });
                    }
                });
                this.employeeStatus = [{ label: '---Chọn---', value: -1 }, ...this.employeeStatus];
            }
        });
    }
    onNodeSelect(event) {
        var _a;
        this.detailOrganizeMap = event.node;
        localStorage.setItem('organize', JSON.stringify(event.node));
        // this.query.orgId = this.selectedNode?.orgId;
        this.query.orgId = (_a = this.detailOrganizeMap) === null || _a === void 0 ? void 0 : _a.orgId;
        this.isHrDiagram = false;
        this.load();
    }
    hrDiagram() {
        this.selectedNode = null;
        this.listAgencyMap = [];
        this.getAgencyOrganizeMap(true);
    }
    Back() {
        this.router.navigate(['/page-agency']);
    }
    Close() {
        this.displayOrganize = false;
    }
    onCellClicked(event) {
        if (event.column.colId == "avatar_url") {
            this.isShowAvatar = true;
            this.imgAvatar = event.value;
        }
    }
    exportGrid() {
        this.gridApi.exportDataAsExcel();
    }
    getContextMenuItems(params) {
        var result = [
            'copy',
            'paste',
            'separator',
        ];
        return result;
    }
    exportExel() {
        this.spinner.show();
        this.query.pageSize = 1000000;
        const query = Object.assign({}, this.query);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query);
        this.apiService.getEmployeePage(queryParams).subscribe((results) => {
            const dataExport = [];
            let gridflexs = results.data.gridflexs;
            let arrKey = gridflexs.map(elementName => elementName.columnField);
            let dataList = results.data.dataList.data;
            for (let elementValue of dataList) {
                const data = {};
                for (let elementName of gridflexs) {
                    if (arrKey.indexOf(elementName.columnField) > -1 && !elementName.isHide && elementName.columnField !== 'statusName') {
                        let valueColumn = elementValue[elementName.columnField];
                        if (elementName.columnField == 'status_name' || elementName.columnField == 'isContacted' || elementName.columnField == 'isProfileFull' || elementName.columnField == 'lockName') {
                            valueColumn = this.replaceHtmlToText(valueColumn);
                        }
                        data[elementName.columnCaption] = valueColumn || '';
                    }
                }
                dataExport.push(data);
            }
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách hồ sơ nhân sự ' + new Date());
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    getColumnDefsMoveOrgan() {
        this.columnDefsMoveOrgan = [
            {
                headerName: 'Stt',
                filter: '',
                maxWidth: 90,
                pinned: 'left',
                cellRenderer: params => {
                    return params.rowIndex + 1;
                },
                cellClass: ['border-right', 'no-auto'],
            },
            {
                headerName: 'Mã NV',
                filter: '',
                cellClass: ['border-right', 'yellow-bg'],
                field: 'code',
                editable: true
            },
            {
                headerName: 'Họ tên',
                filter: '',
                cellClass: ['border-right'],
                field: 'full_name',
            },
            {
                headerName: 'Số ĐT',
                filter: '',
                cellClass: ['border-right'],
                field: 'phone1',
            },
            {
                headerName: 'Tổ chức',
                filter: '',
                cellClass: ['border-right'],
                field: 'organization',
            },
            {
                headerName: 'Thao tác',
                filter: '',
                maxWidth: 120,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons2(params),
                field: 'button'
            }
        ];
    }
    showButtons2(params) {
        return {
            buttons: [
                {
                    onClick: this.delStaffinDataOraMove.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                },
            ]
        };
    }
    delStaffinDataOraMove(data) {
        this.theOrganToMoveData = this.theOrganToMoveData.filter(a => a.CustId != data.rowData.CustId);
        if (this.theOrganToMoveData.length < 1) {
            this.isButtonmoveOrganNow = true;
        }
    }
    theOrganToMove() {
        // ColumnDefs for data move 
        this.getColumnDefsMoveOrgan();
        this.getOrgan();
        if (this.listDataSelect.length > 0) {
            this.theOrganToMoveData = (0,lodash__WEBPACK_IMPORTED_MODULE_8__.cloneDeep)(this.listDataSelect);
            this.isTheOrganToMove = true;
        }
        else {
            this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Vui lòng nhân sự' });
        }
    }
    getOrgan() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.organs = results.data.map(d => {
                    return {
                        label: d.organizationName,
                        value: `${d.organizeId}`
                    };
                });
                this.organs = [...this.organs];
            }
        });
    }
    getOrganizeTree() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ parentId: this.organizeId });
        this.apiService.getOrganizeTree(queryParams)
            .subscribe((results) => {
            if (results && results.status === 'success') {
                this.departmentFiltes = results.data;
            }
        }, error => { });
        this.queryStaffToMove.orgId = '';
        this.aDepartment = '';
        if (this.organizeId && this.queryStaffToMove.orgId) {
            this.isButtonmoveOrganNow = false;
        }
        else {
            this.isButtonmoveOrganNow = true;
        }
    }
    // handleChangeOrganize() {
    //   this.getOrganizeTree();
    // }
    onChangeTreeDepart(event) {
        this.queryStaffToMove.orgId = event.node.orgId;
        // if(this.organizeId && event.node.orgId){
        //   this.isButtonmoveOrganNow = false;
        // }
        // else {
        //   this.isButtonmoveOrganNow = true;
        // }
        //MS-773
        this.isButtonmoveOrganNow = false;
    }
    moveOrganNow() {
        if (this.theOrganToMoveData.length > 0) {
            this.queryStaffToMove.organizeId = this.organizeId;
            this.queryStaffToMove.members = this.theOrganToMoveData.map(o => {
                return {
                    empId: o.empId,
                    code: o.code
                };
            });
            this.apiService.setListEmployeeChange(this.queryStaffToMove).subscribe(results => {
                if (results.status === 'success') {
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Cập nhật thành công' });
                    this.load();
                    this.listDataSelect = [];
                    this.isTheOrganToMove = false;
                }
                else {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
                }
            });
        }
    }
    rowSelected(data) {
        if (data[0] && data[0].emp_st !== 1) {
            this.listDataSelect = data;
        }
        else {
            this.listDataSelect = [];
        }
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    importFileExel() {
        this.router.navigate(['/nhan-su/ho-so-nhan-su/import']);
    }
}
CauTrucBangLuongComponent.ɵfac = function CauTrucBangLuongComponent_Factory(t) { return new (t || CauTrucBangLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_12__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_7__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_11__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.Router)); };
CauTrucBangLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({ type: CauTrucBangLuongComponent, selectors: [["app-cau-truc-bang-luong"]], decls: 91, vars: 54, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [3, "displayTitle", "items", "title"], [1, "d-flex", "bet", "mid", "bottom", "gap-12"], ["styleClass", "p-button-sm height-56"], ["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M13.6667 8.08835H8.08848V13.6666H5.91161V8.08835H0.333374V5.91148H5.91161V0.333252H8.08848V5.91148H13.6667V8.08835Z", "fill", "#F6FBFF"], ["styleClass", "p-button-sm height-56 btn-dele"], ["width", "14", "height", "16", "viewBox", "0 0 14 16", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M11.1663 5.91658V14.2499H2.83301V5.91658H11.1663ZM9.91634 0.083252H4.08301L3.24967 0.916585H0.333008V2.58325H13.6663V0.916585H10.7497L9.91634 0.083252ZM12.833 4.24992H1.16634V14.2499C1.16634 15.1666 1.91634 15.9166 2.83301 15.9166H11.1663C12.083 15.9166 12.833 15.1666 12.833 14.2499V4.24992Z", "fill", "#F6FBFF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M4.49967 12.1666V7.58325H6.16634V12.1666H4.49967Z", "fill", "#F6FBFF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M7.83301 12.1666V7.58325H9.49967V12.1666H7.83301Z", "fill", "#F6FBFF"], ["width", "16", "height", "15", "viewBox", "0 0 16 15", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M13.8333 9.49992V12.8333H2.16667V9.49992H0.5V14.4999H15.5V9.49992H13.8333ZM8.83333 7.55825L10.9917 5.40825L12.1667 6.58325L8 10.7499L3.83333 6.58325L5.00833 5.40825L7.16667 7.55825V0.333252H8.83333V7.55825Z", "fill", "#F6FBFF"], ["width", "14", "height", "20", "viewBox", "0 0 14 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M6.99992 4.99992V7.49992L10.3333 4.16658L6.99992 0.833252V3.33325C3.31659 3.33325 0.333252 6.31658 0.333252 9.99992C0.333252 11.3083 0.716585 12.5249 1.36659 13.5499L2.58325 12.3333C2.20825 11.6416 1.99992 10.8416 1.99992 9.99992C1.99992 7.24158 4.24159 4.99992 6.99992 4.99992ZM12.6333 6.44992L11.4166 7.66658C11.7833 8.36658 11.9999 9.15825 11.9999 9.99992C11.9999 12.7583 9.75825 14.9999 6.99992 14.9999V12.4999L3.66659 15.8333L6.99992 19.1666V16.6666C10.6833 16.6666 13.6666 13.6833 13.6666 9.99992C13.6666 8.69158 13.2833 7.47492 12.6333 6.44992Z", "fill", "#F6FBFF"], [1, "bread-filter", "d-flex", "bet", "bottom"], [1, "col-item"], [1, "d-flex", "align-items-center"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "field-group", "select", "mb-0"], ["appendTo", "body", "name", "emp_st", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "d-flex", "end", "middle", "gap-16"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 "], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "18", "height", "18", "viewBox", "0 0 18 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M10.2002 13.2H13.2002V10.2H14.8002V13.2H17.8002V14.8H14.8002V17.7999H13.2002V14.8H10.2002V13.2Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 0.199951H7.8002V7.79995H0.200195V0.199951ZM6.2002 1.79995H1.8002V6.19995H6.2002V1.79995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.8002 7.79995H10.2002V0.199951H17.8002V7.79995ZM11.8002 6.19995H16.2002V1.79995H11.8002V6.19995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 10.2H7.8002V17.7999H0.200195V10.2ZM6.2002 11.8H1.8002V16.2H6.2002V11.8Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M6.10199 10.0001C6.10199 7.84533 7.84722 6.1001 10.002 6.1001C12.1568 6.1001 13.902 7.84533 13.902 10.0001C13.902 12.1549 12.1568 13.9001 10.002 13.9001C7.84722 13.9001 6.10199 12.1549 6.10199 10.0001ZM7.90199 10.0001C7.90199 11.1553 8.84676 12.1001 10.002 12.1001C11.1572 12.1001 12.102 11.1553 12.102 10.0001C12.102 8.84487 11.1572 7.9001 10.002 7.9001C8.84676 7.9001 7.90199 8.84487 7.90199 10.0001Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.3328 10.9677L17.3257 11.0239L19.4802 12.7087C19.6292 12.8265 19.6721 13.0416 19.5748 13.2212L17.5754 16.68L17.5748 16.6811C17.5036 16.8078 17.368 16.8801 17.232 16.8801C17.1842 16.8801 17.1358 16.8723 17.0864 16.8561L14.547 15.8363L14.502 15.8701C13.9872 16.2562 13.4345 16.5915 12.8341 16.8376L12.7811 16.8593L12.393 19.5659L12.3928 19.5677C12.3693 19.7551 12.2042 19.9001 12.002 19.9001H8.00199C7.79981 19.9001 7.63464 19.7551 7.61124 19.5677L7.22286 16.8593L7.16991 16.8376C6.56875 16.5912 6.01644 16.2658 5.50296 15.8708L5.45771 15.836L2.91485 16.8573C2.87884 16.8717 2.83184 16.8801 2.78199 16.8801C2.63486 16.8801 2.4999 16.8068 2.42916 16.6811L0.429221 13.2212C0.331903 13.0416 0.37495 12.8264 0.523956 12.7086L2.67825 11.0239L2.67122 10.9677C2.63148 10.6497 2.60199 10.3243 2.60199 10.0001C2.60199 9.67591 2.63148 9.35045 2.67122 9.0325L2.67825 8.97625L0.523811 7.29149C0.371682 7.17128 0.32503 6.95535 0.428568 6.78014L2.42857 3.32015L2.42915 3.31912C2.50042 3.19243 2.63599 3.1201 2.77199 3.1201C2.81979 3.1201 2.86823 3.12789 2.91764 3.14406L5.45696 4.16387L5.50199 4.1301C6.01682 3.74398 6.56946 3.40872 7.16991 3.16263L7.22286 3.14093L7.611 0.434295L7.61122 0.432501C7.63464 0.245098 7.79981 0.100098 8.00199 0.100098H12.002C12.2042 0.100098 12.3693 0.2451 12.3927 0.432503L12.7811 3.14093L12.8341 3.16263C13.4352 3.40901 13.9875 3.73438 14.501 4.12936L14.5463 4.16417L17.0891 3.14295C17.1251 3.12854 17.1721 3.1201 17.222 3.1201C17.3691 3.1201 17.5041 3.19335 17.5748 3.31913L19.5748 6.779C19.6721 6.95858 19.6291 7.17383 19.48 7.29161L17.3257 8.97625L17.3328 9.0325C17.3725 9.35055 17.402 9.66597 17.402 10.0001C17.402 10.3342 17.3725 10.6496 17.3328 10.9677ZM15.2644 5.79743L14.2575 6.20588L13.393 5.54083L13.392 5.5401C12.9857 5.23541 12.5786 5.0012 12.1406 4.81785L11.133 4.40909L10.7789 1.9001H9.21572L9.00298 3.33608L8.85105 4.40907L7.84369 4.81772C7.42462 4.99148 7.00691 5.23644 6.57171 5.56031L5.71691 6.20616L4.72926 5.8073L3.37883 5.265L2.59177 6.6255L3.7406 7.51903L4.58581 8.18381L4.45272 9.2578L4.45249 9.26015C4.42253 9.5597 4.40199 9.79442 4.40199 10.0001C4.40199 10.2057 4.42249 10.4405 4.45242 10.7497L4.58581 11.8264L3.74017 12.4915L2.59177 13.3847L3.37883 14.7452L4.72958 14.2028L5.73646 13.7943L6.60102 14.4594L6.60199 14.4601C7.00825 14.7648 7.41539 14.999 7.85338 15.1823L8.86102 15.5911L9.21511 18.1001H10.7883L11.001 16.6641L11.1529 15.5911L12.1603 15.1825C12.5794 15.0087 12.9971 14.7638 13.4323 14.4399L14.2871 13.794L15.2747 14.1929L16.6252 14.7352L17.4122 13.3747L16.2634 12.4812L15.4182 11.8164L15.5513 10.7424L15.5515 10.74C15.5814 10.4406 15.602 10.2158 15.602 10.0001C15.602 9.78595 15.5917 9.57141 15.5512 9.2573L15.4182 8.18381L16.2642 7.5184L17.4018 6.61472L16.6152 5.255L15.2644 5.79743Z", "fill", "#F3F8FF"], ["styleClass", "menu-option-right", 3, "model", "appendTo", "popup"], ["menuButton", ""], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "rowSelection", "floatingFilter", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "Chuy\u1EC3n t\u1ED5 ch\u1EE9c", 3, "modal", "visible", "visibleChange"], [1, "grid"], [1, "col-4"], [1, "field-group", "select", "mb-0", "label-8", 3, "ngClass"], ["appendTo", "body", "name", "organizeId", "placeholder", "Ch\u1ECDn t\u1ED5 ch\u1EE9c", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "onChange", "ngModelChange"], [1, "field-group", "select", "mb-0", "label-8"], ["selectionMode", "single", "name", "aDepartment", "placeholder", "Ch\u1ECDn ph\u00F2ng ban", 3, "filterInputAutoFocus", "filter", "metaKeySelection", "ngModel", "ngClass", "options", "ngModelChange", "onNodeSelect"], [1, "col-12"], [3, "listsData", "height", "idGrid", "domLayout", "columnDefs", "rowSelection", 4, "ngIf"], ["styleClass", "hr-diagram", 3, "appendTo", "autoZIndex", "visible", "modal", "breakpoints", "visibleChange"], ["pTemplate", "header"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect", 4, "ngIf"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [3, "listsData", "height", "columnDefs", "rowSelection", "floatingFilter"], [2, "vertical-align", "middle"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"], [3, "listsData", "height", "idGrid", "domLayout", "columnDefs", "rowSelection"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect"], ["pTemplate", "person"], ["pTemplate", "department"], [1, "node-header", "p-corner-top"], [1, "node-content"], ["width", "32", 3, "src"]], template: function CauTrucBangLuongComponent_Template(rf, ctx) { if (rf & 1) {
        const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](5, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "svg", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](7, "path", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](8, " \u00A0 Th\u00EAm m\u01A1\u0301i ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](10, "svg", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](11, "path", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](12, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](13, "path", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](14, " \u00A0 Xo\u0301a ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](15, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](17, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](18, " \u00A0 C\u00E2\u0323p nh\u00E2\u0323t ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](19, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](20, "svg", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](21, "path", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](22, " \u00A0 Import ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](23, "section", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](24, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](25, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](26, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](27, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](28, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("keydown.enter", function CauTrucBangLuongComponent_Template_input_keydown_enter_28_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function CauTrucBangLuongComponent_Template_input_ngModelChange_28_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](29, "span", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function CauTrucBangLuongComponent_Template_span_click_29_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](30, "svg", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](31, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](32, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](33, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](34, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](35, "p-dropdown", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("ngModelChange", function CauTrucBangLuongComponent_Template_p_dropdown_ngModelChange_35_listener($event) { return ctx.query.emp_st = $event; })("onChange", function CauTrucBangLuongComponent_Template_p_dropdown_onChange_35_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](36, CauTrucBangLuongComponent_ng_template_36_Template, 2, 1, "ng-template", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](37, CauTrucBangLuongComponent_ng_template_37_Template, 3, 1, "ng-template", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](38, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](39, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](40, "p-button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function CauTrucBangLuongComponent_Template_p_button_click_40_listener() { ctx.query.offSet = 0; ctx.query.filter = ""; ctx.query.emp_st = -1; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](41, "svg", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](42, "path", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](43, "p-button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](44, "svg", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](45, "path", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](46, "path", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](47, "path", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](48, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](49, "p-button", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function CauTrucBangLuongComponent_Template_p_button_click_49_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r21); const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵreference"](62); return _r2.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](50, "svg", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](51, "path", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](52, "path", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](53, "path", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](54, "path", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](55, " \u00A0 Ti\u1EC7n \u00EDch ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](56, "p-button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](57, "svg", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](58, "path", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](59, "path", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](60, " \u00A0 T\u00F9y ch\u1EC9nh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](61, "p-menu", 48, 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](63, "section", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](64, "div", 51, 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](66, CauTrucBangLuongComponent_app_list_grid_angular_66_Template, 1, 5, "app-list-grid-angular", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](67, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](68, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](69);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](70, "p-paginator", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("onPageChange", function CauTrucBangLuongComponent_Template_p_paginator_onPageChange_70_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](71, "p-dialog", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("visibleChange", function CauTrucBangLuongComponent_Template_p_dialog_visibleChange_71_listener($event) { return ctx.isTheOrganToMove = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](72, "div", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](73, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](74, "div", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](75, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](76, "T\u1ED5 ch\u1EE9c");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](77, "p-dropdown", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("onChange", function CauTrucBangLuongComponent_Template_p_dropdown_onChange_77_listener() { return ctx.getOrganizeTree(); })("ngModelChange", function CauTrucBangLuongComponent_Template_p_dropdown_ngModelChange_77_listener($event) { return ctx.organizeId = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](78, CauTrucBangLuongComponent_ng_template_78_Template, 2, 1, "ng-template", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](79, CauTrucBangLuongComponent_ng_template_79_Template, 3, 1, "ng-template", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](80, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](81, "div", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](82, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](83, "B\u1ED9 ph\u1EADn");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](84, "p-treeSelect", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("ngModelChange", function CauTrucBangLuongComponent_Template_p_treeSelect_ngModelChange_84_listener($event) { return ctx.aDepartment = $event; })("onNodeSelect", function CauTrucBangLuongComponent_Template_p_treeSelect_onNodeSelect_84_listener($event) { return ctx.onChangeTreeDepart($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](85, "div", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](86, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](87, CauTrucBangLuongComponent_app_list_grid_angular_87_Template, 1, 6, "app-list-grid-angular", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](88, "p-dialog", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("visibleChange", function CauTrucBangLuongComponent_Template_p_dialog_visibleChange_88_listener($event) { return ctx.isHrDiagram = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](89, CauTrucBangLuongComponent_ng_template_89_Template, 1, 0, "ng-template", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](90, CauTrucBangLuongComponent_p_organizationChart_90_Template, 3, 3, "p-organizationChart", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("displayTitle", true)("items", ctx.items)("title", "C\u00E2\u0301u tru\u0301c ba\u0309ng l\u01B0\u01A1ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.employeeStatus)("ngModel", ctx.query.emp_st)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("model", ctx.itemsToolOfGrid)("appendTo", "body")("popup", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](47, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](46, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](49, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("modal", true)("visible", ctx.isTheOrganToMove);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngClass", ctx.organizeId ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.organs)("ngModel", ctx.organizeId)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("filterInputAutoFocus", true)("filter", true)("metaKeySelection", false)("ngModel", ctx.aDepartment)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](50, _c3, ctx.departmentFiltes.length <= 0 ? "tree-empty" : ""))("options", ctx.departmentFiltes);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.columnDefsMoveOrgan.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](52, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("appendTo", "body")("autoZIndex", true)("visible", ctx.isHrDiagram)("modal", true)("breakpoints", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](53, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.isHrDiagram);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_15__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgModel, primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__.Dropdown, primeng_api__WEBPACK_IMPORTED_MODULE_14__.PrimeTemplate, primeng_menu__WEBPACK_IMPORTED_MODULE_19__.Menu, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_20__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.Dialog, primeng_treeselect__WEBPACK_IMPORTED_MODULE_22__.TreeSelect, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__.ListGridAngularComponent, primeng_organizationchart__WEBPACK_IMPORTED_MODULE_23__.OrganizationChart], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjYXUtdHJ1Yy1iYW5nLWx1b25nLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 59602:
/*!*******************************************************************************************************!*\
  !*** ./src/app/components/luong-thue/bang-luong/chi-tiet-bang-luong/chi-tiet-bang-luong.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietBangLuongComponent": () => (/* binding */ ChiTietBangLuongComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/organizationchart */ 87051);






























function ChiTietBangLuongComponent_ng_template_36_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](item_r10.label);
} }
function ChiTietBangLuongComponent_ng_template_37_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](car_r11.label);
} }
function ChiTietBangLuongComponent_app_list_grid_angular_66_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-list-grid-angular", 69);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("listsData", ctx_r4.listsData)("height", ctx_r4.heightGrid)("columnDefs", ctx_r4.columnDefs)("rowSelection", "multiple")("floatingFilter", true);
} }
function ChiTietBangLuongComponent_ng_template_78_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "span", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](item_r12 == null ? null : item_r12.label);
} }
function ChiTietBangLuongComponent_ng_template_79_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](car_r13 == null ? null : car_r13.label);
} }
function ChiTietBangLuongComponent_app_list_grid_angular_87_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-list-grid-angular", 72);
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("listsData", ctx_r7.theOrganToMoveData)("height", 500)("idGrid", "theOrganToMoveData")("domLayout", "autoHeight")("columnDefs", ctx_r7.columnDefsMoveOrgan)("rowSelection", "multiple");
} }
function ChiTietBangLuongComponent_ng_template_89_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](0, " L\u1ECDc nh\u00E2n s\u1EF1 theo s\u01A1 \u0111\u1ED3 t\u1ED5 ch\u1EE9c\n");
} }
function ChiTietBangLuongComponent_p_organizationChart_90_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "img", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const node_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"]("", node_r16.data.position ? node_r16.data.position : "No position", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpropertyInterpolate"]("src", node_r16.data.avatarUrl ? node_r16.data.avatarUrl : "../../../../../assets/images/img_avatar.png", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](node_r16.data.full_name ? node_r16.data.full_name : "No name");
} }
function ChiTietBangLuongComponent_p_organizationChart_90_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](0);
} if (rf & 2) {
    const node_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", node_r17.label, " ");
} }
function ChiTietBangLuongComponent_p_organizationChart_90_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "p-organizationChart", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("selectionChange", function ChiTietBangLuongComponent_p_organizationChart_90_Template_p_organizationChart_selectionChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r19); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](); return ctx_r18.selectedNode = $event; })("onNodeSelect", function ChiTietBangLuongComponent_p_organizationChart_90_Template_p_organizationChart_onNodeSelect_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r19); const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](); return ctx_r20.onNodeSelect($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, ChiTietBangLuongComponent_p_organizationChart_90_ng_template_1_Template, 6, 3, "ng-template", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, ChiTietBangLuongComponent_p_organizationChart_90_ng_template_2_Template, 1, 1, "ng-template", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", ctx_r9.listAgencyMap)("preserveSpace", false)("selection", ctx_r9.selectedNode);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "60vw" }; };
const _c3 = function (a0) { return [a0]; };
const _c4 = function () { return { width: "90vw" }; };
const _c5 = function () { return { "1024": "95vw", "640px": "100vw" }; };
class ChiTietBangLuongComponent {
    constructor(apiService, spinner, route, confirmationService, messageService, fileService, changeDetector, router) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.changeDetector = changeDetector;
        this.router = router;
        this.tabsItem = [];
        this.excelStyles = [
            {
                id: 'stringType',
                dataType: 'string'
            },
            {
                id: 'dateType',
                dataType: 'dateTime'
            },
            {
                id: 'numberType',
                dataType: 'number'
            }
        ];
        this.pagingComponent = {
            total: 0
        };
        this.projects = [];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.listsData = null;
        this.capaStatus = [
            { label: 'Tất cả', value: -1 },
            { label: 'Chưa duyệt', value: 0 },
            { label: 'Đã duyệt', value: 1 },
            { label: 'Từ chối', value: 2 },
            { label: 'Khởi tạo', value: null },
        ];
        this.totalRecord = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.isShowAvatar = false;
        this.imgAvatar = '';
        this.modelTM = {};
        this.displayEmployee = false;
        // for the move organ
        this.departmentFiltes = [];
        this.organizeId = '';
        this.theOrganToMoveData = [];
        this.isTheOrganToMove = false;
        this.queryStaffToMove = {
            organizeId: '',
            orgId: '',
            members: []
        };
        this.organs = [];
        this.isButtonmoveOrganNow = true;
        this.itemsToolOfGrid = [];
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            orgId: 0,
            isLock: -1,
            isApprove: -1,
            emp_st: -1
        };
        this.titleForm = {
            label: 'Thêm mới phòng ban',
            value: 'Add'
        };
        this.displayOrganize = false;
        this.displayButton = false;
        this.detailOrganizeMap = null;
        this.departments = [];
        this.isHrDiagram = false;
        this.displaySetting = false;
        this.gridKey = '';
        this.employeeStatus = [];
        this.organizeList = [];
        this.columnDefsMoveOrgan = [];
        this.listDataSelect = [];
        this.loadjs = 0;
        this.heightGrid = 0;
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            tooltipComponentParams: { color: '#ececec' },
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 50;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__.AvatarFullComponent,
        };
    }
    onmouseenter(event) {
        console.log(event);
    }
    cancel() {
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            orgId: 0,
            isLock: -1,
            isApprove: -1,
            emp_st: -1
        };
        this.load();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    getAgencyOrganizeMap(type = false) {
        this.apiService.getAgencyOrganizeMap().subscribe(results => {
            var _a;
            if (results.status === 'success') {
                this.listAgencyMap = [...results.data.root];
                if (localStorage.getItem("organize") === null) {
                    this.selectedNode = this.listAgencyMap[0];
                    localStorage.setItem('organize', JSON.stringify(this.listAgencyMap[0]));
                    this.query.orgId = this.selectedNode.orgId;
                    this.load();
                }
                else {
                    this.selectedNode = JSON.parse(localStorage.getItem("organize"));
                    this.query.orgId = (_a = this.selectedNode) === null || _a === void 0 ? void 0 : _a.orgId;
                    this.listAgencyMap = this.expanded(this.listAgencyMap, this.selectedNode.parentId);
                    this.selected(this.listAgencyMap, this.query.orgId);
                    if (type) {
                        this.isHrDiagram = true;
                    }
                    this.load();
                }
            }
        });
    }
    expanded(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                d.expanded = true;
            }
            else {
                if (d.children.length > 0)
                    this.expanded(d.children, this.selectedNode.parentId);
            }
            d.children.forEach((elm) => {
                elm.children.forEach((e) => {
                    if (e.expanded === true) {
                        elm.expanded = true;
                    }
                });
            });
        });
        return datas;
    }
    selected(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                this.selectedNode = d;
                this.detailOrganizeMap = d;
            }
            else {
                if (d.children.length > 0)
                    this.selected(d.children, this.selectedNode.orgId);
            }
        });
    }
    themnhanvien() {
        const params = {
            empId: 0
        };
        this.router.navigate(['/ho-so-nhan-su/them-moi-nhan-vien'], { queryParams: params });
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getEmployeePage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.EditEmployee.bind(this),
                    label: 'Thông tin chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                },
                {
                    onClick: this.xoanhanvien.bind(this),
                    label: 'Xóa nhân viên này',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: '',
                filter: false,
                maxWidth: 50,
                pinned: 'left',
                cellRenderer: params => {
                    // return params.rowIndex + 1
                },
                cellClass: ['border-right', 'no-auto'],
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: false,
                field: 'checkbox2',
                suppressSizeToFit: false,
                suppressColumnsToolPanel: false,
                checkboxSelection: (params) => {
                    return !!params.data && params.data.emp_st === 0;
                },
                showDisabledCheckboxes: true,
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: '...',
                filter: '',
                maxWidth: 64,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right cell-action', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                field: 'checkbox'
            }
        ];
        this.detailCellRendererParams = {
            detailGridOptions: {
                frameworkComponents: {},
                getRowHeight: (params) => {
                    return 40;
                },
                columnDefs: [
                    ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.colsDetail),
                ],
                enableCellTextSelection: true,
                onFirstDataRendered(params) {
                    let allColumnIds = [];
                    params.columnApi.getAllColumns()
                        .forEach((column) => {
                        if (column.colDef.cellClass.indexOf('auto') < 0) {
                            allColumnIds.push(column);
                        }
                        else {
                            column.colDef.suppressSizeToFit = true;
                            allColumnIds.push(column);
                        }
                    });
                    params.api.sizeColumnsToFit(allColumnIds);
                },
            },
            getDetailRowData(params) {
                params.successCallback(params.data.AgencyGenerals);
            },
            excelStyles: [
                {
                    id: 'stringType',
                    dataType: 'string'
                }
            ],
            template: function (params) {
                var personName = params.data.theme;
                return ('<div style="height: 100%; background-color: #EDF6FF; padding: 20px; box-sizing: border-box;">' +
                    `  <div style="height: 10%; padding: 2px; font-weight: bold;">###### Danh sách (${params.data.AgencyGenerals.length}) : [` +
                    personName + ']' +
                    '</div>' +
                    '  <div ref="eDetailGrid" style="height: 90%;"></div>' +
                    '</div>');
            },
        };
    }
    xoanhanvien(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa nhân viên?',
            accept: () => {
                this.apiService.deleteEmployee(event.rowData.empId).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa nhân viên thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    staffActivity(event) {
        this.confirmationService.confirm({
            target: event.target,
            message: "Quản trị cần xác nhận nhân viên trong ngày làm việc đầu tiên là 'Xác nhận làm việc'. Ngày làm việc cuối cùng là 'Chấm dứt hợp đồng'",
            icon: 'pi pi-exclamation-triangle',
            rejectLabel: 'Chấm dứt hợp đồng',
            acceptLabel: 'Xác nhận làm việc',
            key: 'hosonhansu',
            acceptButtonStyleClass: 'p-button-sm',
            rejectButtonStyleClass: 'p-button-sm p-button-secondary',
            accept: () => {
                this.unLockEmployee({
                    empId: event.rowData.empId
                });
            },
            reject: () => {
                this.setEmployeeClose({
                    empId: event.rowData.empId
                });
            }
        });
    }
    unLockEmployee(params) {
        this.apiService.setEmployeeOpenhrm(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Xác nhận làm việc thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    setEmployeeClose(params) {
        this.apiService.setEmployeeClose(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Xác nhận nghỉ việc thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    staffApprove(event) {
        this.confirmationService.confirm({
            target: event.target,
            message: 'Bạn có muốn phê duyệt/hủy phê duyệt nhân viên này không?',
            icon: 'pi pi-exclamation-triangle',
            rejectLabel: 'Hủy phê duyệt',
            acceptLabel: 'Phê duyệt',
            key: 'hosonhansu',
            acceptButtonStyleClass: 'p-button-sm',
            rejectButtonStyleClass: 'p-button-sm p-button-secondary',
            accept: () => {
                this.setAccountStatus({
                    empId: event.rowData.empId,
                    status: true
                });
            },
            reject: () => {
                this.setAccountStatus({
                    empId: event.rowData.empId,
                    status: false
                });
            }
        });
    }
    setAccountStatus(params) {
        this.apiService.setEmployeeApprovehrm(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: params.status ? 'Phê duyệt thành công' : 'Hủy phê duyệt thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    EditEmployee(event) {
        const params = {
            empId: event.rowData.empId
        };
        this.router.navigate(['/nhan-su/ho-so-nhan-su/chi-tiet-ho-so-nhan-su'], { queryParams: params });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Lương - thuế' },
            { label: 'Bảng lương' },
            { label: 'Chi tiết bảng lương' },
        ];
        this.getAgencyOrganizeMap();
        this.getEmployeeStatus();
        this.getOrgan();
        this.itemsToolOfGrid = [
            {
                label: 'Import file',
                code: 'Import',
                icon: 'pi pi-upload',
                command: () => {
                    this.importFileExel();
                }
            },
            {
                label: 'Export file',
                code: 'Import',
                icon: 'pi pi-download',
                command: () => {
                    this.exportExel();
                }
            },
        ];
        this.tabsItem = [
            { name: 'New York', code: 'NY' },
            { name: 'Rome', code: 'RM' },
            { name: 'London', code: 'LDN' },
            { name: 'Istanbul', code: 'IST' },
            { name: 'Paris', code: 'PRS' }
        ];
    }
    getEmployeeStatus() {
        this.apiService.getEmployeeStatus().subscribe(results => {
            if (results.status === 'success') {
                this.employeeStatus = [];
                results.data.forEach(s => {
                    if (s.value != "3") {
                        this.employeeStatus.push({
                            label: s.name,
                            value: s.value
                        });
                    }
                });
                this.employeeStatus = [{ label: '---Chọn---', value: -1 }, ...this.employeeStatus];
            }
        });
    }
    onNodeSelect(event) {
        var _a;
        this.detailOrganizeMap = event.node;
        localStorage.setItem('organize', JSON.stringify(event.node));
        // this.query.orgId = this.selectedNode?.orgId;
        this.query.orgId = (_a = this.detailOrganizeMap) === null || _a === void 0 ? void 0 : _a.orgId;
        this.isHrDiagram = false;
        this.load();
    }
    hrDiagram() {
        this.selectedNode = null;
        this.listAgencyMap = [];
        this.getAgencyOrganizeMap(true);
    }
    Back() {
        this.router.navigate(['/page-agency']);
    }
    Close() {
        this.displayOrganize = false;
    }
    onCellClicked(event) {
        if (event.column.colId == "avatar_url") {
            this.isShowAvatar = true;
            this.imgAvatar = event.value;
        }
    }
    exportGrid() {
        this.gridApi.exportDataAsExcel();
    }
    getContextMenuItems(params) {
        var result = [
            'copy',
            'paste',
            'separator',
        ];
        return result;
    }
    exportExel() {
        this.spinner.show();
        this.query.pageSize = 1000000;
        const query = Object.assign({}, this.query);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query);
        this.apiService.getEmployeePage(queryParams).subscribe((results) => {
            const dataExport = [];
            let gridflexs = results.data.gridflexs;
            let arrKey = gridflexs.map(elementName => elementName.columnField);
            let dataList = results.data.dataList.data;
            for (let elementValue of dataList) {
                const data = {};
                for (let elementName of gridflexs) {
                    if (arrKey.indexOf(elementName.columnField) > -1 && !elementName.isHide && elementName.columnField !== 'statusName') {
                        let valueColumn = elementValue[elementName.columnField];
                        if (elementName.columnField == 'status_name' || elementName.columnField == 'isContacted' || elementName.columnField == 'isProfileFull' || elementName.columnField == 'lockName') {
                            valueColumn = this.replaceHtmlToText(valueColumn);
                        }
                        data[elementName.columnCaption] = valueColumn || '';
                    }
                }
                dataExport.push(data);
            }
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách hồ sơ nhân sự ' + new Date());
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    getColumnDefsMoveOrgan() {
        this.columnDefsMoveOrgan = [
            {
                headerName: 'Stt',
                filter: '',
                maxWidth: 90,
                pinned: 'left',
                cellRenderer: params => {
                    return params.rowIndex + 1;
                },
                cellClass: ['border-right', 'no-auto'],
            },
            {
                headerName: 'Mã NV',
                filter: '',
                cellClass: ['border-right', 'yellow-bg'],
                field: 'code',
                editable: true
            },
            {
                headerName: 'Họ tên',
                filter: '',
                cellClass: ['border-right'],
                field: 'full_name',
            },
            {
                headerName: 'Số ĐT',
                filter: '',
                cellClass: ['border-right'],
                field: 'phone1',
            },
            {
                headerName: 'Tổ chức',
                filter: '',
                cellClass: ['border-right'],
                field: 'organization',
            },
            {
                headerName: 'Thao tác',
                filter: '',
                maxWidth: 120,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons2(params),
                field: 'button'
            }
        ];
    }
    showButtons2(params) {
        return {
            buttons: [
                {
                    onClick: this.delStaffinDataOraMove.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                },
            ]
        };
    }
    delStaffinDataOraMove(data) {
        this.theOrganToMoveData = this.theOrganToMoveData.filter(a => a.CustId != data.rowData.CustId);
        if (this.theOrganToMoveData.length < 1) {
            this.isButtonmoveOrganNow = true;
        }
    }
    theOrganToMove() {
        // ColumnDefs for data move 
        this.getColumnDefsMoveOrgan();
        this.getOrgan();
        if (this.listDataSelect.length > 0) {
            this.theOrganToMoveData = (0,lodash__WEBPACK_IMPORTED_MODULE_8__.cloneDeep)(this.listDataSelect);
            this.isTheOrganToMove = true;
        }
        else {
            this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Vui lòng nhân sự' });
        }
    }
    getOrgan() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.organs = results.data.map(d => {
                    return {
                        label: d.organizationName,
                        value: `${d.organizeId}`
                    };
                });
                this.organs = [...this.organs];
            }
        });
    }
    getOrganizeTree() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ parentId: this.organizeId });
        this.apiService.getOrganizeTree(queryParams)
            .subscribe((results) => {
            if (results && results.status === 'success') {
                this.departmentFiltes = results.data;
            }
        }, error => { });
        this.queryStaffToMove.orgId = '';
        this.aDepartment = '';
        if (this.organizeId && this.queryStaffToMove.orgId) {
            this.isButtonmoveOrganNow = false;
        }
        else {
            this.isButtonmoveOrganNow = true;
        }
    }
    // handleChangeOrganize() {
    //   this.getOrganizeTree();
    // }
    onChangeTreeDepart(event) {
        this.queryStaffToMove.orgId = event.node.orgId;
        // if(this.organizeId && event.node.orgId){
        //   this.isButtonmoveOrganNow = false;
        // }
        // else {
        //   this.isButtonmoveOrganNow = true;
        // }
        //MS-773
        this.isButtonmoveOrganNow = false;
    }
    moveOrganNow() {
        if (this.theOrganToMoveData.length > 0) {
            this.queryStaffToMove.organizeId = this.organizeId;
            this.queryStaffToMove.members = this.theOrganToMoveData.map(o => {
                return {
                    empId: o.empId,
                    code: o.code
                };
            });
            this.apiService.setListEmployeeChange(this.queryStaffToMove).subscribe(results => {
                if (results.status === 'success') {
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Cập nhật thành công' });
                    this.load();
                    this.listDataSelect = [];
                    this.isTheOrganToMove = false;
                }
                else {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
                }
            });
        }
    }
    rowSelected(data) {
        if (data[0] && data[0].emp_st !== 1) {
            this.listDataSelect = data;
        }
        else {
            this.listDataSelect = [];
        }
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    importFileExel() {
        this.router.navigate(['/nhan-su/ho-so-nhan-su/import']);
    }
}
ChiTietBangLuongComponent.ɵfac = function ChiTietBangLuongComponent_Factory(t) { return new (t || ChiTietBangLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_12__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_7__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_11__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.Router)); };
ChiTietBangLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({ type: ChiTietBangLuongComponent, selectors: [["app-chi-tiet-bang-luong"]], decls: 91, vars: 54, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [3, "displayTitle", "items", "title"], [1, "d-flex", "bet", "mid", "bottom", "gap-12"], ["styleClass", "p-button-sm height-56"], ["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M13.6667 8.08835H8.08848V13.6666H5.91161V8.08835H0.333374V5.91148H5.91161V0.333252H8.08848V5.91148H13.6667V8.08835Z", "fill", "#F6FBFF"], ["styleClass", "p-button-sm height-56 btn-dele"], ["width", "14", "height", "16", "viewBox", "0 0 14 16", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M11.1663 5.91658V14.2499H2.83301V5.91658H11.1663ZM9.91634 0.083252H4.08301L3.24967 0.916585H0.333008V2.58325H13.6663V0.916585H10.7497L9.91634 0.083252ZM12.833 4.24992H1.16634V14.2499C1.16634 15.1666 1.91634 15.9166 2.83301 15.9166H11.1663C12.083 15.9166 12.833 15.1666 12.833 14.2499V4.24992Z", "fill", "#F6FBFF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M4.49967 12.1666V7.58325H6.16634V12.1666H4.49967Z", "fill", "#F6FBFF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M7.83301 12.1666V7.58325H9.49967V12.1666H7.83301Z", "fill", "#F6FBFF"], ["width", "16", "height", "15", "viewBox", "0 0 16 15", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M13.8333 9.49992V12.8333H2.16667V9.49992H0.5V14.4999H15.5V9.49992H13.8333ZM8.83333 7.55825L10.9917 5.40825L12.1667 6.58325L8 10.7499L3.83333 6.58325L5.00833 5.40825L7.16667 7.55825V0.333252H8.83333V7.55825Z", "fill", "#F6FBFF"], ["width", "14", "height", "20", "viewBox", "0 0 14 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M6.99992 4.99992V7.49992L10.3333 4.16658L6.99992 0.833252V3.33325C3.31659 3.33325 0.333252 6.31658 0.333252 9.99992C0.333252 11.3083 0.716585 12.5249 1.36659 13.5499L2.58325 12.3333C2.20825 11.6416 1.99992 10.8416 1.99992 9.99992C1.99992 7.24158 4.24159 4.99992 6.99992 4.99992ZM12.6333 6.44992L11.4166 7.66658C11.7833 8.36658 11.9999 9.15825 11.9999 9.99992C11.9999 12.7583 9.75825 14.9999 6.99992 14.9999V12.4999L3.66659 15.8333L6.99992 19.1666V16.6666C10.6833 16.6666 13.6666 13.6833 13.6666 9.99992C13.6666 8.69158 13.2833 7.47492 12.6333 6.44992Z", "fill", "#F6FBFF"], [1, "bread-filter", "d-flex", "bet", "bottom"], [1, "col-item"], [1, "d-flex", "align-items-center"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "field-group", "select", "mb-0"], ["appendTo", "body", "name", "emp_st", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "d-flex", "end", "middle", "gap-16"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 "], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "18", "height", "18", "viewBox", "0 0 18 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M10.2002 13.2H13.2002V10.2H14.8002V13.2H17.8002V14.8H14.8002V17.7999H13.2002V14.8H10.2002V13.2Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 0.199951H7.8002V7.79995H0.200195V0.199951ZM6.2002 1.79995H1.8002V6.19995H6.2002V1.79995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.8002 7.79995H10.2002V0.199951H17.8002V7.79995ZM11.8002 6.19995H16.2002V1.79995H11.8002V6.19995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 10.2H7.8002V17.7999H0.200195V10.2ZM6.2002 11.8H1.8002V16.2H6.2002V11.8Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M6.10199 10.0001C6.10199 7.84533 7.84722 6.1001 10.002 6.1001C12.1568 6.1001 13.902 7.84533 13.902 10.0001C13.902 12.1549 12.1568 13.9001 10.002 13.9001C7.84722 13.9001 6.10199 12.1549 6.10199 10.0001ZM7.90199 10.0001C7.90199 11.1553 8.84676 12.1001 10.002 12.1001C11.1572 12.1001 12.102 11.1553 12.102 10.0001C12.102 8.84487 11.1572 7.9001 10.002 7.9001C8.84676 7.9001 7.90199 8.84487 7.90199 10.0001Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.3328 10.9677L17.3257 11.0239L19.4802 12.7087C19.6292 12.8265 19.6721 13.0416 19.5748 13.2212L17.5754 16.68L17.5748 16.6811C17.5036 16.8078 17.368 16.8801 17.232 16.8801C17.1842 16.8801 17.1358 16.8723 17.0864 16.8561L14.547 15.8363L14.502 15.8701C13.9872 16.2562 13.4345 16.5915 12.8341 16.8376L12.7811 16.8593L12.393 19.5659L12.3928 19.5677C12.3693 19.7551 12.2042 19.9001 12.002 19.9001H8.00199C7.79981 19.9001 7.63464 19.7551 7.61124 19.5677L7.22286 16.8593L7.16991 16.8376C6.56875 16.5912 6.01644 16.2658 5.50296 15.8708L5.45771 15.836L2.91485 16.8573C2.87884 16.8717 2.83184 16.8801 2.78199 16.8801C2.63486 16.8801 2.4999 16.8068 2.42916 16.6811L0.429221 13.2212C0.331903 13.0416 0.37495 12.8264 0.523956 12.7086L2.67825 11.0239L2.67122 10.9677C2.63148 10.6497 2.60199 10.3243 2.60199 10.0001C2.60199 9.67591 2.63148 9.35045 2.67122 9.0325L2.67825 8.97625L0.523811 7.29149C0.371682 7.17128 0.32503 6.95535 0.428568 6.78014L2.42857 3.32015L2.42915 3.31912C2.50042 3.19243 2.63599 3.1201 2.77199 3.1201C2.81979 3.1201 2.86823 3.12789 2.91764 3.14406L5.45696 4.16387L5.50199 4.1301C6.01682 3.74398 6.56946 3.40872 7.16991 3.16263L7.22286 3.14093L7.611 0.434295L7.61122 0.432501C7.63464 0.245098 7.79981 0.100098 8.00199 0.100098H12.002C12.2042 0.100098 12.3693 0.2451 12.3927 0.432503L12.7811 3.14093L12.8341 3.16263C13.4352 3.40901 13.9875 3.73438 14.501 4.12936L14.5463 4.16417L17.0891 3.14295C17.1251 3.12854 17.1721 3.1201 17.222 3.1201C17.3691 3.1201 17.5041 3.19335 17.5748 3.31913L19.5748 6.779C19.6721 6.95858 19.6291 7.17383 19.48 7.29161L17.3257 8.97625L17.3328 9.0325C17.3725 9.35055 17.402 9.66597 17.402 10.0001C17.402 10.3342 17.3725 10.6496 17.3328 10.9677ZM15.2644 5.79743L14.2575 6.20588L13.393 5.54083L13.392 5.5401C12.9857 5.23541 12.5786 5.0012 12.1406 4.81785L11.133 4.40909L10.7789 1.9001H9.21572L9.00298 3.33608L8.85105 4.40907L7.84369 4.81772C7.42462 4.99148 7.00691 5.23644 6.57171 5.56031L5.71691 6.20616L4.72926 5.8073L3.37883 5.265L2.59177 6.6255L3.7406 7.51903L4.58581 8.18381L4.45272 9.2578L4.45249 9.26015C4.42253 9.5597 4.40199 9.79442 4.40199 10.0001C4.40199 10.2057 4.42249 10.4405 4.45242 10.7497L4.58581 11.8264L3.74017 12.4915L2.59177 13.3847L3.37883 14.7452L4.72958 14.2028L5.73646 13.7943L6.60102 14.4594L6.60199 14.4601C7.00825 14.7648 7.41539 14.999 7.85338 15.1823L8.86102 15.5911L9.21511 18.1001H10.7883L11.001 16.6641L11.1529 15.5911L12.1603 15.1825C12.5794 15.0087 12.9971 14.7638 13.4323 14.4399L14.2871 13.794L15.2747 14.1929L16.6252 14.7352L17.4122 13.3747L16.2634 12.4812L15.4182 11.8164L15.5513 10.7424L15.5515 10.74C15.5814 10.4406 15.602 10.2158 15.602 10.0001C15.602 9.78595 15.5917 9.57141 15.5512 9.2573L15.4182 8.18381L16.2642 7.5184L17.4018 6.61472L16.6152 5.255L15.2644 5.79743Z", "fill", "#F3F8FF"], ["styleClass", "menu-option-right", 3, "model", "appendTo", "popup"], ["menuButton", ""], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "rowSelection", "floatingFilter", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "Chuy\u1EC3n t\u1ED5 ch\u1EE9c", 3, "modal", "visible", "visibleChange"], [1, "grid"], [1, "col-4"], [1, "field-group", "select", "mb-0", "label-8", 3, "ngClass"], ["appendTo", "body", "name", "organizeId", "placeholder", "Ch\u1ECDn t\u1ED5 ch\u1EE9c", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "onChange", "ngModelChange"], [1, "field-group", "select", "mb-0", "label-8"], ["selectionMode", "single", "name", "aDepartment", "placeholder", "Ch\u1ECDn ph\u00F2ng ban", 3, "filterInputAutoFocus", "filter", "metaKeySelection", "ngModel", "ngClass", "options", "ngModelChange", "onNodeSelect"], [1, "col-12"], [3, "listsData", "height", "idGrid", "domLayout", "columnDefs", "rowSelection", 4, "ngIf"], ["styleClass", "hr-diagram", 3, "appendTo", "autoZIndex", "visible", "modal", "breakpoints", "visibleChange"], ["pTemplate", "header"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect", 4, "ngIf"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [3, "listsData", "height", "columnDefs", "rowSelection", "floatingFilter"], [2, "vertical-align", "middle"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"], [3, "listsData", "height", "idGrid", "domLayout", "columnDefs", "rowSelection"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect"], ["pTemplate", "person"], ["pTemplate", "department"], [1, "node-header", "p-corner-top"], [1, "node-content"], ["width", "32", 3, "src"]], template: function ChiTietBangLuongComponent_Template(rf, ctx) { if (rf & 1) {
        const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](5, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "svg", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](7, "path", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](8, " \u00A0 Th\u00EAm m\u01A1\u0301i ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](10, "svg", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](11, "path", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](12, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](13, "path", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](14, " \u00A0 Xo\u0301a ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](15, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](17, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](18, " \u00A0 C\u00E2\u0323p nh\u00E2\u0323t ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](19, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](20, "svg", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](21, "path", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](22, " \u00A0 Import ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](23, "section", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](24, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](25, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](26, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](27, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](28, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("keydown.enter", function ChiTietBangLuongComponent_Template_input_keydown_enter_28_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function ChiTietBangLuongComponent_Template_input_ngModelChange_28_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](29, "span", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ChiTietBangLuongComponent_Template_span_click_29_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](30, "svg", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](31, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](32, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](33, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](34, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](35, "p-dropdown", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("ngModelChange", function ChiTietBangLuongComponent_Template_p_dropdown_ngModelChange_35_listener($event) { return ctx.query.emp_st = $event; })("onChange", function ChiTietBangLuongComponent_Template_p_dropdown_onChange_35_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](36, ChiTietBangLuongComponent_ng_template_36_Template, 2, 1, "ng-template", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](37, ChiTietBangLuongComponent_ng_template_37_Template, 3, 1, "ng-template", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](38, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](39, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](40, "p-button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ChiTietBangLuongComponent_Template_p_button_click_40_listener() { ctx.query.offSet = 0; ctx.query.filter = ""; ctx.query.emp_st = -1; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](41, "svg", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](42, "path", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](43, "p-button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](44, "svg", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](45, "path", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](46, "path", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](47, "path", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](48, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](49, "p-button", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ChiTietBangLuongComponent_Template_p_button_click_49_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r21); const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵreference"](62); return _r2.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](50, "svg", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](51, "path", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](52, "path", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](53, "path", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](54, "path", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](55, " \u00A0 Ti\u1EC7n \u00EDch ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](56, "p-button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](57, "svg", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](58, "path", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](59, "path", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](60, " \u00A0 T\u00F9y ch\u1EC9nh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](61, "p-menu", 48, 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](63, "section", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](64, "div", 51, 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](66, ChiTietBangLuongComponent_app_list_grid_angular_66_Template, 1, 5, "app-list-grid-angular", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](67, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](68, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](69);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](70, "p-paginator", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("onPageChange", function ChiTietBangLuongComponent_Template_p_paginator_onPageChange_70_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](71, "p-dialog", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("visibleChange", function ChiTietBangLuongComponent_Template_p_dialog_visibleChange_71_listener($event) { return ctx.isTheOrganToMove = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](72, "div", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](73, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](74, "div", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](75, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](76, "T\u1ED5 ch\u1EE9c");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](77, "p-dropdown", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("onChange", function ChiTietBangLuongComponent_Template_p_dropdown_onChange_77_listener() { return ctx.getOrganizeTree(); })("ngModelChange", function ChiTietBangLuongComponent_Template_p_dropdown_ngModelChange_77_listener($event) { return ctx.organizeId = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](78, ChiTietBangLuongComponent_ng_template_78_Template, 2, 1, "ng-template", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](79, ChiTietBangLuongComponent_ng_template_79_Template, 3, 1, "ng-template", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](80, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](81, "div", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](82, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](83, "B\u1ED9 ph\u1EADn");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](84, "p-treeSelect", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("ngModelChange", function ChiTietBangLuongComponent_Template_p_treeSelect_ngModelChange_84_listener($event) { return ctx.aDepartment = $event; })("onNodeSelect", function ChiTietBangLuongComponent_Template_p_treeSelect_onNodeSelect_84_listener($event) { return ctx.onChangeTreeDepart($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](85, "div", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](86, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](87, ChiTietBangLuongComponent_app_list_grid_angular_87_Template, 1, 6, "app-list-grid-angular", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](88, "p-dialog", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("visibleChange", function ChiTietBangLuongComponent_Template_p_dialog_visibleChange_88_listener($event) { return ctx.isHrDiagram = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](89, ChiTietBangLuongComponent_ng_template_89_Template, 1, 0, "ng-template", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](90, ChiTietBangLuongComponent_p_organizationChart_90_Template, 3, 3, "p-organizationChart", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("displayTitle", true)("items", ctx.items)("title", "Chi ti\u00EA\u0301t ba\u0309ng l\u01B0\u01A1ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.employeeStatus)("ngModel", ctx.query.emp_st)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("model", ctx.itemsToolOfGrid)("appendTo", "body")("popup", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](47, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](46, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](49, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("modal", true)("visible", ctx.isTheOrganToMove);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngClass", ctx.organizeId ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.organs)("ngModel", ctx.organizeId)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("filterInputAutoFocus", true)("filter", true)("metaKeySelection", false)("ngModel", ctx.aDepartment)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](50, _c3, ctx.departmentFiltes.length <= 0 ? "tree-empty" : ""))("options", ctx.departmentFiltes);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.columnDefsMoveOrgan.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](52, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("appendTo", "body")("autoZIndex", true)("visible", ctx.isHrDiagram)("modal", true)("breakpoints", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](53, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.isHrDiagram);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_15__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgModel, primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__.Dropdown, primeng_api__WEBPACK_IMPORTED_MODULE_14__.PrimeTemplate, primeng_menu__WEBPACK_IMPORTED_MODULE_19__.Menu, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_20__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.Dialog, primeng_treeselect__WEBPACK_IMPORTED_MODULE_22__.TreeSelect, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__.ListGridAngularComponent, primeng_organizationchart__WEBPACK_IMPORTED_MODULE_23__.OrganizationChart], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC1iYW5nLWx1b25nLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 87050:
/*!***********************************************************************************************!*\
  !*** ./src/app/components/luong-thue/bang-luong/cong-thuc-luong/cong-thuc-luong.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CongThucLuongComponent": () => (/* binding */ CongThucLuongComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/organizationchart */ 87051);






























function CongThucLuongComponent_ng_template_36_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](item_r10.label);
} }
function CongThucLuongComponent_ng_template_37_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](car_r11.label);
} }
function CongThucLuongComponent_app_list_grid_angular_66_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-list-grid-angular", 69);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("listsData", ctx_r4.listsData)("height", ctx_r4.heightGrid)("columnDefs", ctx_r4.columnDefs)("rowSelection", "multiple")("floatingFilter", true);
} }
function CongThucLuongComponent_ng_template_78_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "span", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](item_r12 == null ? null : item_r12.label);
} }
function CongThucLuongComponent_ng_template_79_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](car_r13 == null ? null : car_r13.label);
} }
function CongThucLuongComponent_app_list_grid_angular_87_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-list-grid-angular", 72);
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("listsData", ctx_r7.theOrganToMoveData)("height", 500)("idGrid", "theOrganToMoveData")("domLayout", "autoHeight")("columnDefs", ctx_r7.columnDefsMoveOrgan)("rowSelection", "multiple");
} }
function CongThucLuongComponent_ng_template_89_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](0, " L\u1ECDc nh\u00E2n s\u1EF1 theo s\u01A1 \u0111\u1ED3 t\u1ED5 ch\u1EE9c\n");
} }
function CongThucLuongComponent_p_organizationChart_90_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "img", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const node_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"]("", node_r16.data.position ? node_r16.data.position : "No position", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpropertyInterpolate"]("src", node_r16.data.avatarUrl ? node_r16.data.avatarUrl : "../../../../../assets/images/img_avatar.png", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](node_r16.data.full_name ? node_r16.data.full_name : "No name");
} }
function CongThucLuongComponent_p_organizationChart_90_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](0);
} if (rf & 2) {
    const node_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", node_r17.label, " ");
} }
function CongThucLuongComponent_p_organizationChart_90_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "p-organizationChart", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("selectionChange", function CongThucLuongComponent_p_organizationChart_90_Template_p_organizationChart_selectionChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r19); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](); return ctx_r18.selectedNode = $event; })("onNodeSelect", function CongThucLuongComponent_p_organizationChart_90_Template_p_organizationChart_onNodeSelect_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r19); const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](); return ctx_r20.onNodeSelect($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, CongThucLuongComponent_p_organizationChart_90_ng_template_1_Template, 6, 3, "ng-template", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, CongThucLuongComponent_p_organizationChart_90_ng_template_2_Template, 1, 1, "ng-template", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", ctx_r9.listAgencyMap)("preserveSpace", false)("selection", ctx_r9.selectedNode);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "60vw" }; };
const _c3 = function (a0) { return [a0]; };
const _c4 = function () { return { width: "90vw" }; };
const _c5 = function () { return { "1024": "95vw", "640px": "100vw" }; };
class CongThucLuongComponent {
    constructor(apiService, spinner, route, confirmationService, messageService, fileService, changeDetector, router) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.changeDetector = changeDetector;
        this.router = router;
        this.tabsItem = [];
        this.excelStyles = [
            {
                id: 'stringType',
                dataType: 'string'
            },
            {
                id: 'dateType',
                dataType: 'dateTime'
            },
            {
                id: 'numberType',
                dataType: 'number'
            }
        ];
        this.pagingComponent = {
            total: 0
        };
        this.projects = [];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.listsData = null;
        this.capaStatus = [
            { label: 'Tất cả', value: -1 },
            { label: 'Chưa duyệt', value: 0 },
            { label: 'Đã duyệt', value: 1 },
            { label: 'Từ chối', value: 2 },
            { label: 'Khởi tạo', value: null },
        ];
        this.totalRecord = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.isShowAvatar = false;
        this.imgAvatar = '';
        this.modelTM = {};
        this.displayEmployee = false;
        // for the move organ
        this.departmentFiltes = [];
        this.organizeId = '';
        this.theOrganToMoveData = [];
        this.isTheOrganToMove = false;
        this.queryStaffToMove = {
            organizeId: '',
            orgId: '',
            members: []
        };
        this.organs = [];
        this.isButtonmoveOrganNow = true;
        this.itemsToolOfGrid = [];
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            orgId: 0,
            isLock: -1,
            isApprove: -1,
            emp_st: -1
        };
        this.titleForm = {
            label: 'Thêm mới phòng ban',
            value: 'Add'
        };
        this.displayOrganize = false;
        this.displayButton = false;
        this.detailOrganizeMap = null;
        this.departments = [];
        this.isHrDiagram = false;
        this.displaySetting = false;
        this.gridKey = '';
        this.employeeStatus = [];
        this.organizeList = [];
        this.columnDefsMoveOrgan = [];
        this.listDataSelect = [];
        this.loadjs = 0;
        this.heightGrid = 0;
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            tooltipComponentParams: { color: '#ececec' },
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 50;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__.AvatarFullComponent,
        };
    }
    onmouseenter(event) {
        console.log(event);
    }
    cancel() {
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            orgId: 0,
            isLock: -1,
            isApprove: -1,
            emp_st: -1
        };
        this.load();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    getAgencyOrganizeMap(type = false) {
        this.apiService.getAgencyOrganizeMap().subscribe(results => {
            var _a;
            if (results.status === 'success') {
                this.listAgencyMap = [...results.data.root];
                if (localStorage.getItem("organize") === null) {
                    this.selectedNode = this.listAgencyMap[0];
                    localStorage.setItem('organize', JSON.stringify(this.listAgencyMap[0]));
                    this.query.orgId = this.selectedNode.orgId;
                    this.load();
                }
                else {
                    this.selectedNode = JSON.parse(localStorage.getItem("organize"));
                    this.query.orgId = (_a = this.selectedNode) === null || _a === void 0 ? void 0 : _a.orgId;
                    this.listAgencyMap = this.expanded(this.listAgencyMap, this.selectedNode.parentId);
                    this.selected(this.listAgencyMap, this.query.orgId);
                    if (type) {
                        this.isHrDiagram = true;
                    }
                    this.load();
                }
            }
        });
    }
    expanded(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                d.expanded = true;
            }
            else {
                if (d.children.length > 0)
                    this.expanded(d.children, this.selectedNode.parentId);
            }
            d.children.forEach((elm) => {
                elm.children.forEach((e) => {
                    if (e.expanded === true) {
                        elm.expanded = true;
                    }
                });
            });
        });
        return datas;
    }
    selected(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                this.selectedNode = d;
                this.detailOrganizeMap = d;
            }
            else {
                if (d.children.length > 0)
                    this.selected(d.children, this.selectedNode.orgId);
            }
        });
    }
    themnhanvien() {
        const params = {
            empId: 0
        };
        this.router.navigate(['/ho-so-nhan-su/them-moi-nhan-vien'], { queryParams: params });
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getEmployeePage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.EditEmployee.bind(this),
                    label: 'Thông tin chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                },
                {
                    onClick: this.xoanhanvien.bind(this),
                    label: 'Xóa nhân viên này',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: '',
                filter: false,
                maxWidth: 50,
                pinned: 'left',
                cellRenderer: params => {
                    // return params.rowIndex + 1
                },
                cellClass: ['border-right', 'no-auto'],
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: false,
                field: 'checkbox2',
                suppressSizeToFit: false,
                suppressColumnsToolPanel: false,
                checkboxSelection: (params) => {
                    return !!params.data && params.data.emp_st === 0;
                },
                showDisabledCheckboxes: true,
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: '...',
                filter: '',
                maxWidth: 64,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right cell-action', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                field: 'checkbox'
            }
        ];
        this.detailCellRendererParams = {
            detailGridOptions: {
                frameworkComponents: {},
                getRowHeight: (params) => {
                    return 40;
                },
                columnDefs: [
                    ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.colsDetail),
                ],
                enableCellTextSelection: true,
                onFirstDataRendered(params) {
                    let allColumnIds = [];
                    params.columnApi.getAllColumns()
                        .forEach((column) => {
                        if (column.colDef.cellClass.indexOf('auto') < 0) {
                            allColumnIds.push(column);
                        }
                        else {
                            column.colDef.suppressSizeToFit = true;
                            allColumnIds.push(column);
                        }
                    });
                    params.api.sizeColumnsToFit(allColumnIds);
                },
            },
            getDetailRowData(params) {
                params.successCallback(params.data.AgencyGenerals);
            },
            excelStyles: [
                {
                    id: 'stringType',
                    dataType: 'string'
                }
            ],
            template: function (params) {
                var personName = params.data.theme;
                return ('<div style="height: 100%; background-color: #EDF6FF; padding: 20px; box-sizing: border-box;">' +
                    `  <div style="height: 10%; padding: 2px; font-weight: bold;">###### Danh sách (${params.data.AgencyGenerals.length}) : [` +
                    personName + ']' +
                    '</div>' +
                    '  <div ref="eDetailGrid" style="height: 90%;"></div>' +
                    '</div>');
            },
        };
    }
    xoanhanvien(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa nhân viên?',
            accept: () => {
                this.apiService.deleteEmployee(event.rowData.empId).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa nhân viên thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    staffActivity(event) {
        this.confirmationService.confirm({
            target: event.target,
            message: "Quản trị cần xác nhận nhân viên trong ngày làm việc đầu tiên là 'Xác nhận làm việc'. Ngày làm việc cuối cùng là 'Chấm dứt hợp đồng'",
            icon: 'pi pi-exclamation-triangle',
            rejectLabel: 'Chấm dứt hợp đồng',
            acceptLabel: 'Xác nhận làm việc',
            key: 'hosonhansu',
            acceptButtonStyleClass: 'p-button-sm',
            rejectButtonStyleClass: 'p-button-sm p-button-secondary',
            accept: () => {
                this.unLockEmployee({
                    empId: event.rowData.empId
                });
            },
            reject: () => {
                this.setEmployeeClose({
                    empId: event.rowData.empId
                });
            }
        });
    }
    unLockEmployee(params) {
        this.apiService.setEmployeeOpenhrm(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Xác nhận làm việc thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    setEmployeeClose(params) {
        this.apiService.setEmployeeClose(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Xác nhận nghỉ việc thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    staffApprove(event) {
        this.confirmationService.confirm({
            target: event.target,
            message: 'Bạn có muốn phê duyệt/hủy phê duyệt nhân viên này không?',
            icon: 'pi pi-exclamation-triangle',
            rejectLabel: 'Hủy phê duyệt',
            acceptLabel: 'Phê duyệt',
            key: 'hosonhansu',
            acceptButtonStyleClass: 'p-button-sm',
            rejectButtonStyleClass: 'p-button-sm p-button-secondary',
            accept: () => {
                this.setAccountStatus({
                    empId: event.rowData.empId,
                    status: true
                });
            },
            reject: () => {
                this.setAccountStatus({
                    empId: event.rowData.empId,
                    status: false
                });
            }
        });
    }
    setAccountStatus(params) {
        this.apiService.setEmployeeApprovehrm(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: params.status ? 'Phê duyệt thành công' : 'Hủy phê duyệt thành công' });
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    EditEmployee(event) {
        const params = {
            empId: event.rowData.empId
        };
        this.router.navigate(['/nhan-su/ho-so-nhan-su/chi-tiet-ho-so-nhan-su'], { queryParams: params });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Lương - thuế' },
            { label: 'Bảng lương' },
            { label: 'Công thức lương' },
        ];
        this.getAgencyOrganizeMap();
        this.getEmployeeStatus();
        this.getOrgan();
        this.itemsToolOfGrid = [
            {
                label: 'Import file',
                code: 'Import',
                icon: 'pi pi-upload',
                command: () => {
                    this.importFileExel();
                }
            },
            {
                label: 'Export file',
                code: 'Import',
                icon: 'pi pi-download',
                command: () => {
                    this.exportExel();
                }
            },
        ];
        this.tabsItem = [
            { name: 'New York', code: 'NY' },
            { name: 'Rome', code: 'RM' },
            { name: 'London', code: 'LDN' },
            { name: 'Istanbul', code: 'IST' },
            { name: 'Paris', code: 'PRS' }
        ];
    }
    getEmployeeStatus() {
        this.apiService.getEmployeeStatus().subscribe(results => {
            if (results.status === 'success') {
                this.employeeStatus = [];
                results.data.forEach(s => {
                    if (s.value != "3") {
                        this.employeeStatus.push({
                            label: s.name,
                            value: s.value
                        });
                    }
                });
                this.employeeStatus = [{ label: '---Chọn---', value: -1 }, ...this.employeeStatus];
            }
        });
    }
    onNodeSelect(event) {
        var _a;
        this.detailOrganizeMap = event.node;
        localStorage.setItem('organize', JSON.stringify(event.node));
        // this.query.orgId = this.selectedNode?.orgId;
        this.query.orgId = (_a = this.detailOrganizeMap) === null || _a === void 0 ? void 0 : _a.orgId;
        this.isHrDiagram = false;
        this.load();
    }
    hrDiagram() {
        this.selectedNode = null;
        this.listAgencyMap = [];
        this.getAgencyOrganizeMap(true);
    }
    Back() {
        this.router.navigate(['/page-agency']);
    }
    Close() {
        this.displayOrganize = false;
    }
    onCellClicked(event) {
        if (event.column.colId == "avatar_url") {
            this.isShowAvatar = true;
            this.imgAvatar = event.value;
        }
    }
    exportGrid() {
        this.gridApi.exportDataAsExcel();
    }
    getContextMenuItems(params) {
        var result = [
            'copy',
            'paste',
            'separator',
        ];
        return result;
    }
    exportExel() {
        this.spinner.show();
        this.query.pageSize = 1000000;
        const query = Object.assign({}, this.query);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query);
        this.apiService.getEmployeePage(queryParams).subscribe((results) => {
            const dataExport = [];
            let gridflexs = results.data.gridflexs;
            let arrKey = gridflexs.map(elementName => elementName.columnField);
            let dataList = results.data.dataList.data;
            for (let elementValue of dataList) {
                const data = {};
                for (let elementName of gridflexs) {
                    if (arrKey.indexOf(elementName.columnField) > -1 && !elementName.isHide && elementName.columnField !== 'statusName') {
                        let valueColumn = elementValue[elementName.columnField];
                        if (elementName.columnField == 'status_name' || elementName.columnField == 'isContacted' || elementName.columnField == 'isProfileFull' || elementName.columnField == 'lockName') {
                            valueColumn = this.replaceHtmlToText(valueColumn);
                        }
                        data[elementName.columnCaption] = valueColumn || '';
                    }
                }
                dataExport.push(data);
            }
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách hồ sơ nhân sự ' + new Date());
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    getColumnDefsMoveOrgan() {
        this.columnDefsMoveOrgan = [
            {
                headerName: 'Stt',
                filter: '',
                maxWidth: 90,
                pinned: 'left',
                cellRenderer: params => {
                    return params.rowIndex + 1;
                },
                cellClass: ['border-right', 'no-auto'],
            },
            {
                headerName: 'Mã NV',
                filter: '',
                cellClass: ['border-right', 'yellow-bg'],
                field: 'code',
                editable: true
            },
            {
                headerName: 'Họ tên',
                filter: '',
                cellClass: ['border-right'],
                field: 'full_name',
            },
            {
                headerName: 'Số ĐT',
                filter: '',
                cellClass: ['border-right'],
                field: 'phone1',
            },
            {
                headerName: 'Tổ chức',
                filter: '',
                cellClass: ['border-right'],
                field: 'organization',
            },
            {
                headerName: 'Thao tác',
                filter: '',
                maxWidth: 120,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons2(params),
                field: 'button'
            }
        ];
    }
    showButtons2(params) {
        return {
            buttons: [
                {
                    onClick: this.delStaffinDataOraMove.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                },
            ]
        };
    }
    delStaffinDataOraMove(data) {
        this.theOrganToMoveData = this.theOrganToMoveData.filter(a => a.CustId != data.rowData.CustId);
        if (this.theOrganToMoveData.length < 1) {
            this.isButtonmoveOrganNow = true;
        }
    }
    theOrganToMove() {
        // ColumnDefs for data move 
        this.getColumnDefsMoveOrgan();
        this.getOrgan();
        if (this.listDataSelect.length > 0) {
            this.theOrganToMoveData = (0,lodash__WEBPACK_IMPORTED_MODULE_8__.cloneDeep)(this.listDataSelect);
            this.isTheOrganToMove = true;
        }
        else {
            this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Vui lòng nhân sự' });
        }
    }
    getOrgan() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.organs = results.data.map(d => {
                    return {
                        label: d.organizationName,
                        value: `${d.organizeId}`
                    };
                });
                this.organs = [...this.organs];
            }
        });
    }
    getOrganizeTree() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ parentId: this.organizeId });
        this.apiService.getOrganizeTree(queryParams)
            .subscribe((results) => {
            if (results && results.status === 'success') {
                this.departmentFiltes = results.data;
            }
        }, error => { });
        this.queryStaffToMove.orgId = '';
        this.aDepartment = '';
        if (this.organizeId && this.queryStaffToMove.orgId) {
            this.isButtonmoveOrganNow = false;
        }
        else {
            this.isButtonmoveOrganNow = true;
        }
    }
    // handleChangeOrganize() {
    //   this.getOrganizeTree();
    // }
    onChangeTreeDepart(event) {
        this.queryStaffToMove.orgId = event.node.orgId;
        // if(this.organizeId && event.node.orgId){
        //   this.isButtonmoveOrganNow = false;
        // }
        // else {
        //   this.isButtonmoveOrganNow = true;
        // }
        //MS-773
        this.isButtonmoveOrganNow = false;
    }
    moveOrganNow() {
        if (this.theOrganToMoveData.length > 0) {
            this.queryStaffToMove.organizeId = this.organizeId;
            this.queryStaffToMove.members = this.theOrganToMoveData.map(o => {
                return {
                    empId: o.empId,
                    code: o.code
                };
            });
            this.apiService.setListEmployeeChange(this.queryStaffToMove).subscribe(results => {
                if (results.status === 'success') {
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Cập nhật thành công' });
                    this.load();
                    this.listDataSelect = [];
                    this.isTheOrganToMove = false;
                }
                else {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
                }
            });
        }
    }
    rowSelected(data) {
        if (data[0] && data[0].emp_st !== 1) {
            this.listDataSelect = data;
        }
        else {
            this.listDataSelect = [];
        }
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    importFileExel() {
        this.router.navigate(['/nhan-su/ho-so-nhan-su/import']);
    }
}
CongThucLuongComponent.ɵfac = function CongThucLuongComponent_Factory(t) { return new (t || CongThucLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_12__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_14__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_7__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_11__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.Router)); };
CongThucLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({ type: CongThucLuongComponent, selectors: [["app-cong-thuc-luong"]], decls: 91, vars: 54, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [3, "displayTitle", "items", "title"], [1, "d-flex", "bet", "mid", "bottom", "gap-12"], ["styleClass", "p-button-sm height-56"], ["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M13.6667 8.08835H8.08848V13.6666H5.91161V8.08835H0.333374V5.91148H5.91161V0.333252H8.08848V5.91148H13.6667V8.08835Z", "fill", "#F6FBFF"], ["styleClass", "p-button-sm height-56 btn-dele"], ["width", "14", "height", "16", "viewBox", "0 0 14 16", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M11.1663 5.91658V14.2499H2.83301V5.91658H11.1663ZM9.91634 0.083252H4.08301L3.24967 0.916585H0.333008V2.58325H13.6663V0.916585H10.7497L9.91634 0.083252ZM12.833 4.24992H1.16634V14.2499C1.16634 15.1666 1.91634 15.9166 2.83301 15.9166H11.1663C12.083 15.9166 12.833 15.1666 12.833 14.2499V4.24992Z", "fill", "#F6FBFF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M4.49967 12.1666V7.58325H6.16634V12.1666H4.49967Z", "fill", "#F6FBFF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M7.83301 12.1666V7.58325H9.49967V12.1666H7.83301Z", "fill", "#F6FBFF"], ["width", "16", "height", "15", "viewBox", "0 0 16 15", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M13.8333 9.49992V12.8333H2.16667V9.49992H0.5V14.4999H15.5V9.49992H13.8333ZM8.83333 7.55825L10.9917 5.40825L12.1667 6.58325L8 10.7499L3.83333 6.58325L5.00833 5.40825L7.16667 7.55825V0.333252H8.83333V7.55825Z", "fill", "#F6FBFF"], ["width", "14", "height", "20", "viewBox", "0 0 14 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M6.99992 4.99992V7.49992L10.3333 4.16658L6.99992 0.833252V3.33325C3.31659 3.33325 0.333252 6.31658 0.333252 9.99992C0.333252 11.3083 0.716585 12.5249 1.36659 13.5499L2.58325 12.3333C2.20825 11.6416 1.99992 10.8416 1.99992 9.99992C1.99992 7.24158 4.24159 4.99992 6.99992 4.99992ZM12.6333 6.44992L11.4166 7.66658C11.7833 8.36658 11.9999 9.15825 11.9999 9.99992C11.9999 12.7583 9.75825 14.9999 6.99992 14.9999V12.4999L3.66659 15.8333L6.99992 19.1666V16.6666C10.6833 16.6666 13.6666 13.6833 13.6666 9.99992C13.6666 8.69158 13.2833 7.47492 12.6333 6.44992Z", "fill", "#F6FBFF"], [1, "bread-filter", "d-flex", "bet", "bottom"], [1, "col-item"], [1, "d-flex", "align-items-center"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "field-group", "select", "mb-0"], ["appendTo", "body", "name", "emp_st", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "d-flex", "end", "middle", "gap-16"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 "], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "18", "height", "18", "viewBox", "0 0 18 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M10.2002 13.2H13.2002V10.2H14.8002V13.2H17.8002V14.8H14.8002V17.7999H13.2002V14.8H10.2002V13.2Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 0.199951H7.8002V7.79995H0.200195V0.199951ZM6.2002 1.79995H1.8002V6.19995H6.2002V1.79995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.8002 7.79995H10.2002V0.199951H17.8002V7.79995ZM11.8002 6.19995H16.2002V1.79995H11.8002V6.19995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 10.2H7.8002V17.7999H0.200195V10.2ZM6.2002 11.8H1.8002V16.2H6.2002V11.8Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M6.10199 10.0001C6.10199 7.84533 7.84722 6.1001 10.002 6.1001C12.1568 6.1001 13.902 7.84533 13.902 10.0001C13.902 12.1549 12.1568 13.9001 10.002 13.9001C7.84722 13.9001 6.10199 12.1549 6.10199 10.0001ZM7.90199 10.0001C7.90199 11.1553 8.84676 12.1001 10.002 12.1001C11.1572 12.1001 12.102 11.1553 12.102 10.0001C12.102 8.84487 11.1572 7.9001 10.002 7.9001C8.84676 7.9001 7.90199 8.84487 7.90199 10.0001Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.3328 10.9677L17.3257 11.0239L19.4802 12.7087C19.6292 12.8265 19.6721 13.0416 19.5748 13.2212L17.5754 16.68L17.5748 16.6811C17.5036 16.8078 17.368 16.8801 17.232 16.8801C17.1842 16.8801 17.1358 16.8723 17.0864 16.8561L14.547 15.8363L14.502 15.8701C13.9872 16.2562 13.4345 16.5915 12.8341 16.8376L12.7811 16.8593L12.393 19.5659L12.3928 19.5677C12.3693 19.7551 12.2042 19.9001 12.002 19.9001H8.00199C7.79981 19.9001 7.63464 19.7551 7.61124 19.5677L7.22286 16.8593L7.16991 16.8376C6.56875 16.5912 6.01644 16.2658 5.50296 15.8708L5.45771 15.836L2.91485 16.8573C2.87884 16.8717 2.83184 16.8801 2.78199 16.8801C2.63486 16.8801 2.4999 16.8068 2.42916 16.6811L0.429221 13.2212C0.331903 13.0416 0.37495 12.8264 0.523956 12.7086L2.67825 11.0239L2.67122 10.9677C2.63148 10.6497 2.60199 10.3243 2.60199 10.0001C2.60199 9.67591 2.63148 9.35045 2.67122 9.0325L2.67825 8.97625L0.523811 7.29149C0.371682 7.17128 0.32503 6.95535 0.428568 6.78014L2.42857 3.32015L2.42915 3.31912C2.50042 3.19243 2.63599 3.1201 2.77199 3.1201C2.81979 3.1201 2.86823 3.12789 2.91764 3.14406L5.45696 4.16387L5.50199 4.1301C6.01682 3.74398 6.56946 3.40872 7.16991 3.16263L7.22286 3.14093L7.611 0.434295L7.61122 0.432501C7.63464 0.245098 7.79981 0.100098 8.00199 0.100098H12.002C12.2042 0.100098 12.3693 0.2451 12.3927 0.432503L12.7811 3.14093L12.8341 3.16263C13.4352 3.40901 13.9875 3.73438 14.501 4.12936L14.5463 4.16417L17.0891 3.14295C17.1251 3.12854 17.1721 3.1201 17.222 3.1201C17.3691 3.1201 17.5041 3.19335 17.5748 3.31913L19.5748 6.779C19.6721 6.95858 19.6291 7.17383 19.48 7.29161L17.3257 8.97625L17.3328 9.0325C17.3725 9.35055 17.402 9.66597 17.402 10.0001C17.402 10.3342 17.3725 10.6496 17.3328 10.9677ZM15.2644 5.79743L14.2575 6.20588L13.393 5.54083L13.392 5.5401C12.9857 5.23541 12.5786 5.0012 12.1406 4.81785L11.133 4.40909L10.7789 1.9001H9.21572L9.00298 3.33608L8.85105 4.40907L7.84369 4.81772C7.42462 4.99148 7.00691 5.23644 6.57171 5.56031L5.71691 6.20616L4.72926 5.8073L3.37883 5.265L2.59177 6.6255L3.7406 7.51903L4.58581 8.18381L4.45272 9.2578L4.45249 9.26015C4.42253 9.5597 4.40199 9.79442 4.40199 10.0001C4.40199 10.2057 4.42249 10.4405 4.45242 10.7497L4.58581 11.8264L3.74017 12.4915L2.59177 13.3847L3.37883 14.7452L4.72958 14.2028L5.73646 13.7943L6.60102 14.4594L6.60199 14.4601C7.00825 14.7648 7.41539 14.999 7.85338 15.1823L8.86102 15.5911L9.21511 18.1001H10.7883L11.001 16.6641L11.1529 15.5911L12.1603 15.1825C12.5794 15.0087 12.9971 14.7638 13.4323 14.4399L14.2871 13.794L15.2747 14.1929L16.6252 14.7352L17.4122 13.3747L16.2634 12.4812L15.4182 11.8164L15.5513 10.7424L15.5515 10.74C15.5814 10.4406 15.602 10.2158 15.602 10.0001C15.602 9.78595 15.5917 9.57141 15.5512 9.2573L15.4182 8.18381L16.2642 7.5184L17.4018 6.61472L16.6152 5.255L15.2644 5.79743Z", "fill", "#F3F8FF"], ["styleClass", "menu-option-right", 3, "model", "appendTo", "popup"], ["menuButton", ""], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "rowSelection", "floatingFilter", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "Chuy\u1EC3n t\u1ED5 ch\u1EE9c", 3, "modal", "visible", "visibleChange"], [1, "grid"], [1, "col-4"], [1, "field-group", "select", "mb-0", "label-8", 3, "ngClass"], ["appendTo", "body", "name", "organizeId", "placeholder", "Ch\u1ECDn t\u1ED5 ch\u1EE9c", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "onChange", "ngModelChange"], [1, "field-group", "select", "mb-0", "label-8"], ["selectionMode", "single", "name", "aDepartment", "placeholder", "Ch\u1ECDn ph\u00F2ng ban", 3, "filterInputAutoFocus", "filter", "metaKeySelection", "ngModel", "ngClass", "options", "ngModelChange", "onNodeSelect"], [1, "col-12"], [3, "listsData", "height", "idGrid", "domLayout", "columnDefs", "rowSelection", 4, "ngIf"], ["styleClass", "hr-diagram", 3, "appendTo", "autoZIndex", "visible", "modal", "breakpoints", "visibleChange"], ["pTemplate", "header"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect", 4, "ngIf"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [3, "listsData", "height", "columnDefs", "rowSelection", "floatingFilter"], [2, "vertical-align", "middle"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"], [3, "listsData", "height", "idGrid", "domLayout", "columnDefs", "rowSelection"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect"], ["pTemplate", "person"], ["pTemplate", "department"], [1, "node-header", "p-corner-top"], [1, "node-content"], ["width", "32", 3, "src"]], template: function CongThucLuongComponent_Template(rf, ctx) { if (rf & 1) {
        const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](5, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "svg", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](7, "path", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](8, " \u00A0 Th\u00EAm m\u01A1\u0301i ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](10, "svg", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](11, "path", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](12, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](13, "path", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](14, " \u00A0 Xo\u0301a ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](15, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](17, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](18, " \u00A0 C\u00E2\u0323p nh\u00E2\u0323t ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](19, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](20, "svg", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](21, "path", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](22, " \u00A0 Import ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](23, "section", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](24, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](25, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](26, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](27, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](28, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("keydown.enter", function CongThucLuongComponent_Template_input_keydown_enter_28_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function CongThucLuongComponent_Template_input_ngModelChange_28_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](29, "span", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function CongThucLuongComponent_Template_span_click_29_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](30, "svg", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](31, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](32, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](33, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](34, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](35, "p-dropdown", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("ngModelChange", function CongThucLuongComponent_Template_p_dropdown_ngModelChange_35_listener($event) { return ctx.query.emp_st = $event; })("onChange", function CongThucLuongComponent_Template_p_dropdown_onChange_35_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](36, CongThucLuongComponent_ng_template_36_Template, 2, 1, "ng-template", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](37, CongThucLuongComponent_ng_template_37_Template, 3, 1, "ng-template", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](38, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](39, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](40, "p-button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function CongThucLuongComponent_Template_p_button_click_40_listener() { ctx.query.offSet = 0; ctx.query.filter = ""; ctx.query.emp_st = -1; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](41, "svg", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](42, "path", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](43, "p-button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](44, "svg", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](45, "path", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](46, "path", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](47, "path", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](48, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](49, "p-button", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function CongThucLuongComponent_Template_p_button_click_49_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r21); const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵreference"](62); return _r2.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](50, "svg", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](51, "path", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](52, "path", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](53, "path", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](54, "path", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](55, " \u00A0 Ti\u1EC7n \u00EDch ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](56, "p-button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](57, "svg", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](58, "path", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](59, "path", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](60, " \u00A0 T\u00F9y ch\u1EC9nh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](61, "p-menu", 48, 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](63, "section", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](64, "div", 51, 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](66, CongThucLuongComponent_app_list_grid_angular_66_Template, 1, 5, "app-list-grid-angular", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](67, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](68, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](69);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](70, "p-paginator", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("onPageChange", function CongThucLuongComponent_Template_p_paginator_onPageChange_70_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](71, "p-dialog", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("visibleChange", function CongThucLuongComponent_Template_p_dialog_visibleChange_71_listener($event) { return ctx.isTheOrganToMove = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](72, "div", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](73, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](74, "div", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](75, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](76, "T\u1ED5 ch\u1EE9c");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](77, "p-dropdown", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("onChange", function CongThucLuongComponent_Template_p_dropdown_onChange_77_listener() { return ctx.getOrganizeTree(); })("ngModelChange", function CongThucLuongComponent_Template_p_dropdown_ngModelChange_77_listener($event) { return ctx.organizeId = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](78, CongThucLuongComponent_ng_template_78_Template, 2, 1, "ng-template", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](79, CongThucLuongComponent_ng_template_79_Template, 3, 1, "ng-template", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](80, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](81, "div", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](82, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](83, "B\u1ED9 ph\u1EADn");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](84, "p-treeSelect", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("ngModelChange", function CongThucLuongComponent_Template_p_treeSelect_ngModelChange_84_listener($event) { return ctx.aDepartment = $event; })("onNodeSelect", function CongThucLuongComponent_Template_p_treeSelect_onNodeSelect_84_listener($event) { return ctx.onChangeTreeDepart($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](85, "div", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](86, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](87, CongThucLuongComponent_app_list_grid_angular_87_Template, 1, 6, "app-list-grid-angular", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](88, "p-dialog", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("visibleChange", function CongThucLuongComponent_Template_p_dialog_visibleChange_88_listener($event) { return ctx.isHrDiagram = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](89, CongThucLuongComponent_ng_template_89_Template, 1, 0, "ng-template", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](90, CongThucLuongComponent_p_organizationChart_90_Template, 3, 3, "p-organizationChart", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("displayTitle", true)("items", ctx.items)("title", "C\u00F4ng th\u01B0\u0301c l\u01B0\u01A1ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.employeeStatus)("ngModel", ctx.query.emp_st)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("model", ctx.itemsToolOfGrid)("appendTo", "body")("popup", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](47, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](46, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](49, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("modal", true)("visible", ctx.isTheOrganToMove);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngClass", ctx.organizeId ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.organs)("ngModel", ctx.organizeId)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("filterInputAutoFocus", true)("filter", true)("metaKeySelection", false)("ngModel", ctx.aDepartment)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](50, _c3, ctx.departmentFiltes.length <= 0 ? "tree-empty" : ""))("options", ctx.departmentFiltes);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.columnDefsMoveOrgan.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](52, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("appendTo", "body")("autoZIndex", true)("visible", ctx.isHrDiagram)("modal", true)("breakpoints", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](53, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.isHrDiagram);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_15__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgModel, primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__.Dropdown, primeng_api__WEBPACK_IMPORTED_MODULE_14__.PrimeTemplate, primeng_menu__WEBPACK_IMPORTED_MODULE_19__.Menu, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_20__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.Dialog, primeng_treeselect__WEBPACK_IMPORTED_MODULE_22__.TreeSelect, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__.ListGridAngularComponent, primeng_organizationchart__WEBPACK_IMPORTED_MODULE_23__.OrganizationChart], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb25nLXRodWMtbHVvbmcuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 725:
/*!******************************************************************************************************************************!*\
  !*** ./src/app/components/luong-thue/tinh-luong/tab-bang-luong/chi-tiet-tab-bang-luong/chi-tiet-tab-bang-luong.component.ts ***!
  \******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietTabBangLuongComponent": () => (/* binding */ ChiTietTabBangLuongComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);






















function ChiTietTabBangLuongComponent_app_edit_detail_3_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-edit-detail", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("callback", function ChiTietTabBangLuongComponent_app_edit_detail_3_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return ctx_r4.handleSave($event); })("callbackcancel", function ChiTietTabBangLuongComponent_app_edit_detail_3_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r5); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return ctx_r6.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
function ChiTietTabBangLuongComponent_app_list_grid_angular_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "app-list-grid-angular", 15);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("columnDefs", ctx_r1.columnDefs)("height", 500)("listsData", ctx_r1.listsData);
} }
function ChiTietTabBangLuongComponent_app_edit_detail_12_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-edit-detail", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("callback", function ChiTietTabBangLuongComponent_app_edit_detail_12_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return ctx_r7.handleSaveTab1($event); })("callbackcancel", function ChiTietTabBangLuongComponent_app_edit_detail_12_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r8); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return ctx_r9.quaylaiDetail($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("detail", ctx_r2.detailInfoDetail)("manhinh", "Edit")("optionsButtonsEdit", ctx_r2.optionsButon)("dataView", ctx_r2.listViewsDetail);
} }
function ChiTietTabBangLuongComponent_app_config_grid_table_form_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "app-config-grid-table-form", 16);
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r3.gridKey);
} }
const _c0 = function () { return { width: "600px" }; };
const _c1 = function () { return { width: "50vw" }; };
class ChiTietTabBangLuongComponent {
    constructor(activatedRoute, apiService, spinner, messageService, router, confirmationService) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.router = router;
        this.confirmationService = confirmationService;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS.EDIT_TINH_LUONG_BANG_LUONG) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.titlePage = '';
        this.idForm = null;
        this.detailOut = new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subject();
        this.tabIndex = 0;
        this.columnDefs = [];
        this.listsData = [];
        this.gridflexs = [];
        this.gridKey = '';
        this.displaySetting = false;
        this.isFormDetail = false;
        this.IdDetail = null;
        this.listViewsDetail = [];
        this.detailInfoDetail = null;
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.getDetail();
    }
    getDetail() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ Id: this.idForm });
        this.apiService.getPayrollInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(listViews);
                this.detailInfo = results.data;
            }
        });
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getDetail();
        }
        else {
            this.detailOut.emit();
        }
    }
    handleSave(event) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: event });
        this.apiService.setPayrollInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.detailOut.emit();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
    handleChange(e) {
        this.tabIndex = e;
        if (e === 1) {
            this.getPayrollComponentPage();
        }
    }
    cauhinh() {
        this.displaySetting = true;
    }
    getPayrollComponentPage() {
        this.spinner.show();
        this.columnDefs = [];
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ appInfoId: this.idForm, offSet: 0, pageSize: 10000 });
        this.apiService.getPayrollComponentPage(queryParams).subscribe(repo => {
            if (repo.status === 'success') {
                this.listsData = repo.data.dataList.data;
                this.gridflexs = repo.data.gridflexs;
                if (repo.data.dataList.gridKey) {
                    this.gridKey = repo.data.dataList.gridKey;
                }
                this.spinner.hide();
                this.initGrid();
            }
            else {
                this.spinner.hide();
            }
        });
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.AgGridFn)(this.gridflexs.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editRow.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'pi pi-tablet',
                    class: 'btn-primary mr5',
                    // hide: CheckHideAction(MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, ACTIONS.VIEW_TINH_LUONG_BANG_LUONG)
                },
                {
                    onClick: this.deleteRow.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    // hide: CheckHideAction(MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, ACTIONS.DELETE_TINH_LUONG_BANG_LUONG)
                },
            ]
        };
    }
    editRow(event) {
        this.IdDetail = event.rowData.id;
        this.getPayrollComponentInfo();
    }
    addPayroll() {
        this.IdDetail = null;
        this.getPayrollComponentInfo();
    }
    getPayrollComponentInfo() {
        this.listViewsDetail = [];
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ Id: this.IdDetail, appInfoId: this.idForm });
        this.apiService.getPayrollComponentInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViewsDetail = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(listViews);
                this.detailInfoDetail = results.data;
                this.isFormDetail = true;
            }
        });
    }
    deleteRow(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa',
            accept: () => {
                const query = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ Id: event.rowData.id });
                this.apiService.delPayrollComponent(query).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa công' });
                        this.getPayrollComponentPage();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    handleSaveTab1(event) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfoDetail), { group_fields: event });
        this.apiService.setPayrollComponentInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.isFormDetail = false;
                this.getPayrollComponentPage();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
    quaylaiDetail(data) {
        if (data === 'CauHinh') {
            this.getPayrollComponentInfo();
        }
        else {
            this.isFormDetail = false;
        }
    }
}
ChiTietTabBangLuongComponent.ɵfac = function ChiTietTabBangLuongComponent_Factory(t) { return new (t || ChiTietTabBangLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_12__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_13__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_13__.ConfirmationService)); };
ChiTietTabBangLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({ type: ChiTietTabBangLuongComponent, selectors: [["app-chi-tiet-tab-bang-luong"]], inputs: { idForm: "idForm" }, outputs: { detailOut: "detailOut" }, decls: 15, vars: 23, consts: [[3, "activeIndex", "onChange", "activeIndexChange"], ["header", "Th\u00F4ng tin chi ti\u1EBFt b\u1EA3ng l\u01B0\u01A1ng"], [1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], ["header", "Th\u00E0nh ph\u1EA7n l\u01B0\u01A1ng"], [1, "grid"], [1, "col-6"], [1, "col-6", "text-right"], ["label", "Th\u00EAm m\u1EDBi", "icon", "pi pi-plus", "styleClass", "p-button-sm mr-1", 3, "click"], ["label", "C\u1EA5u h\u00ECnh", "icon", "pi pi-cog", "styleClass", "p-button-sm", 3, "click"], [3, "columnDefs", "height", "listsData", 4, "ngIf"], ["header", "Th\u00EAm th\u00E0nh ph\u1EA7n l\u01B0\u01A1ng", 3, "visible", "modal", "draggable", "resizable", "focusTrap", "visibleChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "appendTo", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"], [3, "columnDefs", "height", "listsData"], [3, "typeConfig", "gridKey"]], template: function ChiTietTabBangLuongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "p-tabView", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("onChange", function ChiTietTabBangLuongComponent_Template_p_tabView_onChange_0_listener($event) { return ctx.handleChange($event.index); })("activeIndexChange", function ChiTietTabBangLuongComponent_Template_p_tabView_activeIndexChange_0_listener($event) { return ctx.tabIndex = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "p-tabPanel", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](3, ChiTietTabBangLuongComponent_app_edit_detail_3_Template, 1, 4, "app-edit-detail", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](4, "p-tabPanel", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](8, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ChiTietTabBangLuongComponent_Template_p_button_click_8_listener() { return ctx.addPayroll(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "p-button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ChiTietTabBangLuongComponent_Template_p_button_click_9_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](10, ChiTietTabBangLuongComponent_app_list_grid_angular_10_Template, 1, 3, "app-list-grid-angular", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](11, "p-dialog", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("visibleChange", function ChiTietTabBangLuongComponent_Template_p_dialog_visibleChange_11_listener($event) { return ctx.isFormDetail = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](12, ChiTietTabBangLuongComponent_app_edit_detail_12_Template, 1, 4, "app-edit-detail", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](13, "p-dialog", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("visibleChange", function ChiTietTabBangLuongComponent_Template_p_dialog_visibleChange_13_listener($event) { return ctx.displaySetting = $event; })("onHide", function ChiTietTabBangLuongComponent_Template_p_dialog_onHide_13_listener() { return ctx.getPayrollComponentPage(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](14, ChiTietTabBangLuongComponent_app_config_grid_table_form_14_Template, 1, 2, "app-config-grid-table-form", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("activeIndex", ctx.tabIndex);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](21, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("visible", ctx.isFormDetail)("modal", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.listViewsDetail.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](22, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("visible", ctx.displaySetting)("appendTo", "body")("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [primeng_tabview__WEBPACK_IMPORTED_MODULE_14__.TabView, primeng_tabview__WEBPACK_IMPORTED_MODULE_14__.TabPanel, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, primeng_button__WEBPACK_IMPORTED_MODULE_16__.Button, primeng_dialog__WEBPACK_IMPORTED_MODULE_17__.Dialog, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__.EditDetailComponent, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_6__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_7__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC10YWItYmFuZy1sdW9uZy5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 19535:
/*!**************************************************************************************************!*\
  !*** ./src/app/components/luong-thue/tinh-luong/tab-bang-luong/muc-luong/muc-luong.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MucLuongComponent": () => (/* binding */ MucLuongComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);



















function MucLuongComponent_app_list_grid_angular_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "app-list-grid-angular", 10);
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("columnDefs", ctx_r0.columnDefs)("height", 500)("listsData", ctx_r0.listsData);
} }
function MucLuongComponent_app_edit_detail_7_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "app-edit-detail", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("callback", function MucLuongComponent_app_edit_detail_7_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r4); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r3.handleSaveTab1($event); })("callbackcancel", function MucLuongComponent_app_edit_detail_7_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r4); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r5.quaylaiDetail($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("detail", ctx_r1.detailInfoDetail)("manhinh", "Edit")("optionsButtonsEdit", ctx_r1.optionsButon)("dataView", ctx_r1.listViewsDetail);
} }
function MucLuongComponent_app_config_grid_table_form_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "app-config-grid-table-form", 12);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r2.gridKey);
} }
const _c0 = function () { return { width: "600px" }; };
const _c1 = function () { return { width: "50vw" }; };
class MucLuongComponent {
    constructor(activatedRoute, apiService, spinner, messageService, router, confirmationService) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.router = router;
        this.confirmationService = confirmationService;
        this.detailInfo = null;
        this.listViews = [];
        this.baseId = null;
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: '', icon: 'pi pi-check' }
        ];
        this.displaySetting = false;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_8__.Subject();
        this.columnDefs = [];
        this.listsData = [];
        this.gridKey = "";
        this.gridflexs = [];
        this.isFormDetail = false;
        this.IdDetail = null;
        this.listViewsDetail = [];
        this.detailInfoDetail = null;
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    ngOnInit() {
        this.getPayrollRankPage();
    }
    getPayrollRankPage() {
        this.spinner.show();
        this.columnDefs = [];
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify({ baseId: this.baseId, offSet: 0, pageSize: 10000 });
        this.apiService.getPayrollRankPage(queryParams).subscribe(repo => {
            if (repo.status === 'success') {
                this.listsData = repo.data.dataList.data;
                this.gridflexs = repo.data.gridflexs;
                if (repo.data.dataList.gridKey) {
                    this.gridKey = repo.data.dataList.gridKey;
                }
                this.spinner.hide();
                this.initGrid();
            }
            else {
                this.spinner.hide();
            }
        });
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.AgGridFn)(this.gridflexs.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editRow.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'pi pi-tablet',
                    class: 'btn-primary mr5',
                    // hide: CheckHideAction(MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, ACTIONS.VIEW_TINH_LUONG_BANG_LUONG)
                },
                {
                    onClick: this.deleteRow.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    // hide: CheckHideAction(MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, ACTIONS.DELETE_TINH_LUONG_BANG_LUONG)
                },
            ]
        };
    }
    editRow(event) {
        this.IdDetail = event.rowData.id;
        this.getPayrollRankInfo();
    }
    addPayroll() {
        this.IdDetail = null;
        this.getPayrollRankInfo();
    }
    getPayrollRankInfo() {
        this.listViewsDetail = [];
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify({ id: this.IdDetail, baseId: this.baseId });
        this.apiService.getPayrollRankInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_2__.cloneDeep)(results.data.group_fields);
                this.listViewsDetail = (0,lodash__WEBPACK_IMPORTED_MODULE_2__.cloneDeep)(listViews);
                this.detailInfoDetail = results.data;
                this.isFormDetail = true;
            }
        });
    }
    deleteRow(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa',
            accept: () => {
                const query = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify({ id: event.rowData.id });
                this.apiService.delPayrollRank(query).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa công' });
                        this.getPayrollRankPage();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    handleSaveTab1(event) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfoDetail), { group_fields: event });
        this.apiService.setPayrollRankInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.isFormDetail = false;
                this.getPayrollRankPage();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
    quaylaiDetail(data) {
        if (data === 'CauHinh') {
            this.getPayrollRankInfo();
        }
        else {
            this.isFormDetail = false;
        }
    }
}
MucLuongComponent.ɵfac = function MucLuongComponent_Factory(t) { return new (t || MucLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_0__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_11__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_12__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_12__.ConfirmationService)); };
MucLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({ type: MucLuongComponent, selectors: [["app-muc-luong"]], inputs: { baseId: "baseId" }, decls: 10, vars: 21, consts: [[1, "grid"], [1, "col-6"], [1, "col-6", "text-right"], ["label", "Th\u00EAm m\u1EDBi", "icon", "pi pi-plus", "styleClass", "p-button-sm mr-1", 3, "click"], ["label", "C\u1EA5u h\u00ECnh", "icon", "pi pi-cog", "styleClass", "p-button-sm", 3, "click"], [3, "columnDefs", "height", "listsData", 4, "ngIf"], ["header", "Th\u00EAm m\u1EDBi m\u1EE9c l\u01B0\u01A1ng", 3, "visible", "modal", "draggable", "resizable", "focusTrap", "visibleChange"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "appendTo", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "columnDefs", "height", "listsData"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"], [3, "typeConfig", "gridKey"]], template: function MucLuongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](3, "p-button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function MucLuongComponent_Template_p_button_click_3_listener() { return ctx.addPayroll(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "p-button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function MucLuongComponent_Template_p_button_click_4_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](5, MucLuongComponent_app_list_grid_angular_5_Template, 1, 3, "app-list-grid-angular", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](6, "p-dialog", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("visibleChange", function MucLuongComponent_Template_p_dialog_visibleChange_6_listener($event) { return ctx.isFormDetail = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](7, MucLuongComponent_app_edit_detail_7_Template, 1, 4, "app-edit-detail", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](8, "p-dialog", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("visibleChange", function MucLuongComponent_Template_p_dialog_visibleChange_8_listener($event) { return ctx.displaySetting = $event; })("onHide", function MucLuongComponent_Template_p_dialog_onHide_8_listener() { return ctx.getPayrollRankPage(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](9, MucLuongComponent_app_config_grid_table_form_9_Template, 1, 2, "app-config-grid-table-form", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](19, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("visible", ctx.isFormDetail)("modal", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.listViewsDetail.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](20, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("visible", ctx.displaySetting)("appendTo", "body")("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [primeng_button__WEBPACK_IMPORTED_MODULE_13__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, primeng_dialog__WEBPACK_IMPORTED_MODULE_15__.Dialog, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_4__.ListGridAngularComponent, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__.EditDetailComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_6__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtdWMtbHVvbmcuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 68379:
/*!*********************************************************************************************!*\
  !*** ./src/app/components/luong-thue/tinh-luong/tab-bang-luong/tab-bang-luong.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabBangLuongComponent": () => (/* binding */ TabBangLuongComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);

























function TabBangLuongComponent_app_list_grid_angular_26_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "app-list-grid-angular", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("showConfig", function TabBangLuongComponent_app_list_grid_angular_26_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return ctx_r2.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("height", ctx_r0.heightGrid)("columnDefs", ctx_r0.columnDefs)("rowSelection", "multiple")("listsData", ctx_r0.listsData)("height", ctx_r0.heightGrid);
} }
function TabBangLuongComponent_app_config_grid_table_form_32_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-config-grid-table-form", 28);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r1.gridKey);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "50vw" }; };
class TabBangLuongComponent {
    constructor(apiService, spinner, route, confirmationService, messageService, fileService, changeDetector, organizeInfoService, router) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.idOutPut = new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter();
        this.pagingComponent = {
            total: 0
        };
        this.gridKey = '';
        this.displaySetting = false;
        this.projects = [];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.listsData = null;
        this.totalRecord = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.modelTM = {};
        this.itemsToolOfGrid = [];
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS;
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.employeeStatus = [];
        this.loadjs = 0;
        this.heightGrid = 300;
    }
    cancel() {
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds
        };
        this.load();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getPayrollInfoPage(queryParams).subscribe((results) => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
            this.listsData = (_b = (_a = results === null || results === void 0 ? void 0 : results.data) === null || _a === void 0 ? void 0 : _a.dataList) === null || _b === void 0 ? void 0 : _b.data;
            this.gridKey = (_d = (_c = results === null || results === void 0 ? void 0 : results.data) === null || _c === void 0 ? void 0 : _c.dataList) === null || _d === void 0 ? void 0 : _d.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = (_f = (_e = results === null || results === void 0 ? void 0 : results.data) === null || _e === void 0 ? void 0 : _e.dataList) === null || _f === void 0 ? void 0 : _f.recordsTotal;
            this.countRecord.totalRecord = (_h = (_g = results === null || results === void 0 ? void 0 : results.data) === null || _g === void 0 ? void 0 : _g.dataList) === null || _h === void 0 ? void 0 : _h.recordsTotal;
            this.countRecord.currentRecordStart = ((_k = (_j = results === null || results === void 0 ? void 0 : results.data) === null || _j === void 0 ? void 0 : _j.dataList) === null || _k === void 0 ? void 0 : _k.recordsTotal) === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = (_m = (_l = results === null || results === void 0 ? void 0 : results.data) === null || _l === void 0 ? void 0 : _l.dataList) === null || _m === void 0 ? void 0 : _m.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editRow.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'pi pi-tablet',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS.VIEW_TINH_LUONG_BANG_LUONG)
                },
                {
                    onClick: this.deleteRow.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS.DELETE_TINH_LUONG_BANG_LUONG)
                },
            ]
        };
    }
    editRow(event) {
        this.idOutPut.emit(event);
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    deleteRow(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa',
            accept: () => {
                const query = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ Id: event.rowData.appInfoId });
                this.apiService.delPayrollInfo(query).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Lương - thuế' },
        ];
        this.getEmployeeStatus();
        // this.itemsToolOfGrid = [
        //   {
        //     label: 'Import file',
        //     code: 'Import',
        //     icon: 'pi pi-upload',
        //     command: () => {
        //       // this.importFileExel();
        //     }
        //   },
        //   {
        //     label: 'Export file',
        //     code: 'Import',
        //     icon: 'pi pi-download',
        //     command: () => {
        //       this.exportExel();
        //     }
        //   },
        // ]
    }
    getEmployeeStatus() {
        this.apiService.getEmployeeStatus().subscribe(results => {
            if (results.status === 'success') {
                this.employeeStatus = [];
                results.data.forEach(s => {
                    if (s.value != "3") {
                        this.employeeStatus.push({
                            label: s.name,
                            value: s.value
                        });
                    }
                });
                this.employeeStatus = [{ label: '---Chọn mã chỉ tiêu---', value: -1 }, ...this.employeeStatus];
            }
        });
    }
    exportExel() {
        this.spinner.show();
        this.query.pageSize = 1000000;
        const query = Object.assign({}, this.query);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query);
        this.apiService.getEmployeePage(queryParams).subscribe((results) => {
            const dataExport = [];
            let gridflexs = results.data.gridflexs;
            let arrKey = gridflexs.map(elementName => elementName.columnField);
            let dataList = results.data.dataList.data;
            for (let elementValue of dataList) {
                const data = {};
                for (let elementName of gridflexs) {
                    if (arrKey.indexOf(elementName.columnField) > -1 && !elementName.isHide && elementName.columnField !== 'statusName') {
                        let valueColumn = elementValue[elementName.columnField];
                        if (elementName.columnField == 'status_name' || elementName.columnField == 'isContacted' || elementName.columnField == 'isProfileFull' || elementName.columnField == 'lockName') {
                            valueColumn = this.replaceHtmlToText(valueColumn);
                        }
                        data[elementName.columnCaption] = valueColumn || '';
                    }
                }
                dataExport.push(data);
            }
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách hồ sơ nhân sự ' + new Date());
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 75;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cauhinh() {
        this.displaySetting = true;
    }
}
TabBangLuongComponent.ɵfac = function TabBangLuongComponent_Factory(t) { return new (t || TabBangLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_12__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_12__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.Router)); };
TabBangLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: TabBangLuongComponent, selectors: [["app-tab-bang-luong"]], outputs: { idOutPut: "idOutPut" }, decls: 33, vars: 23, consts: [[1, "bread-filter", "d-flex", "end", "bottom"], [1, "col-item"], [1, "d-flex", "align-items-center"], [1, "d-flex", "end", "bottom", "gap-16"], [1, "d-flex", "end", "middle", "gap-16"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 "], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M6.10199 10.0001C6.10199 7.84533 7.84722 6.1001 10.002 6.1001C12.1568 6.1001 13.902 7.84533 13.902 10.0001C13.902 12.1549 12.1568 13.9001 10.002 13.9001C7.84722 13.9001 6.10199 12.1549 6.10199 10.0001ZM7.90199 10.0001C7.90199 11.1553 8.84676 12.1001 10.002 12.1001C11.1572 12.1001 12.102 11.1553 12.102 10.0001C12.102 8.84487 11.1572 7.9001 10.002 7.9001C8.84676 7.9001 7.90199 8.84487 7.90199 10.0001Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.3328 10.9677L17.3257 11.0239L19.4802 12.7087C19.6292 12.8265 19.6721 13.0416 19.5748 13.2212L17.5754 16.68L17.5748 16.6811C17.5036 16.8078 17.368 16.8801 17.232 16.8801C17.1842 16.8801 17.1358 16.8723 17.0864 16.8561L14.547 15.8363L14.502 15.8701C13.9872 16.2562 13.4345 16.5915 12.8341 16.8376L12.7811 16.8593L12.393 19.5659L12.3928 19.5677C12.3693 19.7551 12.2042 19.9001 12.002 19.9001H8.00199C7.79981 19.9001 7.63464 19.7551 7.61124 19.5677L7.22286 16.8593L7.16991 16.8376C6.56875 16.5912 6.01644 16.2658 5.50296 15.8708L5.45771 15.836L2.91485 16.8573C2.87884 16.8717 2.83184 16.8801 2.78199 16.8801C2.63486 16.8801 2.4999 16.8068 2.42916 16.6811L0.429221 13.2212C0.331903 13.0416 0.37495 12.8264 0.523956 12.7086L2.67825 11.0239L2.67122 10.9677C2.63148 10.6497 2.60199 10.3243 2.60199 10.0001C2.60199 9.67591 2.63148 9.35045 2.67122 9.0325L2.67825 8.97625L0.523811 7.29149C0.371682 7.17128 0.32503 6.95535 0.428568 6.78014L2.42857 3.32015L2.42915 3.31912C2.50042 3.19243 2.63599 3.1201 2.77199 3.1201C2.81979 3.1201 2.86823 3.12789 2.91764 3.14406L5.45696 4.16387L5.50199 4.1301C6.01682 3.74398 6.56946 3.40872 7.16991 3.16263L7.22286 3.14093L7.611 0.434295L7.61122 0.432501C7.63464 0.245098 7.79981 0.100098 8.00199 0.100098H12.002C12.2042 0.100098 12.3693 0.2451 12.3927 0.432503L12.7811 3.14093L12.8341 3.16263C13.4352 3.40901 13.9875 3.73438 14.501 4.12936L14.5463 4.16417L17.0891 3.14295C17.1251 3.12854 17.1721 3.1201 17.222 3.1201C17.3691 3.1201 17.5041 3.19335 17.5748 3.31913L19.5748 6.779C19.6721 6.95858 19.6291 7.17383 19.48 7.29161L17.3257 8.97625L17.3328 9.0325C17.3725 9.35055 17.402 9.66597 17.402 10.0001C17.402 10.3342 17.3725 10.6496 17.3328 10.9677ZM15.2644 5.79743L14.2575 6.20588L13.393 5.54083L13.392 5.5401C12.9857 5.23541 12.5786 5.0012 12.1406 4.81785L11.133 4.40909L10.7789 1.9001H9.21572L9.00298 3.33608L8.85105 4.40907L7.84369 4.81772C7.42462 4.99148 7.00691 5.23644 6.57171 5.56031L5.71691 6.20616L4.72926 5.8073L3.37883 5.265L2.59177 6.6255L3.7406 7.51903L4.58581 8.18381L4.45272 9.2578L4.45249 9.26015C4.42253 9.5597 4.40199 9.79442 4.40199 10.0001C4.40199 10.2057 4.42249 10.4405 4.45242 10.7497L4.58581 11.8264L3.74017 12.4915L2.59177 13.3847L3.37883 14.7452L4.72958 14.2028L5.73646 13.7943L6.60102 14.4594L6.60199 14.4601C7.00825 14.7648 7.41539 14.999 7.85338 15.1823L8.86102 15.5911L9.21511 18.1001H10.7883L11.001 16.6641L11.1529 15.5911L12.1603 15.1825C12.5794 15.0087 12.9971 14.7638 13.4323 14.4399L14.2871 13.794L15.2747 14.1929L16.6252 14.7352L17.4122 13.3747L16.2634 12.4812L15.4182 11.8164L15.5513 10.7424L15.5515 10.74C15.5814 10.4406 15.602 10.2158 15.602 10.0001C15.602 9.78595 15.5917 9.57141 15.5512 9.2573L15.4182 8.18381L16.2642 7.5184L17.4018 6.61472L16.6152 5.255L15.2644 5.79743Z", "fill", "#F3F8FF"], [1, "pb-0", "pt-0"], [3, "height", "columnDefs", "rowSelection", "listsData", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "height", "columnDefs", "rowSelection", "listsData", "showConfig"], [3, "typeConfig", "gridKey"]], template: function TabBangLuongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](7, "input", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("keydown.enter", function TabBangLuongComponent_Template_input_keydown_enter_7_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function TabBangLuongComponent_Template_input_ngModelChange_7_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "span", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function TabBangLuongComponent_Template_span_click_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "svg", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](10, "path", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](11, "p-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function TabBangLuongComponent_Template_p_button_click_11_listener() { ctx.query.offSet = 0; ctx.query.filter = ""; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](12, "svg", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](13, "path", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](14, "p-button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](15, "svg", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](16, "path", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](19, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](20, "p-button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](21, "svg", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](22, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](23, "path", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](24, " \u00A0 T\u00F9y ch\u1EC9nh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](25, "section", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](26, TabBangLuongComponent_app_list_grid_angular_26_Template, 1, 5, "app-list-grid-angular", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](27, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](28, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](30, "p-paginator", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("onPageChange", function TabBangLuongComponent_Template_p_paginator_onPageChange_30_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](31, "p-dialog", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("visibleChange", function TabBangLuongComponent_Template_p_dialog_visibleChange_31_listener($event) { return ctx.displaySetting = $event; })("onHide", function TabBangLuongComponent_Template_p_dialog_onHide_31_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](32, TabBangLuongComponent_app_config_grid_table_form_32_Template, 1, 2, "app-config-grid-table-form", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction1"](20, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](19, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](22, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_15__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_16__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_17__.Dialog, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWItYmFuZy1sdW9uZy5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 26259:
/*!***************************************************************************************************************************************!*\
  !*** ./src/app/components/luong-thue/tinh-luong/tab-cap-bac-luong/chi-tiet-tab-cap-bac-luong/chi-tiet-tab-cap-bac-luong.component.ts ***!
  \***************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietTabCapBacLuongComponent": () => (/* binding */ ChiTietTabCapBacLuongComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_bang_luong_muc_luong_muc_luong_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-bang-luong/muc-luong/muc-luong.component */ 19535);



















function ChiTietTabCapBacLuongComponent_app_edit_detail_3_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "app-edit-detail", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("callback", function ChiTietTabCapBacLuongComponent_app_edit_detail_3_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r2.handleSave($event); })("callbackcancel", function ChiTietTabCapBacLuongComponent_app_edit_detail_3_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r3); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r4.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
function ChiTietTabCapBacLuongComponent_app_muc_luong_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "app-muc-luong", 7);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("baseId", ctx_r1.idForm);
} }
class ChiTietTabCapBacLuongComponent {
    constructor(activatedRoute, apiService, spinner, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS.EDIT_TINH_LUONG_CAP_BAC_LUONG) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.titlePage = '';
        this.idForm = null;
        this.detailOut = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_8__.Subject();
        this.tabIndex = 0;
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.getDetail();
    }
    getDetail() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ baseId: this.idForm });
        this.apiService.getPayrollBaseInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(listViews);
                this.detailInfo = results.data;
            }
        });
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getDetail();
        }
        else {
            this.detailOut.emit();
        }
    }
    handleSave(event) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: event });
        this.apiService.setPayrollBaseInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.detailOut.emit();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
    handleChange(e) {
        this.tabIndex = e;
    }
}
ChiTietTabCapBacLuongComponent.ɵfac = function ChiTietTabCapBacLuongComponent_Factory(t) { return new (t || ChiTietTabCapBacLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_11__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_12__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.Router)); };
ChiTietTabCapBacLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({ type: ChiTietTabCapBacLuongComponent, selectors: [["app-chi-tiet-tab-cap-bac-luong"]], inputs: { idForm: "idForm" }, outputs: { detailOut: "detailOut" }, decls: 6, vars: 3, consts: [[3, "activeIndex", "onChange", "activeIndexChange"], ["header", "Th\u00F4ng tin chi ti\u1EBFt b\u1EADc l\u01B0\u01A1ng"], [1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], ["header", "M\u1EE9c l\u01B0\u01A1ng"], [3, "baseId", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"], [3, "baseId"]], template: function ChiTietTabCapBacLuongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "p-tabView", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("onChange", function ChiTietTabCapBacLuongComponent_Template_p_tabView_onChange_0_listener($event) { return ctx.handleChange($event.index); })("activeIndexChange", function ChiTietTabCapBacLuongComponent_Template_p_tabView_activeIndexChange_0_listener($event) { return ctx.tabIndex = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "p-tabPanel", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](3, ChiTietTabCapBacLuongComponent_app_edit_detail_3_Template, 1, 4, "app-edit-detail", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "p-tabPanel", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](5, ChiTietTabCapBacLuongComponent_app_muc_luong_5_Template, 1, 1, "app-muc-luong", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("activeIndex", ctx.tabIndex);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.tabIndex === 1);
    } }, directives: [primeng_tabview__WEBPACK_IMPORTED_MODULE_13__.TabView, primeng_tabview__WEBPACK_IMPORTED_MODULE_13__.TabPanel, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__.EditDetailComponent, src_app_components_luong_thue_tinh_luong_tab_bang_luong_muc_luong_muc_luong_component__WEBPACK_IMPORTED_MODULE_6__.MucLuongComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC10YWItY2FwLWJhYy1sdW9uZy5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 56710:
/*!***************************************************************************************************!*\
  !*** ./src/app/components/luong-thue/tinh-luong/tab-cap-bac-luong/tab-cap-bac-luong.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabCapBacLuongComponent": () => (/* binding */ TabCapBacLuongComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);























function TabCapBacLuongComponent_app_list_grid_angular_23_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-list-grid-angular", 24);
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("height", ctx_r0.heightGrid)("columnDefs", ctx_r0.columnDefs)("rowSelection", "multiple")("listsData", ctx_r0.listsData)("height", ctx_r0.heightGrid);
} }
function TabCapBacLuongComponent_app_config_grid_table_form_29_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-config-grid-table-form", 25);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r1.gridKey);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "50vw" }; };
class TabCapBacLuongComponent {
    constructor(apiService, spinner, confirmationService, messageService, fileService, organizeInfoService, changeDetector) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.organizeInfoService = organizeInfoService;
        this.changeDetector = changeDetector;
        this.idOutPut = new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter();
        this.pagingComponent = {
            total: 0
        };
        this.projects = [];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.listsData = null;
        this.totalRecord = 0;
        this.first = 0;
        this.gridKey = '';
        this.displaySetting = false;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.loadjs = 0;
        this.heightGrid = 300;
    }
    cancel() {
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds
        };
        this.load();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getPayrollBasePage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editRow.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'pi pi-tablet',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS.VIEW_TINH_LUONG_CAP_BAC_LUONG)
                },
                {
                    onClick: this.deleteRow.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS.DELETE_TINH_LUONG_CAP_BAC_LUONG)
                },
            ]
        };
    }
    editRow(event) {
        this.idOutPut.emit(event);
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    deleteRow(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa?',
            accept: () => {
                const query = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ baseId: event.rowData.baseId });
                this.apiService.delPayrollBase(query).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Lương - thuế' },
        ];
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 75;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cauhinh() {
        this.displaySetting = true;
    }
}
TabCapBacLuongComponent.ɵfac = function TabCapBacLuongComponent_Factory(t) { return new (t || TabCapBacLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef)); };
TabCapBacLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: TabCapBacLuongComponent, selectors: [["app-tab-cap-bac-bang-luong"]], outputs: { idOutPut: "idOutPut" }, decls: 30, vars: 23, consts: [[1, "bread-filter", "d-flex", "end", "bottom"], [1, "d-flex", "end", "middle", "gap-16"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 "], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M6.10199 10.0001C6.10199 7.84533 7.84722 6.1001 10.002 6.1001C12.1568 6.1001 13.902 7.84533 13.902 10.0001C13.902 12.1549 12.1568 13.9001 10.002 13.9001C7.84722 13.9001 6.10199 12.1549 6.10199 10.0001ZM7.90199 10.0001C7.90199 11.1553 8.84676 12.1001 10.002 12.1001C11.1572 12.1001 12.102 11.1553 12.102 10.0001C12.102 8.84487 11.1572 7.9001 10.002 7.9001C8.84676 7.9001 7.90199 8.84487 7.90199 10.0001Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.3328 10.9677L17.3257 11.0239L19.4802 12.7087C19.6292 12.8265 19.6721 13.0416 19.5748 13.2212L17.5754 16.68L17.5748 16.6811C17.5036 16.8078 17.368 16.8801 17.232 16.8801C17.1842 16.8801 17.1358 16.8723 17.0864 16.8561L14.547 15.8363L14.502 15.8701C13.9872 16.2562 13.4345 16.5915 12.8341 16.8376L12.7811 16.8593L12.393 19.5659L12.3928 19.5677C12.3693 19.7551 12.2042 19.9001 12.002 19.9001H8.00199C7.79981 19.9001 7.63464 19.7551 7.61124 19.5677L7.22286 16.8593L7.16991 16.8376C6.56875 16.5912 6.01644 16.2658 5.50296 15.8708L5.45771 15.836L2.91485 16.8573C2.87884 16.8717 2.83184 16.8801 2.78199 16.8801C2.63486 16.8801 2.4999 16.8068 2.42916 16.6811L0.429221 13.2212C0.331903 13.0416 0.37495 12.8264 0.523956 12.7086L2.67825 11.0239L2.67122 10.9677C2.63148 10.6497 2.60199 10.3243 2.60199 10.0001C2.60199 9.67591 2.63148 9.35045 2.67122 9.0325L2.67825 8.97625L0.523811 7.29149C0.371682 7.17128 0.32503 6.95535 0.428568 6.78014L2.42857 3.32015L2.42915 3.31912C2.50042 3.19243 2.63599 3.1201 2.77199 3.1201C2.81979 3.1201 2.86823 3.12789 2.91764 3.14406L5.45696 4.16387L5.50199 4.1301C6.01682 3.74398 6.56946 3.40872 7.16991 3.16263L7.22286 3.14093L7.611 0.434295L7.61122 0.432501C7.63464 0.245098 7.79981 0.100098 8.00199 0.100098H12.002C12.2042 0.100098 12.3693 0.2451 12.3927 0.432503L12.7811 3.14093L12.8341 3.16263C13.4352 3.40901 13.9875 3.73438 14.501 4.12936L14.5463 4.16417L17.0891 3.14295C17.1251 3.12854 17.1721 3.1201 17.222 3.1201C17.3691 3.1201 17.5041 3.19335 17.5748 3.31913L19.5748 6.779C19.6721 6.95858 19.6291 7.17383 19.48 7.29161L17.3257 8.97625L17.3328 9.0325C17.3725 9.35055 17.402 9.66597 17.402 10.0001C17.402 10.3342 17.3725 10.6496 17.3328 10.9677ZM15.2644 5.79743L14.2575 6.20588L13.393 5.54083L13.392 5.5401C12.9857 5.23541 12.5786 5.0012 12.1406 4.81785L11.133 4.40909L10.7789 1.9001H9.21572L9.00298 3.33608L8.85105 4.40907L7.84369 4.81772C7.42462 4.99148 7.00691 5.23644 6.57171 5.56031L5.71691 6.20616L4.72926 5.8073L3.37883 5.265L2.59177 6.6255L3.7406 7.51903L4.58581 8.18381L4.45272 9.2578L4.45249 9.26015C4.42253 9.5597 4.40199 9.79442 4.40199 10.0001C4.40199 10.2057 4.42249 10.4405 4.45242 10.7497L4.58581 11.8264L3.74017 12.4915L2.59177 13.3847L3.37883 14.7452L4.72958 14.2028L5.73646 13.7943L6.60102 14.4594L6.60199 14.4601C7.00825 14.7648 7.41539 14.999 7.85338 15.1823L8.86102 15.5911L9.21511 18.1001H10.7883L11.001 16.6641L11.1529 15.5911L12.1603 15.1825C12.5794 15.0087 12.9971 14.7638 13.4323 14.4399L14.2871 13.794L15.2747 14.1929L16.6252 14.7352L17.4122 13.3747L16.2634 12.4812L15.4182 11.8164L15.5513 10.7424L15.5515 10.74C15.5814 10.4406 15.602 10.2158 15.602 10.0001C15.602 9.78595 15.5917 9.57141 15.5512 9.2573L15.4182 8.18381L16.2642 7.5184L17.4018 6.61472L16.6152 5.255L15.2644 5.79743Z", "fill", "#F3F8FF"], [1, "pt-0", "pb-0"], ["app-tab-cap-bac-bang-luong", "", 3, "height", "columnDefs", "rowSelection", "listsData", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["app-tab-cap-bac-bang-luong", "", 3, "height", "columnDefs", "rowSelection", "listsData"], [3, "typeConfig", "gridKey"]], template: function TabCapBacLuongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "input", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("keydown.enter", function TabCapBacLuongComponent_Template_input_keydown_enter_4_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function TabCapBacLuongComponent_Template_input_ngModelChange_4_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function TabCapBacLuongComponent_Template_span_click_5_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "svg", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](7, "path", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function TabCapBacLuongComponent_Template_p_button_click_8_listener() { ctx.query.offSet = 0; ctx.query.filter = ""; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "svg", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](10, "path", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](11, "p-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](12, "svg", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](13, "path", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](15, "path", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](16, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](17, "p-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](18, "svg", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](19, "path", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](20, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](21, " \u00A0 T\u00F9y ch\u1EC9nh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](22, "section", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](23, TabCapBacLuongComponent_app_list_grid_angular_23_Template, 1, 5, "app-list-grid-angular", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](24, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](25, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](27, "p-paginator", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("onPageChange", function TabCapBacLuongComponent_Template_p_paginator_onPageChange_27_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](28, "p-dialog", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("visibleChange", function TabCapBacLuongComponent_Template_p_dialog_visibleChange_28_listener($event) { return ctx.displaySetting = $event; })("onHide", function TabCapBacLuongComponent_Template_p_dialog_onHide_28_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](29, TabCapBacLuongComponent_app_config_grid_table_form_29_Template, 1, 2, "app-config-grid-table-form", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction1"](20, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](19, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](22, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_14__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_15__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_16__.Dialog, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWItY2FwLWJhYy1sdW9uZy5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 55810:
/*!****************************************************************************************************************************************!*\
  !*** ./src/app/components/luong-thue/tinh-luong/tab-thanh-phan-luong/chi-tiet-thanh-phan-luong/chi-tiet-thanh-phan-luong.component.ts ***!
  \****************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietThanhPhanLuongComponent": () => (/* binding */ ChiTietThanhPhanLuongComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../common/edit-detail/edit-detail.component */ 58638);

















function ChiTietThanhPhanLuongComponent_app_edit_detail_1_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "app-edit-detail", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("callback", function ChiTietThanhPhanLuongComponent_app_edit_detail_1_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r1.handleSave($event); })("callbackcancel", function ChiTietThanhPhanLuongComponent_app_edit_detail_1_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r3.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
class ChiTietThanhPhanLuongComponent {
    constructor(activatedRoute, apiService, spinner, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS.EDIT_TINH_LUONG_THANH_PHAN_LUONG) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.titlePage = '';
        this.idForm = null;
        this.detailOut = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.getDetail();
    }
    getDetail() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ Id: this.idForm });
        this.apiService.getComponentInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(listViews);
                this.detailInfo = results.data;
            }
        });
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getDetail();
        }
        else {
            this.detailOut.emit();
        }
    }
    handleSave(event) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: event });
        this.apiService.setComponentInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.detailOut.emit();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
}
ChiTietThanhPhanLuongComponent.ɵfac = function ChiTietThanhPhanLuongComponent_Factory(t) { return new (t || ChiTietThanhPhanLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router)); };
ChiTietThanhPhanLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: ChiTietThanhPhanLuongComponent, selectors: [["app-chi-tiet-thanh-phan-luong"]], inputs: { idForm: "idForm" }, outputs: { detailOut: "detailOut" }, decls: 2, vars: 1, consts: [[1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function ChiTietThanhPhanLuongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, ChiTietThanhPhanLuongComponent_app_edit_detail_1_Template, 1, 4, "app-edit-detail", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC10aGFuaC1waGFuLWx1b25nLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 23788:
/*!*********************************************************************************************************!*\
  !*** ./src/app/components/luong-thue/tinh-luong/tab-thanh-phan-luong/tab-thanh-phan-luong.component.ts ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabThanhPhanLuongComponent": () => (/* binding */ TabThanhPhanLuongComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);























function TabThanhPhanLuongComponent_app_list_grid_angular_23_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "app-list-grid-angular", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("showConfig", function TabThanhPhanLuongComponent_app_list_grid_angular_23_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return ctx_r2.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("height", ctx_r0.heightGrid)("columnDefs", ctx_r0.columnDefs)("rowSelection", "multiple")("listsData", ctx_r0.listsData)("height", ctx_r0.heightGrid);
} }
function TabThanhPhanLuongComponent_app_config_grid_table_form_29_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-config-grid-table-form", 25);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r1.gridKey);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "50vw" }; };
class TabThanhPhanLuongComponent {
    constructor(apiService, spinner, confirmationService, messageService, fileService, organizeInfoService, changeDetector) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.organizeInfoService = organizeInfoService;
        this.changeDetector = changeDetector;
        this.idOutPut = new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter();
        this.pagingComponent = {
            total: 0
        };
        this.projects = [];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.listsData = null;
        this.totalRecord = 0;
        this.first = 0;
        this.gridKey = '';
        this.displaySetting = false;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.loadjs = 0;
        this.heightGrid = 300;
    }
    cancel() {
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds
        };
        this.load();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getComponentPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editRow.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS.VIEW_TINH_LUONG_THANH_PHAN_LUONG)
                },
                {
                    onClick: this.deleteRow.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS.DELETE_TINH_LUONG_THANH_PHAN_LUONG)
                },
            ]
        };
    }
    editRow(event) {
        this.idOutPut.emit(event);
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    deleteRow(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa?',
            accept: () => {
                const query = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ Id: event.rowData.componentId });
                this.apiService.delComponent(query).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Lương - thuế' },
        ];
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 75;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cauhinh() {
        this.displaySetting = true;
    }
}
TabThanhPhanLuongComponent.ɵfac = function TabThanhPhanLuongComponent_Factory(t) { return new (t || TabThanhPhanLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef)); };
TabThanhPhanLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: TabThanhPhanLuongComponent, selectors: [["app-tab-thanh-phan-luong"]], outputs: { idOutPut: "idOutPut" }, decls: 30, vars: 23, consts: [[1, "bread-filter", "d-flex", "end", "bottom"], [1, "d-flex", "end", "middle", "gap-16"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 "], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M6.10199 10.0001C6.10199 7.84533 7.84722 6.1001 10.002 6.1001C12.1568 6.1001 13.902 7.84533 13.902 10.0001C13.902 12.1549 12.1568 13.9001 10.002 13.9001C7.84722 13.9001 6.10199 12.1549 6.10199 10.0001ZM7.90199 10.0001C7.90199 11.1553 8.84676 12.1001 10.002 12.1001C11.1572 12.1001 12.102 11.1553 12.102 10.0001C12.102 8.84487 11.1572 7.9001 10.002 7.9001C8.84676 7.9001 7.90199 8.84487 7.90199 10.0001Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.3328 10.9677L17.3257 11.0239L19.4802 12.7087C19.6292 12.8265 19.6721 13.0416 19.5748 13.2212L17.5754 16.68L17.5748 16.6811C17.5036 16.8078 17.368 16.8801 17.232 16.8801C17.1842 16.8801 17.1358 16.8723 17.0864 16.8561L14.547 15.8363L14.502 15.8701C13.9872 16.2562 13.4345 16.5915 12.8341 16.8376L12.7811 16.8593L12.393 19.5659L12.3928 19.5677C12.3693 19.7551 12.2042 19.9001 12.002 19.9001H8.00199C7.79981 19.9001 7.63464 19.7551 7.61124 19.5677L7.22286 16.8593L7.16991 16.8376C6.56875 16.5912 6.01644 16.2658 5.50296 15.8708L5.45771 15.836L2.91485 16.8573C2.87884 16.8717 2.83184 16.8801 2.78199 16.8801C2.63486 16.8801 2.4999 16.8068 2.42916 16.6811L0.429221 13.2212C0.331903 13.0416 0.37495 12.8264 0.523956 12.7086L2.67825 11.0239L2.67122 10.9677C2.63148 10.6497 2.60199 10.3243 2.60199 10.0001C2.60199 9.67591 2.63148 9.35045 2.67122 9.0325L2.67825 8.97625L0.523811 7.29149C0.371682 7.17128 0.32503 6.95535 0.428568 6.78014L2.42857 3.32015L2.42915 3.31912C2.50042 3.19243 2.63599 3.1201 2.77199 3.1201C2.81979 3.1201 2.86823 3.12789 2.91764 3.14406L5.45696 4.16387L5.50199 4.1301C6.01682 3.74398 6.56946 3.40872 7.16991 3.16263L7.22286 3.14093L7.611 0.434295L7.61122 0.432501C7.63464 0.245098 7.79981 0.100098 8.00199 0.100098H12.002C12.2042 0.100098 12.3693 0.2451 12.3927 0.432503L12.7811 3.14093L12.8341 3.16263C13.4352 3.40901 13.9875 3.73438 14.501 4.12936L14.5463 4.16417L17.0891 3.14295C17.1251 3.12854 17.1721 3.1201 17.222 3.1201C17.3691 3.1201 17.5041 3.19335 17.5748 3.31913L19.5748 6.779C19.6721 6.95858 19.6291 7.17383 19.48 7.29161L17.3257 8.97625L17.3328 9.0325C17.3725 9.35055 17.402 9.66597 17.402 10.0001C17.402 10.3342 17.3725 10.6496 17.3328 10.9677ZM15.2644 5.79743L14.2575 6.20588L13.393 5.54083L13.392 5.5401C12.9857 5.23541 12.5786 5.0012 12.1406 4.81785L11.133 4.40909L10.7789 1.9001H9.21572L9.00298 3.33608L8.85105 4.40907L7.84369 4.81772C7.42462 4.99148 7.00691 5.23644 6.57171 5.56031L5.71691 6.20616L4.72926 5.8073L3.37883 5.265L2.59177 6.6255L3.7406 7.51903L4.58581 8.18381L4.45272 9.2578L4.45249 9.26015C4.42253 9.5597 4.40199 9.79442 4.40199 10.0001C4.40199 10.2057 4.42249 10.4405 4.45242 10.7497L4.58581 11.8264L3.74017 12.4915L2.59177 13.3847L3.37883 14.7452L4.72958 14.2028L5.73646 13.7943L6.60102 14.4594L6.60199 14.4601C7.00825 14.7648 7.41539 14.999 7.85338 15.1823L8.86102 15.5911L9.21511 18.1001H10.7883L11.001 16.6641L11.1529 15.5911L12.1603 15.1825C12.5794 15.0087 12.9971 14.7638 13.4323 14.4399L14.2871 13.794L15.2747 14.1929L16.6252 14.7352L17.4122 13.3747L16.2634 12.4812L15.4182 11.8164L15.5513 10.7424L15.5515 10.74C15.5814 10.4406 15.602 10.2158 15.602 10.0001C15.602 9.78595 15.5917 9.57141 15.5512 9.2573L15.4182 8.18381L16.2642 7.5184L17.4018 6.61472L16.6152 5.255L15.2644 5.79743Z", "fill", "#F3F8FF"], [1, "pt-0", "pb-0"], [3, "height", "columnDefs", "rowSelection", "listsData", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "height", "columnDefs", "rowSelection", "listsData", "showConfig"], [3, "typeConfig", "gridKey"]], template: function TabThanhPhanLuongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "input", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("keydown.enter", function TabThanhPhanLuongComponent_Template_input_keydown_enter_4_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function TabThanhPhanLuongComponent_Template_input_ngModelChange_4_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function TabThanhPhanLuongComponent_Template_span_click_5_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "svg", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](7, "path", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function TabThanhPhanLuongComponent_Template_p_button_click_8_listener() { ctx.query.offSet = 0; ctx.query.filter = ""; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "svg", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](10, "path", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](11, "p-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](12, "svg", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](13, "path", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](15, "path", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](16, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](17, "p-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](18, "svg", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](19, "path", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](20, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](21, " \u00A0 T\u00F9y ch\u1EC9nh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](22, "section", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](23, TabThanhPhanLuongComponent_app_list_grid_angular_23_Template, 1, 5, "app-list-grid-angular", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](24, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](25, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](27, "p-paginator", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("onPageChange", function TabThanhPhanLuongComponent_Template_p_paginator_onPageChange_27_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](28, "p-dialog", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("visibleChange", function TabThanhPhanLuongComponent_Template_p_dialog_visibleChange_28_listener($event) { return ctx.displaySetting = $event; })("onHide", function TabThanhPhanLuongComponent_Template_p_dialog_onHide_28_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](29, TabThanhPhanLuongComponent_app_config_grid_table_form_29_Template, 1, 2, "app-config-grid-table-form", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction1"](20, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](19, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](22, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_14__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_15__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_16__.Dialog, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWItdGhhbmgtcGhhbi1sdW9uZy5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 80555:
/*!***************************************************************************************************************************************************!*\
  !*** ./src/app/components/luong-thue/tinh-luong/tab-thiet-lap-tham-so/chi-tiet-tab-thiet-lap-tham-so/chi-tiet-tab-thiet-lap-tham-so.component.ts ***!
  \***************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietTabThietLapThamSoComponent": () => (/* binding */ ChiTietTabThietLapThamSoComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../common/edit-detail/edit-detail.component */ 58638);

















function ChiTietTabThietLapThamSoComponent_app_edit_detail_1_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "app-edit-detail", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("callback", function ChiTietTabThietLapThamSoComponent_app_edit_detail_1_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r1.handleSave($event); })("callbackcancel", function ChiTietTabThietLapThamSoComponent_app_edit_detail_1_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r3.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
class ChiTietTabThietLapThamSoComponent {
    constructor(activatedRoute, apiService, spinner, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS.EDIT_TINH_LUONG_THIET_LAP_THAM_SO) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.titlePage = '';
        this.idForm = null;
        this.detailOut = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.getDetail();
    }
    getDetail() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ Id: this.idForm });
        this.apiService.getPayrollParam(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(listViews);
                this.detailInfo = results.data;
            }
        });
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getDetail();
        }
        else {
            this.detailOut.emit();
        }
    }
    handleSave(event) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: event });
        this.apiService.setPayrollParam(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.detailOut.emit();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
}
ChiTietTabThietLapThamSoComponent.ɵfac = function ChiTietTabThietLapThamSoComponent_Factory(t) { return new (t || ChiTietTabThietLapThamSoComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router)); };
ChiTietTabThietLapThamSoComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: ChiTietTabThietLapThamSoComponent, selectors: [["app-chi-tiet-tab-thiet-lap-tham-so"]], inputs: { idForm: "idForm" }, outputs: { detailOut: "detailOut" }, decls: 2, vars: 1, consts: [[1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function ChiTietTabThietLapThamSoComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, ChiTietTabThietLapThamSoComponent_app_edit_detail_1_Template, 1, 4, "app-edit-detail", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC10YWItdGhpZXQtbGFwLXRoYW0tc28uY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 27088:
/*!***********************************************************************************************************!*\
  !*** ./src/app/components/luong-thue/tinh-luong/tab-thiet-lap-tham-so/tab-thiet-lap-tham-so.component.ts ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabThietLapThamSoComponent": () => (/* binding */ TabThietLapThamSoComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);





















function TabThietLapThamSoComponent_app_list_grid_angular_5_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "app-list-grid-angular", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("showConfig", function TabThietLapThamSoComponent_app_list_grid_angular_5_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return ctx_r2.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("height", ctx_r0.heightGrid)("columnDefs", ctx_r0.columnDefs)("rowSelection", "multiple")("listsData", ctx_r0.listsData);
} }
function TabThietLapThamSoComponent_app_config_grid_table_form_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-config-grid-table-form", 11);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r1.gridKey);
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "50vw" }; };
class TabThietLapThamSoComponent {
    constructor(apiService, spinner, confirmationService, messageService, fileService, organizeInfoService, changeDetector) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.organizeInfoService = organizeInfoService;
        this.changeDetector = changeDetector;
        this.idOutPut = new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter();
        this.pagingComponent = {
            total: 0
        };
        this.projects = [];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.listsData = null;
        this.totalRecord = 0;
        this.first = 0;
        this.displaySetting = false;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS;
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.gridKey = '';
        this.loadjs = 0;
        this.heightGrid = 300;
    }
    cancel() {
        this.query = {
            filter: '',
            gridWidth: 0,
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds
        };
        this.load();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getPayrollParamPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editRow.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS.VIEW_TINH_LUONG_THIET_LAP_THAM_SO)
                },
                {
                    onClick: this.deleteRow.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS.DELETE_TINH_LUONG_THIET_LAP_THAM_SO)
                },
            ]
        };
    }
    editRow(event) {
        this.idOutPut.emit(event);
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    deleteRow(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa?',
            accept: () => {
                const query = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ Id: event.rowData.id });
                this.apiService.delPayrollParam(query).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Lương - thuế' },
        ];
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 75;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cauhinh() {
        this.displaySetting = true;
    }
}
TabThietLapThamSoComponent.ɵfac = function TabThietLapThamSoComponent_Factory(t) { return new (t || TabThietLapThamSoComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_4__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef)); };
TabThietLapThamSoComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: TabThietLapThamSoComponent, selectors: [["app-tab-thiet-lap-tham-so"]], outputs: { idOutPut: "idOutPut" }, decls: 12, vars: 21, consts: [[1, "bread-filter", "d-flex", "end", "bottom"], [1, "d-flex", "end", "bottom", "gap-16"], [1, "col-item"], [1, "d-flex", "end", "middle", "gap-16"], [1, "pt-0", "pb-0"], [3, "height", "columnDefs", "rowSelection", "listsData", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "height", "columnDefs", "rowSelection", "listsData", "showConfig"], [3, "typeConfig", "gridKey"]], template: function TabThietLapThamSoComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "section", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](5, TabThietLapThamSoComponent_app_list_grid_angular_5_Template, 1, 4, "app-list-grid-angular", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](7, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "p-paginator", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("onPageChange", function TabThietLapThamSoComponent_Template_p_paginator_onPageChange_9_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](10, "p-dialog", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("visibleChange", function TabThietLapThamSoComponent_Template_p_dialog_visibleChange_10_listener($event) { return ctx.displaySetting = $event; })("onHide", function TabThietLapThamSoComponent_Template_p_dialog_onHide_10_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](11, TabThietLapThamSoComponent_app_config_grid_table_form_11_Template, 1, 2, "app-config-grid-table-form", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction1"](18, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](17, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](20, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_13__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_14__.Dialog, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWItdGhpZXQtbGFwLXRoYW0tc28uY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 47857:
/*!**************************************************************************!*\
  !*** ./src/app/components/luong-thue/tinh-luong/tinh-luong.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TinhLuongComponent": () => (/* binding */ TinhLuongComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _tab_bang_luong_tab_bang_luong_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-bang-luong/tab-bang-luong.component */ 68379);
/* harmony import */ var _tab_thiet_lap_tham_so_tab_thiet_lap_tham_so_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-thiet-lap-tham-so/tab-thiet-lap-tham-so.component */ 27088);
/* harmony import */ var _tab_thanh_phan_luong_tab_thanh_phan_luong_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-thanh-phan-luong/tab-thanh-phan-luong.component */ 23788);
/* harmony import */ var _tab_cap_bac_luong_tab_cap_bac_luong_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-cap-bac-luong/tab-cap-bac-luong.component */ 56710);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_bang_luong_chi_tiet_tab_bang_luong_chi_tiet_tab_bang_luong_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-bang-luong/chi-tiet-tab-bang-luong/chi-tiet-tab-bang-luong.component */ 725);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_thiet_lap_tham_so_chi_tiet_tab_thiet_lap_tham_so_chi_tiet_tab_thiet_lap_tham_so_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-thiet-lap-tham-so/chi-tiet-tab-thiet-lap-tham-so/chi-tiet-tab-thiet-lap-tham-so.component */ 80555);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_thanh_phan_luong_chi_tiet_thanh_phan_luong_chi_tiet_thanh_phan_luong_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-thanh-phan-luong/chi-tiet-thanh-phan-luong/chi-tiet-thanh-phan-luong.component */ 55810);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_cap_bac_luong_chi_tiet_tab_cap_bac_luong_chi_tiet_tab_cap_bac_luong_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-cap-bac-luong/chi-tiet-tab-cap-bac-luong/chi-tiet-tab-cap-bac-luong.component */ 26259);


































const _c0 = ["tabBangLuong"];
const _c1 = ["tabThietLapThamSo"];
const _c2 = ["tabThanhPhanLuong"];
const _c3 = ["TabCapBacLuongComponent"];
function TinhLuongComponent_p_button_13_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "p-button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function TinhLuongComponent_p_button_13_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r9.addNew(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "svg", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](2, "path", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](3, " \u00A0 Th\u00EAm m\u01A1\u0301i ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function TinhLuongComponent_app_tab_bang_luong_17_Template(rf, ctx) { if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-tab-bang-luong", 23, 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("idOutPut", function TinhLuongComponent_app_tab_bang_luong_17_Template_app_tab_bang_luong_idOutPut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r13); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r12.editEvent($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function TinhLuongComponent_app_tab_thiet_lap_tham_so_19_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-tab-thiet-lap-tham-so", 23, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("idOutPut", function TinhLuongComponent_app_tab_thiet_lap_tham_so_19_Template_app_tab_thiet_lap_tham_so_idOutPut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r15.editEvent($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function TinhLuongComponent_app_tab_thanh_phan_luong_21_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-tab-thanh-phan-luong", 23, 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("idOutPut", function TinhLuongComponent_app_tab_thanh_phan_luong_21_Template_app_tab_thanh_phan_luong_idOutPut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r19); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r18.editEvent($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function TinhLuongComponent_app_tab_cap_bac_bang_luong_23_Template(rf, ctx) { if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-tab-cap-bac-bang-luong", 23, 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("idOutPut", function TinhLuongComponent_app_tab_cap_bac_bang_luong_23_Template_app_tab_cap_bac_bang_luong_idOutPut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r22); const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r21.editEvent($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function TinhLuongComponent_app_chi_tiet_tab_bang_luong_25_Template(rf, ctx) { if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-chi-tiet-tab-bang-luong", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("detailOut", function TinhLuongComponent_app_chi_tiet_tab_bang_luong_25_Template_app_chi_tiet_tab_bang_luong_detailOut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r24); const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r23.theEventDetail($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("idForm", ctx_r5.idForm);
} }
function TinhLuongComponent_app_chi_tiet_tab_thiet_lap_tham_so_26_Template(rf, ctx) { if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-chi-tiet-tab-thiet-lap-tham-so", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("detailOut", function TinhLuongComponent_app_chi_tiet_tab_thiet_lap_tham_so_26_Template_app_chi_tiet_tab_thiet_lap_tham_so_detailOut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r26); const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r25.theEventDetail($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("idForm", ctx_r6.idForm);
} }
function TinhLuongComponent_app_chi_tiet_thanh_phan_luong_27_Template(rf, ctx) { if (rf & 1) {
    const _r28 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-chi-tiet-thanh-phan-luong", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("detailOut", function TinhLuongComponent_app_chi_tiet_thanh_phan_luong_27_Template_app_chi_tiet_thanh_phan_luong_detailOut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r28); const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r27.theEventDetail($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("idForm", ctx_r7.idForm);
} }
function TinhLuongComponent_app_chi_tiet_tab_cap_bac_luong_28_Template(rf, ctx) { if (rf & 1) {
    const _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-chi-tiet-tab-cap-bac-luong", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("detailOut", function TinhLuongComponent_app_chi_tiet_tab_cap_bac_luong_28_Template_app_chi_tiet_tab_cap_bac_luong_detailOut_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r30); const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r29.theEventDetail($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("idForm", ctx_r8.idForm);
} }
const _c4 = function () { return { width: "1000px" }; };
class TinhLuongComponent {
    constructor(apiService, spinner, route, confirmationService, messageService, fileService, changeDetector, router) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.changeDetector = changeDetector;
        this.router = router;
        this.tabsItem = [];
        this.pagingComponent = {
            total: 0
        };
        this.items = [];
        this.organs = [];
        this.itemsToolOfGrid = [];
        this.titleAddnew = '';
        this.listViews = [];
        this.detailInfo = [];
        this.isFormDetail = false;
        this.idForm = null;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_16__.Subject();
        this.displayOrganize = false;
        this.displayButton = false;
        this.detailOrganizeMap = null;
        this.isHrDiagram = false;
        this.displaySetting = false;
        this.gridKey = '';
        this.tabIndex = 0;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS;
        this.isAddNewButton = false;
        this.isNew = false;
        this.loadjs = 0;
        this.heightGrid = 0;
    }
    cauhinh() {
        this.displaySetting = true;
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Lương - thuế' },
            { label: 'Thiết lập tham Số' },
        ];
        this.getOrgan();
        this.itemsToolOfGrid = [
            {
                label: 'Export file',
                code: 'Import',
                icon: 'pi pi-download',
                disabled: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.IMPORT),
                command: () => {
                    // this.exportExel();
                }
            },
        ];
        this.checkIsAddNew();
    }
    checkIsAddNew() {
        if (this.tabIndex === 0 && !(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.ADD_TINH_LUONG_BANG_LUONG)) {
            this.isAddNewButton = true;
        }
        else if (this.tabIndex === 1 && !(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.ADD_TINH_LUONG_THIET_LAP_THAM_SO)) {
            this.isAddNewButton = true;
        }
        else if (this.tabIndex === 2 && !(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.ADD_TINH_LUONG_THANH_PHAN_LUONG)) {
            this.isAddNewButton = true;
        }
        else if (this.tabIndex === 3 && !(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetPayrollAppInfoPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.ADD_TINH_LUONG_CAP_BAC_LUONG)) {
            this.isAddNewButton = true;
        }
        else {
            this.isAddNewButton = false;
        }
    }
    editEvent(event) {
        let id = null;
        if (this.tabIndex === 0) {
            this.idForm = event.rowData.appInfoId;
        }
        else if (this.tabIndex === 1) {
            this.idForm = event.rowData.id;
        }
        else if (this.tabIndex === 2) {
            this.idForm = event.rowData.componentId;
        }
        else if (this.tabIndex === 3) {
            this.idForm = event.rowData.baseId;
        }
        this.isFormDetail = true;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ recordId: event.rowData.id });
        // this.apiService.getPayrollAppInfo(queryParams).subscribe(results => {
        //   if (results.status === 'success') {
        //     this.listViews = cloneDeep(results.data.group_fields);
        //     this.detailInfo = results.data;
        //   }
        // })
    }
    addNew() {
        if (this.tabIndex === 0) {
            this.isFormDetail = true;
            this.idForm = null;
        }
        else if (this.tabIndex === 1) {
            this.isFormDetail = true;
            this.idForm = null;
        }
        else if (this.tabIndex === 2) {
            this.isFormDetail = true;
            this.idForm = null;
        }
        else if (this.tabIndex === 3) {
            this.isFormDetail = true;
            this.idForm = null;
        }
    }
    checkTitleAddNew() {
        if (this.tabIndex === 0) {
            this.titleAddnew = 'Bảng lương';
            this.items[this.items.length - 1] = 'Bảng lương';
        }
        else if (this.tabIndex === 1) {
            this.titleAddnew = 'Thiết lâp tham số';
            this.items[this.items.length - 1] = 'Thiết lâp tham số';
        }
        else if (this.tabIndex === 2) {
            this.titleAddnew = 'Thành phần lương';
            this.items[this.items.length - 1] = 'Thành phần lương';
        }
        else if (this.tabIndex === 3) {
            this.titleAddnew = 'Cấp bậc lương';
            this.items[this.items.length - 1] = 'Cấp bậc lương';
        }
    }
    hrDiagram() {
        this.selectedNode = null;
        this.listAgencyMap = [];
        this.getAgencyOrganizeMap(true);
    }
    changeOrigin() {
        this.tabIndex = 0;
    }
    getAgencyOrganizeMap(type = false) {
        this.apiService.getAgencyOrganizeMap().subscribe(results => {
            if (results.status === 'success') {
                this.listAgencyMap = [...results.data.root];
                if (localStorage.getItem("organize") === null) {
                    this.selectedNode = this.listAgencyMap[0];
                    localStorage.setItem('organize', JSON.stringify(this.listAgencyMap[0]));
                }
                else {
                    this.selectedNode = JSON.parse(localStorage.getItem("organize"));
                    if (type) {
                        this.isHrDiagram = true;
                    }
                }
            }
        });
    }
    Back() {
        this.router.navigate(['/page-agency']);
    }
    Close() {
        this.displayOrganize = false;
    }
    getContextMenuItems(params) {
        var result = [
            'copy',
            'paste',
            'separator',
        ];
        return result;
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    getOrgan() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.organs = results.data.map(d => {
                    return {
                        label: d.organizationName,
                        value: `${d.organizeId}`
                    };
                });
                this.organs = [...this.organs];
            }
        });
    }
    ngAfterViewChecked() {
        // const a: any = document.querySelector(".header");
        // const b: any = document.querySelector(".sidebarBody");
        // const c: any = document.querySelector(".bread-filter");
        // const d: any = document.querySelector(".bread-crumb");
        // const e: any = document.querySelector(".paginator");
        // this.loadjs++
        // if (this.loadjs === 5) {
        //   if (b && b.clientHeight) {
        //     const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 25;
        //     this.heightGrid = window.innerHeight - totalHeight
        //     this.changeDetector.detectChanges();
        //   } else {
        //     this.loadjs = 0;
        //   }
        // }
    }
    handleChange(e) {
        this.tabIndex = e;
        this.checkTitleAddNew();
        this.checkIsAddNew();
    }
    // thanh phan luong
    getHrmPayrollAttributeInfo(id = null) {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ Id: id });
        this.apiService.getHrmPayrollAttributeInfo(queryParams).subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_4__.cloneDeep)(results.data.group_fields);
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_4__.cloneDeep)(listViews);
                this.detailInfo = results.data;
            }
        });
    }
    // loai bang luong
    // getHrmPayrollTypeInfo(id = null) {
    //   const queryParams = queryString.stringify({ Id: id })
    //   this.apiService.getHrmPayrollTypeInfo(queryParams).subscribe( results => {
    //     if (results.status === 'success') {
    //       const listViews = cloneDeep(results.data.group_fields);
    //       this.listViews = cloneDeep(listViews);
    //       this.detailInfo = results.data;
    //       this.ngOnInit();
    //     }
    //   })
    // }
    ngOnDestroy() {
        if (this.unsubscribe$) {
            this.unsubscribe$.unsubscribe();
        }
    }
    // handleSave(event) {
    //   if(this.tabIndex === 0){
    //   }else if(this.tabIndex === 1){
    //   }else if(this.tabIndex === 2){
    //     this.getHrmPayrollTypeInfo();
    //   }else if(this.tabIndex === 3){
    //     this.setHrmPayrollTypeInfo(event);
    //   }
    // }
    // // loai bang luong
    // setHrmPayrollTypeInfo(data) {
    //   const params = {
    //     ...this.detailInfo, group_fields: data
    //   };
    //   this.spinner.show();
    //   this.apiService.setHrmPayrollTypeInfo(params)
    //     .pipe(takeUntil(this.unsubscribe$))
    //     .subscribe((results: any) => {
    //       if (results.status === 'success') {
    //         this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
    //         this.spinner.hide();
    //         this.isNew = false;
    //         this.tabIndex = this.tabIndex;
    //       } else {
    //         this.messageService.add({
    //           severity: 'error', summary: 'Thông báo',
    //           detail: results.message
    //         });
    //         this.spinner.hide();
    //       }
    //     }), error => {
    //       console.error('Error:', error);
    //       this.spinner.hide();
    //     }; 
    // }
    // quaylai(event){
    //   this.isNew = false
    // }
    // getIsNewPopup(event){
    //   this.isNew = event
    // }
    // from detail
    theEventDetail(event) {
        this.isFormDetail = false;
        if (this.tabIndex === 0) {
            this.tabBangLuong.load();
        }
        if (this.tabIndex === 1) {
            this.tabThietLapThamSo.load();
        }
        if (this.tabIndex === 2) {
            this.tabThanhPhanLuong.load();
        }
        if (this.tabIndex === 3) {
            this.TabCapBacLuongComponent.load();
        }
    }
}
TinhLuongComponent.ɵfac = function TinhLuongComponent_Factory(t) { return new (t || TinhLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_17__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_18__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_19__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_19__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_3__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_15__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_18__.Router)); };
TinhLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({ type: TinhLuongComponent, selectors: [["app-tinh-luong"]], viewQuery: function TinhLuongComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵviewQuery"](_c2, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵviewQuery"](_c3, 5);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵloadQuery"]()) && (ctx.tabBangLuong = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵloadQuery"]()) && (ctx.tabThietLapThamSo = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵloadQuery"]()) && (ctx.tabThanhPhanLuong = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵloadQuery"]()) && (ctx.TabCapBacLuongComponent = _t.first);
    } }, decls: 29, vars: 22, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [3, "displayTitle", "items", "title"], [1, "d-flex", "bet", "mid", "bottom", "gap-12"], ["styleClass", "p-button-sm height-56 btn-dele"], ["width", "16", "height", "18", "viewBox", "0 0 16 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M4.50938 0.666748H15.5V14.2943H11.8929V17.3334H0.5V4.11827H4.50938V0.666748ZM6.17604 4.11827H11.8929V12.6277H13.8333V2.33341H6.17604V4.11827ZM2.16667 5.78493V15.6667H10.2263V5.78493H2.16667Z", "fill", "#F6FBFF"], ["width", "18", "height", "15", "viewBox", "0 0 18 15", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M2.26223 2.90476L12.1908 7.04762L2.25429 5.46032L2.26223 2.90476ZM12.1829 8.23809L2.25429 12.381V9.8254L12.1829 8.23809ZM0.674929 0.5L0.666992 6.84921L7.0162 7.64286L0.666992 8.43651L0.674929 14.7857L17.3337 7.64286L0.674929 0.5Z", "fill", "#F6FBFF"], ["styleClass", "p-button-sm height-56", 3, "click", 4, "ngIf"], [1, "pb-0"], [3, "activeIndex", "onChange", "activeIndexChange"], ["header", "Ba\u0309ng L\u01B0\u01A1ng"], [3, "idOutPut", 4, "ngIf"], ["header", "Thi\u00EA\u0301t l\u00E2p tham s\u00F4\u0301"], ["header", "Tha\u0300nh ph\u00E2\u0300n l\u01B0\u01A1ng"], ["header", "C\u1EA5p b\u1EADc l\u01B0\u01A1ng"], [3, "header", "visible", "modal", "draggable", "resizable", "focusTrap", "visibleChange"], [3, "idForm", "detailOut", 4, "ngIf"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M13.6668 8.08835H8.0886V13.6666H5.91173V8.08835H0.333496V5.91148H5.91173V0.333252H8.0886V5.91148H13.6668V8.08835Z", "fill", "#F6FBFF"], [3, "idOutPut"], ["tabBangLuong", ""], ["tabThietLapThamSo", ""], ["tabThanhPhanLuong", ""], ["TabCapBacLuongComponent", ""], [3, "idForm", "detailOut"]], template: function TinhLuongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "svg", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](7, "path", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](8, " \u00A0 Nh\u00E2n ba\u0309n ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](10, "svg", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](11, "path", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](12, " \u00A0 G\u01B0\u0309i ba\u0309ng l\u01B0\u01A1ng ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](13, TinhLuongComponent_p_button_13_Template, 4, 0, "p-button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](14, "section", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](15, "p-tabView", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("onChange", function TinhLuongComponent_Template_p_tabView_onChange_15_listener($event) { return ctx.handleChange($event.index); })("activeIndexChange", function TinhLuongComponent_Template_p_tabView_activeIndexChange_15_listener($event) { return ctx.tabIndex = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](16, "p-tabPanel", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](17, TinhLuongComponent_app_tab_bang_luong_17_Template, 2, 0, "app-tab-bang-luong", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](18, "p-tabPanel", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](19, TinhLuongComponent_app_tab_thiet_lap_tham_so_19_Template, 2, 0, "app-tab-thiet-lap-tham-so", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](20, "p-tabPanel", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](21, TinhLuongComponent_app_tab_thanh_phan_luong_21_Template, 2, 0, "app-tab-thanh-phan-luong", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](22, "p-tabPanel", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](23, TinhLuongComponent_app_tab_cap_bac_bang_luong_23_Template, 2, 0, "app-tab-cap-bac-bang-luong", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](24, "p-dialog", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function TinhLuongComponent_Template_p_dialog_visibleChange_24_listener($event) { return ctx.isFormDetail = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](25, TinhLuongComponent_app_chi_tiet_tab_bang_luong_25_Template, 1, 1, "app-chi-tiet-tab-bang-luong", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](26, TinhLuongComponent_app_chi_tiet_tab_thiet_lap_tham_so_26_Template, 1, 1, "app-chi-tiet-tab-thiet-lap-tham-so", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](27, TinhLuongComponent_app_chi_tiet_thanh_phan_luong_27_Template, 1, 1, "app-chi-tiet-thanh-phan-luong", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](28, TinhLuongComponent_app_chi_tiet_tab_cap_bac_luong_28_Template, 1, 1, "app-chi-tiet-tab-cap-bac-luong", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("displayTitle", true)("items", ctx.items)("title", "Ti\u0301nh l\u01B0\u01A1ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.isAddNewButton);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("activeIndex", ctx.tabIndex);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.tabIndex === 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.tabIndex === 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.tabIndex === 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.tabIndex === 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](21, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpropertyInterpolate"]("header", ctx.titleAddnew);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.isFormDetail)("modal", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.isFormDetail && ctx.tabIndex === 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.isFormDetail && ctx.tabIndex === 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.isFormDetail && ctx.tabIndex === 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.isFormDetail && ctx.tabIndex === 3);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_10__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_20__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_21__.NgIf, primeng_tabview__WEBPACK_IMPORTED_MODULE_22__.TabView, primeng_tabview__WEBPACK_IMPORTED_MODULE_22__.TabPanel, primeng_dialog__WEBPACK_IMPORTED_MODULE_23__.Dialog, _tab_bang_luong_tab_bang_luong_component__WEBPACK_IMPORTED_MODULE_5__.TabBangLuongComponent, _tab_thiet_lap_tham_so_tab_thiet_lap_tham_so_component__WEBPACK_IMPORTED_MODULE_6__.TabThietLapThamSoComponent, _tab_thanh_phan_luong_tab_thanh_phan_luong_component__WEBPACK_IMPORTED_MODULE_7__.TabThanhPhanLuongComponent, _tab_cap_bac_luong_tab_cap_bac_luong_component__WEBPACK_IMPORTED_MODULE_8__.TabCapBacLuongComponent, src_app_components_luong_thue_tinh_luong_tab_bang_luong_chi_tiet_tab_bang_luong_chi_tiet_tab_bang_luong_component__WEBPACK_IMPORTED_MODULE_11__.ChiTietTabBangLuongComponent, src_app_components_luong_thue_tinh_luong_tab_thiet_lap_tham_so_chi_tiet_tab_thiet_lap_tham_so_chi_tiet_tab_thiet_lap_tham_so_component__WEBPACK_IMPORTED_MODULE_12__.ChiTietTabThietLapThamSoComponent, src_app_components_luong_thue_tinh_luong_tab_thanh_phan_luong_chi_tiet_thanh_phan_luong_chi_tiet_thanh_phan_luong_component__WEBPACK_IMPORTED_MODULE_13__.ChiTietThanhPhanLuongComponent, src_app_components_luong_thue_tinh_luong_tab_cap_bac_luong_chi_tiet_tab_cap_bac_luong_chi_tiet_tab_cap_bac_luong_component__WEBPACK_IMPORTED_MODULE_14__.ChiTietTabCapBacLuongComponent], styles: [".select-default[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  text-align: left;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .p-person {\n  padding: 0;\n  border: 0 none;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-header, [_nghost-%COMP%]     .p-organizationchart .node-content {\n  padding: 0.5em 0.7rem;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-header {\n  background-color: #495ebb;\n  color: #ffffff;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-content {\n  text-align: center;\n  border: 1px solid #495ebb;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .node-content img {\n  border-radius: 50%;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .department-cfo {\n  background-color: #7247bc;\n  color: #ffffff;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .department-coo {\n  background-color: #a534b6;\n  color: #ffffff;\n}\n\n[_nghost-%COMP%]     .p-organizationchart .department-cto {\n  background-color: #e9286f;\n  color: #ffffff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRpbmgtbHVvbmcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtBQUNKOztBQUVJO0VBQ0ksVUFBQTtFQUNBLGNBQUE7QUFDUjs7QUFFSTtFQUNJLHFCQUFBO0FBQVI7O0FBR0k7RUFDSSx5QkFBQTtFQUNBLGNBQUE7QUFEUjs7QUFJSTtFQUNJLGtCQUFBO0VBQ0EseUJBQUE7QUFGUjs7QUFLSTtFQUNJLGtCQUFBO0FBSFI7O0FBTUk7RUFDSSx5QkFBQTtFQUNBLGNBQUE7QUFKUjs7QUFPSTtFQUNJLHlCQUFBO0VBQ0EsY0FBQTtBQUxSOztBQVFJO0VBQ0kseUJBQUE7RUFDQSxjQUFBO0FBTlIiLCJmaWxlIjoidGluaC1sdW9uZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZWxlY3QtZGVmYXVsdCBsYWJlbHtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbn1cclxuOmhvc3QgOjpuZy1kZWVwIC5wLW9yZ2FuaXphdGlvbmNoYXJ0IHtcclxuICAgIC5wLXBlcnNvbiB7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICBib3JkZXI6IDAgbm9uZTtcclxuICAgIH1cclxuXHJcbiAgICAubm9kZS1oZWFkZXIsIC5ub2RlLWNvbnRlbnQge1xyXG4gICAgICAgIHBhZGRpbmc6IC41ZW0gLjdyZW07XHJcbiAgICB9XHJcblxyXG4gICAgLm5vZGUtaGVhZGVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDk1ZWJiO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgfVxyXG5cclxuICAgIC5ub2RlLWNvbnRlbnQge1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjNDk1ZWJiO1xyXG4gICAgfVxyXG5cclxuICAgIC5ub2RlLWNvbnRlbnQgaW1nIHtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICB9XHJcblxyXG4gICAgLmRlcGFydG1lbnQtY2ZvIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNzI0N2JjO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgfVxyXG5cclxuICAgIC5kZXBhcnRtZW50LWNvbyB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2E1MzRiNjtcclxuICAgICAgICBjb2xvcjogI2ZmZmZmZjtcclxuICAgIH1cclxuXHJcbiAgICAuZGVwYXJ0bWVudC1jdG8ge1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNlOTI4NmY7XHJcbiAgICAgICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICB9XHJcbn0iXX0= */"] });


/***/ }),

/***/ 1149:
/*!***************************************************************!*\
  !*** ./src/app/pages/luong-thue/luong-thue-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LuongThueRoutingModule": () => (/* binding */ LuongThueRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var src_app_components_luong_thue_bang_luong_bang_luong_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/components/luong-thue/bang-luong/bang-luong.component */ 39995);
/* harmony import */ var src_app_components_luong_thue_bang_luong_chi_tiet_bang_luong_chi_tiet_bang_luong_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/components/luong-thue/bang-luong/chi-tiet-bang-luong/chi-tiet-bang-luong.component */ 59602);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tinh_luong_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tinh-luong.component */ 47857);
/* harmony import */ var src_app_components_luong_thue_bang_luong_cau_truc_bang_luong_cau_truc_bang_luong_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/components/luong-thue/bang-luong/cau-truc-bang-luong/cau-truc-bang-luong.component */ 66538);
/* harmony import */ var src_app_components_luong_thue_bang_luong_cong_thuc_luong_cong_thuc_luong_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/components/luong-thue/bang-luong/cong-thuc-luong/cong-thuc-luong.component */ 87050);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 14001);








const routes = [
    {
        path: "",
        redirectTo: "danh-sach-bang-luong",
        pathMatch: 'full'
    },
    {
        path: 'danh-sach-bang-luong',
        component: src_app_components_luong_thue_bang_luong_bang_luong_component__WEBPACK_IMPORTED_MODULE_0__.BangLuongComponent,
        data: {
            title: 'Danh sách bảng lương',
            url: 'danh-sach-bang-luong',
        },
    },
    {
        path: 'tinh-luong',
        component: src_app_components_luong_thue_tinh_luong_tinh_luong_component__WEBPACK_IMPORTED_MODULE_2__.TinhLuongComponent,
        data: {
            title: 'Thiết lập tham số',
            url: 'thiet-lap-tham-so',
        },
    },
    {
        path: 'danh-sach-bang-luong/chi-tiet-bang-luong',
        component: src_app_components_luong_thue_bang_luong_chi_tiet_bang_luong_chi_tiet_bang_luong_component__WEBPACK_IMPORTED_MODULE_1__.ChiTietBangLuongComponent,
        data: {
            title: 'Chi tiết bảng lương',
            url: 'chi-tiet-bang-luong',
        },
    },
    {
        path: 'danh-sach-bang-luong/cau-truc-bang-luong',
        component: src_app_components_luong_thue_bang_luong_cau_truc_bang_luong_cau_truc_bang_luong_component__WEBPACK_IMPORTED_MODULE_3__.CauTrucBangLuongComponent,
        data: {
            title: 'Chi tiết bảng lương',
            url: 'chi-tiet-bang-luong',
        },
    },
    {
        path: 'danh-sach-bang-luong/cong-thuc-luong',
        component: src_app_components_luong_thue_bang_luong_cong_thuc_luong_cong_thuc_luong_component__WEBPACK_IMPORTED_MODULE_4__.CongThucLuongComponent,
        data: {
            title: 'Chi tiết bảng lương',
            url: 'chi-tiet-bang-luong',
        },
    },
    ,
];
class LuongThueRoutingModule {
}
LuongThueRoutingModule.ɵfac = function LuongThueRoutingModule_Factory(t) { return new (t || LuongThueRoutingModule)(); };
LuongThueRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({ type: LuongThueRoutingModule });
LuongThueRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](LuongThueRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule] }); })();


/***/ }),

/***/ 30772:
/*!*******************************************************!*\
  !*** ./src/app/pages/luong-thue/luong-thue.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LuongThueModule": () => (/* binding */ LuongThueModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_tree__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! primeng/tree */ 35295);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! primeng/table */ 43750);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! primeng/multiselect */ 92487);
/* harmony import */ var src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/list-grid-angular/list-grid-angular.module */ 8145);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! primeng/splitbutton */ 71494);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! primeng/autocomplete */ 17611);
/* harmony import */ var src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/edit-detail/edit-detail.module */ 38160);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! primeng/fileupload */ 83735);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_card__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! primeng/card */ 33506);
/* harmony import */ var primeng_badge__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! primeng/badge */ 62051);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! primeng/tooltip */ 39243);
/* harmony import */ var primeng_slider__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! primeng/slider */ 52340);
/* harmony import */ var src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/pipe/currency-pipe.module */ 44093);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! @ag-grid-community/angular */ 11775);
/* harmony import */ var src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component */ 75137);
/* harmony import */ var src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component-1 */ 90457);
/* harmony import */ var primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! primeng/confirmdialog */ 71849);
/* harmony import */ var primeng_sidebar__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! primeng/sidebar */ 65357);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var primeng_messages__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/messages */ 93713);
/* harmony import */ var primeng_message__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/message */ 15357);
/* harmony import */ var _luong_thue_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./luong-thue-routing.module */ 1149);
/* harmony import */ var src_app_components_page_notify_page_notify_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/page-notify/page-notify.module */ 47186);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! primeng/organizationchart */ 87051);
/* harmony import */ var src_app_common_grid_add_grid_add_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common/grid-add/grid-add.module */ 57380);
/* harmony import */ var primeng_panel__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! primeng/panel */ 53581);
/* harmony import */ var src_app_common_search_user_master_search_user_master_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/common/search-user-master/search-user-master.module */ 44038);
/* harmony import */ var src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/common/hrm-breadcrumb/hrm-breadcrumb.module */ 38040);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_checkbox__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! primeng/checkbox */ 77588);
/* harmony import */ var src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/common/config-grid-table-form/config-grid-table-form.module */ 45092);
/* harmony import */ var src_app_components_luong_thue_bang_luong_bang_luong_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/components/luong-thue/bang-luong/bang-luong.component */ 39995);
/* harmony import */ var primeng_listbox__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! primeng/listbox */ 61529);
/* harmony import */ var src_app_components_luong_thue_bang_luong_chi_tiet_bang_luong_chi_tiet_bang_luong_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/components/luong-thue/bang-luong/chi-tiet-bang-luong/chi-tiet-bang-luong.component */ 59602);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_bang_luong_tab_bang_luong_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-bang-luong/tab-bang-luong.component */ 68379);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_thiet_lap_tham_so_tab_thiet_lap_tham_so_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-thiet-lap-tham-so/tab-thiet-lap-tham-so.component */ 27088);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_thanh_phan_luong_tab_thanh_phan_luong_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-thanh-phan-luong/tab-thanh-phan-luong.component */ 23788);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tinh_luong_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tinh-luong.component */ 47857);
/* harmony import */ var src_app_components_luong_thue_bang_luong_cau_truc_bang_luong_cau_truc_bang_luong_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/components/luong-thue/bang-luong/cau-truc-bang-luong/cau-truc-bang-luong.component */ 66538);
/* harmony import */ var src_app_components_luong_thue_bang_luong_cong_thuc_luong_cong_thuc_luong_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/components/luong-thue/bang-luong/cong-thuc-luong/cong-thuc-luong.component */ 87050);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_thanh_phan_luong_chi_tiet_thanh_phan_luong_chi_tiet_thanh_phan_luong_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-thanh-phan-luong/chi-tiet-thanh-phan-luong/chi-tiet-thanh-phan-luong.component */ 55810);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_bang_luong_chi_tiet_tab_bang_luong_chi_tiet_tab_bang_luong_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-bang-luong/chi-tiet-tab-bang-luong/chi-tiet-tab-bang-luong.component */ 725);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_thiet_lap_tham_so_chi_tiet_tab_thiet_lap_tham_so_chi_tiet_tab_thiet_lap_tham_so_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-thiet-lap-tham-so/chi-tiet-tab-thiet-lap-tham-so/chi-tiet-tab-thiet-lap-tham-so.component */ 80555);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_cap_bac_luong_tab_cap_bac_luong_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-cap-bac-luong/tab-cap-bac-luong.component */ 56710);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_cap_bac_luong_chi_tiet_tab_cap_bac_luong_chi_tiet_tab_cap_bac_luong_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-cap-bac-luong/chi-tiet-tab-cap-bac-luong/chi-tiet-tab-cap-bac-luong.component */ 26259);
/* harmony import */ var src_app_components_luong_thue_tinh_luong_tab_bang_luong_muc_luong_muc_luong_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! src/app/components/luong-thue/tinh-luong/tab-bang-luong/muc-luong/muc-luong.component */ 19535);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/core */ 14001);


























































class LuongThueModule {
}
LuongThueModule.ɵfac = function LuongThueModule_Factory(t) { return new (t || LuongThueModule)(); };
LuongThueModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵdefineNgModule"]({ type: LuongThueModule });
LuongThueModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵdefineInjector"]({ providers: [], imports: [[
            primeng_messages__WEBPACK_IMPORTED_MODULE_26__.MessagesModule,
            primeng_message__WEBPACK_IMPORTED_MODULE_27__.MessageModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_28__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_28__.ReactiveFormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_29__.CommonModule,
            primeng_tree__WEBPACK_IMPORTED_MODULE_30__.TreeModule,
            primeng_table__WEBPACK_IMPORTED_MODULE_31__.TableModule,
            primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_32__.BreadcrumbModule,
            primeng_multiselect__WEBPACK_IMPORTED_MODULE_33__.MultiSelectModule,
            src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularModule,
            primeng_button__WEBPACK_IMPORTED_MODULE_34__.ButtonModule,
            primeng_splitbutton__WEBPACK_IMPORTED_MODULE_35__.SplitButtonModule,
            primeng_calendar__WEBPACK_IMPORTED_MODULE_36__.CalendarModule,
            primeng_autocomplete__WEBPACK_IMPORTED_MODULE_37__.AutoCompleteModule,
            src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__.EditDetailModule,
            primeng_fileupload__WEBPACK_IMPORTED_MODULE_38__.FileUploadModule,
            primeng_organizationchart__WEBPACK_IMPORTED_MODULE_39__.OrganizationChartModule,
            primeng_treeselect__WEBPACK_IMPORTED_MODULE_40__.TreeSelectModule,
            primeng_menu__WEBPACK_IMPORTED_MODULE_41__.MenuModule,
            primeng_card__WEBPACK_IMPORTED_MODULE_42__.CardModule,
            primeng_badge__WEBPACK_IMPORTED_MODULE_43__.BadgeModule,
            primeng_tooltip__WEBPACK_IMPORTED_MODULE_44__.TooltipModule,
            primeng_slider__WEBPACK_IMPORTED_MODULE_45__.SliderModule,
            primeng_sidebar__WEBPACK_IMPORTED_MODULE_46__.SidebarModule,
            _luong_thue_routing_module__WEBPACK_IMPORTED_MODULE_5__.LuongThueRoutingModule,
            src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__.CurrencyFormatPipeModule,
            primeng_dialog__WEBPACK_IMPORTED_MODULE_47__.DialogModule,
            primeng_dropdown__WEBPACK_IMPORTED_MODULE_48__.DropdownModule,
            src_app_components_page_notify_page_notify_module__WEBPACK_IMPORTED_MODULE_6__.PageNotifyModule,
            primeng_tabview__WEBPACK_IMPORTED_MODULE_49__.TabViewModule,
            primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_50__.OverlayPanelModule,
            primeng_paginator__WEBPACK_IMPORTED_MODULE_51__.PaginatorModule,
            src_app_common_grid_add_grid_add_module__WEBPACK_IMPORTED_MODULE_7__.GridAddModule,
            primeng_panel__WEBPACK_IMPORTED_MODULE_52__.PanelModule,
            src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_9__.HrmBreadCrumbModule,
            src_app_common_search_user_master_search_user_master_module__WEBPACK_IMPORTED_MODULE_8__.CommonSearchUserMasterModule,
            primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_53__.ConfirmDialogModule,
            src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_10__.ConfigGridTableFormModule,
            primeng_checkbox__WEBPACK_IMPORTED_MODULE_54__.CheckboxModule,
            primeng_listbox__WEBPACK_IMPORTED_MODULE_55__.ListboxModule,
            _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_56__.AgGridModule.withComponents([
                src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_3__.ButtonRendererComponent,
                src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_4__.ButtonRendererComponent1
            ]),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵsetNgModuleScope"](LuongThueModule, { declarations: [src_app_components_luong_thue_tinh_luong_tinh_luong_component__WEBPACK_IMPORTED_MODULE_16__.TinhLuongComponent,
        src_app_components_luong_thue_bang_luong_bang_luong_component__WEBPACK_IMPORTED_MODULE_11__.BangLuongComponent,
        src_app_components_luong_thue_tinh_luong_tab_thiet_lap_tham_so_tab_thiet_lap_tham_so_component__WEBPACK_IMPORTED_MODULE_14__.TabThietLapThamSoComponent,
        src_app_components_luong_thue_tinh_luong_tab_bang_luong_tab_bang_luong_component__WEBPACK_IMPORTED_MODULE_13__.TabBangLuongComponent,
        src_app_components_luong_thue_tinh_luong_tab_thiet_lap_tham_so_tab_thiet_lap_tham_so_component__WEBPACK_IMPORTED_MODULE_14__.TabThietLapThamSoComponent,
        src_app_components_luong_thue_tinh_luong_tab_thanh_phan_luong_tab_thanh_phan_luong_component__WEBPACK_IMPORTED_MODULE_15__.TabThanhPhanLuongComponent,
        src_app_components_luong_thue_tinh_luong_tab_cap_bac_luong_tab_cap_bac_luong_component__WEBPACK_IMPORTED_MODULE_22__.TabCapBacLuongComponent,
        src_app_components_luong_thue_bang_luong_chi_tiet_bang_luong_chi_tiet_bang_luong_component__WEBPACK_IMPORTED_MODULE_12__.ChiTietBangLuongComponent,
        src_app_components_luong_thue_bang_luong_cau_truc_bang_luong_cau_truc_bang_luong_component__WEBPACK_IMPORTED_MODULE_17__.CauTrucBangLuongComponent,
        src_app_components_luong_thue_bang_luong_cong_thuc_luong_cong_thuc_luong_component__WEBPACK_IMPORTED_MODULE_18__.CongThucLuongComponent,
        src_app_components_luong_thue_tinh_luong_tab_thanh_phan_luong_chi_tiet_thanh_phan_luong_chi_tiet_thanh_phan_luong_component__WEBPACK_IMPORTED_MODULE_19__.ChiTietThanhPhanLuongComponent,
        src_app_components_luong_thue_tinh_luong_tab_bang_luong_chi_tiet_tab_bang_luong_chi_tiet_tab_bang_luong_component__WEBPACK_IMPORTED_MODULE_20__.ChiTietTabBangLuongComponent,
        src_app_components_luong_thue_tinh_luong_tab_thiet_lap_tham_so_chi_tiet_tab_thiet_lap_tham_so_chi_tiet_tab_thiet_lap_tham_so_component__WEBPACK_IMPORTED_MODULE_21__.ChiTietTabThietLapThamSoComponent,
        src_app_components_luong_thue_tinh_luong_tab_cap_bac_luong_chi_tiet_tab_cap_bac_luong_chi_tiet_tab_cap_bac_luong_component__WEBPACK_IMPORTED_MODULE_23__.ChiTietTabCapBacLuongComponent,
        src_app_components_luong_thue_tinh_luong_tab_bang_luong_muc_luong_muc_luong_component__WEBPACK_IMPORTED_MODULE_24__.MucLuongComponent], imports: [primeng_messages__WEBPACK_IMPORTED_MODULE_26__.MessagesModule,
        primeng_message__WEBPACK_IMPORTED_MODULE_27__.MessageModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_28__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_28__.ReactiveFormsModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_29__.CommonModule,
        primeng_tree__WEBPACK_IMPORTED_MODULE_30__.TreeModule,
        primeng_table__WEBPACK_IMPORTED_MODULE_31__.TableModule,
        primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_32__.BreadcrumbModule,
        primeng_multiselect__WEBPACK_IMPORTED_MODULE_33__.MultiSelectModule,
        src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularModule,
        primeng_button__WEBPACK_IMPORTED_MODULE_34__.ButtonModule,
        primeng_splitbutton__WEBPACK_IMPORTED_MODULE_35__.SplitButtonModule,
        primeng_calendar__WEBPACK_IMPORTED_MODULE_36__.CalendarModule,
        primeng_autocomplete__WEBPACK_IMPORTED_MODULE_37__.AutoCompleteModule,
        src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__.EditDetailModule,
        primeng_fileupload__WEBPACK_IMPORTED_MODULE_38__.FileUploadModule,
        primeng_organizationchart__WEBPACK_IMPORTED_MODULE_39__.OrganizationChartModule,
        primeng_treeselect__WEBPACK_IMPORTED_MODULE_40__.TreeSelectModule,
        primeng_menu__WEBPACK_IMPORTED_MODULE_41__.MenuModule,
        primeng_card__WEBPACK_IMPORTED_MODULE_42__.CardModule,
        primeng_badge__WEBPACK_IMPORTED_MODULE_43__.BadgeModule,
        primeng_tooltip__WEBPACK_IMPORTED_MODULE_44__.TooltipModule,
        primeng_slider__WEBPACK_IMPORTED_MODULE_45__.SliderModule,
        primeng_sidebar__WEBPACK_IMPORTED_MODULE_46__.SidebarModule,
        _luong_thue_routing_module__WEBPACK_IMPORTED_MODULE_5__.LuongThueRoutingModule,
        src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__.CurrencyFormatPipeModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_47__.DialogModule,
        primeng_dropdown__WEBPACK_IMPORTED_MODULE_48__.DropdownModule,
        src_app_components_page_notify_page_notify_module__WEBPACK_IMPORTED_MODULE_6__.PageNotifyModule,
        primeng_tabview__WEBPACK_IMPORTED_MODULE_49__.TabViewModule,
        primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_50__.OverlayPanelModule,
        primeng_paginator__WEBPACK_IMPORTED_MODULE_51__.PaginatorModule,
        src_app_common_grid_add_grid_add_module__WEBPACK_IMPORTED_MODULE_7__.GridAddModule,
        primeng_panel__WEBPACK_IMPORTED_MODULE_52__.PanelModule,
        src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_9__.HrmBreadCrumbModule,
        src_app_common_search_user_master_search_user_master_module__WEBPACK_IMPORTED_MODULE_8__.CommonSearchUserMasterModule,
        primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_53__.ConfirmDialogModule,
        src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_10__.ConfigGridTableFormModule,
        primeng_checkbox__WEBPACK_IMPORTED_MODULE_54__.CheckboxModule,
        primeng_listbox__WEBPACK_IMPORTED_MODULE_55__.ListboxModule, _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_56__.AgGridModule], exports: [src_app_components_luong_thue_tinh_luong_tab_bang_luong_tab_bang_luong_component__WEBPACK_IMPORTED_MODULE_13__.TabBangLuongComponent,
        src_app_components_luong_thue_tinh_luong_tab_thiet_lap_tham_so_tab_thiet_lap_tham_so_component__WEBPACK_IMPORTED_MODULE_14__.TabThietLapThamSoComponent,
        src_app_components_luong_thue_tinh_luong_tab_thanh_phan_luong_tab_thanh_phan_luong_component__WEBPACK_IMPORTED_MODULE_15__.TabThanhPhanLuongComponent,
        src_app_components_luong_thue_tinh_luong_tab_cap_bac_luong_tab_cap_bac_luong_component__WEBPACK_IMPORTED_MODULE_22__.TabCapBacLuongComponent,
        src_app_components_luong_thue_tinh_luong_tab_thanh_phan_luong_chi_tiet_thanh_phan_luong_chi_tiet_thanh_phan_luong_component__WEBPACK_IMPORTED_MODULE_19__.ChiTietThanhPhanLuongComponent] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_pages_luong-thue_luong-thue_module_ts.437ddc133a1d3733.js.map