(self["webpackChunkucart"] = self["webpackChunkucart"] || []).push([["main"],{

/***/ 83696:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _services_auth_guard_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./services/auth-guard.service */ 35583);
/* harmony import */ var _auth_callback_auth_callback_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth-callback/auth-callback.component */ 81536);
/* harmony import */ var _containers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./containers */ 96068);
/* harmony import */ var _pages_home_home_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/home/home.component */ 43049);
/* harmony import */ var _components_uni_not_found_uni_not_found_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/uni-not-found/uni-not-found.component */ 55386);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 14001);








// import { HomeComponent } from './home/home.component';
// import { OrderSunshineComponent } from './order-sunshine/order-sunshine.component';
// import { ReportendofdayComponent } from './reportendofday/reportendofday.component';
const appRoutes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full',
    },
    { path: 'auth-callback', component: _auth_callback_auth_callback_component__WEBPACK_IMPORTED_MODULE_1__.AuthCallbackComponent },
    {
        path: '', component: _containers__WEBPACK_IMPORTED_MODULE_2__.DefaultLayoutComponent,
        data: { title: '' }, children: [
            { path: 'home', component: _pages_home_home_component__WEBPACK_IMPORTED_MODULE_3__.HomeComponent },
            {
                path: 'tuyen-dung',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_common_edit-detail_edit-detail_module_ts-src_app_common_hrm-breadcrumb_hrm-br-a740d0"), __webpack_require__.e("default-src_app_directive_check-action_module_ts-node_modules_primeng_fesm2020_primeng-splitter_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2020_primeng-picklist_mjs"), __webpack_require__.e("default-src_app_common_form-filter_form-filter_component_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2020_primeng-listbox_mjs"), __webpack_require__.e("default-src_app_common_upload-file_upload-file_module_ts-src_app_components_ns-ho-so-nhan-su_-cee1b8"), __webpack_require__.e("src_app_pages_tuyen-dung_tuyen-dung_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../app/pages/tuyen-dung/tuyen-dung.module */ 68171)).then(m => m.TuyenDungModule)
            },
            {
                path: '404',
                pathMatch: 'full',
                component: _components_uni_not_found_uni_not_found_component__WEBPACK_IMPORTED_MODULE_4__.UniNotFoundComponent
            },
            {
                path: 'nhan-su',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_common_edit-detail_edit-detail_module_ts-src_app_common_hrm-breadcrumb_hrm-br-a740d0"), __webpack_require__.e("default-src_app_directive_check-action_module_ts-node_modules_primeng_fesm2020_primeng-splitter_mjs"), __webpack_require__.e("default-src_app_components_page-notify_store-notify_store-notify_module_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2020_primeng-picklist_mjs"), __webpack_require__.e("default-src_app_common_form-filter_form-filter_component_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2020_primeng-listbox_mjs"), __webpack_require__.e("default-src_app_common_upload-file_upload-file_module_ts-src_app_components_ns-ho-so-nhan-su_-cee1b8"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_nhan-su_nhan-su_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../app/pages/nhan-su/nhan-su.module */ 55118)).then(m => m.NhanSuModule)
            },
            {
                path: 'chinh-sach',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_common_edit-detail_edit-detail_module_ts-src_app_common_hrm-breadcrumb_hrm-br-a740d0"), __webpack_require__.e("default-src_app_common_form-filter_form-filter_component_ts"), __webpack_require__.e("default-src_app_components_bieu-mau_bieu-mau_component_ts-src_app_components_bieu-mau_loai-bi-2aadfb"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_chinh-sach_chinh-sach_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../app/pages/chinh-sach/chinh-sach.module */ 76079)).then(m => m.ChinhSachModule)
            },
            {
                path: 'cai-dat',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_common_edit-detail_edit-detail_module_ts-src_app_common_hrm-breadcrumb_hrm-br-a740d0"), __webpack_require__.e("default-src_app_directive_check-action_module_ts-node_modules_primeng_fesm2020_primeng-splitter_mjs"), __webpack_require__.e("default-src_app_components_page-notify_store-notify_store-notify_module_ts"), __webpack_require__.e("default-src_app_components_page-notify_page-notify_module_ts"), __webpack_require__.e("default-src_app_common_grid-add_grid-add_module_ts-src_app_common_search-user-master_search-u-03fea6"), __webpack_require__.e("default-src_app_components_cai-dat-lich-hop_cai-dat-lich-hop_component_ts-src_app_components_-94ecdd"), __webpack_require__.e("src_app_pages_cai-dat_cai-dat_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../app/pages/cai-dat/cai-dat.module */ 54097)).then(m => m.CaiDatModule)
            },
            {
                path: 'gop-y',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_common_edit-detail_edit-detail_module_ts-src_app_common_hrm-breadcrumb_hrm-br-a740d0"), __webpack_require__.e("default-src_app_directive_check-action_module_ts-node_modules_primeng_fesm2020_primeng-splitter_mjs"), __webpack_require__.e("default-src_app_components_page-notify_store-notify_store-notify_module_ts"), __webpack_require__.e("default-src_app_components_page-notify_page-notify_module_ts"), __webpack_require__.e("default-src_app_common_grid-add_grid-add_module_ts-src_app_common_search-user-master_search-u-03fea6"), __webpack_require__.e("src_app_pages_gop-y_gop-y_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../app/pages/gop-y/gop-y.module */ 75443)).then(m => m.GopYModule)
            },
            {
                path: 'phan-quyen',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_common_edit-detail_edit-detail_module_ts-src_app_common_hrm-breadcrumb_hrm-br-a740d0"), __webpack_require__.e("default-src_app_directive_check-action_module_ts-node_modules_primeng_fesm2020_primeng-splitter_mjs"), __webpack_require__.e("default-src_app_components_page-notify_store-notify_store-notify_module_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2020_primeng-picklist_mjs"), __webpack_require__.e("default-src_app_components_page-notify_page-notify_module_ts"), __webpack_require__.e("src_app_pages_phan-quyen_phan-quyen_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../app/pages/phan-quyen/phan-quyen.module */ 5973)).then(m => m.PhanQuyenModule)
            },
            {
                path: 'luong-thue',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_common_edit-detail_edit-detail_module_ts-src_app_common_hrm-breadcrumb_hrm-br-a740d0"), __webpack_require__.e("default-src_app_directive_check-action_module_ts-node_modules_primeng_fesm2020_primeng-splitter_mjs"), __webpack_require__.e("default-src_app_components_page-notify_store-notify_store-notify_module_ts"), __webpack_require__.e("default-src_app_components_page-notify_page-notify_module_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2020_primeng-listbox_mjs"), __webpack_require__.e("default-src_app_common_grid-add_grid-add_module_ts-src_app_common_search-user-master_search-u-03fea6"), __webpack_require__.e("src_app_pages_luong-thue_luong-thue_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../app/pages/luong-thue/luong-thue.module */ 30772)).then(m => m.LuongThueModule)
            },
            {
                path: 'hoat-dong',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_common_edit-detail_edit-detail_module_ts-src_app_common_hrm-breadcrumb_hrm-br-a740d0"), __webpack_require__.e("default-src_app_common_form-filter_form-filter_component_ts"), __webpack_require__.e("default-src_app_components_bieu-mau_bieu-mau_component_ts-src_app_components_bieu-mau_loai-bi-2aadfb"), __webpack_require__.e("default-src_app_components_cai-dat-lich-hop_cai-dat-lich-hop_component_ts-src_app_components_-94ecdd"), __webpack_require__.e("src_app_pages_hoat-dong_hoat-dong_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../app/pages/hoat-dong/hoat-dong.module */ 49084)).then(m => m.HoatDongModule)
            },
            {
                path: 'bao-cao',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_common_edit-detail_edit-detail_module_ts-src_app_common_hrm-breadcrumb_hrm-br-a740d0"), __webpack_require__.e("default-src_app_directive_check-action_module_ts-node_modules_primeng_fesm2020_primeng-splitter_mjs"), __webpack_require__.e("default-src_app_components_page-notify_store-notify_store-notify_module_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2020_primeng-picklist_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2020_primeng-listbox_mjs"), __webpack_require__.e("default-src_app_common_upload-file_upload-file_module_ts-src_app_components_ns-ho-so-nhan-su_-cee1b8"), __webpack_require__.e("src_app_pages_bao-cao_bao-cao_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../app/pages/bao-cao/bao-cao.module */ 39619)).then(m => m.BaoCaoModule)
            },
            // {
            //   path: 'manager',
            //   loadChildren: () => import('../app/pages/quan-tri/quan-tri.module').then(m => m.QuanTriModule)
            // },
            // {
            //   path: 'partner',
            //   loadChildren: () => import('../app/pages/doi-tac/doi-tac.module').then(m => m.DoiTacModule)
            // },
            // {
            //   path: 'exchange',
            //   loadChildren: () => import('../app/pages/giao-dich/giao-dich.module').then(m => m.GiaoDichModule)
            // },
            // {
            //   path: 'product',
            //   loadChildren: () => import('../app/pages/hang-hoa/hang-hoa.module').then(m => m.HangHoaModule)
            // },
            // {
            //   path: 'user',
            //   loadChildren: () => import('../app/pages/nhan-vien/nhan-vien.module').then(m => m.NhanVienSieuThiModule)
            // },
            // {
            //   path: 'report',
            //   loadChildren: () => import('../app/pages/bao-cao/bao-cao.module').then(m => m.BaoCaoModule)
            // },
        ], canActivate: [_services_auth_guard_service__WEBPACK_IMPORTED_MODULE_0__.AuthGuardService]
    },
];
class AppRoutingModule {
}
AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); };
AppRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forRoot(appRoutes)], _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule] }); })();


/***/ }),

/***/ 2050:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/confirmdialog */ 71849);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/toast */ 31599);







class AppComponent {
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(); };
AppComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 9, vars: 4, consts: [[3, "zIndex"], ["header", "Th\u00F4ng b\u00E1o", "maskStyleClass", "confirm-top-zindex", "icon", "pi pi-exclamation-triangle", 3, "baseZIndex", "transitionOptions"], ["cd", ""], ["type", "button", "pButton", "", "icon", "pi pi-check", "label", "\u0110\u1ED3ng \u00FD", 3, "click"], ["type", "button", "pButton", "", "icon", "pi pi-times", "label", "H\u1EE7y b\u1ECF", 1, "p-button-secondary", "btn-cancel", 3, "click"], ["position", "top-right", 3, "baseZIndex"], ["position", "bottom-center", "key", "bc"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "ngx-spinner", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p-confirmDialog", 1, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "p-footer");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_Template_button_click_5_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1); const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](3); return _r0.accept(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_Template_button_click_6_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1); const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](3); return _r0.reject(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "p-toast", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "p-toast", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("zIndex", 9999999999999);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("baseZIndex", 999999999999)("transitionOptions", "0ms");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("baseZIndex", 999999999999);
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet, ngx_spinner__WEBPACK_IMPORTED_MODULE_2__.NgxSpinnerComponent, primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_3__.ConfirmDialog, primeng_api__WEBPACK_IMPORTED_MODULE_4__.Footer, primeng_button__WEBPACK_IMPORTED_MODULE_5__.ButtonDirective, primeng_toast__WEBPACK_IMPORTED_MODULE_6__.Toast], styles: ["[_nghost-%COMP%]  .button-bar .ui-button.ui-button-text-only .ui-button-text {\n  padding: 0.3em 1em;\n}\n\n[_nghost-%COMP%]  .p-multiselect {\n  width: 100%;\n}\n\n[_nghost-%COMP%]  .p-dropdown {\n  width: 100%;\n}\n\n[_nghost-%COMP%]  p-toolbar {\n  width: 100%;\n}\n\n[_nghost-%COMP%]  .p-autocomplete {\n  width: 100% !important;\n}\n\n[_nghost-%COMP%]  .p-autocomplete .p-autocomplete-multiple-container {\n  width: 100% !important;\n}\n\n[_nghost-%COMP%]  .confirm-top-zindex {\n  z-index: 9999999999999 !important;\n}\n\n[_nghost-%COMP%]  .confirm-top-zindex .p-confirm-dialog {\n  z-index: 9999999999999 !important;\n}\n\n  .ag-cell {\n  overflow: hidden !important;\n  text-overflow: ellipsis !important;\n  white-space: nowrap !important;\n}\n\n[_nghost-%COMP%]  .text-number .ag-cell-wrapper {\n  display: flex;\n  justify-content: flex-end;\n}\n\n[_nghost-%COMP%]  .text-center .ag-cell-wrapper {\n  justify-content: center;\n}\n\n[_nghost-%COMP%]  .p-autocomplete .p-autocomplete-input {\n  width: 100% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSxXQUFBO0FBQ0o7O0FBRUE7RUFDSSxXQUFBO0FBQ0o7O0FBQ0E7RUFDSSxXQUFBO0FBRUo7O0FBQUE7RUFDSSxzQkFBQTtBQUdKOztBQUZJO0VBQ1Esc0JBQUE7QUFJWjs7QUFEQTtFQUNJLGlDQUFBO0FBSUo7O0FBSEk7RUFDSSxpQ0FBQTtBQUtSOztBQU1BO0VBQ0UsMkJBQUE7RUFDQSxrQ0FBQTtFQUNBLDhCQUFBO0FBSEY7O0FBTUE7RUFDRyxhQUFBO0VBQ0EseUJBQUE7QUFISDs7QUFNQTtFQUNHLHVCQUFBO0FBSEg7O0FBTUE7RUFDSSxzQkFBQTtBQUhKIiwiZmlsZSI6ImFwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0OjpuZy1kZWVwIC5idXR0b24tYmFyIC51aS1idXR0b24udWktYnV0dG9uLXRleHQtb25seSAudWktYnV0dG9uLXRleHR7XHJcbiAgICBwYWRkaW5nOiAwLjNlbSAxZW1cclxufVxyXG5cclxuOmhvc3Q6Om5nLWRlZXAgLnAtbXVsdGlzZWxlY3R7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuOmhvc3Q6Om5nLWRlZXAgLnAtZHJvcGRvd257XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG46aG9zdDo6bmctZGVlcCBwLXRvb2xiYXJ7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG46aG9zdDo6bmctZGVlcCAucC1hdXRvY29tcGxldGUgIHtcclxuICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQgO1xyXG4gICAgLnAtYXV0b2NvbXBsZXRlLW11bHRpcGxlLWNvbnRhaW5lciB7XHJcbiAgICAgICAgICAgIHdpZHRoOjEwMCUgIWltcG9ydGFudCAgO1xyXG4gICAgfVxyXG59XHJcbjpob3N0OjpuZy1kZWVwIC5jb25maXJtLXRvcC16aW5kZXh7XHJcbiAgICB6LWluZGV4OiA5OTk5OTk5OTk5OTk5ICFpbXBvcnRhbnQ7XHJcbiAgICAucC1jb25maXJtLWRpYWxvZ3tcclxuICAgICAgICB6LWluZGV4OiA5OTk5OTk5OTk5OTk5ICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn1cclxuLy8gOmhvc3Q6Om5nLWRlZXAgLnAtdHJlZSB7XHJcbi8vICAgICBwYWRkaW5nOiAwICA7XHJcbi8vICAgICBtaW4taGVpZ2h0OiA1MDBweDtcclxuLy8gICAgIC5wLXRyZWUtd3JhcHBlcntcclxuLy8gICAgICAgICBoZWlnaHQ6IDY3MHB4O1xyXG4vLyAgICAgfVxyXG4vLyB9XHJcblxyXG46Om5nLWRlZXAgLmFnLWNlbGwge1xyXG4gIG92ZXJmbG93OiBoaWRkZW4gIWltcG9ydGFudDtcclxuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcyAhaW1wb3J0YW50O1xyXG4gIHdoaXRlLXNwYWNlOiBub3dyYXAgIWltcG9ydGFudDtcclxufVxyXG5cclxuOmhvc3Q6Om5nLWRlZXAgLnRleHQtbnVtYmVyIC5hZy1jZWxsLXdyYXBwZXIgICB7XHJcbiAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XHJcbn1cclxuXHJcbjpob3N0OjpuZy1kZWVwIC50ZXh0LWNlbnRlciAuYWctY2VsbC13cmFwcGVyICAge1xyXG4gICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuOmhvc3Q6Om5nLWRlZXAgLnAtYXV0b2NvbXBsZXRlIC5wLWF1dG9jb21wbGV0ZS1pbnB1dCB7XHJcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50IDtcclxufVxyXG5cclxuIl19 */"] });


/***/ }),

/***/ 34750:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var _shared_components_excel_excel_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./shared/components/excel/excel.module */ 51849);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @angular/platform-browser/animations */ 52650);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 83696);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared/shared.module */ 51382);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ 2050);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./services/auth.service */ 36636);
/* harmony import */ var _services_auth_guard_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./services/auth-guard.service */ 35583);
/* harmony import */ var _auth_callback_auth_callback_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./auth-callback/auth-callback.component */ 81536);
/* harmony import */ var _services_export_file_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services/export-file.service */ 20046);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var _sunshine_sunshine_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./sunshine/sunshine.component */ 82115);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @angular/common/http */ 83981);
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./services/api.service */ 67118);
/* harmony import */ var _services_firebase_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./services/firebase.service */ 24773);
/* harmony import */ var _services_notification_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./services/notification.service */ 48410);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @angular/platform-browser */ 86219);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _services_firebase_auth_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./services/firebase-auth.service */ 16889);
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @angular/fire */ 97445);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/environments/environment */ 18260);
/* harmony import */ var _angular_fire_storage__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @angular/fire/storage */ 29036);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @angular/fire/auth */ 49450);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @angular/fire/firestore */ 16681);
/* harmony import */ var _angular_fire_database__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! @angular/fire/database */ 885);
/* harmony import */ var _services_auth_interceptor__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./services/auth-interceptor */ 32176);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _utils_common_currency_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./utils/common/currency.module */ 87082);
/* harmony import */ var primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! primeng/confirmdialog */ 71849);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _services_api_core_apicore_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./services/api-core/apicore.service */ 51837);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! primeng/toast */ 31599);
/* harmony import */ var primeng_chart__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! primeng/chart */ 61909);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var _utils_common_number_renderer_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./utils/common/number-renderer.component */ 67438);
/* harmony import */ var _utils_common_text_editor_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./utils/common/text-editor.component */ 78560);
/* harmony import */ var _utils_common_checkbox_editor_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./utils/common/checkbox-editor.component */ 69558);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! primeng/splitbutton */ 71494);
/* harmony import */ var primeng_scrollpanel__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! primeng/scrollpanel */ 3628);
/* harmony import */ var primeng_tabmenu__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! primeng/tabmenu */ 72999);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! primeng/autocomplete */ 17611);
/* harmony import */ var _services_navbar_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./services/navbar.service */ 72856);
/* harmony import */ var _utils_common_customtooltip_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./utils/common/customtooltip.component */ 91469);
/* harmony import */ var _utils_common_tooltip_suggestion_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./utils/common/tooltip-suggestion.component */ 16868);
/* harmony import */ var _utils_common_dropdown_renderer_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./utils/common/dropdown-renderer.component */ 30958);
/* harmony import */ var _containers_default_layout__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./containers/default-layout */ 74089);
/* harmony import */ var _pages_home_home_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./pages/home/home.component */ 43049);
/* harmony import */ var primeng_card__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! primeng/card */ 33506);
/* harmony import */ var primeng_timeline__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! primeng/timeline */ 4679);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./common/list-grid-angular/list-grid-angular.module */ 8145);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! primeng/organizationchart */ 87051);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! primeng/multiselect */ 92487);
/* harmony import */ var _fullcalendar_angular__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(/*! @fullcalendar/angular */ 67200);
/* harmony import */ var _services_api_hrm_apihrmv2_service__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./services/api-hrm/apihrmv2.service */ 90579);
/* harmony import */ var _services_organize_info_service__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./services/organize-info.service */ 88585);
/* harmony import */ var _components_uni_not_found_uni_not_found_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./components/uni-not-found/uni-not-found.component */ 55386);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! primeng/dynamicdialog */ 56427);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/core */ 14001);































// 































const APP_CONTAINERS = [_containers_default_layout__WEBPACK_IMPORTED_MODULE_24__.DefaultLayoutComponent];
class AppModule {
}
AppModule.ɵfac = function AppModule_Factory(t) { return new (t || AppModule)(); };
AppModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_31__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__.AppComponent] });
AppModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_31__["ɵɵdefineInjector"]({ providers: [
        _services_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService,
        _services_auth_guard_service__WEBPACK_IMPORTED_MODULE_5__.AuthGuardService,
        _services_firebase_auth_service__WEBPACK_IMPORTED_MODULE_12__.FirebaseAuthService,
        _services_export_file_service__WEBPACK_IMPORTED_MODULE_7__.ExportFileService,
        _services_api_service__WEBPACK_IMPORTED_MODULE_9__.ApiService,
        _services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_26__.ApiHrmService,
        _services_navbar_service__WEBPACK_IMPORTED_MODULE_20__.NavbarService,
        _services_api_core_apicore_service__WEBPACK_IMPORTED_MODULE_16__.ApiCoreService,
        _services_firebase_service__WEBPACK_IMPORTED_MODULE_10__.FeedBaseService,
        _services_notification_service__WEBPACK_IMPORTED_MODULE_11__.NotificationService,
        primeng_api__WEBPACK_IMPORTED_MODULE_32__.ConfirmationService,
        primeng_api__WEBPACK_IMPORTED_MODULE_32__.MessageService,
        _services_organize_info_service__WEBPACK_IMPORTED_MODULE_29__.OrganizeInfoService,
        primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_33__.DialogService,
        _services_api_hrm_apihrmv2_service__WEBPACK_IMPORTED_MODULE_28__.ApiHrmV2Service,
        { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_34__.HTTP_INTERCEPTORS, useClass: _services_auth_interceptor__WEBPACK_IMPORTED_MODULE_14__.AuthInterceptor, multi: true },
    ], imports: [[
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_35__.BrowserAnimationsModule,
            _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule,
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_34__.HttpClientModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_36__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_36__.ReactiveFormsModule,
            _angular_fire__WEBPACK_IMPORTED_MODULE_37__.AngularFireModule.initializeApp(src_environments_environment__WEBPACK_IMPORTED_MODULE_13__.environment.firebase),
            _angular_fire_storage__WEBPACK_IMPORTED_MODULE_38__.AngularFireStorageModule,
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_39__.AngularFireAuthModule,
            _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_40__.AngularFirestoreModule,
            _angular_fire_database__WEBPACK_IMPORTED_MODULE_41__.AngularFireDatabaseModule,
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_42__.BrowserModule,
            primeng_button__WEBPACK_IMPORTED_MODULE_43__.ButtonModule,
            primeng_dialog__WEBPACK_IMPORTED_MODULE_44__.DialogModule,
            _utils_common_currency_module__WEBPACK_IMPORTED_MODULE_15__.CurrencyDirectiveModule,
            primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_45__.ConfirmDialogModule,
            primeng_splitbutton__WEBPACK_IMPORTED_MODULE_46__.SplitButtonModule,
            primeng_scrollpanel__WEBPACK_IMPORTED_MODULE_47__.ScrollPanelModule,
            ngx_spinner__WEBPACK_IMPORTED_MODULE_48__.NgxSpinnerModule,
            _common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_27__.ListGridAngularModule,
            primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_49__.BreadcrumbModule,
            primeng_organizationchart__WEBPACK_IMPORTED_MODULE_50__.OrganizationChartModule,
            primeng_multiselect__WEBPACK_IMPORTED_MODULE_51__.MultiSelectModule,
            // AgGridModule.withComponents([
            //     ButtonRendererComponent1,
            //     NumberCellRenderer,
            //     TextEditorComponent,
            //     CheckboxEditorComponent,
            //     CustomTooltipComponent,
            //     TooltipSuggestionComponent,
            //     DropdownRendererComponent,
            //   ]),
            _shared_components_excel_excel_module__WEBPACK_IMPORTED_MODULE_0__.ExcelModule,
            primeng_toast__WEBPACK_IMPORTED_MODULE_52__.ToastModule,
            primeng_chart__WEBPACK_IMPORTED_MODULE_53__.ChartModule,
            primeng_tabmenu__WEBPACK_IMPORTED_MODULE_54__.TabMenuModule,
            primeng_dropdown__WEBPACK_IMPORTED_MODULE_55__.DropdownModule,
            primeng_calendar__WEBPACK_IMPORTED_MODULE_56__.CalendarModule,
            primeng_autocomplete__WEBPACK_IMPORTED_MODULE_57__.AutoCompleteModule,
            primeng_card__WEBPACK_IMPORTED_MODULE_58__.CardModule,
            primeng_timeline__WEBPACK_IMPORTED_MODULE_59__.TimelineModule,
            _fullcalendar_angular__WEBPACK_IMPORTED_MODULE_60__.FullCalendarModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_31__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_3__.AppComponent, _containers_default_layout__WEBPACK_IMPORTED_MODULE_24__.DefaultLayoutComponent, _auth_callback_auth_callback_component__WEBPACK_IMPORTED_MODULE_6__.AuthCallbackComponent,
        _sunshine_sunshine_component__WEBPACK_IMPORTED_MODULE_8__.SunshineComponent,
        _pages_home_home_component__WEBPACK_IMPORTED_MODULE_25__.HomeComponent,
        _utils_common_number_renderer_component__WEBPACK_IMPORTED_MODULE_17__.NumberCellRenderer,
        _utils_common_text_editor_component__WEBPACK_IMPORTED_MODULE_18__.TextEditorComponent,
        _utils_common_checkbox_editor_component__WEBPACK_IMPORTED_MODULE_19__.CheckboxEditorComponent,
        _utils_common_customtooltip_component__WEBPACK_IMPORTED_MODULE_21__.CustomTooltipComponent,
        _utils_common_tooltip_suggestion_component__WEBPACK_IMPORTED_MODULE_22__.TooltipSuggestionComponent,
        _utils_common_dropdown_renderer_component__WEBPACK_IMPORTED_MODULE_23__.DropdownRendererComponent,
        _components_uni_not_found_uni_not_found_component__WEBPACK_IMPORTED_MODULE_30__.UniNotFoundComponent], imports: [_angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_35__.BrowserAnimationsModule,
        _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule,
        _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
        _angular_common_http__WEBPACK_IMPORTED_MODULE_34__.HttpClientModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_36__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_36__.ReactiveFormsModule, _angular_fire__WEBPACK_IMPORTED_MODULE_37__.AngularFireModule, _angular_fire_storage__WEBPACK_IMPORTED_MODULE_38__.AngularFireStorageModule,
        _angular_fire_auth__WEBPACK_IMPORTED_MODULE_39__.AngularFireAuthModule,
        _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_40__.AngularFirestoreModule,
        _angular_fire_database__WEBPACK_IMPORTED_MODULE_41__.AngularFireDatabaseModule,
        _angular_platform_browser__WEBPACK_IMPORTED_MODULE_42__.BrowserModule,
        primeng_button__WEBPACK_IMPORTED_MODULE_43__.ButtonModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_44__.DialogModule,
        _utils_common_currency_module__WEBPACK_IMPORTED_MODULE_15__.CurrencyDirectiveModule,
        primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_45__.ConfirmDialogModule,
        primeng_splitbutton__WEBPACK_IMPORTED_MODULE_46__.SplitButtonModule,
        primeng_scrollpanel__WEBPACK_IMPORTED_MODULE_47__.ScrollPanelModule,
        ngx_spinner__WEBPACK_IMPORTED_MODULE_48__.NgxSpinnerModule,
        _common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_27__.ListGridAngularModule,
        primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_49__.BreadcrumbModule,
        primeng_organizationchart__WEBPACK_IMPORTED_MODULE_50__.OrganizationChartModule,
        primeng_multiselect__WEBPACK_IMPORTED_MODULE_51__.MultiSelectModule,
        // AgGridModule.withComponents([
        //     ButtonRendererComponent1,
        //     NumberCellRenderer,
        //     TextEditorComponent,
        //     CheckboxEditorComponent,
        //     CustomTooltipComponent,
        //     TooltipSuggestionComponent,
        //     DropdownRendererComponent,
        //   ]),
        _shared_components_excel_excel_module__WEBPACK_IMPORTED_MODULE_0__.ExcelModule,
        primeng_toast__WEBPACK_IMPORTED_MODULE_52__.ToastModule,
        primeng_chart__WEBPACK_IMPORTED_MODULE_53__.ChartModule,
        primeng_tabmenu__WEBPACK_IMPORTED_MODULE_54__.TabMenuModule,
        primeng_dropdown__WEBPACK_IMPORTED_MODULE_55__.DropdownModule,
        primeng_calendar__WEBPACK_IMPORTED_MODULE_56__.CalendarModule,
        primeng_autocomplete__WEBPACK_IMPORTED_MODULE_57__.AutoCompleteModule,
        primeng_card__WEBPACK_IMPORTED_MODULE_58__.CardModule,
        primeng_timeline__WEBPACK_IMPORTED_MODULE_59__.TimelineModule,
        _fullcalendar_angular__WEBPACK_IMPORTED_MODULE_60__.FullCalendarModule] }); })();


/***/ }),

/***/ 81536:
/*!**********************************************************!*\
  !*** ./src/app/auth-callback/auth-callback.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthCallbackComponent": () => (/* binding */ AuthCallbackComponent)
/* harmony export */ });
/* harmony import */ var E_uni_frontend_uni_hrm_sunshineapp_vn_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ 62783);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/auth.service */ 36636);
/* harmony import */ var _services_firebase_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/firebase-auth.service */ 16889);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 18260);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 2014);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 83981);












class AuthCallbackComponent {
  constructor(authService, firebaseAuthService, router, http) {
    this.authService = authService;
    this.firebaseAuthService = firebaseAuthService;
    this.router = router;
    this.http = http;
  }

  ngOnInit() {
    var _this = this;

    return (0,E_uni_frontend_uni_hrm_sunshineapp_vn_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.authService.completeAuthentication(); // const token = this.authService.getAccessTokenValue();

      const returnUrl = localStorage.getItem('returnUrl');

      if (returnUrl) {
        _this.router.navigateByUrl(returnUrl);
      }
    })();
  }

  getCustomToken(token) {
    const url = `${_environments_environment__WEBPACK_IMPORTED_MODULE_3__.environment.cloudFunctionServer}/getCustomToken`;
    return this.http.post(url, {
      data: {
        access_token: token
      }
    }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)(response => response.result)).toPromise();
  }

}

AuthCallbackComponent.ɵfac = function AuthCallbackComponent_Factory(t) {
  return new (t || AuthCallbackComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_services_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_services_firebase_auth_service__WEBPACK_IMPORTED_MODULE_2__.FirebaseAuthService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient));
};

AuthCallbackComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: AuthCallbackComponent,
  selectors: [["app-auth-callback"]],
  decls: 1,
  vars: 0,
  template: function AuthCallbackComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "p");
    }
  },
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhdXRoLWNhbGxiYWNrLmNvbXBvbmVudC5jc3MifQ== */"]
});

/***/ }),

/***/ 68909:
/*!*************************************************************!*\
  !*** ./src/app/common/ag-component/avatarFull.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AvatarFullComponent": () => (/* binding */ AvatarFullComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_avatar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/avatar */ 72189);



const _c0 = function () { return { "display": "flex" }; };
function AvatarFullComponent_div_0_p_avatar_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "p-avatar", 3);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](3, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("image", ctx_r2.value ? ctx_r2.value : "");
} }
const _c1 = function () { return { "background-color": "#9c27b0", "color": "#ffffff" }; };
function AvatarFullComponent_div_0_p_avatar_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "p-avatar", 4);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](2, _c1));
} }
function AvatarFullComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, AvatarFullComponent_div_0_p_avatar_1_Template, 1, 4, "p-avatar", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, AvatarFullComponent_div_0_p_avatar_2_Template, 1, 3, "p-avatar", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.value);
} }
function AvatarFullComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "p-avatar", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](3, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("image", ctx_r1.value);
} }
class AvatarFullComponent {
    constructor() {
        this.isImage = true;
    }
    agInit(params) {
        this.value = params.value;
        if (params.data.hasOwnProperty('back_url') && params.data.hasOwnProperty('front_url')) {
            this.isImage = false;
        }
        else {
            this.isImage = true;
        }
    }
    ngOnInit() {
    }
}
AvatarFullComponent.ɵfac = function AvatarFullComponent_Factory(t) { return new (t || AvatarFullComponent)(); };
AvatarFullComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AvatarFullComponent, selectors: [["child-avatar"]], decls: 2, vars: 2, consts: [[4, "ngIf"], ["styleClass", "d-flex", "shape", "circle", 3, "image", "style", 4, "ngIf"], ["icon", "pi pi-user", "styleClass", "mr-2", "styleClass", "d-flex", "shape", "circle", 3, "style", 4, "ngIf"], ["styleClass", "d-flex", "shape", "circle", 3, "image"], ["icon", "pi pi-user", "styleClass", "mr-2", "styleClass", "d-flex", "shape", "circle"], ["size", "large", "styleClass", "d-flex", 3, "image"]], template: function AvatarFullComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, AvatarFullComponent_div_0_Template, 3, 2, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, AvatarFullComponent_div_1_Template, 2, 4, "div", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.isImage);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.isImage);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, primeng_avatar__WEBPACK_IMPORTED_MODULE_2__.Avatar], encapsulation: 2 });


/***/ }),

/***/ 23609:
/*!*****************************************************************************!*\
  !*** ./src/app/common/ag-component/button-renderermutibuttons.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ButtonAgGridComponent": () => (/* binding */ ButtonAgGridComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/menu */ 10543);



// import { ICellRendererParams, IAfterGuiAttachedParams } from 'ag-grid';
class ButtonAgGridComponent {
    constructor() {
        this.items = [];
        this.label = '';
    }
    agInit(params) {
        this.params = params;
        for (let index in this.params.buttons) {
            if (!this.params.buttons[index].hide) {
                const object = { label: this.params.buttons[index].label, icon: this.params.buttons[index].icon, key: this.params.buttons[index].key, command: ($event) => {
                        this.onClick($event, index);
                    } };
                this.items.push(object);
            }
        }
    }
    refresh(params) {
        return true;
    }
    onClick($event, idx) {
        if (this.params.buttons[idx].onClick instanceof Function) {
            // put anything into params u want pass into parents component
            const params = {
                event: $event,
                rowData: this.params.node.data,
                index: this.params.rowIndex
                // ...something
            };
            this.params.buttons[idx].onClick(params);
        }
    }
}
ButtonAgGridComponent.ɵfac = function ButtonAgGridComponent_Factory(t) { return new (t || ButtonAgGridComponent)(); };
ButtonAgGridComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ButtonAgGridComponent, selectors: [["app-button-renderer"]], decls: 3, vars: 5, consts: [["pButton", "", "pRipple", "", "type", "button", "icon", "pi pi-ellipsis-v", 1, "p-button-rounded", "p-button-text", 3, "click"], ["styleClass", "p-menu-buttons menu-agrid", 3, "showTransitionOptions", "hideTransitionOptions", "popup", "model", "appendTo"], ["menu", ""]], template: function ButtonAgGridComponent_Template(rf, ctx) { if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ButtonAgGridComponent_Template_button_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1); const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2); return _r0.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "p-menu", 1, 2);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("showTransitionOptions", "0ms")("hideTransitionOptions", "0ms")("popup", true)("model", ctx.items)("appendTo", "body");
    } }, directives: [primeng_button__WEBPACK_IMPORTED_MODULE_1__.ButtonDirective, primeng_menu__WEBPACK_IMPORTED_MODULE_2__.Menu], encapsulation: 2 });


/***/ }),

/***/ 73964:
/*!****************************************************************!*\
  !*** ./src/app/common/ag-component/customtooltip.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomTooltipComponent": () => (/* binding */ CustomTooltipComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);

function CustomTooltipComponent_span_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r0.data[ctx_r0.params.colDef == null ? null : ctx_r0.params.colDef.field], "");
} }
class CustomTooltipComponent {
    constructor() {
        this.data = null;
        this.isAmount = false;
        this.isHtml = false;
        this.color = '';
    }
    agInit(params) {
        var _a, _b;
        this.params = params;
        this.color = this.params.color || 'white';
        if (this.params.rowIndex === 0) {
            this.data = this.params.api.getDisplayedRowAtIndex(0).data;
            this.data.type = ((_a = this.params) === null || _a === void 0 ? void 0 : _a.type) || 'primary';
            this.pipeCheckTransform();
        }
        if (this.params.rowIndex) {
            this.data = this.params.api.getDisplayedRowAtIndex(this.params.rowIndex).data;
            this.data.type = ((_b = this.params) === null || _b === void 0 ? void 0 : _b.type) || 'primary';
            this.pipeCheckTransform();
        }
    }
    pipeCheckTransform() {
        if (this.params.colDef.field.indexOf('amount') > -1 || this.params.colDef.field.indexOf('price') > -1 ||
            this.params.colDef.field.indexOf('profit') > -1 || this.params.colDef.field.indexOf('revenue') > -1 || this.params.colDef.field.indexOf('promotion_by_value') > -1
            || this.params.colDef.field.indexOf('promotion_value') > -1) {
            this.isAmount = true;
        }
        else {
            this.isAmount = false;
            if (typeof (this.data[this.params.colDef.field]) === 'string' && this.data[this.params.colDef.field].indexOf('<span') > -1) {
                this.isHtml = true;
            }
            else {
                this.isHtml = false;
            }
        }
    }
}
CustomTooltipComponent.ɵfac = function CustomTooltipComponent_Factory(t) { return new (t || CustomTooltipComponent)(); };
CustomTooltipComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CustomTooltipComponent, selectors: [["tooltip-component"]], decls: 6, vars: 4, consts: [[1, "custom-tooltip"], [4, "ngIf"]], template: function CustomTooltipComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, CustomTooltipComponent_span_5_Template, 2, 1, "span", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("background-color", ctx.color);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.params.colDef == null ? null : ctx.params.colDef.headerName);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.data);
    } }, styles: ["[_nghost-%COMP%] {\n  position: absolute;\n  width: 150px;\n  height: 70px;\n  pointer-events: none;\n  transition: opacity 1s;\n}\n\n.ag-tooltip-hiding[_nghost-%COMP%] {\n  opacity: 0;\n}\n\n.custom-tooltip[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 5px;\n  padding-bottom: 5px;\n}\n\n.custom-tooltip[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]:first-of-type {\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbXRvb2x0aXAuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNNO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBQ0Esc0JBQUE7QUFBUjs7QUFHTTtFQUNFLFVBQUE7QUFBUjs7QUFJTTtFQUNFLFdBQUE7RUFDQSxtQkFBQTtBQURSOztBQUtNO0VBQ0UsaUJBQUE7QUFGUiIsImZpbGUiOiJjdXN0b210b29sdGlwLmNvbXBvbmVudC50cyIsInNvdXJjZXNDb250ZW50IjpbIlxuICAgICAgOmhvc3Qge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHdpZHRoOiAxNTBweDtcbiAgICAgICAgaGVpZ2h0OiA3MHB4O1xuICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgdHJhbnNpdGlvbjogb3BhY2l0eSAxcztcbiAgICAgIH1cblxuICAgICAgOmhvc3QuYWctdG9vbHRpcC1oaWRpbmcge1xuICAgICAgICBvcGFjaXR5OiAwO1xuXG4gICAgICB9XG5cbiAgICAgIC5jdXN0b20tdG9vbHRpcCBwIHtcbiAgICAgICAgbWFyZ2luOiA1cHg7XG4gICAgICAgIHBhZGRpbmctYm90dG9tOiA1cHhcblxuICAgICAgfVxuXG4gICAgICAuY3VzdG9tLXRvb2x0aXAgcDpmaXJzdC1vZi10eXBlIHtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICB9XG4gICAgIl19 */"] });


/***/ }),

/***/ 93555:
/*!*************************************************************************!*\
  !*** ./src/app/common/list-grid-angular/list-grid-angular.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListGridAngularComponent": () => (/* binding */ ListGridAngularComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var _ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../ag-component/customtooltip.component */ 73964);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var _ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component */ 75137);
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/api.service */ 67118);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ag-grid-community/angular */ 11775);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/button */ 62150);



















function ListGridAngularComponent_p_button_0_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "p-button", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ListGridAngularComponent_p_button_0_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r2.addRow(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} }
class ListGridAngularComponent {
    constructor(activatedRoute, apiService, spinner, messageService) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_2__.AllModules;
        this.listsData = [];
        this.FnClick = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter();
        this.rowDoubleClicked = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter();
        this.firstDataRendered = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter();
        this.cellDoubleClicked = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter();
        this.onCellClicked = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter();
        this.callback = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter();
        this.showConfig = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter();
        this.columnDefs = [];
        this.rowSelection = 'single';
        this.frameworkComponents = {};
        this.noRowsTemplate = 'Không có kết quả phù hợp';
        this.pinnedTopRowData = [];
        this.floatingFilter = false;
        this.buttons = [];
        this.isShowButton = false;
        this.title = '';
        this.idGrid = 'myGrid';
        this.typeConfig = 'myGrid';
        // autoHeight
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            suppressSorting: false,
            sortable: false,
            suppressSizeToFit: false,
            filter: '',
            rowHeight: 90,
            cellClass: [],
            tooltipComponentParams: { color: '#ececec' },
        };
        this.domLayout = '';
        this.height = 0;
        this.heightRow = 45;
        this.headerHeight = 38;
        this.floatingFiltersHeight = 36;
        this.getContextMenuItems = null;
        this.excelStyles = [
            {
                id: 'stringType',
                dataType: 'string'
            },
            {
                id: 'dateFormat',
                dataType: 'dateTime',
                numberFormat: { format: 'mm/dd/yyyy;@' },
            },
            {
                id: 'text-right',
                dataType: 'number',
                numberFormat: { format: '#,##0' },
            }
        ];
        this.groupDefaultExpanded = 0;
        this.heightAuto = 0;
        this.tooltipShowDelay = 0;
        this.titlePage = '';
        this.listsDataCloone = [];
        this.dataChange = null;
        this.isChange = false;
        this.displaySetting = false;
        this.getMainMenuItems = (params) => {
            let athleteMenuItems = params.defaultItems.slice(0);
            athleteMenuItems = [{
                    name: 'Cấu hình',
                    icon: "<span class='pi pi-cog'></span>",
                    action: (event) => {
                        this.showConfig.emit();
                    },
                }, ...athleteMenuItems];
            return athleteMenuItems;
        };
        this.isRowSelectable = (rowNode) => {
            return rowNode.data.tontai ? false : true;
        };
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.excelExportParams = {
            fileName: this.titlePage ? this.titlePage : 'export',
            processCellCallback: params => {
                console.log(params);
                if (params.node.data) {
                    params.node.data.isContacted = params.node.data.isContacted ? params.node.data.isContacted.split('</span>').shift().split('ml5\">').pop() : '';
                    params.node.data.isProfileFull = params.node.data.isProfileFul ? params.node.data.isProfileFull.split('</span>').shift().split('ml5\">').pop() : '';
                    params.node.data.lockName = params.node.data.isProfileFul ? params.node.data.lockName.split('</span>').shift().split('ml5\">').pop() : '';
                    params.node.data.status_name = params.node.data.isProfileFul ? params.node.data.status_name.split('</span>').shift().split('ml5\">').pop() : '';
                }
                return params.value;
            }
        };
        this.csvExportParams = {
            fileName: this.titlePage ? this.titlePage : 'export'
        };
        this.isRowMaster = (dataItem) => {
            if (dataItem) {
                if (dataItem.Details) {
                    return dataItem && dataItem.Details ? dataItem.Details.length > 0 : false;
                }
                else if (dataItem.orderDetails) {
                    return dataItem && dataItem.orderDetails ? dataItem.orderDetails.length > 0 : false;
                }
                else if (dataItem.details) {
                    return dataItem && dataItem.details ? dataItem.details.length > 0 : false;
                }
                else if (dataItem.submenus) {
                    return dataItem && dataItem.submenus ? dataItem.submenus.length > 0 : false;
                }
                else if (dataItem.stockDiaryDetails) {
                    return dataItem && dataItem.stockDiaryDetails ? dataItem.stockDiaryDetails.length > 0 : false;
                }
                else if (dataItem.contractFiles) {
                    return dataItem && dataItem.contractFiles ? dataItem.contractFiles.length > 0 : false;
                }
                else {
                    return false;
                }
            }
            else {
                return false;
            }
        };
        this.frameworkComponents = {
            customTooltip: _ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__.CustomTooltipComponent,
            buttonAgGridComponent: _ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_0__.ButtonAgGridComponent,
            avatarRendererFull: _ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__.AvatarFullComponent,
            buttonRendererComponent: src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_4__.ButtonRendererComponent
        };
        this.tooltipShowDelay = 0;
        this.getRowHeight = (params) => {
            if (params.node.master || params.node.level === 0) {
                return this.heightRow;
            }
            else {
            }
        };
        this.sideBar = {
            toolPanels: [
                {
                    id: 'columns',
                    labelDefault: 'Ẩn hiện cột',
                    labelKey: 'columns',
                    iconKey: 'columns',
                    toolPanel: 'agColumnsToolPanel',
                    toolPanelParams: {
                        suppressRowGroups: false,
                        suppressValues: false,
                        suppressPivots: true,
                        suppressPivotMode: true,
                        suppressColumnFilter: true,
                        suppressColumnSelectAll: true,
                        suppressColumnExpandAll: true,
                        suppressSyncLayoutWithGrid: true,
                        suppressColumnMove: false,
                    },
                },
            ],
            defaultToolPanel: '',
        };
    }
    ;
    RowDoubleClicked(event) {
        this.rowDoubleClicked.emit(event);
    }
    onFirstDataRendered(event) {
        this.firstDataRendered.emit(event);
    }
    CellDoubleClicked(event) {
        this.cellDoubleClicked.emit(event);
    }
    CellClicked(event) {
        this.onCellClicked.emit(event);
    }
    ngOnInit() {
        this.listsDataCloone = (0,lodash__WEBPACK_IMPORTED_MODULE_6__.cloneDeep)(this.listsData);
        var pivotModeOn = document.getElementById(`${this.idGrid}`);
        pivotModeOn === null || pivotModeOn === void 0 ? void 0 : pivotModeOn.addEventListener('change', (event) => {
            if (event.target.ariaLabel === 'Press SPACE to toggle visibility (visible)' || event.target.ariaLabel === 'Press SPACE to toggle visibility (hidden)') {
                let allColumnIds = [];
                this.gridColumnApi.getAllColumns()
                    .forEach((column) => {
                    if (column.colDef.cellClass.indexOf('no-auto') < 0) {
                        allColumnIds.push(column);
                    }
                    else {
                        column.colDef.resizable = false;
                    }
                });
                this.gridColumnApi.autoSizeColumns(allColumnIds, false);
                this.autoSizeAll();
            }
            else if (event.target.ariaLabel === 'Press Space to toggle row selection (checked)'
                || event.target.ariaLabel === 'Press Space to toggle row selection (unchecked)'
                || event.target.ariaLabel === 'Press Space to toggle all rows selection (checked)'
                || event.target.ariaLabel === 'Press Space to toggle all rows selection (unchecked)') {
            }
        });
    }
    onRowSelected(event) {
        if (!event.node.isSelected() && this.isChange) {
            this.dataChange = event.data;
            if (this.typeConfig === 'FormInfo') {
                this.callApiForm();
            }
            else {
                this.callApi();
            }
        }
        this.callback.emit(this.gridApi.getSelectedRows());
    }
    // xem lại
    callApiForm() {
        if (this.listsDataCloone.map(d => d.field_name).indexOf(this.dataChange.field_name) < 0) {
            for (let key in this.dataChange) {
                if (key === 'isSpecial' || key === 'isRequire' || key === 'isDisable' || key === 'isVisiable' || key === 'hideInApp' || key === 'isChange' || key === 'isEmpty') {
                    this.dataChange[key] = this.dataChange[key] == 1 || this.dataChange[key] == true ? true : false;
                }
            }
            this.setGridViewInfo();
        }
        else {
            let items = this.listsData.filter(d => d.field_name === this.dataChange.field_name);
            if (items.length > 1) {
                let index = this.listsData.findIndex(d => d.id === this.dataChange.id);
                this.listsData.splice(index, 1);
                this.listsData = [...this.listsData];
                this.dataChange = null;
                this.isChange = false;
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: "Đã tồn tại tên trường !" });
            }
            else {
                for (let key in this.dataChange) {
                    if (key === 'isSpecial' || key === 'isRequire' || key === 'isDisable' || key === 'isVisiable' || key === 'hideInApp' || key === 'isChange' || key === 'isEmpty') {
                        this.dataChange[key] = this.dataChange[key] == 1 || this.dataChange[key] == true ? true : false;
                    }
                }
                this.setGridViewInfo();
            }
        }
    }
    callApi() {
        if (this.listsDataCloone.map(d => d.columnField).indexOf(this.dataChange.columnField) < 0) {
            for (let key in this.dataChange) {
                if (key === 'isUsed' || key === 'isHide' || key === 'isFilter' || key === 'isMasterDetail' || key === 'isStatusLable') {
                    this.dataChange[key] = this.dataChange[key] == 1 || this.dataChange[key] == true ? true : false;
                }
            }
            this.setGridViewInfo();
        }
        else {
            let items = this.listsData.filter(d => d.columnField === this.dataChange.columnField);
            if (items.length > 1) {
                let index = this.listsData.findIndex(d => d.id === this.dataChange.id);
                this.listsData.splice(index, 1);
                this.listsData = [...this.listsData];
                this.dataChange = null;
                this.isChange = false;
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: "Đã tồn tại tên trường !" });
            }
            else {
                for (let key in this.dataChange) {
                    if (key === 'isUsed' || key === 'isHide' || key === 'isFilter' || key === 'isMasterDetail' || key === 'isStatusLable') {
                        this.dataChange[key] = this.dataChange[key] == 1 || this.dataChange[key] == true ? true : false;
                    }
                }
                this.setGridViewInfo();
            }
        }
    }
    setGridViewInfo() {
        this.spinner.show();
        this.apiService.setGridViewInfo(this.typeConfig === 'FormInfo' ? 'SetFormViewInfo' : 'SetGridViewInfo', this.dataChange).subscribe(results => {
            if (results.status === 'success') {
                this.listsDataCloone = [];
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Cập nhật thành công' });
                this.isChange = false;
                this.listsData = [...this.listsData];
                this.listsDataCloone = (0,lodash__WEBPACK_IMPORTED_MODULE_6__.cloneDeep)(this.listsData);
                this.dataChange = null;
                // this.doubleClicked.emit()
                this.spinner.hide();
            }
            else {
                setTimeout(() => {
                    let index = this.listsData.findIndex(d => d.id === this.dataChange.id);
                    this.gridApi.setFocusedCell(index, 'columnCaption');
                    this.gridApi.startEditingCell({
                        rowIndex: index,
                        colKey: 'columnCaption',
                    });
                    this.dataChange = null;
                }, 500);
                this.spinner.hide();
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    onCellValueChanged(event) {
        console.log(event);
        console.log(event.value != event.oldValue);
        if (event.value != event.oldValue) {
            this.isChange = true;
        }
        else {
            this.isChange = false;
        }
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        let allColumnIds = [];
        this.gridColumnApi.getAllColumns()
            .forEach((column) => {
            if (column && column.colDef.cellClass && column.colDef.cellClass.length > 0 && column.colDef.cellClass.indexOf('no-auto') < 0) {
                allColumnIds.push(column);
            }
            else {
                column.colDef.resizable = false;
            }
        });
        this.gridColumnApi.autoSizeColumns(allColumnIds, false);
    }
    ngOnChanges() {
        // this.heightAuto = this.listsData.length > 0 ? 50 + (this.listsData.length === 1 ? 80 : 60 * this.listsData.length) : 100;
        this.heightAuto = this.height;
        // this.heightAuto = this.heightAuto < 660 ? this.heightAuto : 660
    }
    sizeToFit() {
        if (this.gridApi) {
            let allColumnIds = [];
            this.gridColumnApi.getAllColumns()
                .forEach((column) => {
                if (column.colDef.cellClass.indexOf('no-auto') < 0) {
                    allColumnIds.push(column);
                }
                else {
                    column.colDef.suppressSizeToFit = true;
                    allColumnIds.push(column);
                }
            });
            this.gridApi.sizeColumnsToFit(allColumnIds);
        }
    }
    getDataAsExcel(event) {
        console.log(event);
    }
    autoSizeAll() {
        if (this.gridColumnApi) {
            if (this.gridColumnApi.columnModel.scrollWidth > this.gridColumnApi.columnModel.bodyWidth) {
                this.sizeToFit();
            }
            else {
                let allColumnIds = [];
                this.gridColumnApi.getAllColumns()
                    .forEach((column) => {
                    if (column.colDef.cellClass.indexOf('no-auto') < 0) {
                        allColumnIds.push(column);
                    }
                    else {
                        column.colDef.resizable = false;
                    }
                });
                this.gridColumnApi.autoSizeColumns(allColumnIds, false);
            }
        }
    }
    OnClick(event) {
        this.FnClick.emit(event);
    }
    create(label) {
        this.callback.emit(label);
    }
    cellClicked(event) {
        if (event.colDef.field === 'meta_file_name') {
            this.downloadButtonClicked(event.data.meta_file_url);
        }
    }
    downloadButtonClicked(urlLink) {
        var url = urlLink;
        var elem = document.createElement('a');
        elem.href = url;
        elem.target = 'hiddenIframe';
        elem.click();
    }
    handleScroll(event) {
        if (this.gridColumnApi) {
            let allColumnIds = [];
            this.gridColumnApi.getAllColumns()
                .forEach((column) => {
                if (column.colDef.cellClass.indexOf('no-auto') < 0) {
                    allColumnIds.push(column);
                }
                else {
                    column.colDef.resizable = false;
                }
            });
            this.gridColumnApi.autoSizeColumns(allColumnIds, false);
            const grid = document.getElementById(`${this.idGrid}`);
            if (grid) {
                if ((event.left === 0) || (event.left > 200 && event.left < 220)
                    || (event.left > 400 && event.left < 420)
                    || (event.left > 600 && event.left < 620)
                    || (event.left > 800 && event.left < 820)
                    || (event.left > 1200)) {
                    const gridBody = grid.querySelector('.ag-body-viewport');
                    this.autoSizeAll();
                }
            }
        }
    }
    addRow() {
    }
}
ListGridAngularComponent.ɵfac = function ListGridAngularComponent_Factory(t) { return new (t || ListGridAngularComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_api_service__WEBPACK_IMPORTED_MODULE_5__.ApiService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_9__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.MessageService)); };
ListGridAngularComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({ type: ListGridAngularComponent, selectors: [["app-list-grid-angular"]], inputs: { listsData: "listsData", columnDefs: "columnDefs", rowSelection: "rowSelection", frameworkComponents: "frameworkComponents", detailCellRendererParams: "detailCellRendererParams", rowClassRules: "rowClassRules", noRowsTemplate: "noRowsTemplate", pinnedTopRowData: "pinnedTopRowData", floatingFilter: "floatingFilter", buttons: "buttons", isShowButton: "isShowButton", title: "title", idGrid: "idGrid", typeConfig: "typeConfig", defaultColDef: "defaultColDef", domLayout: "domLayout", height: "height", heightRow: "heightRow", headerHeight: "headerHeight", floatingFiltersHeight: "floatingFiltersHeight", getContextMenuItems: "getContextMenuItems", excelStyles: "excelStyles" }, outputs: { FnClick: "FnClick", rowDoubleClicked: "rowDoubleClicked", firstDataRendered: "firstDataRendered", cellDoubleClicked: "cellDoubleClicked", onCellClicked: "onCellClicked", callback: "callback", showConfig: "showConfig" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵNgOnChangesFeature"]], decls: 4, vars: 38, consts: [["label", "Add row", "styleClass", "p-button-sm add-a-row", 3, "click", 4, "ngIf"], [1, "section"], [1, "ag-theme-material", 2, "width", "100%", 3, "excelStyles", "getContextMenuItems", "id", "pinnedTopRowData", "domLayout", "defaultExcelExportParams", "defaultCsvExportParams", "rowData", "columnDefs", "skipHeaderOnAutoSize", "headerHeight", "floatingFiltersHeight", "floatingFilter", "isRowMaster", "groupDefaultExpanded", "masterDetail", "stopEditingWhenCellsLoseFocus", "modules", "groupDisplayType", "rowClassRules", "overlayNoRowsTemplate", "detailCellRendererParams", "tooltipShowDelay", "rowSelection", "defaultColDef", "enableCellTextSelection", "suppressCopyRowsToClipboard", "enableRangeSelection", "groupUseEntireRow", "getRowHeight", "accentedSort", "isRowSelectable", "getMainMenuItems", "frameworkComponents", "bodyScroll", "gridReady", "rowDoubleClicked", "cellDoubleClicked", "rowSelected", "cellValueChanged", "cellClicked", "firstDataRendered"], ["agGrid", ""], ["label", "Add row", "styleClass", "p-button-sm add-a-row", 3, "click"]], template: function ListGridAngularComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](0, ListGridAngularComponent_p_button_0_Template, 1, 0, "p-button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "ag-grid-angular", 2, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("bodyScroll", function ListGridAngularComponent_Template_ag_grid_angular_bodyScroll_2_listener($event) { return ctx.handleScroll($event); })("gridReady", function ListGridAngularComponent_Template_ag_grid_angular_gridReady_2_listener($event) { return ctx.onGridReady($event); })("rowDoubleClicked", function ListGridAngularComponent_Template_ag_grid_angular_rowDoubleClicked_2_listener($event) { return ctx.RowDoubleClicked($event); })("cellDoubleClicked", function ListGridAngularComponent_Template_ag_grid_angular_cellDoubleClicked_2_listener($event) { return ctx.CellDoubleClicked($event); })("rowSelected", function ListGridAngularComponent_Template_ag_grid_angular_rowSelected_2_listener($event) { return ctx.onRowSelected($event); })("cellValueChanged", function ListGridAngularComponent_Template_ag_grid_angular_cellValueChanged_2_listener($event) { return ctx.onCellValueChanged($event); })("cellClicked", function ListGridAngularComponent_Template_ag_grid_angular_cellClicked_2_listener($event) { return ctx.CellClicked($event); })("firstDataRendered", function ListGridAngularComponent_Template_ag_grid_angular_firstDataRendered_2_listener($event) { return ctx.onFirstDataRendered($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.isShowButton);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleProp"]("height", ctx.domLayout === "" ? ctx.height + "px" : "");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("id", ctx.idGrid);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("excelStyles", ctx.excelStyles)("getContextMenuItems", ctx.getContextMenuItems)("pinnedTopRowData", ctx.pinnedTopRowData)("domLayout", ctx.domLayout)("defaultExcelExportParams", ctx.excelExportParams)("defaultCsvExportParams", ctx.csvExportParams)("rowData", ctx.listsData)("columnDefs", ctx.columnDefs)("skipHeaderOnAutoSize", false)("headerHeight", ctx.headerHeight)("floatingFiltersHeight", ctx.floatingFiltersHeight)("floatingFilter", ctx.floatingFilter)("isRowMaster", ctx.isRowMaster)("groupDefaultExpanded", ctx.groupDefaultExpanded)("masterDetail", true)("stopEditingWhenCellsLoseFocus", true)("modules", ctx.modules)("groupDisplayType", "groupRows")("rowClassRules", ctx.rowClassRules)("overlayNoRowsTemplate", ctx.noRowsTemplate)("detailCellRendererParams", ctx.detailCellRendererParams)("tooltipShowDelay", ctx.tooltipShowDelay)("rowSelection", ctx.rowSelection)("defaultColDef", ctx.defaultColDef)("enableCellTextSelection", true)("suppressCopyRowsToClipboard", true)("groupDisplayType", "groupRows")("enableRangeSelection", true)("groupUseEntireRow", true)("getRowHeight", ctx.getRowHeight)("accentedSort", true)("isRowSelectable", ctx.isRowSelectable)("getMainMenuItems", ctx.getMainMenuItems)("frameworkComponents", ctx.frameworkComponents);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_12__.AgGridAngular, primeng_button__WEBPACK_IMPORTED_MODULE_13__.Button], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsaXN0LWdyaWQtYW5ndWxhci5jb21wb25lbnQuY3NzIn0= */"] });


/***/ }),

/***/ 8145:
/*!**********************************************************************!*\
  !*** ./src/app/common/list-grid-angular/list-grid-angular.module.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListGridAngularModule": () => (/* binding */ ListGridAngularModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var _list_grid_angular_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-grid-angular.component */ 93555);
/* harmony import */ var _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ag-grid-community/angular */ 11775);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);








class ListGridAngularModule {
}
ListGridAngularModule.ɵfac = function ListGridAngularModule_Factory(t) { return new (t || ListGridAngularModule)(); };
ListGridAngularModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: ListGridAngularModule });
ListGridAngularModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule,
            _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_5__.AgGridModule,
            primeng_button__WEBPACK_IMPORTED_MODULE_6__.ButtonModule,
            primeng_dialog__WEBPACK_IMPORTED_MODULE_7__.DialogModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](ListGridAngularModule, { declarations: [_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularComponent], imports: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule,
        _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_5__.AgGridModule,
        primeng_button__WEBPACK_IMPORTED_MODULE_6__.ButtonModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_7__.DialogModule], exports: [_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularComponent] }); })();


/***/ }),

/***/ 98552:
/*!*****************************************************!*\
  !*** ./src/app/common/pipe/currency-format.pipe.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CurrencyFormatPipe": () => (/* binding */ CurrencyFormatPipe)
/* harmony export */ });
/* harmony import */ var numeral__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! numeral */ 89714);
/* harmony import */ var numeral__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(numeral__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);


class CurrencyFormatPipe {
    transform(value) {
        return numeral__WEBPACK_IMPORTED_MODULE_0__(value).format('0,0[.][00]');
    }
}
CurrencyFormatPipe.ɵfac = function CurrencyFormatPipe_Factory(t) { return new (t || CurrencyFormatPipe)(); };
CurrencyFormatPipe.ɵpipe = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({ name: "currencyFormat", type: CurrencyFormatPipe, pure: true });


/***/ }),

/***/ 44093:
/*!*****************************************************!*\
  !*** ./src/app/common/pipe/currency-pipe.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CurrencyFormatPipeModule": () => (/* binding */ CurrencyFormatPipeModule)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _currency_format_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./currency-format.pipe */ 98552);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);





class CurrencyFormatPipeModule {
}
CurrencyFormatPipeModule.ɵfac = function CurrencyFormatPipeModule_Factory(t) { return new (t || CurrencyFormatPipeModule)(); };
CurrencyFormatPipeModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: CurrencyFormatPipeModule });
CurrencyFormatPipeModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule,
            // BrowserModule,
            // BrowserAnimationsModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](CurrencyFormatPipeModule, { declarations: [_currency_format_pipe__WEBPACK_IMPORTED_MODULE_0__.CurrencyFormatPipe], imports: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule], exports: [_currency_format_pipe__WEBPACK_IMPORTED_MODULE_0__.CurrencyFormatPipe] }); })();


/***/ }),

/***/ 55386:
/*!*********************************************************************!*\
  !*** ./src/app/components/uni-not-found/uni-not-found.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UniNotFoundComponent": () => (/* binding */ UniNotFoundComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);

class UniNotFoundComponent {
    constructor() {
        this.items = [];
    }
    ngOnInit() {
        this.items = [
            { label: '404' },
        ];
    }
}
UniNotFoundComponent.ɵfac = function UniNotFoundComponent_Factory(t) { return new (t || UniNotFoundComponent)(); };
UniNotFoundComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: UniNotFoundComponent, selectors: [["app-uni-not-found"]], decls: 4, vars: 0, consts: [[1, "main-grid"], [1, "logo-not-found", "text-center", 2, "padding-top", "100px"], [2, "font-size", "18px", "margin-top", "5px"]], template: function UniNotFoundComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, " Kh\u00F4ng c\u00F3 quy\u1EC1n truy c\u1EADp");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".logo-not-found[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]   path[_ngcontent-%COMP%] {\n  fill: #182850;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVuaS1ub3QtZm91bmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRVE7RUFDSSxhQUFBO0FBRFoiLCJmaWxlIjoidW5pLW5vdC1mb3VuZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2dvLW5vdC1mb3VuZHtcclxuICAgIHN2Z3tcclxuICAgICAgICBwYXRoe1xyXG4gICAgICAgICAgICBmaWxsOiAjMTgyODUwO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */"] });


/***/ }),

/***/ 86131:
/*!***********************************************************************!*\
  !*** ./src/app/containers/default-layout/default-layout.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefaultLayoutComponent": () => (/* binding */ DefaultLayoutComponent)
/* harmony export */ });
/* harmony import */ var src_app_theme_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/theme.service */ 59752);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _shared_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/navbar/navbar.component */ 31614);
/* harmony import */ var _shared_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/sidebar/sidebar.component */ 96263);







class DefaultLayoutComponent {
    constructor(router, themeService) {
        this.router = router;
        this.themeService = themeService;
        this.sidebarMinimized = false;
    }
    ngOnInit() {
    }
    changeTheme(theme) {
        this.themeService.switchTheme(theme);
    }
}
DefaultLayoutComponent.ɵfac = function DefaultLayoutComponent_Factory(t) { return new (t || DefaultLayoutComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_theme_service__WEBPACK_IMPORTED_MODULE_0__.ThemeService)); };
DefaultLayoutComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: DefaultLayoutComponent, selectors: [["app-dashboard"]], decls: 6, vars: 0, consts: [[1, "app-body"], [1, "header"], [1, "main"]], template: function DefaultLayoutComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "app-navbar");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](4, "app-sidebar");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](5, "router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    } }, directives: [_shared_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_1__.NavbarComponent, _shared_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_2__.SidebarComponent, _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterOutlet], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZWZhdWx0LWxheW91dC5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 74089:
/*!****************************************************!*\
  !*** ./src/app/containers/default-layout/index.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefaultLayoutComponent": () => (/* reexport safe */ _default_layout_component__WEBPACK_IMPORTED_MODULE_0__.DefaultLayoutComponent)
/* harmony export */ });
/* harmony import */ var _default_layout_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./default-layout.component */ 86131);



/***/ }),

/***/ 96068:
/*!*************************************!*\
  !*** ./src/app/containers/index.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefaultLayoutComponent": () => (/* reexport safe */ _default_layout__WEBPACK_IMPORTED_MODULE_0__.DefaultLayoutComponent)
/* harmony export */ });
/* harmony import */ var _default_layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./default-layout */ 74089);



/***/ }),

/***/ 43049:
/*!**********************************************!*\
  !*** ./src/app/pages/home/home.component.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeComponent": () => (/* binding */ HomeComponent)
/* harmony export */ });
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! chart.js */ 71871);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 53951);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/organizationchart */ 87051);


















function HomeComponent_ng_template_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r10.label);
} }
function HomeComponent_ng_template_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](car_r11.label);
} }
function HomeComponent_div_16_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "svg", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](5, "path", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "path", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "path", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "path", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "path", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](10, "path", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceHTML"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "div", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "h1");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](20, "Ng\u01B0\u1EDDi");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23, "-10% ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](25, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "p-dropdown", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function HomeComponent_div_16_Template_p_dropdown_ngModelChange_26_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r14); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r13.selectedMonth = $event; })("onChange", function HomeComponent_div_16_Template_p_dropdown_onChange_26_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r14); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r15.changeMonths($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const tongQuanNhanSu_r12 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](tongQuanNhanSu_r12 == null ? null : tongQuanNhanSu_r12.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](tongQuanNhanSu_r12 == null ? null : tongQuanNhanSu_r12.tongnv);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx_r2.selectedMonth)("options", ctx_r2.months);
} }
function HomeComponent_canvas_28_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "canvas", 65);
} }
function HomeComponent_canvas_41_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "canvas", 66);
} }
function HomeComponent_canvas_50_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "canvas", 67);
} }
function HomeComponent_canvas_70_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "canvas", 68);
} }
function HomeComponent_ng_template_76_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "img", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const node_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](node_r16.data.position ? node_r16.data.position : "No position");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("src", node_r16.data.avatarUrl ? node_r16.data.avatarUrl : "../../../../../assets/images/img_avatar.png", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](node_r16.data.full_name ? node_r16.data.full_name : "No name");
} }
function HomeComponent_ng_template_77_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](0);
} if (rf & 2) {
    const node_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", node_r17.label, " ");
} }
const _c0 = function () { return { width: "90vw" }; };
const _c1 = function () { return { "1024": "95vw", "640px": "100vw" }; };
// import { ChartsModule } from 'ng2-charts';
class HomeComponent {
    constructor(HomeService, route, apiService, spinner, router) {
        this.HomeService = HomeService;
        this.route = route;
        this.apiService = apiService;
        this.spinner = spinner;
        this.router = router;
        this.bodyClasses = 'skin-blue sidebar-mini';
        this.body = document.getElementsByTagName('body')[0];
        this.columnDefs = [];
        this.columnDefs1 = [];
        this.months = [];
        this.years = [];
        this.organs = [];
        // nsMoi: nhan su moi, 
        this.dashboardData = null;
        this.selectedMonth = { name: 'Tháng ' + (moment__WEBPACK_IMPORTED_MODULE_2__().month() + 1), code: (moment__WEBPACK_IMPORTED_MODULE_2__().month() + 1) };
        this.selectedYear = {
            name: 2022,
            code: 2022
        };
        this.queryDashboard = {
            orgid: "",
            months: (moment__WEBPACK_IMPORTED_MODULE_2__().month() + 1),
            years: 2022
        };
        this.currentYear = moment__WEBPACK_IMPORTED_MODULE_2__().year();
        this.bg = [
            '#4591FE',
            '#F0D042',
            '#FF7C59',
            '#DA100B',
            '#FFA384',
            '#36eb44',
            '#beeb36',
            '#eb3679',
            '#eb36d5',
            '#7c36eb',
            '#36daeb',
            '#36ebb9',
            '#36eb6e',
        ];
        // line chart
        this.chartOptions = {
            responsive: true
        };
        this.theOrginSelected = {};
        // line chart end
        // bar chart
        this.barChartOptions = {
            scaleShowVerticalLines: false,
            responsive: true
        };
        this.detailOrganizeMap = null;
        this.orgId = '';
        this.isHrDiagram = false;
    }
    ngOnInit() {
        this.columnDefs = [
            {
                headerName: 'Thời gian',
                cellClass: ['border-right'],
                field: 'date'
            },
            {
                headerName: 'Hoạt động',
                cellClass: ['border-right'],
                field: 'hoat_dong'
            }
        ];
        this.columnDefs1 = [
            {
                headerName: 'Tên khách hàng',
                cellClass: ['border-right'],
                field: 'tenKH'
            },
            {
                headerName: 'Nội Dung cần hỗ trợ',
                cellClass: ['border-right'],
                field: 'noiDung'
            }
        ];
        this.months = [
            { name: 'Tháng 1', code: 1 },
            { name: 'Tháng 2', code: 2 },
            { name: 'Tháng 3', code: 3 },
            { name: 'Tháng 4', code: 4 },
            { name: 'Tháng 5', code: 5 },
            { name: 'Tháng 6', code: 6 },
            { name: 'Tháng 7', code: 7 },
            { name: 'Tháng 8', code: 8 },
            { name: 'Tháng 9', code: 9 },
            { name: 'Tháng 10', code: 10 },
            { name: 'Tháng 11', code: 11 },
            { name: 'Tháng 12', code: 12 },
        ];
        this.getYears();
        this.getAgencyOrganizeMap();
        this.getOrgan();
    }
    ngOnDestroy() {
    }
    getOrgan() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_3__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.organs = results.data.map(d => {
                    return {
                        label: d.organizationName,
                        value: `${d.organizeId}`
                    };
                });
                this.organs = [...this.organs];
            }
        });
    }
    getOriginLabelByid() {
        this.theOrginSelected = this.organs.filter(d => d.value === this.queryDashboard.orgid);
    }
    onChartClick(event) {
        console.log(event, this.queryDashboard.orgid);
    }
    getYears() {
        let yearsTem = [];
        for (let i = 2000; i <= this.currentYear; i++) {
            yearsTem.push({ name: i, code: i });
        }
        this.years = yearsTem;
    }
    chartSlNhanSu() {
        let configs = {
            type: 'bar',
            canvasID: 'so-luong-nhan-su',
            options: {
                responsive: true,
                indexAxis: 'x',
                plugins: {
                    // htmlLegend: {
                    //   containerID: 'legend-so-luong-nhan-su',
                    // },
                    legend: {
                        display: false,
                    },
                },
            }
        };
        let labels = this.dashboardData.nhansuthang.map(month => {
            return month.months;
        });
        let value = this.dashboardData.nhansuthang.map(tongnv => {
            return tongnv.tongnv;
        });
        let datas = {
            labels: labels,
            datasets: [{
                    label: 'My First Dataset',
                    data: value,
                    backgroundColor: [
                        '#4591FE',
                    ],
                    borderWidth: 1,
                    cornerRadius: 20,
                    barThickness: 40,
                    borderRadius: 4,
                    borderSkipped: false,
                }]
        };
        this.drawChart(configs, datas);
    }
    chartBDNhanSu() {
        let configs = {
            type: 'line',
            canvasID: 'bien-dong-nhan-su',
            options: {
                responsive: true,
                // indexAxis: 'x',
                plugins: {
                    htmlLegend: {
                        containerID: 'legend-bien-dong-nhan-su',
                    },
                    legend: {
                        display: false,
                    },
                },
            }
        };
        let labelsNsIn = this.dashboardData.nhansu_in.map(month => {
            return month.months;
        });
        let valueNsIn = this.dashboardData.nhansu_in.map(tongnv => {
            return tongnv.tongnv;
        });
        let labelsNsOut = this.dashboardData.nhansu_out.map(month => {
            return month.months;
        });
        let valueNsOut = this.dashboardData.nhansu_out.map(tongnv => {
            return tongnv.tongnv;
        });
        let datas = {
            labels: labelsNsIn,
            datasets: [
                {
                    label: 'Tiếp nhận',
                    data: valueNsIn,
                    backgroundColor: [
                        '#1F8B24',
                    ],
                    borderWidth: 1,
                    cornerRadius: 20,
                    barThickness: 40,
                    borderRadius: 4,
                    borderSkipped: false,
                },
                {
                    label: 'Nghỉ việc',
                    data: valueNsOut,
                    backgroundColor: [
                        '#DA100B',
                    ],
                    borderWidth: 1,
                    cornerRadius: 20,
                    barThickness: 40,
                    borderRadius: 4,
                    borderSkipped: false,
                },
            ]
        };
        this.drawChart(configs, datas);
    }
    charDou() {
        let configs = {
            type: 'doughnut',
            canvasID: 'doughnut',
            options: {
                responsive: true,
                indexAxis: 'x',
                plugins: {
                    htmlLegend: {
                        containerID: 'legend-doughnut',
                    },
                    legend: {
                        display: false,
                    },
                },
            }
        };
        let labels = [];
        let bg = [];
        for (let i = 0; i < this.dashboardData.nhansu_hd.length; i++) {
            labels.push(this.dashboardData.nhansu_hd[i].name);
            bg.push(this.bg[i]);
        }
        ;
        let value = this.dashboardData.nhansu_hd.map(tongnv => {
            return tongnv.tongnv;
        });
        let datas = {
            labels: labels,
            datasets: [{
                    label: '',
                    data: value,
                    backgroundColor: bg,
                    borderWidth: 1,
                    cornerRadius: 20,
                    barThickness: 40,
                    borderRadius: 4,
                    borderSkipped: false,
                }]
        };
        this.drawChart(configs, datas);
    }
    charDou2() {
        let configs = {
            type: 'doughnut',
            canvasID: 'doughnut-2',
            options: {
                responsive: true,
                indexAxis: 'x',
                plugins: {
                    htmlLegend: {
                        containerID: 'legend-doughnut-2',
                    },
                    legend: {
                        display: false,
                    },
                },
            }
        };
        let labels = [];
        let bg = [];
        for (let i = 0; i < this.dashboardData.nhansu_sex.length; i++) {
            labels.push(this.dashboardData.nhansu_sex[i].name);
            bg.push(this.bg[i]);
        }
        ;
        let value = this.dashboardData.nhansu_sex.map(tongnv => {
            return tongnv.tongnv;
        });
        let datas = {
            labels: labels,
            datasets: [{
                    label: '',
                    data: value,
                    backgroundColor: bg,
                    borderWidth: 1,
                    cornerRadius: 20,
                    barThickness: 40,
                    borderRadius: 4,
                    borderSkipped: false,
                }]
        };
        this.drawChart(configs, datas);
    }
    load() { }
    /*
      configs: type, options(htmlLegend), canvasID
      data:
    */
    drawChart(configs, datas) {
        if (configs.canvasID) {
            setTimeout(() => {
                let ctx = document.getElementById(configs.canvasID);
                ctx = ctx.getContext('2d');
                let chart = new chart_js__WEBPACK_IMPORTED_MODULE_1__.Chart(ctx, {
                    type: configs.type,
                    data: datas,
                    options: configs.options,
                    plugins: [{
                            id: 'htmlLegend',
                            afterUpdate(chart, args, options) {
                                var _a;
                                if ((_a = configs.options.plugins.htmlLegend) === null || _a === void 0 ? void 0 : _a.containerID) {
                                    const legendContainer = document.getElementById(configs.options.plugins.htmlLegend.containerID);
                                    let listContainer = legendContainer.querySelector('ul');
                                    if (!listContainer) {
                                        listContainer = document.createElement('ul');
                                        listContainer.style.display = 'flex';
                                        listContainer.style.flexDirection = 'row';
                                        listContainer.style.margin = 0;
                                        listContainer.style.padding = 0;
                                        legendContainer.appendChild(listContainer);
                                    }
                                    const ul = listContainer;
                                    // Remove old legend items
                                    while (ul.firstChild) {
                                        ul.firstChild.remove();
                                    }
                                    const items = chart.options.plugins.legend.labels.generateLabels(chart);
                                    items.forEach((item) => {
                                        const li = document.createElement('li');
                                        const { type } = chart.config;
                                        li.onclick = () => {
                                            if (type === 'pie' || type === 'doughnut') {
                                                // Pie and doughnut charts only have a single dataset and visibility is per item
                                                chart.toggleDataVisibility(item.index);
                                            }
                                            else {
                                                chart.setDatasetVisibility(item.datasetIndex, !chart.isDatasetVisible(item.datasetIndex));
                                            }
                                            chart.update();
                                        };
                                        // Color box
                                        const boxSpan = document.createElement('span');
                                        boxSpan.style.background = item.fillStyle;
                                        // Text
                                        const textContainer = document.createElement('span');
                                        textContainer.style.textDecoration = item.hidden ? 'line-through' : '';
                                        let numberValue = '';
                                        if (type === 'pie' || type === 'doughnut') {
                                            if (chart.config.data.datasets.length === 1) {
                                                numberValue += ' (' + new Intl.NumberFormat().format(chart.config.data.datasets[0].data[item.index]) + ')';
                                            }
                                        }
                                        const text = document.createTextNode(item.text + numberValue);
                                        textContainer.appendChild(text);
                                        li.appendChild(boxSpan);
                                        li.appendChild(textContainer);
                                        ul.appendChild(li);
                                    });
                                }
                            }
                        }],
                });
                chart.update();
                // chart.destroy();
            }, 500);
        }
    }
    hrDiagram() {
        this.spinner.show();
        this.selectedNode = null;
        this.listAgencyMap = [];
        this.isHrDiagram = true;
        this.getAgencyOrganizeMap(true);
    }
    getAgencyOrganizeMap(type = false) {
        this.apiService.getAgencyOrganizeMap().subscribe(results => {
            if (results.status === 'success') {
                this.spinner.hide();
                this.listAgencyMap = [...results.data.root];
                if (localStorage.getItem("organize") === null) {
                    this.selectedNode = this.listAgencyMap[0];
                    this.detailOrganizeMap = this.selectedNode;
                    localStorage.setItem('organize', JSON.stringify(this.listAgencyMap[0]));
                    this.queryDashboard.orgid = this.selectedNode.orgId;
                    this.getOriginLabelByid();
                    // this.query.org_level = this.selectedNode.org_level;
                    this.load();
                }
                else {
                    this.selectedNode = JSON.parse(localStorage.getItem("organize"));
                    this.queryDashboard.orgid = this.selectedNode.orgId;
                    this.getOriginLabelByid();
                    // this.parseObjectProperties(this.listAgencyMap, this.selectedNode.organizeId);
                    this.detailOrganizeMap = this.selectedNode;
                    if (type) {
                        this.isHrDiagram = true;
                    }
                    this.load();
                }
                this.getDashboardInfo();
            }
        });
    }
    onNodeSelect(event) {
        this.detailOrganizeMap = event.node;
        this.isHrDiagram = false;
        this.queryDashboard.orgid = this.detailOrganizeMap.orgId;
        localStorage.setItem("organize", JSON.stringify(this.detailOrganizeMap));
        this.getDashboardInfo();
    }
    getDashboardInfo() {
        this.getOriginLabelByid();
        this.dashboardData = null;
        this.apiService.getDashboardInfo(this.queryDashboard)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.finalize)(() => this.spinner.hide()))
            .subscribe(results => {
            if (results.status === 'success') {
                this.dashboardData = results.data;
                this.chartSlNhanSu();
                this.chartBDNhanSu();
                this.charDou();
                this.charDou2();
            }
        });
    }
    // select month
    changeMonths(e) {
        this.queryDashboard.months = e.value.code;
        this.spinner.show();
        this.getDashboardInfo();
    }
    // select year
    changeYears(e) {
        this.queryDashboard.years = e.value.code;
        this.spinner.show();
        this.getDashboardInfo();
    }
}
HomeComponent.ɵfac = function HomeComponent_Factory(t) { return new (t || HomeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_0__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_0__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_7__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router)); };
HomeComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: HomeComponent, selectors: [["app-home"]], decls: 78, vars: 34, consts: [[1, "content-body"], [1, "grid"], [1, "col-12"], [1, "select-ori", "mr-2", "float-left"], [1, "name"], [1, "field-group", "select", "mb-0", "valid", 3, "ngClass"], ["panelStyleClass", "select-ori-panel", "placeholder", "Ch\u1ECDn t\u1ED5 ch\u1EE9c", "appendTo", "body", "name", "OrganizeId", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "dia", 3, "click"], ["width", "22", "height", "19", "viewBox", "0 0 22 19", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11 0C8.92893 0 7.25 1.67148 7.25 3.73335C7.25 5.54325 8.54366 7.05234 10.2606 7.39415V10.5496H4.49291C4.29682 10.5496 4.10876 10.6272 3.9701 10.7652C3.83144 10.9033 3.75354 11.0905 3.75354 11.2857V14.8684H1.23937C1.04328 14.8684 0.855215 14.946 0.716557 15.084C0.577898 15.2221 0.5 15.4093 0.5 15.6045V17.7639C0.5 17.9591 0.577898 18.1464 0.716557 18.2844C0.855215 18.4224 1.04328 18.5 1.23937 18.5C1.43546 18.5 1.62353 18.4224 1.76218 18.2844C1.90084 18.1464 1.97874 17.9591 1.97874 17.7639V16.3406H7.00709V17.7639C7.00709 17.9591 7.08498 18.1464 7.22364 18.2844C7.3623 18.4224 7.55036 18.5 7.74646 18.5C7.94255 18.5 8.13061 18.4224 8.26927 18.2844C8.40793 18.1464 8.48583 17.9591 8.48583 17.7639V15.6045C8.48583 15.4093 8.40793 15.2221 8.26927 15.084C8.13061 14.946 7.94255 14.8684 7.74646 14.8684H5.23229V12.0218H16.7677V14.8684H14.2535C14.0575 14.8684 13.8694 14.946 13.7307 15.084C13.5921 15.2221 13.5142 15.4093 13.5142 15.6045V17.7639C13.5142 17.9591 13.5921 18.1464 13.7307 18.2844C13.8694 18.4224 14.0575 18.5 14.2535 18.5C14.4496 18.5 14.6377 18.4224 14.7764 18.2844C14.915 18.1464 14.9929 17.9591 14.9929 17.7639V16.3406H20.0213V17.7639C20.0213 17.9591 20.0992 18.1464 20.2378 18.2844C20.3765 18.4224 20.5645 18.5 20.7606 18.5C20.9567 18.5 21.1448 18.4224 21.2834 18.2844C21.4221 18.1464 21.5 17.9591 21.5 17.7639V15.6045C21.5 15.4093 21.4221 15.2221 21.2834 15.084C21.1448 14.946 20.9567 14.8684 20.7606 14.8684H18.2465V11.2857C18.2465 11.0905 18.1686 10.9033 18.0299 10.7652C17.8912 10.6272 17.7032 10.5496 17.5071 10.5496H11.7394V7.39415C13.4563 7.05234 14.75 5.54325 14.75 3.73335C14.75 1.67148 13.0711 0 11 0Z", "fill", "#0979FD"], [1, "grid", "boxs"], [1, "col-9", "pr-0"], ["class", "col-3 pt-0", 4, "ngFor", "ngForOf"], [1, "chart-section"], [1, "d-flex", "bet"], [1, "des"], [1, "select-noborder", "d-flex", "bet", "middle"], [1, "mr-2"], ["name", "selectedYear", "optionLabel", "name", 3, "ngModel", "options", "ngModelChange", "onChange"], [1, "chart"], ["style", "max-height: 250px", "id", "so-luong-nhan-su", 4, "ngIf"], [1, "d-flex", "bet", "middle"], [1, "desc"], ["id", "legend-bien-dong-nhan-su", 1, "legend-default", "line"], [1, "d-flex", "center"], [1, "select-noborder"], ["optionLabel", "name", 3, "ngModel", "options", "ngModelChange", "onChange"], ["style", "max-height: 200px", "id", "bien-dong-nhan-su", 4, "ngIf"], [1, "col-3"], [1, "sidebar", "col-12", "pt-0", "pl-0"], [1, "box"], ["style", "max-width: 180px; margin: auto", "id", "doughnut", 4, "ngIf"], ["id", "legend-doughnut", 1, "legend-default", "dou"], [1, "icon"], ["width", "6", "height", "10", "viewBox", "0 0 6 10", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.259459 0.278481C0.54816 0.00352719 1.01624 0.00352719 1.30494 0.278481L5.74054 4.50286C6.02924 4.77781 6.02924 5.2236 5.74054 5.49856L1.30494 9.72293C1.01624 9.99789 0.54816 9.99789 0.259459 9.72293C-0.029243 9.44798 -0.029243 9.00219 0.259459 8.72724L4.17232 5.00071L0.259459 1.27418C-0.029243 0.999223 -0.029243 0.553435 0.259459 0.278481Z", "fill", "#99A2BC"], ["style", "max-width: 180px; margin: auto", "id", "doughnut-2", 4, "ngIf"], ["id", "legend-doughnut-2", 1, "legend-default", "dou"], ["styleClass", "hr-diagram", 3, "appendTo", "autoZIndex", "visible", "modal", "breakpoints", "visibleChange"], ["selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect"], ["mydiv", ""], ["pTemplate", "person"], ["pTemplate", "department"], [2, "vertical-align", "middle"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [1, "col-3", "pt-0"], [1, "card"], [1, "card-content"], [1, "icon", "d-flex", "middle", "center"], ["width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M8.414 7.02347C8.414 5.07744 10.0196 3.5 12 3.5C13.9804 3.5 15.586 5.07744 15.586 7.02347V7.92546C15.586 9.87149 13.9804 11.4489 12 11.4489C10.0196 11.4489 8.414 9.87149 8.414 7.92546V7.02347Z", "fill", "#FF7C59"], ["d", "M6.18961 13.2051C6.16381 13.2046 6.13793 13.2043 6.11198 13.2043H3.89606C2.02054 13.2043 0.5 14.6982 0.5 16.5411V17.412C0.5 18.293 1.22686 19.0071 2.12333 19.0071H4.50679V16.8126C4.50679 15.3702 5.15924 14.0781 6.18961 13.2051Z", "fill", "#FF7C59"], ["d", "M17.8104 13.2051C18.8408 14.0781 19.4932 15.3702 19.4932 16.8126V19.0071H21.8767C22.7731 19.0071 23.5 18.293 23.5 17.412V16.5411C23.5 14.6982 21.9795 13.2043 20.1039 13.2043H17.888C17.8621 13.2043 17.8362 13.2046 17.8104 13.2051Z", "fill", "#FF7C59"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M18.0362 19.0918V16.8126C18.0362 16.0106 17.7472 15.2746 17.2657 14.6998C16.6445 13.9582 15.703 13.4851 14.6483 13.4851H9.35166C7.47946 13.4851 5.9638 14.976 5.9638 16.8126V19.0918C6.20934 19.906 6.97642 20.5 7.88472 20.5H16.1153C17.0236 20.5 17.7907 19.906 18.0362 19.0918Z", "fill", "#FF7C59"], ["d", "M5.00402 6.20445C3.49565 6.20445 2.27274 7.4059 2.27274 8.88812V9.5724C2.27274 11.0546 3.49565 12.2561 5.00402 12.2561C6.5124 12.2561 7.73531 11.0546 7.73531 9.5724V8.88812C7.73531 7.4059 6.5124 6.20445 5.00402 6.20445Z", "fill", "#FF7C59"], ["d", "M16.2647 8.88812C16.2647 7.4059 17.4876 6.20445 18.996 6.20445C20.5044 6.20445 21.7273 7.4059 21.7273 8.88812V9.5724C21.7273 11.0546 20.5044 12.2561 18.996 12.2561C17.4876 12.2561 16.2647 11.0546 16.2647 9.5724V8.88812Z", "fill", "#FF7C59"], [1, "media", "align-items-stretch"], [1, "per-50", "d-flex", "bottom", "bet"], [1, "qan", "d-flex", "bet"], [1, ""], [1, "per"], [1, "the-month"], ["name", "selectedMonth", "optionLabel", "name", 3, "ngModel", "options", "ngModelChange", "onChange"], ["id", "so-luong-nhan-su", 2, "max-height", "250px"], ["id", "bien-dong-nhan-su", 2, "max-height", "200px"], ["id", "doughnut", 2, "max-width", "180px", "margin", "auto"], ["id", "doughnut-2", 2, "max-width", "180px", "margin", "auto"], [1, "node-header", "p-corner-top"], [1, "node-content"], ["width", "32", 3, "src"]], template: function HomeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "p-dropdown", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function HomeComponent_Template_p_dropdown_ngModelChange_7_listener($event) { return ctx.queryDashboard.orgid = $event; })("onChange", function HomeComponent_Template_p_dropdown_onChange_7_listener() { return ctx.getDashboardInfo(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, HomeComponent_ng_template_8_Template, 2, 1, "ng-template", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, HomeComponent_ng_template_9_Template, 3, 1, "ng-template", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function HomeComponent_Template_div_click_10_listener() { return ctx.hrDiagram(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](12, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](16, HomeComponent_div_16_Template, 27, 4, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22, "S\u1ED1 l\u01B0\u1EE3ng nh\u00E2n s\u1EF1 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "label", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](25, "N\u0103m");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "p-dropdown", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function HomeComponent_Template_p_dropdown_ngModelChange_26_listener($event) { return ctx.selectedYear = $event; })("onChange", function HomeComponent_Template_p_dropdown_onChange_26_listener($event) { return ctx.changeYears($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](28, HomeComponent_canvas_28_Template, 1, 0, "canvas", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](29, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](30, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](32, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](33, "Bi\u1EBFn \u0111\u1ED9ng nh\u00E2n s\u1EF1 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](34, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](35);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](36, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](37, "ul", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](38, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](39, "p-dropdown", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function HomeComponent_Template_p_dropdown_ngModelChange_39_listener($event) { return ctx.selectedYear = $event; })("onChange", function HomeComponent_Template_p_dropdown_onChange_39_listener($event) { return ctx.changeYears($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](40, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](41, HomeComponent_canvas_41_Template, 1, 0, "canvas", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](42, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](43, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](44, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](45, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](46, "Th\u1ED1ng k\u00EA h\u1EE3p \u0111\u1ED3ng theo lo\u1EA1i h\u1EE3p \u0111\u1ED3ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](47, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](48);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](49, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](50, HomeComponent_canvas_50_Template, 1, 0, "canvas", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](51, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](52, "ul");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](53, "ul");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](54, "li", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](55);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](56, "span", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](57, "svg", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](58, "path", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](59, "li", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](60);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](61, "span", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](62, "svg", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](63, "path", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](64, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](65, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](66, "Th\u1ED1ng k\u00EA h\u1EE3p \u0111\u1ED3ng theo lo\u1EA1i h\u1EE3p \u0111\u1ED3ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](67, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](68);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](69, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](70, HomeComponent_canvas_70_Template, 1, 0, "canvas", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](71, "div", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](72, "ul");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](73, "p-dialog", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function HomeComponent_Template_p_dialog_visibleChange_73_listener($event) { return ctx.isHrDiagram = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](74, "p-organizationChart", 41, 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("selectionChange", function HomeComponent_Template_p_organizationChart_selectionChange_74_listener($event) { return ctx.selectedNode = $event; })("onNodeSelect", function HomeComponent_Template_p_organizationChart_onNodeSelect_74_listener($event) { return ctx.onNodeSelect($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](76, HomeComponent_ng_template_76_Template, 6, 3, "ng-template", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](77, HomeComponent_ng_template_77_Template, 1, 1, "ng-template", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.organs)("ngModel", ctx.queryDashboard.orgid);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.dashboardData == null ? null : ctx.dashboardData.tongquan);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx.selectedYear)("options", ctx.years);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.dashboardData);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.selectedNode == null ? null : ctx.selectedNode.label);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx.selectedYear)("options", ctx.years);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.dashboardData);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate3"]("", ctx.theOrginSelected[0] == null ? null : ctx.theOrginSelected[0].label, " - \u0110\u1EBFn ng\u00E0y ", ctx.queryDashboard.months, "/", ctx.queryDashboard.years, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.dashboardData);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("H\u1EE3p \u0111\u1ED3ng s\u1EAFp h\u1EBFt h\u1EA1n: ", ctx.dashboardData == null ? null : ctx.dashboardData.hd_saphethan, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("H\u1EE3p \u0111\u1ED3ng qu\u00E1 h\u1EA1n: ", ctx.dashboardData == null ? null : ctx.dashboardData.hd_quahan, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate3"]("", ctx.theOrginSelected[0] == null ? null : ctx.theOrginSelected[0].label, " - \u0110\u1EBFn ng\u00E0y ", ctx.queryDashboard.months, "/", ctx.queryDashboard.years, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.dashboardData);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](32, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("appendTo", "body")("autoZIndex", true)("visible", ctx.isHrDiagram)("modal", true)("breakpoints", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](33, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", ctx.listAgencyMap)("preserveSpace", false)("selection", ctx.selectedNode);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgClass, primeng_dropdown__WEBPACK_IMPORTED_MODULE_9__.Dropdown, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgModel, primeng_api__WEBPACK_IMPORTED_MODULE_11__.PrimeTemplate, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, primeng_dialog__WEBPACK_IMPORTED_MODULE_12__.Dialog, primeng_organizationchart__WEBPACK_IMPORTED_MODULE_13__.OrganizationChart], styles: [".section[_ngcontent-%COMP%] {\n  border-radius: 4px;\n  padding-left: 24px;\n  padding-right: 24px;\n  padding-top: 20px;\n}\n.section[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 16px;\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n.section.activites[_ngcontent-%COMP%] {\n  margin-bottom: 15px;\n  padding-top: 15px;\n  padding-bottom: 16px;\n}\n.section.activites[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  margin-top: 0px;\n  margin-bottom: 15px;\n}\n.section.chart[_ngcontent-%COMP%] {\n  padding-left: 24px;\n  padding-right: 24px;\n  margin-bottom: 7px;\n}\n.section.chart[_ngcontent-%COMP%]   .the-chart[_ngcontent-%COMP%] {\n  padding-top: 30px;\n}\n.section.chart[_ngcontent-%COMP%]   .head[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n@media screen and (max-width: 767px) {\n  .section.chart[_ngcontent-%COMP%]   .head[_ngcontent-%COMP%] {\n    display: block;\n  }\n  .section.chart[_ngcontent-%COMP%]   .head[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n    margin-bottom: 20px;\n  }\n}\n.section[_ngcontent-%COMP%]   .time[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-end;\n}\n.section.document[_ngcontent-%COMP%] {\n  text-align: center;\n  padding-top: 16px;\n  padding-bottom: 16px;\n}\n.section.document[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  max-width: 100%;\n}\n.section.document[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  margin-top: 0px;\n  margin-bottom: 30px;\n}\n.section[_ngcontent-%COMP%]   .readmore[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 16px;\n  cursor: pointer;\n}\n.section[_ngcontent-%COMP%]   .line[_ngcontent-%COMP%] {\n  margin-top: 35px;\n  margin-bottom: 22px;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n}\n[_nghost-%COMP%]  .menu-timeline.menu-tab {\n  margin-right: 24px;\n}\n[_nghost-%COMP%]  .menu-timeline .p-tabmenu-nav {\n  background: none;\n}\n[_nghost-%COMP%]  .menu-timeline .p-tabmenu-nav li a {\n  background: none !important;\n  border: none !important;\n  padding: 4px 12px 6px !important;\n}\n[_nghost-%COMP%]  .menu-timeline .p-tabmenu-nav li a span {\n  font-size: 12px;\n  line-height: 16px;\n  font-weight: 500;\n}\n[_nghost-%COMP%]  .menu-timeline .p-tabmenu-nav li.p-tabmenu-ink-bar {\n  top: calc(100% - 1px) !important;\n  bottom: auto !important;\n}\n[_nghost-%COMP%]  .menu-timeline .p-dropdown {\n  border: none;\n  padding-left: 8px;\n}\n[_nghost-%COMP%]  .menu-timeline .p-dropdown .p-dropdown-label {\n  padding: 5px 0px;\n  font-size: 12px;\n  line-height: 16px;\n}\n[_nghost-%COMP%]  .menu-timeline .p-dropdown .p-dropdown-trigger-icon {\n  font-size: 10px;\n}\n[_nghost-%COMP%]  .menu-timeline .p-dropdown.p-focus {\n  box-shadow: none;\n}\n[_nghost-%COMP%]  .p-timeline-event .p-timeline-event-opposite {\n  display: none;\n}\n[_nghost-%COMP%]  .p-timeline-event .p-timeline-event-content {\n  font-size: 12px;\n  line-height: 16px;\n}\n[_nghost-%COMP%]  .p-timeline-event .p-timeline-event-content p {\n  margin: 0px;\n}\n[_nghost-%COMP%]  .timeline-default .p-timeline-event-separator .p-timeline-event-marker {\n  width: 10px;\n  height: 10px;\n  background: none;\n}\n[_nghost-%COMP%]  .timeline-default .p-timeline-event-separator .p-timeline-event-connector {\n  margin-bottom: 0px;\n  margin-top: 0px;\n  width: 1px;\n}\n[_nghost-%COMP%]  .boxs .card p {\n  margin-top: 0;\n  font-size: 14px;\n  color: #8E9ABB;\n}\n[_nghost-%COMP%]  .boxs .card .icon {\n  width: 40px;\n  height: 40px;\n  min-width: 40px;\n  background: #FFEFEB;\n  border-radius: 8px;\n  text-align: center;\n}\n[_nghost-%COMP%]  .boxs .card .media {\n  padding-left: 15px;\n  width: 100%;\n}\n[_nghost-%COMP%]  .boxs .card .per span {\n  min-height: 24px;\n  background: #FFEFEB;\n  border-radius: 4px;\n  color: #FF7C59;\n  font-size: 12px;\n  padding: 4px;\n  display: block;\n}\n[_nghost-%COMP%]  .boxs .card .per span.green {\n  color: #1F8B24;\n  background: #E2F9E3;\n}\n[_nghost-%COMP%]  .boxs .card .per-50 > div {\n  width: 50%;\n}\n[_nghost-%COMP%]  .boxs .card .per-50 .the-month {\n  width: auto;\n}\n.timeline-item[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 4px;\n}\n.home[_ngcontent-%COMP%] {\n  padding: 20px;\n}\n.home[_ngcontent-%COMP%]   .grid[_ngcontent-%COMP%] {\n  margin-left: -8px;\n  margin-right: -8px;\n}\n.home[_ngcontent-%COMP%]   .grid[_ngcontent-%COMP%]   .col-3[_ngcontent-%COMP%], .home[_ngcontent-%COMP%]   .grid[_ngcontent-%COMP%]   .col-9[_ngcontent-%COMP%] {\n  padding-left: 8px;\n  padding-right: 8px;\n}\n@media screen and (max-width: 767px) {\n  .home[_ngcontent-%COMP%]   .grid[_ngcontent-%COMP%]   .col-3[_ngcontent-%COMP%], .home[_ngcontent-%COMP%]   .grid[_ngcontent-%COMP%]   .col-9[_ngcontent-%COMP%] {\n    width: 100%;\n  }\n}\n.home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%] {\n  display: flex;\n  margin-right: -0.5rem;\n  margin-left: -0.5rem;\n  margin-bottom: 7px;\n}\n.home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%] {\n  height: 100%;\n  border-radius: 4px;\n  padding: 20px 44px 24px;\n  display: flex;\n  align-items: flex-start;\n}\n.home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%]   .desc[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n@media screen and (max-width: 1199px) {\n  .home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%] {\n    padding-left: 15px;\n    padding-right: 15px;\n  }\n}\n.home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  font-size: 14px;\n  margin-top: 0px;\n  margin-bottom: 4px;\n}\n.home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%]   .quan[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 24px;\n  line-height: 32px;\n  margin-bottom: 4px;\n  display: flex;\n  align-items: flex-start;\n}\n.home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%]   .quan[_ngcontent-%COMP%]   .number[_ngcontent-%COMP%] {\n  margin-right: 25px;\n}\n.home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%]   .quan[_ngcontent-%COMP%]   .number[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 14px;\n}\n@media screen and (max-width: 1024px) {\n  .home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%]   .quan[_ngcontent-%COMP%]   .number[_ngcontent-%COMP%] {\n    text-align: left;\n  }\n}\n.home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%]   .quan[_ngcontent-%COMP%]   .percen[_ngcontent-%COMP%] {\n  font-size: 12px;\n  padding: 4px;\n  border-radius: 4px;\n  line-height: 1;\n  margin-top: 5px;\n}\n@media screen and (max-width: 1024px) {\n  .home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%]   .quan[_ngcontent-%COMP%] {\n    justify-content: center;\n  }\n}\n@media screen and (max-width: 1024px) {\n  .home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%] {\n    display: block;\n    text-align: center;\n  }\n}\n.home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  border-radius: 4px;\n  margin-right: 24px;\n  position: relative;\n}\n.home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .icon.icon3[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%], .home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .icon.icon2[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  top: 12px;\n  left: 10px;\n}\n.home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 10px;\n  left: 12px;\n}\n@media screen and (max-width: 1024px) {\n  .home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%] {\n    margin: 0px auto 10px;\n  }\n}\n@media screen and (max-width: 1024px) {\n  .home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%] {\n    display: block;\n  }\n  .home[_ngcontent-%COMP%]   .boxs[_ngcontent-%COMP%]   .col-4[_ngcontent-%COMP%] {\n    width: 100%;\n  }\n}\n.home-notice[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 0px;\n  left: 0px;\n  width: 100%;\n  display: flex;\n  padding: 20px;\n}\n@media screen and (max-width: 991px) {\n  .home-notice[_ngcontent-%COMP%] {\n    display: block;\n    text-align: center;\n  }\n  .home-notice[_ngcontent-%COMP%]   .number-day-use[_ngcontent-%COMP%] {\n    margin-bottom: 10px;\n  }\n}\n.home-notice[_ngcontent-%COMP%]   .number-day-use[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  margin-right: 30px;\n  font-size: 14px;\n}\n.home-notice[_ngcontent-%COMP%]   .contact[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%]:first-child {\n  margin-right: 15px;\n}\n.card[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n  padding: 15px;\n  align-items: flex-start;\n  background: #fff;\n  border: none;\n  box-shadow: 0 10px 40px 0 #3e396b12, 0 2px 9px 0 #3e396b0f;\n  border-radius: 5px;\n}\n.card[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%]   .text-center[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 35px;\n}\n.card[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  margin-top: 0px;\n  margin-bottom: 10px;\n}\n.card[_ngcontent-%COMP%]   .card-content1[_ngcontent-%COMP%] {\n  width: 100%;\n  justify-content: space-between;\n  padding: 10px 30px;\n  align-items: flex-start;\n  background: #fff;\n  border: none;\n  box-shadow: 0 10px 40px 0 #3e396b12, 0 2px 9px 0 #3e396b0f;\n  border-radius: 5px;\n}\n.card[_ngcontent-%COMP%]   .card-content1[_ngcontent-%COMP%]   .text-center[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 35px;\n}\n.card[_ngcontent-%COMP%]   .card-content1[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  margin-top: 0px;\n}\n.card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%] {\n  padding: 0px 30px;\n}\n.custom-card[_ngcontent-%COMP%] {\n  margin-top: 15px;\n}\n.custom-card[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%] {\n  background: #fff;\n}\n.custom-card[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%] {\n  padding: 20px 30px;\n  background: #fff;\n}\n.custom-card[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n.custom-card[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%] {\n  box-shadow: none;\n}\n.custom-card[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-header-custom[_ngcontent-%COMP%] {\n  background: #fff;\n  border-bottom: 1px solid #e7e7e7;\n}\n.custom-card[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-header-custom[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0px;\n}\n.boxs[_ngcontent-%COMP%] {\n  display: flex;\n}\n.boxs[_ngcontent-%COMP%]   .text-center[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  color: #0979fd;\n}\n.boxs[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%] {\n  height: 100%;\n  background: #fff;\n}\n.boxs[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  color: #212633;\n  font-size: 24px;\n  font-weight: 500;\n}\n.boxs[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%] {\n  height: 100%;\n}\n.read-more[_ngcontent-%COMP%] {\n  margin-top: 5px;\n  display: inline-block;\n}\n.read-more[_ngcontent-%COMP%]:hover {\n  cursor: pointer;\n  color: #0979fd;\n}\n.sidebar[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%] {\n  background: #FFFFFF;\n  box-shadow: 0 10px 40px 0 #3e396b12, 0 2px 9px 0 #3e396b0f;\n  border-radius: 8px;\n  padding: 15px;\n  margin-bottom: 22px;\n}\n.sidebar[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: #76809B;\n  font-size: 14px;\n}\n.sidebar[_ngcontent-%COMP%]   .box[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0px;\n}\n.sidebar[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  color: rgba(43, 47, 51, 0.8);\n  font-size: 16px;\n  font-weight: 600;\n  margin-bottom: 15px;\n}\n.chart-section[_ngcontent-%COMP%] {\n  background: #FFFFFF;\n  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.05);\n  border-radius: 8px;\n  padding: 30px 20px;\n  margin-bottom: 15px;\n}\n.chart-section[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 16px;\n  line-height: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQUNKO0FBQUk7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFFUjtBQUFJO0VBQ0ksbUJBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0FBRVI7QUFEUTtFQUNJLGVBQUE7RUFDQSxtQkFBQTtBQUdaO0FBQUk7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFFUjtBQURRO0VBQ0ksaUJBQUE7QUFHWjtBQURRO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUFHWjtBQUZZO0VBSko7SUFLUSxjQUFBO0VBS2Q7RUFKYztJQUNJLG1CQUFBO0VBTWxCO0FBQ0Y7QUFGSTtFQUNJLGFBQUE7RUFDQSxxQkFBQTtBQUlSO0FBRkk7RUFJSSxrQkFBQTtFQUtBLGlCQUFBO0VBQ0Esb0JBQUE7QUFIUjtBQU5RO0VBQ0ksZUFBQTtBQVFaO0FBTFE7RUFDSSxlQUFBO0VBQ0EsbUJBQUE7QUFPWjtBQUZJO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FBSVI7QUFGSTtFQUNJLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUlSO0FBQ1E7RUFDSSxrQkFBQTtBQUVaO0FBQVE7RUFDSSxnQkFBQTtBQUVaO0FBQWdCO0VBQ0ksMkJBQUE7RUFDQSx1QkFBQTtFQUNBLGdDQUFBO0FBRXBCO0FBRG9CO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFHeEI7QUFBZ0I7RUFDSSxnQ0FBQTtFQUNBLHVCQUFBO0FBRXBCO0FBRVE7RUFDSSxZQUFBO0VBQ0EsaUJBQUE7QUFBWjtBQUNZO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFDaEI7QUFDWTtFQUNJLGVBQUE7QUFDaEI7QUFDWTtFQUNJLGdCQUFBO0FBQ2hCO0FBSVE7RUFDSSxhQUFBO0FBRlo7QUFJUTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQUZaO0FBR1k7RUFDSSxXQUFBO0FBRGhCO0FBUVk7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBTmhCO0FBUVk7RUFDSSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxVQUFBO0FBTmhCO0FBWVk7RUFDSSxhQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFWaEI7QUFZWTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQVZoQjtBQVlZO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0FBVmhCO0FBYWdCO0VBQ0ksZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtBQVhwQjtBQVlvQjtFQUNJLGNBQUE7RUFDQSxtQkFBQTtBQVZ4QjtBQWVnQjtFQUNJLFVBQUE7QUFicEI7QUFlZ0I7RUFDSSxXQUFBO0FBYnBCO0FBb0JJO0VBQ0ksY0FBQTtFQUNBLGVBQUE7QUFqQlI7QUFvQkE7RUFDSSxhQUFBO0FBakJKO0FBa0JJO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtBQWhCUjtBQWlCUTs7RUFFSSxpQkFBQTtFQUNBLGtCQUFBO0FBZlo7QUFnQlk7RUFKSjs7SUFLUSxXQUFBO0VBWmQ7QUFDRjtBQWVJO0VBQ0ksYUFBQTtFQUNBLHFCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtBQWJSO0FBY1E7RUFDSSxZQUFBO0VBSUEsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtBQWZaO0FBU1k7RUFDSSxlQUFBO0FBUGhCO0FBYVk7RUFUSjtJQVVRLGtCQUFBO0lBQ0EsbUJBQUE7RUFWZDtBQUNGO0FBV1k7RUFDSSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBVGhCO0FBV1k7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0FBVGhCO0FBVWdCO0VBQ0ksa0JBQUE7QUFScEI7QUFTb0I7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQVB4QjtBQVNvQjtFQU5KO0lBT1EsZ0JBQUE7RUFOdEI7QUFDRjtBQVFnQjtFQUNJLGVBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQU5wQjtBQVFnQjtFQXhCSjtJQXlCUSx1QkFBQTtFQUxsQjtBQUNGO0FBT1k7RUE5Q0o7SUErQ1EsY0FBQTtJQUNBLGtCQUFBO0VBSmQ7QUFDRjtBQU1RO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFKWjtBQU9nQjtFQUNJLFNBQUE7RUFDQSxVQUFBO0FBTHBCO0FBUVk7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FBTmhCO0FBUVk7RUFsQko7SUFtQlEscUJBQUE7RUFMZDtBQUNGO0FBT1E7RUE5RUo7SUErRVEsY0FBQTtFQUpWO0VBS1U7SUFDSSxXQUFBO0VBSGQ7QUFDRjtBQU9BO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0FBSko7QUFLSTtFQVBKO0lBUVEsY0FBQTtJQUNBLGtCQUFBO0VBRk47RUFHTTtJQUNJLG1CQUFBO0VBRFY7QUFDRjtBQUlRO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0FBRlo7QUFPWTtFQUNJLGtCQUFBO0FBTGhCO0FBV0k7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLDBEQUFBO0VBQ0Esa0JBQUE7QUFSUjtBQVVZO0VBQ0ksZUFBQTtBQVJoQjtBQVlRO0VBQ0ksZUFBQTtFQUNBLG1CQUFBO0FBVlo7QUFhSTtFQUNJLFdBQUE7RUFDQSw4QkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSwwREFBQTtFQUNBLGtCQUFBO0FBWFI7QUFhWTtFQUNJLGVBQUE7QUFYaEI7QUFlUTtFQUNJLGVBQUE7QUFiWjtBQWlCSTtFQUNJLGlCQUFBO0FBZlI7QUFrQkE7RUFDSSxnQkFBQTtBQWZKO0FBZ0JJO0VBQ0ksZ0JBQUE7QUFkUjtBQWVRO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtBQWJaO0FBY1k7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7QUFaaEI7QUFlUTtFQUNJLGdCQUFBO0FBYlo7QUFlUTtFQUNJLGdCQUFBO0VBQ0EsZ0NBQUE7QUFiWjtBQWNZO0VBQ0ksV0FBQTtBQVpoQjtBQWlCQTtFQUNJLGFBQUE7QUFkSjtBQWdCUTtFQUNJLGNBQUE7QUFkWjtBQWlCSTtFQU1JLFlBQUE7RUFDQSxnQkFBQTtBQXBCUjtBQWNRO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQVpaO0FBaUJJO0VBQ0ksWUFBQTtBQWZSO0FBa0JBO0VBQ0ksZUFBQTtFQUNBLHFCQUFBO0FBZko7QUFnQkk7RUFDSSxlQUFBO0VBQ0EsY0FBQTtBQWRSO0FBa0JJO0VBQ0ksbUJBQUE7RUFDQSwwREFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBZlI7QUFnQlE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQWRaO0FBZ0JRO0VBQ0ksV0FBQTtBQWRaO0FBa0JRO0VBQ0ksNEJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQWhCWjtBQW9CQTtFQUNJLG1CQUFBO0VBQ0EsMkNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFqQko7QUFrQkk7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQWhCUiIsImZpbGUiOiJob21lLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlY3Rpb257XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDI0cHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAyNHB4O1xyXG4gICAgcGFkZGluZy10b3A6IDIwcHg7XHJcbiAgICAudGl0bGV7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICAgIH1cclxuICAgICYuYWN0aXZpdGVze1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgICAgICAgcGFkZGluZy10b3A6IDE1cHg7XHJcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDE2cHg7XHJcbiAgICAgICAgLnRpdGxle1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgJi5jaGFydHtcclxuICAgICAgICBwYWRkaW5nLWxlZnQ6IDI0cHg7XHJcbiAgICAgICAgcGFkZGluZy1yaWdodDogMjRweDtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiA3cHg7XHJcbiAgICAgICAgLnRoZS1jaGFydHtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6IDMwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5oZWFke1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgICAgIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2N3B4KSB7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICAgICAgICAgIC50aXRsZXtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLnRpbWV7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBhbGlnbi1pdGVtczogZmxleC1lbmQ7XHJcbiAgICB9XHJcbiAgICAmLmRvY3VtZW50e1xyXG4gICAgICAgIHN2Z3tcclxuICAgICAgICAgICAgbWF4LXdpZHRoOiAxMDAlO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgLnRpdGxle1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHBhZGRpbmctdG9wOiAxNnB4O1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAxNnB4O1xyXG4gICAgfVxyXG4gICAgLnJlYWRtb3Jle1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICB9XHJcbiAgICAubGluZXtcclxuICAgICAgICBtYXJnaW4tdG9wOiAzNXB4O1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIycHg7XHJcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgfVxyXG59XHJcbjpob3N0OjpuZy1kZWVwe1xyXG4gICAgLm1lbnUtdGltZWxpbmV7XHJcbiAgICAgICAgJi5tZW51LXRhYntcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAyNHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAucC10YWJtZW51LW5hdntcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbm9uZTtcclxuICAgICAgICAgICAgbGl7XHJcbiAgICAgICAgICAgICAgICBhe1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IG5vbmUgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiA0cHggMTJweCA2cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICBzcGFue1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICYucC10YWJtZW51LWluay1iYXJ7XHJcbiAgICAgICAgICAgICAgICAgICAgdG9wOiBjYWxjKDEwMCUgLSAxcHgpICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgYm90dG9tOiBhdXRvICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLnAtZHJvcGRvd257XHJcbiAgICAgICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiA4cHg7XHJcbiAgICAgICAgICAgIC5wLWRyb3Bkb3duLWxhYmVse1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogNXB4IDBweDtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxNnB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5wLWRyb3Bkb3duLXRyaWdnZXItaWNvbntcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAmLnAtZm9jdXN7XHJcbiAgICAgICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLnAtdGltZWxpbmUtZXZlbnR7XHJcbiAgICAgICAgLnAtdGltZWxpbmUtZXZlbnQtb3Bwb3NpdGV7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5wLXRpbWVsaW5lLWV2ZW50LWNvbnRlbnR7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDE2cHg7XHJcbiAgICAgICAgICAgIHB7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgLnRpbWVsaW5lLWRlZmF1bHR7XHJcbiAgICAgICAgLnAtdGltZWxpbmUtZXZlbnQtc2VwYXJhdG9ye1xyXG4gICAgICAgICAgICAucC10aW1lbGluZS1ldmVudC1tYXJrZXJ7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTBweDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMTBweDtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IG5vbmU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLnAtdGltZWxpbmUtZXZlbnQtY29ubmVjdG9ye1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDFweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5ib3hze1xyXG4gICAgICAgIC5jYXJke1xyXG4gICAgICAgICAgICBwe1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMDtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAjOEU5QUJCO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5pY29ue1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDQwcHg7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICAgICAgICAgICAgICBtaW4td2lkdGg6IDQwcHg7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjRkZFRkVCO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5tZWRpYXtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMTVweDtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5wZXJ7XHJcbiAgICAgICAgICAgICAgICBzcGFue1xyXG4gICAgICAgICAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDI0cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI0ZGRUZFQjtcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICNGRjdDNTk7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDRweDtcclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICAgICAgICAgICAgICAmLmdyZWVue1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzFGOEIyNDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI0UyRjlFMztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLnBlci01MHtcclxuICAgICAgICAgICAgICAgICY+ZGl2e1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiA1MCU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAudGhlLW1vbnRoe1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbi50aW1lbGluZS1pdGVte1xyXG4gICAgaXtcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICBtYXJnaW4tdG9wOiA0cHg7XHJcbiAgICB9XHJcbn1cclxuLmhvbWV7XHJcbiAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgLmdyaWR7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IC04cHg7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAtOHB4O1xyXG4gICAgICAgIC5jb2wtMyxcclxuICAgICAgICAuY29sLTl7XHJcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogOHB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nLXJpZ2h0OiA4cHg7XHJcbiAgICAgICAgICAgIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2N3B4KSB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5ib3hze1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAtMC41cmVtO1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAtMC41cmVtO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDdweDtcclxuICAgICAgICAuYm94e1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgICAgIC5kZXNje1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgICAgICAgICAgcGFkZGluZzogMjBweCA0NHB4IDI0cHg7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAgICAgICAgICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAxMTk5cHgpIHtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMTVweDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDE1cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaDV7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLnF1YW57XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDMycHg7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgICAgICAgICAgICAgICAubnVtYmVye1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMjVweDtcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMTAyNHB4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLnBlcmNlbntcclxuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogNHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgICAgICAgICAgICAgICAgICBsaW5lLWhlaWdodDogMTtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAxMDI0cHgpIHtcclxuICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAxMDI0cHgpIHtcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5pY29ue1xyXG4gICAgICAgICAgICB3aWR0aDogNDBweDtcclxuICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMjRweDtcclxuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgICAmLmljb24zLFxyXG4gICAgICAgICAgICAmLmljb24ye1xyXG4gICAgICAgICAgICAgICAgc3Zne1xyXG4gICAgICAgICAgICAgICAgICAgIHRvcDogMTJweDtcclxuICAgICAgICAgICAgICAgICAgICBsZWZ0OiAxMHB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHN2Z3tcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgIHRvcDogMTBweDtcclxuICAgICAgICAgICAgICAgIGxlZnQ6IDEycHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMTAyNHB4KSB7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDBweCBhdXRvIDEwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMTAyNHB4KSB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgICAgICAuY29sLTR7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4uaG9tZS1ub3RpY2V7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBib3R0b206IDBweDtcclxuICAgIGxlZnQ6IDBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIHBhZGRpbmc6IDIwcHg7XHJcbiAgICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA5OTFweCkge1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAubnVtYmVyLWRheS11c2V7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLm51bWJlci1kYXktdXNle1xyXG4gICAgICAgIGxhYmVse1xyXG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDMwcHg7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweCA7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmNvbnRhY3R7XHJcbiAgICAgICAgLmJ0bntcclxuICAgICAgICAgICAgJjpmaXJzdC1jaGlsZHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTVweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4uY2FyZHtcclxuICAgIC5jYXJkLWNvbnRlbnR7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICBwYWRkaW5nOiAxNXB4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDAgMTBweCA0MHB4IDAgIzNlMzk2YjEyLCAwIDJweCA5cHggMCAjM2UzOTZiMGY7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICAgIC50ZXh0LWNlbnRlcntcclxuICAgICAgICAgICAgaXtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMzVweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBoMXtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5jYXJkLWNvbnRlbnQxe1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICBwYWRkaW5nOiAxMHB4IDMwcHg7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgYm94LXNoYWRvdzogMCAxMHB4IDQwcHggMCAjM2UzOTZiMTIsIDAgMnB4IDlweCAwICMzZTM5NmIwZjtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgLnRleHQtY2VudGVye1xyXG4gICAgICAgICAgICBpe1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAzNXB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIGgxe1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICBcclxuICAgIC5jYXJkLWhlYWRlcntcclxuICAgICAgICBwYWRkaW5nOiAwcHggMzBweDtcclxuICAgIH1cclxufVxyXG4uY3VzdG9tLWNhcmR7XHJcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gICAgLmNhcmR7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAuY2FyZC1oZWFkZXJ7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDIwcHggMzBweDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgaDR7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLmNhcmQtY29udGVudHtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmNhcmQtaGVhZGVyLWN1c3RvbXtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlN2U3ZTc7XHJcbiAgICAgICAgICAgIGg0e1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuLmJveHN7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgLnRleHQtY2VudGVye1xyXG4gICAgICAgIGl7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMDk3OWZkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5jYXJkLWNvbnRlbnR7XHJcbiAgICAgICAgaDF7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMjEyNjMzO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgfVxyXG4gICAgLmNhcmR7XHJcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgfVxyXG59XHJcbi5yZWFkLW1vcmV7XHJcbiAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAmOmhvdmVye1xyXG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICBjb2xvcjogIzA5NzlmZDtcclxuICAgIH1cclxufVxyXG4uc2lkZWJhcntcclxuICAgIC5ib3h7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI0ZGRkZGRjtcclxuICAgICAgICBib3gtc2hhZG93OiAwIDEwcHggNDBweCAwICMzZTM5NmIxMiwgMCAycHggOXB4IDAgIzNlMzk2YjBmO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgICAgICBwYWRkaW5nOiAxNXB4O1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIycHg7XHJcbiAgICAgICAgcHtcclxuICAgICAgICAgICAgY29sb3I6ICM3NjgwOUI7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaDN7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMHB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHVse1xyXG4gICAgICAgIGxpe1xyXG4gICAgICAgICAgICBjb2xvcjogcmdiYSg0MywgNDcsIDUxLCAwLjgpO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbi5jaGFydC1zZWN0aW9ue1xyXG4gICAgYmFja2dyb3VuZDogI0ZGRkZGRjtcclxuICAgIGJveC1zaGFkb3c6IDBweCAycHggMnB4IHJnYmEoMCwgMCwgMCwgMC4wNSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICBwYWRkaW5nOiAzMHB4IDIwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG4gICAgaDN7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDIwcHg7XHJcbiAgICB9XHJcbn0iXX0= */"] });


/***/ }),

/***/ 51837:
/*!******************************************************!*\
  !*** ./src/app/services/api-core/apicore.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiCoreService": () => (/* binding */ ApiCoreService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 83981);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 18260);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../auth.service */ 36636);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 14001);






const apiBaseUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiBase;
const apiCoreBaseUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiCoreBase;
class ApiCoreService {
    constructor(http, authService) {
        this.http = http;
        this.authService = authService;
        this.options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
                'Content-Type': 'application/json',
            })
        };
    }
    // Start api Stores
    getManagerList() {
        return this.http
            .get(`${apiCoreBaseUrl}/api/v1/coresystem/GetManagerList?userRole=-1`, this.options);
    }
    getClientWebInfo(queryParams) {
        return this.http
            .get(`${apiCoreBaseUrl}/api/v1/coresystem/GetClientWebInfo?` + queryParams, this.options);
    }
    deleteCustUser(params) {
        return this.http
            .delete(`${apiCoreBaseUrl}/api/v1/individual/DeleteCustUser?` + params, this.options);
    }
    setCustUser(params) {
        return this.http
            .post(`${apiCoreBaseUrl}/api/v1/individual/SetCustUser`, params, this.options);
    }
    getCustIndiIdentity(queryParams) {
        return this.http.get(`${apiCoreBaseUrl}/api/v1/individual/GetCustIndiIdentity?` + queryParams, this.options);
    }
    setCustIndiIdentityCreate(params) {
        return this.http.post(`${apiCoreBaseUrl}/api/v1/individual/SetCustIndiIdentityCreate`, params, this.options);
    }
    getProfileInfo(queryParams) {
        return this.http.get(`${apiCoreBaseUrl}/api/v1/coreuser/GetProfileInfo?` + queryParams, this.options);
    }
    setProfileInfo(queryParams) {
        return this.http.put(`${apiCoreBaseUrl}/api/v1/coreuser/SetProfileInfo`, queryParams, this.options);
    }
    setProfileIdcardVerify(params) {
        return this.http.put(`${apiCoreBaseUrl}/api/v1/coreuser/SetProfileIdcardVerify`, params, this.options);
    }
    geAddressList(queryParams) {
        return this.http.get(`${apiCoreBaseUrl}/api/v1/corelogin/GeAddressList?` + queryParams, this.options);
    }
    setCustAddressContact(params) {
        return this.http.post(`${apiCoreBaseUrl}/api/v1/individual/SetCustAddressContact`, params, this.options);
    }
    setCustIndiIdentity(params) {
        return this.http.put(`${apiCoreBaseUrl}/api/v1/individual/SetCustIndiIdentity`, params, this.options);
    }
    getCustCoporatePage(queryParams) {
        return this.http.get(`${apiCoreBaseUrl}/api/v1/customer/GetCustCoporatePage?` + queryParams, this.options);
    }
    searchCustomer(queryParams) {
        return this.http
            .get(`${apiCoreBaseUrl}/api/v1/customer/GetCustIndividualPage?` + queryParams, this.options);
    }
}
ApiCoreService.ɵfac = function ApiCoreService_Factory(t) { return new (t || ApiCoreService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService)); };
ApiCoreService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: ApiCoreService, factory: ApiCoreService.ɵfac });


/***/ }),

/***/ 52964:
/*!****************************************************!*\
  !*** ./src/app/services/api-hrm/apihrm.service.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiHrmService": () => (/* binding */ ApiHrmService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 83981);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 18260);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../auth.service */ 36636);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 14001);







const apiBaseUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiBase;
const apiHrmServer = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiHrmBase;
const apiCore = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiCoreBase;
const apiShome = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiShomeBase;
class ApiHrmService {
    constructor(http, authService) {
        this.http = http;
        this.authService = authService;
        this.options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
                'Content-Type': 'application/json',
            })
        };
    }
    getIdentityCardInfomation(image) {
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                'key': 'WZWfWCN2VPDxbYsV6sRfR0N1fV8x030h'
            })
        };
        const formdata = new FormData();
        formdata.append('image', image, 'TanTano');
        formdata.append('request_id', '14071996');
        return this.http.post('https://api.cloudekyc.com/v3.2/ocr/recognition', formdata, options);
    }
    // Dashboard
    getCustObjectListNew(type = false, queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/category/GetObjectList?` + queryParams, this.options);
    }
    // Worktime
    getWorktimePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/worktime/GetWorktimePage?` + queryParams, this.options);
    }
    DelWorktimeInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/worktime/DelWorktimeInfo?` + queryParams, this.options);
    }
    getWorktimeInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/worktime/GetWorktimeInfo?` + queryParams, this.options);
    }
    getWorktimeList(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/worktime/GetWorktimeList?` + queryParams, this.options);
    }
    setWorktimeInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/worktime/SetWorktimeInfo`, queryParams, this.options);
    }
    //góp ý
    getFeedbackInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/feedback/GetFeedbackInfo?` + queryParams, this.options);
    }
    getFeedbackPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/feedback/GetFeedbackPage?` + queryParams, this.options);
    }
    // end thông báo
    getEmployeeSearch(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employee/GetEmployeeSearch?` + queryParams, this.options);
    }
    getReport(api, params) {
        return this.http.get(`${apiHrmServer}${api}?${params}`, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            }),
            responseType: "blob"
        });
    }
    setIncomTaxImport(data, datect) {
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                'Authorization': this.authService.getAuthorizationHeaderValue(),
                // 'Content-Type': 'multipart/form-data'
            })
        };
        const formdata = new FormData();
        formdata.append('formFile', data);
        return this.http.post(`${apiHrmServer}/api/v2/incometax/SetIncomTaxImport?date_ct=${datect}`, formdata, options);
    }
    // IncomTax
    getIncomeTaxPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/incometax/GetIncomeTaxPage?${queryParams}`, this.options);
    }
    // notifi
    setNotifyToPushRun(params) {
        return this.http.put(`${apiHrmServer}/api/v1/notify/SetNotifyToPushRun`, params, this.options);
    }
    setAppNotifyStatus(params) {
        return this.http.post(`${apiHrmServer}/api/v1/notify/SetAppNotifyStatus`, params, this.options);
    }
    setNotifyStatus(params) {
        return this.http.post(`${apiHrmServer}/api/v1/notify/SetNotifyStatus`, params, this.options);
    }
    delAppNotifyInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/notify/DelAppNotifyInfo?` + queryParams, this.options);
    }
    delNotifyInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/notify/delNotifyInfo?` + queryParams, this.options);
    }
    getAppNotifyPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetAppNotifyPage?` + queryParams, this.options);
    }
    getNotifyPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyPage?` + queryParams, this.options);
    }
    getNotifyTempList() {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyTempList`, this.options);
    }
    getNotifyRefPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyRefPage?` + queryParams, this.options);
    }
    getNotifyTempPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyTempPage?` + queryParams, this.options);
    }
    getNotifyRef(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyRef?` + queryParams, this.options);
    }
    getUserByPush(queryParams) {
        return this.http.put(`${apiHrmServer}/api/v1/notify/GetUserByPush`, queryParams, this.options);
    }
    getNotifyTemp(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyTemp?` + queryParams, this.options);
    }
    delNotifyRef(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/notify/DelNotifyRef?` + queryParams, this.options);
    }
    delNotifyTemp(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/notify/DelNotifyTemp?` + queryParams, this.options);
    }
    getModuleList() {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetOrgRoots`, this.options);
    }
    setNotifyCreatePush(params) {
        return this.http.put(`${apiHrmServer}/api/v1/notify/SetNotifyCreatePush`, params, this.options);
    }
    setNotifyTemp(params) {
        return this.http.post(`${apiHrmServer}/api/v1/notify/SetNotifyTemp`, params, this.options);
    }
    setNotifyRef(params) {
        return this.http.post(`${apiHrmServer}/api/v1/notify/SetNotifyRef`, params, this.options);
    }
    getDocumentUrl(filter, offset, pagesize) {
        return this.http.get(apiBaseUrl + '/GetDocumentUrl?ProjectCd=&filter=' + filter + '&offSet=' + offset + '&pageSize=' + pagesize, this.options).toPromise();
    }
    setDocumentUrl(documentUrl) {
        const doc = {
            projectCd: '',
            documentTitle: '',
            documentUrl
        };
        return this.http.post(apiBaseUrl + '/SetDocumentUrl', doc, this.options).toPromise();
    }
    getAppNotifyInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetAppNotifyInfo?` + queryParams, this.options);
    }
    getNotifyInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyInfo?` + queryParams, this.options);
    }
    setAppNotifyInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v1/notify/SetAppNotifyInfo`, params, this.options);
    }
    setNotifyInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v1/notify/SetNotifyInfo`, params, this.options);
    }
    delNotifyPushs(queryParams) {
        return this.http.put(`${apiHrmServer}/api/v1/notify/DelNotifyPushs`, queryParams, this.options);
    }
    getNotifyCommentList(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyCommentList?` + queryParams, this.options);
    }
    getNotifyToPushs(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyToPushs?` + queryParams, this.options);
    }
    getNotifyCommentChilds(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyCommentChilds?` + queryParams, this.options);
    }
    getNotifyPushStatus() {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyPushStatus`, this.options);
    }
    setNotifyCommentAuth(params) {
        return this.http.put(`${apiHrmServer}/api/v1/notify/SetNotifyCommentAuth`, params, this.options);
    }
    delNotifyPush(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/notify/DelNotifyPush?` + queryParams, this.options);
    }
    setNotifyComment(params) {
        return this.http.post(`${apiHrmServer}/api/v1/notify/SetNotifyComment`, params, this.options);
    }
    getIncomeTaxInfo(id) {
        return this.http.get(`${apiHrmServer}/api/v2/incometax/GetIncomeTaxInfo?id=${id}`, this.options);
    }
    getIncomeTaxTypes() {
        return this.http.get(`${apiHrmServer}/api/v2/incometax/GetIncomeTaxTypes`, this.options);
    }
    setIncomTaxInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/incometax/SetIncomTaxInfo`, params, this.options);
    }
    deleteIncomeTaxStatus(id) {
        return this.http.delete(`${apiHrmServer}/api/v2/incometax/SetIncomeTaxStatus?id=${id}`, this.options);
    }
    setSalaryRecordInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v1/salary/SetSalaryRecordInfo`, queryParams, this.options);
    }
    setSalaryRecordApprove(queryParams) {
        return this.http.put(`${apiHrmServer}/api/v1/salary/SetSalaryRecordApprove`, queryParams, this.options);
    }
    getEatingPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/eating/GetEatingPage?` + queryParams, this.options);
    }
    getSalaryInfoPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/salary/GetSalaryInfoPage?` + queryParams, this.options);
    }
    getSalaryEmployeePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/salary/getSalaryEmployeePage?` + queryParams, this.options);
    }
    getSalaryRecordInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/salary/GetSalaryRecordInfo?` + queryParams, this.options);
    }
    setSalaryCreateDraft(queryParams) {
        return this.http.put(`${apiHrmServer}/api/v1/salary/SetSalaryCreateDraft`, queryParams, this.options);
    }
    getTimekeepingPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/timekeeping/GetTimekeepingPage?` + queryParams, this.options);
    }
    getEmployeeSalaryMonthPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/timekeeping/GetEmployeeSalaryMonthPage?` + queryParams, this.options);
    }
    getTimekeepingInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/timekeeping/getTimekeepingInfo?` + queryParams, this.options);
    }
    getTimekeepingDetail(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/timekeeping/GetTimekeepingDetail?` + queryParams, this.options);
    }
    updateTimeKeeping(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v1/timekeeping/UpdateTimeKeeping`, queryParams, this.options);
    }
    exportTimekeeping(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/timekeeping/ExportTimekeeping/?${queryParams}`, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            }),
            responseType: "blob"
        });
    }
    getExportReport(url, queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/report/${url}?${queryParams}`, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            }),
            responseType: "blob"
        });
    }
    exportReportLocalhost(url) {
        return this.http.get(url, {
            responseType: "blob"
        });
    }
    getSalaryRecordPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/salary/GetSalaryRecordPage?` + queryParams, this.options);
    }
    setContractInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/contract/SetContractInfo`, params, this.options);
    }
    setTerminateInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/terminate/SetTerminateInfo`, queryParams, this.options);
    }
    getTerminateInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/terminate/GetTerminateInfo?` + queryParams, this.options);
    }
    setContractDraft(params) {
        return this.http.post(`${apiHrmServer}/api/v2/contract/SetContractDraft`, params, this.options);
    }
    setContractUpload(params) {
        return this.http.post(`${apiHrmServer}/api/v2/contract/SetContractUpload`, params, this.options);
    }
    setContractSignedUpload(id, params) {
        return this.http.put(`${apiHrmServer}/api/v2/contract/SetContractSignedUpload?` + id, params, this.options);
    }
    getContractInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/contract/GetContractInfo?` + queryParams, this.options);
    }
    getContractMetaPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/contract/GetContractMetaPage?` + queryParams, this.options);
    }
    getSalaryComponentPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/contract/GetSalaryComponentPage?` + queryParams, this.options);
    }
    setContractCreate(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/contract/SetContractCreate`, queryParams, this.options);
    }
    setContractSigned(queryParams) {
        return this.http.put(`${apiHrmServer}/api/v2/contract/SetContractSigned?` + queryParams, null, this.options);
    }
    setContractComplete(queryParams) {
        return this.http.put(`${apiHrmServer}/api/v2/contract/SetContractComplete?` + queryParams, null, this.options);
    }
    setEmpAttach(params) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/SetEmpAttach`, params, this.options);
    }
    getEmpAttach(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employee/GetEmpAttach?` + queryParams, this.options);
    }
    getAccountInfo(queryParams) {
        return this.http.get(`${apiCore}/api/v1/coreaccount/GetAccountInfo?` + queryParams, this.options);
    }
    getFeedbackType() {
        return this.http.get(`${apiHrmServer}/api/v1/feedback/GetFeedbackType`, this.options);
    }
    setAccountInfo(params) {
        return this.http.post(`${apiCore}/api/v1/coreaccount/SetAccountInfo`, params, this.options);
    }
    setEmpContact(params) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/SetEmpContact`, params, this.options);
    }
    getEmpContact(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employee/GetEmpContact?` + queryParams, this.options);
    }
    getTerminateReasons() {
        return this.http.get(`${apiHrmServer}/api/v2/terminate/GetTerminateReasons?`, this.options);
    }
    getEmployeeData(linkurl, queryParams) {
        if (linkurl === 'GetEmpQualification') {
            return this.http.get(`${apiHrmServer}/api/v2/employeetrain/${linkurl}?` + queryParams, this.options);
        }
        else {
            return this.http.get(`${apiHrmServer}/api/v2/employee/${linkurl}?` + queryParams, this.options);
        }
    }
    setEmployeeInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/SetEmployeeInfo`, params, this.options);
    }
    lockUser(userId) {
        return this.http.post(`${apiHrmServer}/api/v1/user/LockUser`, { userId }, this.options);
    }
    unLockUser(userId) {
        return this.http.post(`${apiHrmServer}/api/v1/user/UnLockUser`, { userId }, this.options);
    }
    getUserCompanies(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/user/GetUserCompanies?` + queryParams, this.options);
    }
    setCandidateRegisters(data) {
        return this.http.post(`${apiHrmServer}/api/v1/user/SetCandidateRegisters`, data, this.options);
    }
    setEmployeeCancel(params) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/SetEmployeeCancel`, params, this.options);
    }
    setEmployeeTermilate(params) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/SetEmployeeTermilate`, params, this.options);
    }
    setEmployeeRehired(params) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/SetEmployeeRehired`, params, this.options);
    }
    setEmployeeChange(params) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/setEmployeeChange`, params, this.options);
    }
    getRecordInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/contract/GetRecordInfo?` + queryParams, this.options);
    }
    getContractPageByEmpId(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/contract/GetContractPageByEmpId?` + queryParams, this.options);
    }
    setEmpDependent(params) {
        return this.http.post(`${apiHrmServer}/api/v2/contract/SetEmpDependent`, params, this.options);
    }
    setContractStatus(params) {
        return this.http.put(`${apiHrmServer}/api/v2/contract/SetContractStatus`, params, this.options);
    }
    setContractCancel(params) {
        return this.http.put(`${apiHrmServer}/api/v2/contract/SetContractCancel`, params, this.options);
    }
    removeUser(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/user/RemoveUser?` + queryParams, this.options);
    }
    deleteUser(queryParams) {
        return this.http.delete(`${apiCore}/api/v1/coreuser/DeleteUser?` + queryParams, this.options);
    }
    hrmDelEmpWorking(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/working/DelEmpWorking?` + queryParams, this.options);
    }
    delContractInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/contract/DelContractInfo?` + queryParams, this.options);
    }
    delEmpAttach(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/employee/DelEmpAttach?` + queryParams, this.options);
    }
    getEmpFilter() {
        return this.http.get(`${apiHrmServer}/api/v2/employee/GetEmpFilter`, this.options);
    }
    exportResume(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employee/ExportResume?${queryParams}`, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            }),
            responseType: "blob"
        });
    }
    setRecordInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/contract/SetRecordInfo`, params, this.options);
    }
    getEmpDependentPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/contract/GetEmpDependentPage?` + queryParams, this.options);
    }
    getEmpDependent(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/contract/GetEmpDependent?` + queryParams, this.options);
    }
    delEmpDependent(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/contract/DelEmpDependent?` + queryParams, this.options);
    }
    setIncomeTaxStatus(id) {
        return this.http.delete(`${apiHrmServer}/api/v2/incometax/SetIncomeTaxStatus?id=` + id, this.options);
    }
    deleteReportIncomeTaxs(params) {
        return this.http.delete(`${apiHrmServer}/api/v1/report/DeleteReportIncomeTaxs?` + params, this.options);
    }
    getMeetingPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/meeting/GetMeetingPage?` + queryParams, this.options);
    }
    getMeetRoomPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/meeting/GetMeetRoomPage?` + queryParams, this.options);
    }
    getMeetingInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/meeting/GetMeetingInfo${queryParams}`, this.options);
    }
    getMeetRoomInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/meeting/GetMeetRoomInfo?` + queryParams, this.options);
    }
    setMeetingInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v2/meeting/SetMeetingInfo`, data, this.options);
    }
    setMeetRoomInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v2/meeting/SetMeetRoomInfo`, data, this.options);
    }
    delMeetRoomInfo(id) {
        return this.http.delete(`${apiHrmServer}/api/v2/meeting/DelMeetRoomInfo?roomId=` + id, this.options);
    }
    delMeetingInfo(query) {
        return this.http.delete(`${apiHrmServer}/api/v2/meeting/DelMeetingInfo?` + query, this.options);
    }
    getMeetRooms(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/meeting/GetMeetRooms?${queryParams}`, this.options);
    }
    // meetingFloor
    getMeetingFloorPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/meeting/GetMeetingFloorPage?` + queryParams, this.options);
    }
    getMeetingFloorInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/meeting/GetMeetingFloorInfo${queryParams}`, this.options);
    }
    setMeetingFloorInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v2/meeting/SetMeetingFloorInfo`, data, this.options);
    }
    delMeetingFloorInfo(params) {
        return this.http.delete(`${apiHrmServer}/api/v2/meeting/DelMeetingFloorInfo` + params, this.options);
    }
    getProductProjs() {
        return this.http
            .get(`${apiCore}/api/v1/coreagent/GetProductProjs`, this.options);
    }
    getAgencyOrganizeList(queryParams) {
        return this.http.get(`${apiCore}/api/v1/coreagent/getAgencyOrganizeList?` + queryParams, this.options);
    }
    getManagerList(queryParams) {
        return this.http.get(`${apiCore}/api/v1/coresystem/GetManagerList?` + queryParams, this.options);
    }
    // from new
    getAgentLeaders(queryParams) {
        return this.http.get(`${apiCore}/api/v1/coreagent/getAgentLeaders?` + queryParams, this.options);
    }
    getOrganizeTree(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetOrganizeTree?` + queryParams, this.options);
    }
    getOrgPositions(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetOrgPositions?` + queryParams, this.options);
    }
    getOrganizePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetOrganizePage?` + queryParams, this.options);
    }
    getContract(queryParams) {
        return this.http.get(`${apiCore}/api/v1/coresaler/GetContract?` + queryParams, this.options);
    }
    getOrganizeInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetOrganizeInfo?` + queryParams, this.options);
    }
    getCompanyList(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/compay/GetCompanyList?` + queryParams, this.options);
    }
    getOrganizeParam(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/report/GetOrganizeParam?` + queryParams, this.options);
    }
    getDepartmentParams(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/report/GetDepartmentParams?` + queryParams, this.options);
    }
    getUsersByAdmin(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/user/getUsersByAdmin?` + queryParams, this.options);
    }
    getEducations() {
        return this.http.get(`${apiHrmServer}/api/v2/category/GetEducations`, this.options);
    }
    getWorkplaces() {
        return this.http.get(`${apiHrmServer}/api/v2/category/GetWorkplaces`, this.options);
    }
    getNotifyRefList() {
        return this.http.get(`${apiHrmServer}/api/v1/notify/GetNotifyRefList`, this.options);
    }
    getVacancyPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetVacancyPage?` + queryParams, this.options);
    }
    getVacancyFilter() {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetVacancyFilter`, this.options);
    }
    getOrgRoots() {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetOrgRoots`, this.options);
    }
    getSalaryTypes(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/salary/GetSalaryTypes?` + queryParams, this.options);
    }
    getJobs(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/category/GetJobs?` + queryParams, this.options);
    }
    getAccountPage(queryParams) {
        return this.http.get(`${apiCore}/api/v1/coreaccount/GetAccountPage?` + queryParams, this.options);
    }
    getEmpLeaders(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employee/GetEmpLeaders?` + queryParams, this.options);
    }
    getBankList() {
        return this.http.get(`${apiCore}/api/v1/coreaccount/GetBankList`, this.options);
    }
    getWorkTimes(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/category/GetWorkTimes?` + queryParams, this.options);
    }
    getWorkShifts(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/category/GetWorShifts?` + queryParams, this.options);
    }
    getSalaryBases() {
        return this.http.get(`${apiHrmServer}/api/v1/salary/GetSalaryBases`, this.options);
    }
    getContractTypes(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/contracttype/GetContractTypes?${queryParams}`, this.options);
    }
    getPrintFiles(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/contract/GetPrintFiles`, queryParams, this.options);
    }
    // Thai sản
    getMaternityPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/maternity/GetMaternityPage?` + queryParams, this.options);
    }
    getMaternityChildInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/maternity/GetMaternityChildInfo?` + queryParams, this.options);
    }
    getMaternityPregnancInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/maternity/GetMaternityPregnancInfo?` + queryParams, this.options);
    }
    getMaternityInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/maternity/GetMaternityInfo?` + queryParams, this.options);
    }
    setMaternityInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/maternity/SetMaternityInfo`, params, this.options);
    }
    setMaternityPolicyInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/maternity/SetMaternityPolicyInfo`, params, this.options);
    }
    setMaternityChildInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/maternity/SetMaternityChildInfo`, params, this.options);
    }
    setMaternityPregnancyInfo(url, params) {
        return this.http.post(`${apiHrmServer}/api/v2/maternity/${url}`, params, this.options);
    }
    delMaternityInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/maternity/DelMaternityInfo?` + queryParams, this.options);
    }
    delMaternityPolicyInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/maternity/DelMaternityPolicyInfo?` + queryParams, this.options);
    }
    delMaternityPregnancyInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/maternity/DelMaternityPregnancyInfo?` + queryParams, this.options);
    }
    delMaternityChildInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/maternity/DelMaternityChildInfo?` + queryParams, this.options);
    }
    // Tuyển dụng
    getWorkflowPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/work/GetWorkflowPage?` + queryParams, this.options);
    }
    getWorkflowInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/work/GetWorkflowInfo?` + queryParams, this.options);
    }
    setWorkApprove(params) {
        return this.http.put(`${apiHrmServer}/api/v2/work/SetWorkApprove`, params, this.options);
    }
    getCandidatePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetCandidatePage?` + queryParams, this.options);
    }
    getCandidateFilter() {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetCandidateFilter`, this.options);
    }
    getCandidatePotentialPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetCandidatePotentialPage?` + queryParams, this.options);
    }
    delCandidateInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/recruitment/DelCandidateInfo?` + queryParams, this.options);
    }
    getJobTitles() {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetJobTitles`, this.options);
    }
    getCandidateStatus() {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetCandidateStatus?`, this.options);
    }
    importCandidates(data) {
        const customOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue()
            })
        };
        return this.http.post(`${apiHrmServer}/api/v1/recruitment/ImportCandidates`, data, customOptions);
    }
    delVacancyInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/recruitment/DelVacancyInfo?` + queryParams, this.options);
    }
    getJobPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetJobPage?` + queryParams, this.options);
    }
    delJobInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/recruitment/DelJobInfo?` + queryParams, this.options);
    }
    getVacancyInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetVacancyInfo?` + queryParams, this.options);
    }
    getVacancyReplicationInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetVacancyReplicationInfo?` + queryParams, this.options);
    }
    setVacancyInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v1/recruitment/SetVacancyInfo`, params, this.options);
    }
    getJobInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetJobInfo?` + queryParams, this.options);
    }
    setJobInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v1/recruitment/SetJobInfo`, params, this.options);
    }
    getCandidateInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetCandidateInfo?` + queryParams, this.options);
    }
    getCandidatesViewInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetCandidatesViewInfo?` + queryParams, this.options);
    }
    setCandidateInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v1/recruitment/SetCandidateInfo`, params, this.options);
    }
    recruiUpdateStatus(queryParams, params = null) {
        return this.http.post(`${apiHrmServer}/api/v1/recruitment/UpdateStatus?` + queryParams, params, this.options);
    }
    getRecruitMailInput(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetRecruitMailInput?` + queryParams, this.options);
    }
    sendRecruitMail(data = null) {
        return this.http.post(`${apiHrmServer}/api/v1/recruitment/SendRecruitMail`, data, this.options);
    }
    updateInterviewResult(query, data = null) {
        return this.http.post(`${apiHrmServer}/api/v1/recruitment/UpdateInterviewResult?` + query, data, this.options);
    }
    exportVacancy(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/ExportVacancy/?${queryParams}`, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            }),
            responseType: "blob"
        });
    }
    getAgencyOrganizeMap() {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetOrganizeMap`, this.options);
    }
    getEmployeePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employee/GetEmployeePage?` + queryParams, this.options);
    }
    deleteEmployee(employeeId) {
        return this.http
            .delete(`${apiHrmServer}/api/v2/employee/DeleteEmployee?empId=${employeeId}`, this.options);
    }
    setEmployeeOpenhrm(params) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/SetEmployeeOpen`, params, this.options);
    }
    setEmployeeClose(params) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/SetEmployeeClose`, params, this.options);
    }
    setEmployeeApprovehrm(params) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/SetEmployeeApprove`, params, this.options);
    }
    getEmployeeStatus(queryParams = null) {
        return this.http.get(`${apiHrmServer}/api/v2/employee/GetEmployeeStatus?` + queryParams, this.options);
    }
    getTerminatePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/terminate/GetTerminatePage?` + queryParams, this.options);
    }
    getTerminateFilter() {
        return this.http.get(`${apiHrmServer}/api/v2/terminate/GetTerminateFilter`, this.options);
    }
    setTerminateStatus(params) {
        return this.http.put(`${apiHrmServer}/api/v2/terminate/SetTerminateStatus`, params, this.options);
    }
    delTerminateInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/terminate/DelTerminateInfo?` + queryParams, this.options);
    }
    getObjectGroup(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/category/GetObjectGroup?` + queryParams, this.options);
    }
    getLeavePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/leave/GetLeavePage?` + queryParams, this.options);
    }
    getLeaveReasonPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/leave/GetLeaveReasonPage?` + queryParams, this.options);
    }
    delLeaveReason(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/leave/DelLeaveReason?` + queryParams, this.options);
    }
    getLeaveReason(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/leave/GetLeaveReason?` + queryParams, this.options);
    }
    getLeaveInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/leave/GetLeaveInfo?` + queryParams, this.options);
    }
    setLeaveHrmInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/leave/SetLeaveHrmInfo`, queryParams, this.options);
    }
    setLeaveInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/leave/SetLeaveInfo`, queryParams, this.options);
    }
    checkLeaveOverLap(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/leave/CheckLeaveOverLap`, queryParams, this.options);
    }
    setLeaveReason(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/leave/SetLeaveReason`, queryParams, this.options);
    }
    cancelLeaveStatuses(params) {
        return this.http.put(`${apiHrmServer}/api/v2/leave/CancelLeaveStatuses`, params, this.options);
    }
    getEatingInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/eating/GetEatingInfo?` + queryParams, this.options);
    }
    delEatingInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/eating/DelEatingInfo?` + queryParams, this.options);
    }
    getEatingForCreateInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/eating/GetEatingForCreateInfo?` + queryParams, this.options);
    }
    getEatingList(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/eating/GetEatingList?` + queryParams, this.options);
    }
    getOrganizeLevelList(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetOrganizeLevelList?` + queryParams, this.options);
    }
    getOrganizeList(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetOrganizeList?` + queryParams, this.options);
    }
    getOrganizations(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetOrganizations?` + queryParams, this.options);
    }
    organizeGetDepartments(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetDepartments?${queryParams}`, this.options);
    }
    setListEmployeeChange(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/SetListEmployeeChange`, queryParams, this.options);
    }
    delOrganize(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/organize/DelOrganize?` + queryParams, this.options);
    }
    setOrganize(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v1/organize/SetOrganize`, queryParams, this.options);
    }
    getPositionList(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/position/GetPositionList?` + queryParams, this.options);
    }
    getPositionTitles(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/position/GetPositionTitles?` + queryParams, this.options);
    }
    setOrganizeInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v1/organize/SetOrganizeInfo`, queryParams, this.options);
    }
    getUsersByCust(custId) {
        return this.http
            .get(`${apiBaseUrl}/api/v1/user/GetUsersByCust?custId=${custId}`, this.options);
    }
    getUserSearchPage(filter) {
        return this.http
            .get(`${apiCore}/api/v1/coreuser/GetUserSearchPage?filter=${filter}`, this.options);
    }
    setOrganizePosition(queryParams) {
        return this.http.put(`${apiHrmServer}/api/v1/organize/SetOrganizePosition`, queryParams, this.options);
    }
    getReportList(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/report/GetReportList?` + queryParams, this.options);
    }
    setUserAdd(params) {
        return this.http.put(`${apiHrmServer}/api/v1/user/SetUserAdd`, params, this.options);
    }
    setOrganizeCompany(queryParams) {
        return this.http.put(`${apiHrmServer}/api/v1/organize/SetOrganizeCompany`, queryParams, this.options);
    }
    getPositionPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/position/GetPositionPage?` + queryParams, this.options);
    }
    delPositionInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/position/DelPositionInfo?` + queryParams, this.options);
    }
    delWorkplaceInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/workplace/DelWorkplaceInfo?` + queryParams, this.options);
    }
    getWorkplacePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/workplace/GetWorkplacePage?` + queryParams, this.options);
    }
    getOrganizeConfig(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetOrganizeConfig?` + queryParams, this.options);
    }
    setOrganizeConfig(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v1/organize/SetOrganizeConfig`, queryParams, this.options);
    }
    getBanByOrganize(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetBanByOrganize?` + queryParams, this.options);
    }
    getDepartmentByOrganize(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetDepartmentByOrganize?` + queryParams, this.options);
    }
    getGroupByOrganize(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetGroupByOrganize?` + queryParams, this.options);
    }
    getTeamByOrganize(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/organize/GetTeamByOrganize?` + queryParams, this.options);
    }
    getPositionInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/position/GetPositionInfo?` + queryParams, this.options);
    }
    setPositionInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/position/SetPositionInfo`, params, this.options);
    }
    getWorkplaceInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/workplace/GetWorkplaceInfo?` + queryParams, this.options);
    }
    setWorkplaceInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/workplace/SetWorkplaceInfo`, queryParams, this.options);
    }
    getCompanyPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/compay/GetCompanyPage?` + queryParams, this.options);
    }
    getCompaniesByUserOrganize(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/compay/GetCompaniesByUserOrganize?` + queryParams, this.options);
    }
    setCompanyInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/compay/SetCompanyInfo`, params, this.options);
    }
    setEatingInfo(params) {
        return this.http.put(`${apiHrmServer}/api/v1/eating/SetEatingInfo`, params, this.options);
    }
    getEatingExport(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/eating/GetEatingExport?${queryParams}`, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            }),
            responseType: "blob"
        });
    }
    gxportEatingPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/eating/ExportEatingPage?${queryParams}`, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            }),
            responseType: "blob"
        });
    }
    exportEatingInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/eating/ExportEatingInfo?${queryParams}`, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            }),
            responseType: "blob"
        });
    }
    delCompanyInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/compay/DelCompanyInfo?` + queryParams, this.options);
    }
    getCompanyInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/compay/GetCompanyInfo?` + queryParams, this.options);
    }
    delComAuthorizeInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/compay/DelComAuthorizeInfo?` + queryParams, this.options);
    }
    getComAuthorizeInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/compay/GetComAuthorizeInfo?` + queryParams, this.options);
    }
    setComAuthorizeInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/compay/SetComAuthorizeInfo`, params, this.options);
    }
    getContractTypePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/contracttype/GetContractTypePage?` + queryParams, this.options);
    }
    getContractPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/contract/GetContractPage?` + queryParams, this.options);
    }
    getContractFilter() {
        return this.http.get(`${apiHrmServer}/api/v2/contract/GetContractFilter`, this.options);
    }
    getContractTypeInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/contracttype/GetContractTypeInfo?` + queryParams, this.options);
    }
    setContractTypeInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/contracttype/SetContractTypeInfo`, params, this.options);
    }
    uploadFileContract(params) {
        return this.http.post(`${apiHrmServer}/api/v2/contracttype/UploadFileContract`, params, this.options);
    }
    delContractTypeInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/contracttype/DelContractTypeInfo?` + queryParams, this.options);
    }
    // api cũ
    getCardCustomers(filter) {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetCardCustomers?${filter}`, this.options);
    }
    getCardInfo(cardNum, customerPhoneNumber, HardwareId) {
        return this.http
            .get(`${apiBaseUrl}/api/v1/shome/GetCardInfo?` +
            `cardNum=${cardNum}&` +
            `customerPhoneNumber=${customerPhoneNumber}&` +
            `hardwareId=${HardwareId}`, this.options);
    }
    getBuildCdByProjectCd(projectCd) {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetBuildCdByProjectCd?` +
            `projectCd=${projectCd}`, this.options);
    }
    getMasElevatorCards(filter, offset, pagesize) {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetMasElevatorCards?` +
            `filter=${filter}&` +
            `offSet=${offset}&` +
            `pageSize=${pagesize}`, this.options);
    }
    GetBuildFloorByProjectCdBuildCd(buildZone, projectCd, buildCd) {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetBuildFloorByProjectCdBuildCd?` +
            `projectCd=${projectCd}&` +
            `buildZone=${buildZone}&` +
            `buildCd=${buildCd}&`, this.options);
    }
    getElevatorDevicePage(filter, offset, pagesize, projectCd, buildZone, buildCd, floorNumber = null) {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetElevatorDevicePage?` +
            `filter=${filter}&` +
            `offSet=${offset}&` +
            `pageSize=${pagesize}&` +
            `buildCd=${buildCd}&` +
            `projectCd=${projectCd}&` +
            `floorNumber=${floorNumber}&` +
            `buildZone=${buildZone}`, this.options);
    }
    getEmployeeCardPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/cardvehicle/GetEmployeeCardPage?` + queryParams, this.options);
    }
    getEmployeeList(queryParams) {
        return this.http
            .get(`${apiBaseUrl}/api/v2/employee/GetEmployeeList?` + queryParams, this.options);
    }
    setVehicleRemove(params) {
        return this.http.put(`${apiHrmServer}/api/v2/cardvehicle/SetVehicleRemove`, params, this.options);
    }
    lockCardVehicle(cardVehicleId) {
        const card = { status: 1, cardVehicleId };
        return this.http.put(`${apiHrmServer}/api/v2/cardvehicle/SetVehicleLock`, card, this.options);
    }
    getUserPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/user/GetUserPage?` + queryParams, this.options);
    }
    getEmployeeVehiclePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/cardvehicle/GetEmployeeVehiclePage?` + queryParams, this.options);
    }
    getEmployeeVehicleInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/cardvehicle/GetEmployeeVehicleInfo?` + queryParams, this.options);
    }
    setEmployeeVehicleInfo(params) {
        return this.http.post(`${apiHrmServer}/api/v2/cardvehicle/SetEmployeeVehicleInfo`, params, this.options);
    }
    setVehicleApprove(data) {
        return this.http.put(`${apiHrmServer}/api/v2/cardvehicle/SetVehicleApprove`, data, this.options);
    }
    getVehicleTypes() {
        return this.http
            .get(`${apiBaseUrl}/api/v1/shome/GetVehicleTypes`, this.options);
    }
    unlockCardVehicle(cardVehicleId) {
        const card = { status: 0, cardVehicleId };
        return this.http.put(`${apiHrmServer}/api/v2/cardvehicle/SetVehicleLock`, card, this.options);
    }
    getCardVehicleDetail(cardVehicleId) {
        return this.http
            .get(`${apiBaseUrl}/api/v1/shome/GetCardVehicleDetail?cardVehicleId=${cardVehicleId}`, this.options);
    }
    getDetailEmployeeVehicleInfo(cardVehicleId) {
        return this.http
            .get(`${apiHrmServer}/api/v2/cardvehicle/GetDetailEmployeeVehicleInfo?cardVehicleId=${cardVehicleId}`, this.options);
    }
    approveCardVehicle(cardVehicleId) {
        const card = { cardVehicleId, status: 1 };
        return this.http.put(`${apiBaseUrl}/api/v1/shome/SetCardVehicleServiceAuth`, card, this.options).toPromise();
    }
    lockCardNV(cardCd) {
        const card = { cardCd, status: 1 };
        return this.http.put(`${apiHrmServer}/api/v2/cardvehicle/SetCardLock`, card, this.options);
    }
    setCardVehicle(cardVehicleId, cardCd = null, vehicleTypeId, vehicleNo, vehicleColor = null, vehicleName, startTime, endTime, note = null, custId = null, imageLinks = null) {
        const cardSet = {
            cardVehicleId, cardCd, vehicleTypeId, vehicleNo, vehicleColor, vehicleName, serviceId: 0,
            startTime, endTime, note, status: 0, custId, imageLinks: imageLinks
        };
        return this.http.put(`${apiHrmServer}/api/v2/cardvehicle/SetServiceVehicle`, cardSet, this.options);
    }
    setCardVip(cardCd, employeeId, cardName) {
        const card = {
            employeeId: employeeId, cardName, cardCd,
            issueDate: '', expireDate: '', cardTypeId: 0, isVIP: true
        };
        return this.http.post(`${apiShome}/api/v1/shome/SetCardVip`, card, this.options);
    }
    unlockCardNV(cardCd) {
        const card = { cardCd, status: 0 };
        return this.http.put(`${apiHrmServer}/api/v2/cardvehicle/SetCardLock`, card, this.options);
    }
    deleteCard(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/cardvehicle/DeleteCard?` + queryParams, this.options);
    }
    GetElevatorFloorPage(filter, offset, pagesize, projectCd, buildCd, buildZone) {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetElevatorFloorPage?` +
            `filter=${filter}&` +
            `offSet=${offset}&` +
            `pageSize=${pagesize}&` +
            `projectCd=${projectCd}&` +
            `buildCd=${buildCd}&` +
            `buildZone=${buildZone}&`, this.options);
    }
    setMasElevatorFloor(params) {
        return this.http
            .post(`${apiShome}/api/v1/shome/SetMasElevatorFloor`, params, this.options);
    }
    getFloorTypeByBuildCd(buildCd) {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetFloorTypeByBuildCd?` +
            `buildCd=${buildCd}&`, this.options);
    }
    getBuildByProjectCd(projectCd) {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetBuildCdByProjectCd?` +
            `projectCd=${projectCd}&`, this.options);
    }
    setMasElevatorDevice(params) {
        return this.http
            .post(`${apiShome}/api/v1/shome/SetMasElevatorDevice`, params, this.options);
    }
    getFoorInfoGo(filter, projectCd, buildZone, buildCd, hardWareId, offset, pagesize) {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetFoorInfoGo?` +
            `filter=${filter}&` +
            `projectCd=${projectCd}&` +
            `buildZone=${buildZone}&` +
            `buildCd=${buildCd}&` +
            `hardWareId=${hardWareId}&` +
            `offSet=${offset}&` +
            `pageSize=${pagesize}`, this.options);
    }
    addRoleCard(mEcard) {
        return this.http.post(`${apiShome}/api/v1/shome/SetMasElevatorCard`, mEcard, this.options);
    }
    getElevatorCardRole() {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetElevatorCardRole`, this.options);
    }
    getCardTypeList() {
        return this.http.get(`${apiBaseUrl}/api/v2/customer/GetCardTypeList`, this.options);
    }
    getProjects() {
        return this.http
            .get(`${apiBaseUrl}/api/v1/shome/GetProjects`, this.options);
    }
    getElevatorFloors(buildCd) {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetElevatorFloors?` +
            `buildCd=${buildCd}`, this.options);
    }
    deleteRoleCard(MasECid) {
        return this.http
            .delete(`${apiShome}/api/v1/shome/DeleteMasElevatorCard?MasECid=${MasECid}`, this.options);
    }
    getBuildZoneByBuildCd(projectCd, buildCd) {
        return this.http
            .get(`${apiShome}/api/v1/shome/GetBuildZoneByBuildCd?` +
            `buildCd=${buildCd}&projectCd=${projectCd}`, this.options);
    }
    getEmployeeCardInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/cardvehicle/GetEmployeeCardInfo?` + queryParams, this.options);
    }
    setEmployeeCardInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/cardvehicle/SetEmployeeCardInfo`, queryParams, this.options);
    }
    getParameterPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/work/GetParameterPage?` + queryParams, this.options);
    }
    getInvParameter(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/work/GetInvParameter?` + queryParams, this.options);
    }
    setInvParameter(params) {
        return this.http.post(`${apiHrmServer}/api/v2/work/SetInvParameter`, params, this.options);
    }
    // AnnualLeave
    getAnnualLeavePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/annualleave/GetAnnualLeavePage?` + queryParams, this.options);
    }
    getAnnualAddPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/annualleave/GetAnnualAddPage?` + queryParams, this.options);
    }
    getAnnualAddInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/annualleave/GetAnnualAddInfo?` + queryParams, this.options);
    }
    setAnnualAddInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/annualleave/SetAnnualAddInfo`, queryParams, this.options);
    }
    setAnnualAddOrgInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/annualleave/SetAnnualAddOrgInfo`, queryParams, this.options);
    }
    delAnnualAddInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/annualleave/DelAnnualAddInfo?` + queryParams, this.options);
    }
    exportAnnualleave(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/annualleave/ExportAnnualleave?${queryParams}`, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            }),
            responseType: "blob"
        });
    }
    getLeaveRequestMonthInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/annualleave/GetLeaveRequestMonthInfo?` + queryParams, this.options);
    }
    annualleaveImport(data) {
        const customOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue()
            })
        };
        return this.http.post(`${apiHrmServer}/api/v2/annualleave/Import`, data, customOptions);
    }
    // TimeLine
    getStatusTimelineEmployee() {
        return this.http.get(`${apiHrmServer}/api/v2/employee/GetStatusTimelineEmployee`, this.options);
    }
    getStatusTimelineTerminate() {
        return this.http.get(`${apiHrmServer}/api/v2/terminate/GetStatusTimelineTerminate`, this.options);
    }
    // Holiday
    getHolidayPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/holiday/GetHolidayPage?` + queryParams, this.options);
    }
    holidayPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/holiday/HolidayPage?` + queryParams, this.options);
    }
    getHolidayInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/holiday/GetHolidayInfo?` + queryParams, this.options);
    }
    getHolidayDate(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/holiday/GetHolidayDate?` + queryParams, this.options);
    }
    setHolidayInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v1/holiday/SetHolidayInfo`, queryParams, this.options);
    }
    delHoliday(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/holiday/DelHoliday?` + queryParams, this.options);
    }
    deleteHoliday(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/holiday/DeleteHoliday?` + queryParams, this.options);
    }
    setHolidayAdd(params) {
        return this.http.post(`${apiHrmServer}/api/v1/holiday/SetHolidayAdd`, params, this.options);
    }
    setHolidayCreate(params) {
        return this.http.post(`${apiHrmServer}/api/v1/holiday/SetHolidayCreate`, params, this.options);
    }
    contractImport(data) {
        const customOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue()
            })
        };
        return this.http.post(`${apiHrmServer}/api/v2/contract/Import`, data, customOptions);
    }
    setListContractStatus(params) {
        return this.http.put(`${apiHrmServer}/api/v2/contract/SetListContractStatus`, params, this.options);
    }
    getDashboardInfo(params) {
        // return this.http.get<any>(`${apiHrmServer}/api/v2/dashboard/GetDashboardInfo?` + queryParams, this.options)
        return this.http.post(`${apiHrmServer}/api/v2/dashboard/GetDashboardInfo`, params, this.options);
    }
    getFormPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/form/GetFormPage?` + queryParams, this.options);
    }
    getFormInfo(formId) {
        return this.http.get(`${apiHrmServer}/api/v2/form/GetFormInfo?formId=${formId}`, this.options);
    }
    setFormInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v2/form/SetFormInfo`, data, this.options);
    }
    delFormInfo(formId) {
        return this.http.delete(`${apiHrmServer}/api/v2/form/DelFormInfo?formId=${formId}`, this.options);
    }
    getFormTypePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/form/GetFormTypePage?` + queryParams, this.options);
    }
    getFormTypes(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/form/GetFormTypes?` + queryParams, this.options);
    }
    getFormTypeInfo(formTypeId) {
        return this.http.get(`${apiHrmServer}/api/v2/form/GetFormTypeInfo?formTypeId=${formTypeId}`, this.options);
    }
    setFormTypeInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v2/form/SetFormTypeInfo`, data, this.options);
    }
    delFormTypeInfo(formId) {
        return this.http.delete(`${apiHrmServer}/api/v2/form/DelFormTypeInfo?formId=${formId}`, this.options);
    }
    employeeImport(data) {
        const customOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue()
            })
        };
        return this.http.post(`${apiHrmServer}/api/v2/employee/Import`, data, customOptions);
    }
    ImportVehicle(data) {
        const customOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue()
            })
        };
        return this.http.post(`${apiHrmServer}/api/v2/cardvehicle/ImportVehicle`, data, customOptions);
    }
    importCards(data) {
        const customOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue()
            })
        };
        return this.http.post(`${apiHrmServer}/api/v2/cardvehicle/ImportCards`, data, customOptions);
    }
    uploadDrive(data) {
        const customOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            })
        };
        return this.http.post(`${apiHrmServer}/api/v2/form/UploadDrive`, data, customOptions);
    }
    getTimekeepingWifiPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/timekeeping/GetTimekeepingWifiPage?` + queryParams, this.options);
    }
    getTimekeepingWifiInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/timekeeping/GetTimekeepingWifiInfo?${queryParams}`, this.options);
    }
    setTimekeepingWifiInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v1/timekeeping/SetTimekeepingWifiInfo`, data, this.options);
    }
    delTimekeepingWifiInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/timekeeping/DelTimekeepingWifiInfo?${queryParams}`, this.options);
    }
    // quá trình thay đổi lương
    getHrmPayrollRecordPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollRecord/GetHrmPayrollRecordPage?` + queryParams, this.options);
    }
    getHrmPayrollRecordInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollRecord/GetHrmPayrollRecordInfo?${queryParams}`, this.options);
    }
    setHrmPayrollRecordInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v1/payrollRecord/SetHrmPayrollRecordInfo`, data, this.options);
    }
    delHrmPayrollRecord(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/payrollRecord/DelHrmPayrollRecord?${queryParams}`, this.options);
    }
    timekeepingDeviceStatus(data) {
        return this.http.post(`${apiHrmServer}/api/v1/timekeeping/TimekeepingDeviceStatus`, data, this.options);
    }
    // new qt thay doi luong
    getSalaryInfoPageDevM(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/salaryInfo/GetSalaryInfoPage?` + queryParams, this.options);
    }
    getSalaryInfoFilter() {
        return this.http.get(`${apiHrmServer}/api/v1/salaryInfo/GetSalaryInfoFilter`, this.options);
    }
    getSalaryInfoDevM(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/salaryInfo/GetSalaryInfo?` + queryParams, this.options);
    }
    getSalaryInfoPageByEmpId(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/salaryInfo/GetSalaryInfoPageByEmpId?` + queryParams, this.options);
    }
    setSalaryInfoDevM(data) {
        return this.http.post(`${apiHrmServer}/api/v1/salaryInfo/SetSalaryInfo`, data, this.options);
    }
    delSalaryInfoDevM(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/salaryInfo/DelSalaryInfo?${queryParams}`, this.options);
    }
    // loai bang luong
    getHrmPayrollTypePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollType/GetHrmPayrollTypePage?` + queryParams, this.options);
    }
    getHrmPayrollTypeInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollType/GetHrmPayrollTypeInfo?${queryParams}`, this.options);
    }
    setHrmPayrollTypeInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v1/payrollType/SetHrmPayrollTypeInfo`, data, this.options);
    }
    delHrmPayrollType(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/payrollType/DelHrmPayrollType?${queryParams}`, this.options);
    }
    getHrmMeetingPerson(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/meeting/GetHrmMeetingPerson?${queryParams}`, this.options);
    }
    getHrmFormsPerson(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/forms/GetHrmFormsPerson?${queryParams}`, this.options);
    }
    // Forms
    getFormGeneral(queryParams, urlLink) {
        return this.http.get(`${apiHrmServer}/api/v2/forms/${urlLink}?${queryParams}`, this.options);
    }
    getFormPersonal(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/forms/GetFormPersonal?${queryParams}`, this.options);
    }
    getFormsInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/forms/getFormsInfo?${queryParams}`, this.options);
    }
    setFormsInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/forms/SetFormsInfo`, queryParams, this.options);
    }
    setFormsTypeInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/forms/SetFormsTypeInfo`, queryParams, this.options);
    }
    shareToApp(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/forms/ShareToApp?` + queryParams, null, this.options);
    }
    uploadDrives(data) {
        const customOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            })
        };
        return this.http.post(`${apiHrmServer}/api/v2/forms/UploadDrive`, data, customOptions);
    }
    delFormsInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/forms/DelFormsInfo?${queryParams}`, this.options);
    }
    delFormsTypeInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/forms/DelFormsTypeInfo?${queryParams}`, this.options);
    }
    getFormsTypePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/forms/GetFormsTypePage?${queryParams}`, this.options);
    }
    getFormsTypes(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/forms/GetFormsTypes?${queryParams}`, this.options);
    }
    getFormsTypeInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/forms/GetFormsTypeInfo?${queryParams}`, this.options);
    }
    getCompaniesByOrganize(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/compay/GetCompaniesByOrganize?` + queryParams, this.options);
    }
    // thành phần lương
    getHrmPayrollAttributePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollAttribute/GetHrmPayrollAttributePage?` + queryParams, this.options);
    }
    getHrmPayrollAttributeInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollAttribute/GetHrmPayrollAttributeInfo?${queryParams}`, this.options);
    }
    setHrmPayrollAttributeInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v1/payrollAttribute/SetHrmPayrollAttributeInfo`, data, this.options);
    }
    delHrmPayrollAttribute(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/payrollAttribute/DelHrmPayrollAttribute?${queryParams}`, this.options);
    }
    getFloorNo() {
        return this.http.get(`${apiHrmServer}/api/v2/meeting/GetFloorNo`, this.options);
    }
    checkTimeHrm(data) {
        return this.http.post(`${apiHrmServer}/api/v2/meeting/CheckTimeHrm`, data, this.options);
    }
    getHrmCardByCustId(query) {
        return this.http.get(`${apiHrmServer}/api/v2/cardvehicle/GetHrmCardByCustId?${query}`, this.options);
    }
    // tính lương
    // bang luong
    getPayrollInfoPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payroll/GetPayrollInfoPage?` + queryParams, this.options);
    }
    getPayrollInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payroll/GetPayrollInfo?${queryParams}`, this.options);
    }
    setPayrollInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v1/payroll/SetPayrollInfo`, data, this.options);
    }
    delPayrollInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/payroll/DelPayrollInfo?${queryParams}`, this.options);
    }
    getPayrollComponentPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payroll/GetPayrollComponentPage?${queryParams}`, this.options);
    }
    getPayrollComponentInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payroll/GetPayrollComponentInfo?${queryParams}`, this.options);
    }
    setPayrollComponentInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v1/payroll/SetPayrollComponentInfo`, queryParams, this.options);
    }
    delPayrollComponent(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/payroll/DelPayrollComponent?${queryParams}`, this.options);
    }
    // tham số
    getPayrollParamPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollparam/GetPayrollParamPage?` + queryParams, this.options);
    }
    getPayrollParam(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollparam/GetPayrollParam?${queryParams}`, this.options);
    }
    setPayrollParam(data) {
        return this.http.post(`${apiHrmServer}/api/v1/payrollparam/SetPayrollParam`, data, this.options);
    }
    delPayrollParam(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/payrollparam/DelPayrollParam?${queryParams}`, this.options);
    }
    // thành phần lương
    getComponentPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollComponent/GetComponentPage?` + queryParams, this.options);
    }
    getComponentInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollComponent/GetComponentInfo?${queryParams}`, this.options);
    }
    setComponentInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v1/payrollComponent/SetComponentInfo`, data, this.options);
    }
    delComponent(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/payrollComponent/DelComponent?${queryParams}`, this.options);
    }
    // cap bac luong
    getPayrollBasePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollbase/GetPayrollBasePage?` + queryParams, this.options);
    }
    getPayrollBaseInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollbase/GetPayrollBaseInfo?${queryParams}`, this.options);
    }
    setPayrollBaseInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v1/payrollbase/SetPayrollBaseInfo`, data, this.options);
    }
    delPayrollBase(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/payrollbase/DelPayrollBase?${queryParams}`, this.options);
    }
    getPayrollRankPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollbase/GetPayrollRankPage?${queryParams}`, this.options);
    }
    getPayrollRankInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/payrollbase/GetPayrollRankInfo?${queryParams}`, this.options);
    }
    delPayrollRank(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/payrollbase/DelPayrollRank?${queryParams}`, this.options);
    }
    setPayrollRankInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v1/payrollbase/SetPayrollRankInfo`, queryParams, this.options);
    }
    employeeGetTerminatePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employee/GetTerminatePage?` + queryParams, this.options);
    }
    recruitAgain(query, data = null) {
        return this.http.post(`${apiHrmServer}/api/v2/employee/RecruitAgain?` + query, data, this.options);
    }
    getUserOrganizeRole() {
        return this.http.get(`${apiHrmServer}/api/v1/user/GetUserOrganize`, this.options);
    }
    // tuye dung -> mail
    getRecruitSendMailPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetRecruitSendMailPage?` + queryParams, this.options);
    }
    getRecruitMailPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetRecruitMailPage?` + queryParams, this.options);
    }
    getRecruitMailInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetRecruitMailInfo?${queryParams}`, this.options);
    }
    setRecruitMailInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v1/recruitment/SetRecruitMailInfo`, data, this.options);
    }
    delRecruitMailInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/recruitment/DelRecruitMailInfo?${queryParams}`, this.options);
    }
    updateCandidatesPotential(queryParams, data = null) {
        return this.http.post(`${apiHrmServer}/api/v1/recruitment/UpdateCandidatesPotential?${queryParams}`, data, this.options);
    }
    // vong tuyen dung
    getRecruitRoundPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetRecruitRoundPage?` + queryParams, this.options);
    }
    getRecruitRoundInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetRecruitRoundInfo?${queryParams}`, this.options);
    }
    setRecruitRoundInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v1/recruitment/SetRecruitRoundInfo`, data, this.options);
    }
    delRecruitRoundInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/recruitment/DelRecruitRoundInfo?${queryParams}`, this.options);
    }
    getRecruitRoundTitles(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetRecruitRoundTitles?` + queryParams, this.options);
    }
    // nguon tuyen dung
    getRecruitSourcePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetRecruitSourcePage?` + queryParams, this.options);
    }
    getRecruitSourceInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v1/recruitment/GetRecruitSourceInfo?${queryParams}`, this.options);
    }
    setRecruitSourceInfo(data) {
        return this.http.post(`${apiHrmServer}/api/v1/recruitment/SetRecruitSourceInfo`, data, this.options);
    }
    delRecruitSourceInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v1/recruitment/DelRecruitSourceInfo?${queryParams}`, this.options);
    }
    //EmpTrain
    getEmpQualification(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/GetEmpQualification?` + queryParams, this.options);
    }
    getEmpWorkedPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/GetEmpWorkedPage?` + queryParams, this.options);
    }
    getEmpWorked(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/GetEmpWorked?` + queryParams, this.options);
    }
    setEmpQualification(data) {
        return this.http.post(`${apiHrmServer}/api/v2/employeetrain/SetEmpQualification`, data, this.options);
    }
    setEmpWorked(data) {
        return this.http.post(`${apiHrmServer}/api/v2/employeetrain/SetEmpWorked`, data, this.options);
    }
    delEmpWorked(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/employeetrain/DelEmpWorked?${queryParams}`, this.options);
    }
    getEducationPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/GetEmpEducationPage?` + queryParams, this.options);
    }
    addEducation(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/AddEducation?` + queryParams, this.options);
    }
    getEmpEducation(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/GetEmpEducation?` + queryParams, this.options);
    }
    getTrainningPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/GetTrainningPage?` + queryParams, this.options);
    }
    addTraining(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/AddTraining?` + queryParams, this.options);
    }
    delEmpEducation(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/employeetrain/DelEmpEducation?` + queryParams, this.options);
    }
    setEmpEducation(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/employeetrain/SetEmpEducation`, queryParams, this.options);
    }
    getSkillPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/GetSkillPage?` + queryParams, this.options);
    }
    addSkill(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/AddSkill?` + queryParams, this.options);
    }
    getCertificatePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/GetCertificatePage?` + queryParams, this.options);
    }
    addCertificate(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/AddCertificate?` + queryParams, this.options);
    }
    getTrainFile(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/GetTrainFile?` + queryParams, this.options);
    }
    setTrainFile(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/employeetrain/SetTrainFile`, queryParams, this.options);
    }
    delTrainFile(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/employeetrain/DelTrainFile?` + queryParams, this.options);
    }
    getEmpTrainPage(queryParams, linkurl) {
        return this.http.get(`${apiHrmServer}/api/v2/employeetrain/${linkurl}?` + queryParams, this.options);
    }
    // EmpProfile
    getEmpProfile(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeeprofile/GetEmpProfile?` + queryParams, this.options);
    }
    setEmpProfile(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/employeeprofile/SetEmpProfile`, queryParams, this.options);
    }
    getEmpIdcardPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeeprofile/GetEmpIdcardPage?` + queryParams, this.options);
    }
    lockEmployee(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/employeeprofile/LockEmployee`, queryParams, this.options);
    }
    unLockEmployee(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/employeeprofile/UnLockEmployee`, queryParams, this.options);
    }
    setEmployeeOpen(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/employeeprofile/SetEmployeeOpen`, queryParams, this.options);
    }
    setEmployeeApprove(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/employeeprofile/SetEmployeeApprove`, queryParams, this.options);
    }
    getEmpRecordPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeeprofile/GetEmpRecordPage?` + queryParams, this.options);
    }
    addEmpRecord(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeeprofile/AddEmpRecord?` + queryParams, this.options);
    }
    empproFileGetEmpAttach(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeeprofile/GetEmpAttach?` + queryParams, this.options);
    }
    empproFileSetEmpAttach(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/employeeprofile/SetEmpAttach`, queryParams, this.options);
    }
    empproFileDelEmpAttach(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/employeeprofile/DelEmpAttach?` + queryParams, this.options);
    }
    getEmpPersonalPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeeprofile/GetEmpPersonalPage?` + queryParams, this.options);
    }
    addEmpPersonal(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeeprofile/AddEmpPersonal?` + queryParams, this.options);
    }
    getEmpContactPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeeprofile/GetEmpContactPage?` + queryParams, this.options);
    }
    // ct hồ sơ ns - thông tin cá nhân - lien hệ
    empProfileGetEmpContact(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employeeprofile/GetEmpContact?` + queryParams, this.options);
    }
    empProfileSetEmpContact(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/employeeprofile/SetEmpContact`, queryParams, this.options);
    }
    delEmpContact(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/employeeprofile/DelEmpContact?` + queryParams, this.options);
    }
    // EmpWorking
    getEmpWorkingPageByEmpId(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/working/GetEmpWorkingPageByEmpId?` + queryParams, this.options);
    }
    getEmpProcessPageByEmpId(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/working/GetEmpProcessPageByEmpId?` + queryParams, this.options);
    }
    getEmpWorkJob(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/working/GetEmpWorkJob?` + queryParams, this.options);
    }
    getEmpWorking(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/working/GetEmpWorking?` + queryParams, this.options);
    }
    getEmpProcessInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/working/GetEmpProcessInfo?` + queryParams, this.options);
    }
    setEmpWorking(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/working/SetEmpWorking`, queryParams, this.options);
    }
    delEmpWorking(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/working/DelEmpWorking?` + queryParams, this.options);
    }
    getEmpWorkingPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/working/GetEmpWorkingPage?` + queryParams, this.options);
    }
    setEmpWorkingChanges(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/working/SetEmpWorkingChanges`, queryParams, this.options);
    }
    setEmpProcessInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/working/SetEmpProcessInfo`, queryParams, this.options);
    }
    delEmpProcessInfo(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/working/DelEmpProcessInfo?` + queryParams, this.options);
    }
    getEmpWorkingFilter() {
        return this.http.get(`${apiHrmServer}/api/v2/working/GetEmpWorkingFilter`, this.options);
    }
    // deleteEmployee(queryParams): Observable<any> {
    //   return this.http.delete<any>(`${apiHrmServer}/api/v2/employeeprofile/DeleteEmployee?` + queryParams, this.options)
    // }
    // contract
    getEmpByContract(query) {
        return this.http.get(`${apiHrmServer}/api/v2/contract/GetEmpByContract?` + query, this.options);
    }
    getObjects(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/category/GetObjects?` + queryParams, this.options);
    }
    //EmpInsurance
    getEmployeeChangeInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/employee/GetEmployeeChangeInfo?` + queryParams, this.options);
    }
    getEmpByInsurance(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/empInsurance/GetEmpByInsurance?` + queryParams, this.options);
    }
    setEmpByInsuranceInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/empInsurance/SetEmpByInsuranceInfo`, queryParams, this.options);
    }
    getEmpAttactInsurPage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/empInsurance/GetEmpAttactPage?` + queryParams, this.options);
    }
    getEmpAttachInsur(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/empInsurance/GetEmpAttach?` + queryParams, this.options);
    }
    setEmpAttachInsur(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/empInsurance/SetEmpAttach`, queryParams, this.options);
    }
    delEmpAttachInsur(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/empInsurance/DelEmpAttach?` + queryParams, this.options);
    }
    getEmpInsurancePage(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/empInsurance/GetEmpInsurancePage?` + queryParams, this.options);
    }
    getEmpInsuranceInfo(queryParams) {
        return this.http.get(`${apiHrmServer}/api/v2/empInsurance/GetEmpInsuranceInfo?` + queryParams, this.options);
    }
    setEmpInsuranceInfo(queryParams) {
        return this.http.post(`${apiHrmServer}/api/v2/empInsurance/SetEmpInsuranceInfo`, queryParams, this.options);
    }
    delEmpInsurance(queryParams) {
        return this.http.delete(`${apiHrmServer}/api/v2/empInsurance/DelEmpInsurance?` + queryParams, this.options);
    }
    insurSetEmployeeChange(params) {
        return this.http.post(`${apiHrmServer}/api/v2/employeejob/SetEmployeeChange`, params, this.options);
    }
    getFilter(url) {
        return this.http.get(`${apiHrmServer + url} `, this.options);
    }
}
ApiHrmService.ɵfac = function ApiHrmService_Factory(t) { return new (t || ApiHrmService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService)); };
ApiHrmService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: ApiHrmService, factory: ApiHrmService.ɵfac });


/***/ }),

/***/ 90579:
/*!******************************************************!*\
  !*** ./src/app/services/api-hrm/apihrmv2.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiHrmV2Service": () => (/* binding */ ApiHrmV2Service)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 83981);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 56769);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 2014);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 62489);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 18260);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../auth.service */ 36636);
/* harmony import */ var numeral__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! numeral */ 89714);
/* harmony import */ var numeral__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(numeral__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 14001);









const apiBaseUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiBase;
const apiHrmServer = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiHrmBase;
const apiCore = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiCoreBase;
const apiShome = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiShomeBase;
class ApiHrmV2Service {
    constructor(httpClient, authService) {
        this.httpClient = httpClient;
        this.authService = authService;
        this.options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
                'Content-Type': 'application/json',
            })
        };
    }
    getOrganizeTreeV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/organize/GetOrganizeTree?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getOrganizationsV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/organize/GetOrganizations?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(item => {
                    return {
                        label: item.organizationName,
                        value: `${item.organizeId}`,
                        name: item.organizationName,
                        code: `${item.organizeId}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getWorkTimesV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/category/GetWorkTimes?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(item => {
                    return {
                        label: item.work_times + '-' + item.work_cd,
                        value: item.work_cd
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getEmployeePageV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/employee/GetEmployeePage?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.dataList.data.map(item => {
                    return {
                        label: item.full_name + '-' + item.phone1,
                        value: item.empId
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getEmployeePageCustIdV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/employee/GetEmployeePage?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.dataList.data.map(item => {
                    return {
                        label: item.full_name + '-' + item.phone1,
                        value: item.CustId
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getWorkShiftsV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/category/GetWorShifts?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(item => {
                    return {
                        name: item.shift_name + '-' + item.shift_cd,
                        code: item.shift_cd,
                        label: item.shift_name + '-' + item.shift_cd,
                        value: item.shift_cd
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getWorktimeListV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/worktime/GetWorktimeList?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return { label: d.work_times + '-' + d.work_name, value: d.work_cd };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getBankListV2(field_name) {
        return this.httpClient.get(`${apiCore}/api/v1/coreaccount/GetBankList`, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.bank_name + '-' + d.bank_code,
                        value: d.bank_code
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getAgentLeadersV2(queryParams, field_name) {
        return this.httpClient.get(`${apiCore}/api/v1/coreagent/getAgentLeaders?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return { label: d.fullName, value: d.saler_id };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getOrgPositionsV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/organize/GetOrgPositions?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return { label: d.positionName, value: d.positionCd };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getPositionListV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/position/GetPositionList?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return { label: d.positionName, value: d.positionId.toUpperCase() };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getPositionTitlesV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/position/GetPositionTitles?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return { label: d.positionTitle, value: d.positionTitleId };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getCompanyListV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/compay/GetCompanyList?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return { label: d.companyName, value: d.companyId };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getCompaniesByOrganize(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/compay/GetCompaniesByOrganize?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return { label: d.companyName, value: d.companyId };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getEmpLeadersV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/employee/GetEmpLeaders?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.fullName + ' [' + d.job_name + '-' + d.org_name + '] - ' + d.phone,
                        value: d.empId
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getAccountPageV2(queryParams, field_name) {
        return this.httpClient.get(`${apiCore}/api/v1/coreaccount/GetAccountPage?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.dataList.data.map(d => {
                    return {
                        label: d.acc_no + '-' + d.link_acc_bank,
                        value: d.acc_no
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getJobsV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/category/GetJobs?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.job_name,
                        value: `${d.jobId.toUpperCase()}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getCompaniesByOrganizeV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/compay/GetCompaniesByOrganize?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.companyName,
                        value: `${d.companyId}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getEmployeeSearchV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/employee/GetEmployeeSearch?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.fullName + '-' + d.phone,
                        value: `${d.empId}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getHrmPayrollTypePageV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/payrollType/GetHrmPayrollTypePage?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.dataList.data.map(d => {
                    return {
                        label: `${d.name}`,
                        value: `${d.id}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getUserByPushV2(queryParams, field_name) {
        return this.httpClient.put(`${apiHrmServer}/api/v1/notify/GetUserByPush?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.fullName + '-' + d.phone,
                        value: `${d.userId}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getNotifyRefListV2(field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/notify/GetNotifyRefList`, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.refName,
                        value: `${d.source_ref}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getContractTypesV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/contracttype/GetContractTypes?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.contractTypeName,
                        value: `${d.contractTypeId}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getSalaryTypesV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/salary/GetSalaryTypes?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.salary_type_name,
                        value: `${d.salary_type}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getSalaryBasesV2(field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/salary/GetSalaryBases`, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.base_name + ' [' + numeral__WEBPACK_IMPORTED_MODULE_2__(d.base_amt).format('0,0') + ']',
                        value: `${d.base_id}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getUsersByAdminV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/user/getUsersByAdmin?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: `${d.fullName} [${d.loginName}]`,
                        value: d.userId
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getVacancyPageV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/recruitment/GetVacancyPage?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.dataList.data.map(d => {
                    return {
                        label: `${d.job_name}`,
                        value: `${d.vacancyId}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('GetVacancyPage not found!', error);
        }));
    }
    getPositionTitles(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/recruitment/GetPositionTitles?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: `${d.vacancy_name}`,
                        value: `${d.vacancyId}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('getPositionTitles not found!', error);
        }));
    }
    getEducationsV2(field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/category/GetEducations`, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: `${d.educationName}`,
                        value: `${d.educationId}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getWorkplacesV2(field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/category/GetWorkplaces`, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: `${d.workplaceName}`,
                        value: `${d.workplaceId}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getProductProjsV2(field_name) {
        return this.httpClient.get(`${apiCore}/api/v1/coreagent/GetProductProjs`, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: `${d.sub_prod_name}`,
                        value: d.sub_prod_cd
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getMeetRoomsV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/meeting/GetMeetRooms?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: `${d.room_name}`,
                        value: `${d.roomId}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getObjectListV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/category/GetObjectList?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: `${d.objName}`,
                        value: `${d.objValue}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getVehicleTypesV2(field_name) {
        return this.httpClient.get(`${apiShome}/api/v1/shome/GetVehicleTypes`, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.vehicleTypeName,
                        value: `${d.vehicleTypeId}`
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getLeaveReasonsV2(field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/leave/GetLeaveReasons`, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.name,
                        value: d.code
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getFloorNoV2(field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/meeting/GetFloorNo`, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: 'Tầng' + ' ' + d.floorNo,
                        value: d.floorNo
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getHrmMeetingPersonV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/meeting/GetHrmMeetingPerson?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.meetingProperties };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getHrmFormsPersonV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/forms/GetHrmFormsPerson?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.meetingProperties };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getRoleTypesV2(field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/userrole/GetRoleTypes`, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.name,
                        value: d.id
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getEatingInputV2(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/eating/GetEatingInput?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.eatingProperties.map(d => {
                    return {
                        name: d.food_name,
                        code: d.menu_date
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getBlockByOrganize(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/organize/GetBlockByOrganize?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.org_name,
                        value: d.orgId
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getBanByOrganize(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/organize/GetBanByOrganize?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.org_name,
                        value: d.orgId
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getDepartmentByOrganize(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/organize/GetDepartmentByOrganize?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.org_name,
                        value: d.orgId
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getGroupByOrganize(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/organize/GetGroupByOrganize?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.org_name,
                        value: d.orgId
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getTeamByOrganize(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/organize/GetTeamByOrganize?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.org_name,
                        value: d.orgId
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getPayrollAppInfoPage(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/payrollAppInfo/GetPayrollAppInfoPage?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.dataList.data.map(d => {
                    return {
                        label: d.app_info_name,
                        value: d.appInfoId
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getCompaniesByUserOrganize(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v2/compay/GetCompaniesByUserOrganize?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        label: d.companyName,
                        value: d.companyId.toUpperCase()
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getCustObjectListV2(url, field_name) {
        return this.httpClient.get(`${apiHrmServer}` + url, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            if (repon.status === 'success' && repon.data && repon.data.length > 0) {
                return {
                    key: field_name, result: repon.data.map(item => {
                        return Object.assign({ label: item.name, name: item.name, code: item.value }, item);
                    })
                };
            }
            else {
                return { key: field_name, result: [] };
            }
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getCustObjectListTreeV2(url, field_name) {
        return this.httpClient.get(`${apiHrmServer}` + url, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    getAutocompleteLinkApiV2(url, field_name) {
        return this.httpClient.get(`${apiHrmServer}` + url, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            return { key: field_name, result: repon.data.map(d => {
                    return {
                        name: d.fullName + '-' + d.code + '-' + d.phone,
                        code: d.empId
                    };
                }) };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
    // danh sách cty trả lương
    getUserCompanies(queryParams, field_name) {
        return this.httpClient.get(`${apiHrmServer}/api/v1/user/GetUserCompanies?` + queryParams, this.options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((repon) => {
            let data = repon.data.filter(d => d.companyId != "00000000-0000-0000-0000-000000000000");
            return { key: field_name, result: data.map(d => {
                    return {
                        label: d.companyName,
                        value: d.companyId.toUpperCase()
                    };
                })
            };
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)('Capital not found!');
        }));
    }
}
ApiHrmV2Service.ɵfac = function ApiHrmV2Service_Factory(t) { return new (t || ApiHrmV2Service)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService)); };
ApiHrmV2Service.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjectable"]({ token: ApiHrmV2Service, factory: ApiHrmV2Service.ɵfac });


/***/ }),

/***/ 67118:
/*!*****************************************!*\
  !*** ./src/app/services/api.service.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiService": () => (/* binding */ ApiService)
/* harmony export */ });
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 18260);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth.service */ 36636);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 83981);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 14001);







const apiBaseUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiBase;
const apiHrmBase = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiHrmBase;
const apiHrmConfig = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiHrmConfig;
const apiCoreBaseUrl = 'https://apicore.sunshinegroup.vn';
class ApiService {
    constructor(http, authService) {
        this.http = http;
        this.authService = authService;
        this.options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
                'Content-Type': 'application/json',
            })
        };
    }
    getListMenuByUserId(userId, webId) {
        return this.http
            .get(`${apiBaseUrl}/api/v1/user/ClientMenuGetListByUserId?` +
            `userId=${userId}&webId=${webId}`, this.options);
    }
    getCustomerInfoByID(custId) {
        return this.http
            .get(`${apiBaseUrl}/api/v2/customer/GetCustomerInfoByID?` +
            `custId=${custId}`, this.options);
    }
    getUsersByCust(paramsQuery) {
        return this.http
            .get(`${apiBaseUrl}/api/v1/user/GetUsersByCust?` + paramsQuery, this.options);
    }
    getEmployeeList(paramsQuery) {
        return this.http
            .get(`${apiBaseUrl}/api/v2/employee/GetEmployeeList?` + paramsQuery, this.options);
    }
    getManagerPage() {
        return this.http
            .get(`${apiCoreBaseUrl}/api/v1/coreuser/GetManagerPage?filter=&offSet=null&pageSize=null`, this.options);
    }
    setCustProfileToSubmit(params) {
        return this.http
            .put(`${apiCoreBaseUrl}/api/v1/customer/SetCustProfileToSubmit`, params, this.options);
    }
    getCustProfileFields(params) {
        return this.http.post(`${apiCoreBaseUrl}/api/v1/customer/GetCustProfileFields`, params, this.options);
    }
    getProfileById(loginName) {
        return this.http.get(`${apiCoreBaseUrl}/api/v1/coreuser/GetProfileById?loginName=${loginName}`, this.options);
    }
    getCustObjectList(fieldObject) {
        return this.http.get(`${apiCoreBaseUrl}/api/v1/customer/GetCustObjectList?fieldObject=${fieldObject}`, this.options);
    }
    setCustProfileFields(params) {
        return this.http.put(`${apiCoreBaseUrl}/api/v1/customer/SetCustProfileFields`, params, this.options);
    }
    setProfileFields(params) {
        return this.http.put(`${apiCoreBaseUrl}/api/v1/coreuser/setProfileFields`, params, this.options);
    }
    setProfileIdcardVerify(params) {
        return this.http.put(`${apiCoreBaseUrl}/api/v1/coreuser/SetProfileIdcardVerify`, params, this.options);
    }
    setMyCustProfile(params) {
        return this.http.put(`${apiCoreBaseUrl}/api/v1/customer/SetMyCustProfile`, params, this.options);
    }
    setCustProfileMeta(params) {
        return this.http.post(`${apiCoreBaseUrl}/api/v1/customer/SetCustProfileMeta`, params, this.options);
    }
    setProfileMeta(params) {
        return this.http.post(`${apiCoreBaseUrl}/api/v1/coreuser/SetProfileMeta`, params, this.options);
    }
    getCustIndividualPage(type, filter, keyType, keyName, custPrivate, offSet, pageSize) {
        console.log('type', keyType);
        console.log('keyName', keyName);
        if (type === 0) {
            const url = 'GetCustIndividualPage';
            return this.http
                .get(`${apiCoreBaseUrl}/api/v1/customer/${url}?` +
                `offSet=${offSet}&` +
                `pageSize=${pageSize}&` +
                `filter=${filter}&` +
                `keyType=${keyType}&` +
                `custPrivate=${custPrivate}&` +
                `keyName=${keyName}`, this.options);
        }
        else {
            const url = 'GetCustCoporatePage';
            return this.http
                .get(`${apiCoreBaseUrl}/api/v1/customer/${url}?` +
                `offSet=${offSet}&` +
                `pageSize=${pageSize}&` +
                `filter=${filter}&` +
                `custPrivate=${custPrivate}&` +
                `keyType=${keyType}&` +
                `keyName=${keyName}`, this.options);
        }
    }
    removeCustProfile(custId) {
        return this.http
            .delete(`${apiCoreBaseUrl}/api/v1/customer/RemoveCustProfile?custId=${custId}`, this.options);
    }
    delProfileMeta(metaId) {
        return this.http
            .delete(`${apiCoreBaseUrl}/api/v1/coreuser/DelProfileMeta?metaId=${metaId}`, this.options);
    }
    getCustomerSearch(custPhone, custPassNo) {
        return this.http
            .get(`${apiBaseUrl}/api/v1/shousing/GetCustomerSearch?` +
            `custPhone=${custPhone}&` +
            `custPassNo=${custPassNo}`, this.options);
    }
    setResetPassword(password) {
        return this.http
            .put(`${apiHrmBase}/api/v1/user/ResetPassword`, password, this.options);
    }
    getCTThueThuNhapCN(id, typeBM) {
        return this.http.get(`${apiHrmBase}/api/v1/report/GetCTThueThuNhapCN?type=xlsx&id=${id}&typeBM=${typeBM}`, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            }),
            responseType: "blob"
        });
    }
    getThuXacNhanThuNhaptype(id) {
        return this.http.get(`${apiHrmBase}/api/v1/report/GetThuXacNhanThuNhap?type=xlsx&id=${id}`, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
                Authorization: this.authService.getAuthorizationHeaderValue(),
            }),
            responseType: "blob"
        });
    }
    getLeaveReasons() {
        return this.http.get(`${apiHrmBase}/api/v2/leave/GetLeaveReasons`, this.options);
    }
    getObjectList(objKey) {
        return this.http.get(`${apiHrmBase}/api/v2/category/GetObjectList?objKey=${objKey}`, this.options);
    }
    getGroupInfo(queryParams) {
        return this.http.get(`${apiHrmBase}/api/v1/config/GetGroupInfo?` + queryParams, this.options);
    }
    setGroupInfo(queryParams) {
        return this.http.post(`${apiHrmBase}/api/v1/config/SetGroupInfo`, queryParams, this.options);
    }
    getGridViewPage(url, queryParams) {
        return this.http.get(`${apiHrmBase}/api/v1/config/${url}?` + queryParams, this.options);
    }
    setGridViewInfo(url, queryParams) {
        return this.http.post(`${apiHrmBase}/api/v1/config/${url}`, queryParams, this.options);
    }
    delFormViewInfo(url, queryParams) {
        return this.http.delete(`${apiHrmBase}/api/v1/config/${url}?` + queryParams, this.options);
    }
    delGridViewInfo(queryParams) {
        return this.http.delete(`${apiHrmBase}/api/v2/config/DelGridViewInfo?` + queryParams, this.options);
    }
    getFormViewPage(queryParams) {
        return this.http.get(`${apiHrmBase}/api/v1/config/GetFormViewPage?` + queryParams, this.options);
    }
    setFormViewInfo(queryParams) {
        return this.http.post(`${apiHrmBase}/api/v1/config/SetFormViewInfo`, queryParams, this.options);
    }
    getMeetRoomForCheck(queryParams) {
        return this.http.get(`${apiHrmBase}/api/v2/meeting/GetMeetRoomForCheck?` + queryParams, this.options);
    }
    // WebMenu
    getUserMenus(query) {
        return this.http.get(`${apiHrmBase}/api/v2/menu/GetUserMenus?` + query, this.options);
    }
    getMenuConfigInfo(query = '') {
        return this.http.get(`${apiHrmBase}/api/v2/menu/GetMenuConfigInfo?` + query, this.options);
    }
    getConfigMenu(query) {
        return this.http.get(`${apiHrmBase}/api/v2/menu/GetConfigMenu?` + query, this.options);
    }
    setConfigMenu(data) {
        return this.http.post(`${apiHrmBase}/api/v2/menu/SetConfigMenu`, data, this.options);
    }
    delConfigMenu(queryParams) {
        return this.http.delete(`${apiHrmBase}/api/v2/menu/DelConfigMenu?` + queryParams, this.options);
    }
    getConfigActionList() {
        return this.http.get(`${apiHrmBase}/api/v2/menu/GetConfigActionList`, this.options);
    }
    setConfigMenuAction(data) {
        return this.http.post(`${apiHrmBase}/api/v2/menu/SetConfigMenuAction`, data, this.options);
    }
    delConfigMenuAction(queryParams) {
        return this.http.delete(`${apiHrmBase}/api/v2/menu/DelConfigMenuAction?` + queryParams, this.options);
    }
    // from hrm config
    clientMenuGetListByUserId(queryParams) {
        return this.http.get(`${apiHrmConfig}/api/v1/webmanager/ClientMenuGetListByUserId?` + queryParams, this.options);
    }
    // UserRole
    setFunctionsToRole(data) {
        return this.http.post(`${apiHrmBase}/api/v2/userrole/SetFunctionsToRole`, data, this.options);
    }
    getRolePermissionInfo(query) {
        return this.http.get(`${apiHrmBase}/api/v2/userrole/GetRolePermissionInfo?` + query, this.options);
    }
    getRolePage(query) {
        return this.http.get(`${apiHrmBase}/api/v2/userrole/GetRolePage?` + query, this.options);
    }
    getRoleInfo(query) {
        return this.http.get(`${apiHrmBase}/api/v2/userrole/GetRoleInfo?` + query, this.options);
    }
    SetRoleInfo(data, query) {
        return this.http.post(`${apiHrmBase}/api/v2/userrole/SetRoleInfo?` + query, data, this.options);
    }
    deleteRole(queryParams) {
        return this.http.delete(`${apiHrmBase}/api/v2/userrole/DeleteRole?` + queryParams, this.options);
    }
    getRoleTypes() {
        return this.http.get(`${apiHrmBase}/api/v2/userrole/GetRoleTypes`, this.options);
    }
}
ApiService.ɵfac = function ApiService_Factory(t) { return new (t || ApiService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService)); };
ApiService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: ApiService, factory: ApiService.ɵfac });


/***/ }),

/***/ 35583:
/*!************************************************!*\
  !*** ./src/app/services/auth-guard.service.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthGuardService": () => (/* binding */ AuthGuardService)
/* harmony export */ });
/* harmony import */ var E_uni_frontend_uni_hrm_sunshineapp_vn_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ 62783);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth.service */ 36636);
/* harmony import */ var _firebase_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./firebase-auth.service */ 16889);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 14001);






class AuthGuardService {
  constructor(authService, firebaseAuthService) {
    this.authService = authService;
    this.firebaseAuthService = firebaseAuthService;
  }

  canActivate(route, state) {
    var _this = this;

    return (0,E_uni_frontend_uni_hrm_sunshineapp_vn_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const isLoginFirebase = _this.firebaseAuthService.authenticated;
      const isLoginSunshine = yield _this.authService.isLoggedIn();

      if (!isLoginSunshine) {
        localStorage.setItem('returnUrl', state.url);

        _this.authService.startAuthentication();
      }

      return isLoginSunshine;
    })();
  }

}

AuthGuardService.ɵfac = function AuthGuardService_Factory(t) {
  return new (t || AuthGuardService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_firebase_auth_service__WEBPACK_IMPORTED_MODULE_2__.FirebaseAuthService));
};

AuthGuardService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: AuthGuardService,
  factory: AuthGuardService.ɵfac
});

/***/ }),

/***/ 32176:
/*!**********************************************!*\
  !*** ./src/app/services/auth-interceptor.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthInterceptor": () => (/* binding */ AuthInterceptor)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 83981);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 56769);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 28433);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 83485);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 62489);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 36636);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-spinner */ 33150);












class AuthInterceptor {
    constructor(auth, router, messageService, spinner) {
        this.auth = auth;
        this.router = router;
        this.messageService = messageService;
        this.spinner = spinner;
    }
    intercept(request, next) {
        let handled = false;
        return next.handle(request)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.retry)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)((returnedError) => {
            let errorMessage = null;
            if (returnedError.error instanceof ErrorEvent) {
                errorMessage = `Error: ${returnedError.error.message}`;
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: `Error: ${returnedError.error.message}` });
            }
            else if (returnedError instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpErrorResponse) {
                //   errorMessage = `Error Status ${returnedError.status}: ${returnedError.error.error} - ${returnedError.error.message}`;
                handled = this.handleServerSideError(returnedError);
            }
            console.error(errorMessage ? errorMessage : returnedError);
            if (!handled) {
                if (errorMessage) {
                    return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(errorMessage);
                }
                else {
                    return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)("Unexpected problem occurred");
                }
            }
            else {
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(returnedError);
            }
        }));
    }
    handleServerSideError(error) {
        let handled = false;
        switch (error.status) {
            case 401:
                // this.auth.signout();
                if (this.auth.isExpired()) {
                    location.reload();
                }
                this.spinner.hide();
                handled = true;
                break;
            case 403:
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: `Error: Quyền truy cập bị từ chối. Vui lòng liên hệ đến Quản trị viên!` });
                this.spinner.hide();
                handled = true;
                break;
            case 500:
                // this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: `Error: Lỗi 500 !` });
                this.spinner.hide();
                handled = true;
                break;
            case 0:
                // this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: `Error: Lỗi 500 !` });
                this.spinner.hide();
                handled = true;
                break;
        }
        return handled;
    }
}
AuthInterceptor.ɵfac = function AuthInterceptor_Factory(t) { return new (t || AuthInterceptor)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_9__.NgxSpinnerService)); };
AuthInterceptor.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjectable"]({ token: AuthInterceptor, factory: AuthInterceptor.ɵfac });


/***/ }),

/***/ 36636:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService),
/* harmony export */   "getClientSettings": () => (/* binding */ getClientSettings)
/* harmony export */ });
/* harmony import */ var E_uni_frontend_uni_hrm_sunshineapp_vn_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ 62783);
/* harmony import */ var oidc_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! oidc-client */ 48725);
/* harmony import */ var oidc_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(oidc_client__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ 18260);
/* harmony import */ var _firebase_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./firebase-auth.service */ 16889);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 2014);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 83981);









class AuthService {
  constructor(http, firebaseAuthService) {
    var _this = this;

    this.http = http;
    this.firebaseAuthService = firebaseAuthService;
    this.manager = new oidc_client__WEBPACK_IMPORTED_MODULE_1__.UserManager(_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.authenSettings);
    this.user = null;
    this.manager.getUser().then( /*#__PURE__*/function () {
      var _ref = (0,E_uni_frontend_uni_hrm_sunshineapp_vn_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (user) {
        _this.user = user;

        if (_this.user) {
          const token = _this.getAccessTokenValue();

          if (!_this.firebaseAuthService.authenticated) {
            const customToken = yield _this.getCustomToken(token);

            if (customToken) {
              _this.firebaseAuthService.customLogin(customToken);
            }
          }
        }
      });

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
  }

  isLoggedIn() {
    // localStorage.removeItem('menuItems');
    if (this.user != null) {
      return new Promise((resolve, reject) => resolve(!this.user.expired));
    }

    return this.manager.getUser().then(user => {
      this.user = user; // this.getEmpDetail()

      return user != null && !user.expired;
    });
  }

  getClaims() {
    return this.user.profile;
  }

  getAuthorizationHeaderValue() {
    return `Bearer ${this.user.access_token}`;
  }

  getAccessTokenValue() {
    return this.user.access_token;
  }

  getUserName() {
    return this.user.profile.name;
  }

  isExpired() {
    return this.user.expired;
  }

  startAuthentication() {
    return this.manager.signinRedirect();
  }

  signout() {
    localStorage.removeItem('menuItems');
    localStorage.removeItem('avatarUrl');
    localStorage.removeItem('employeeId');
    localStorage.removeItem('storeId');
    return this.manager.signoutRedirect();
  }

  completeAuthentication() {
    localStorage.setItem('projectCd', '01');
    return this.manager.signinRedirectCallback().then(user => {
      this.user = user;
    }).then(_ => this.getEmpDetail());
  }

  getUserImage() {
    return localStorage.getItem('avatarUrl');
  }

  getEmpDetail() {// if (localStorage.getItem("employeeId") === null) {
    //   const headers = new HttpHeaders({ Authorization: this.getAuthorizationHeaderValue() });
    //   return this.http.get(environment.apiBase + '/api/v2/employee/GetEmployeeSearch?ftUserId=', { headers }).toPromise()
    //     .then((emp: any) => {
    //       if (emp && emp.data) {
    //         localStorage.setItem('avatarUrl', emp.data.avatarUrl);
    //         localStorage.setItem('employeeId', emp.data.employeeId);
    //       }
    //     });
    // }

    return (0,E_uni_frontend_uni_hrm_sunshineapp_vn_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {})();
  }

  getWorkingProject() {
    return localStorage.getItem('projectCd');
  }

  getCustomToken(token) {
    const url = `${_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.cloudFunctionServer}/getCustomToken`;
    return this.http.post(url, {
      data: {
        access_token: token
      }
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(response => response.result)).toPromise();
  }

}

AuthService.ɵfac = function AuthService_Factory(t) {
  return new (t || AuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_firebase_auth_service__WEBPACK_IMPORTED_MODULE_3__.FirebaseAuthService));
};

AuthService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({
  token: AuthService,
  factory: AuthService.ɵfac
});
function getClientSettings() {
  return {
    authority: 'https://api.sunshinegroup.vn:5000',
    client_id: 'web_s_service_dev',
    redirect_uri: 'http://localhost:4200/auth-callback',
    post_logout_redirect_uri: 'http://localhost:4200',
    response_type: 'id_token token',
    scope: 'openid profile api_sre',
    filterProtocolClaims: true,
    loadUserInfo: true,
    automaticSilentRenew: true,
    silent_redirect_uri: 'http://localhost:4200/silent-refresh.html'
  };
}

/***/ }),

/***/ 20046:
/*!*************************************************!*\
  !*** ./src/app/services/export-file.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExportFileService": () => (/* binding */ ExportFileService)
/* harmony export */ });
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! file-saver */ 68178);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! xlsx */ 97684);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 14001);



const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
class ExportFileService {
    constructor() { }
    exportAsExcelFile(json, excelFileName, sheetNames = ['data']) {
        const worksheet = xlsx__WEBPACK_IMPORTED_MODULE_1__.utils.json_to_sheet(json);
        const workbook = { Sheets: { data: worksheet }, SheetNames: sheetNames };
        const excelBuffer = xlsx__WEBPACK_IMPORTED_MODULE_1__.write(workbook, { bookType: 'xlsx', type: 'array' });
        this.saveAsExcelFile(excelBuffer, excelFileName);
    }
    saveAsExcelFile(buffer, fileName) {
        const data = new Blob([buffer], {
            type: EXCEL_TYPE
        });
        file_saver__WEBPACK_IMPORTED_MODULE_0__.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
    }
}
ExportFileService.ɵfac = function ExportFileService_Factory(t) { return new (t || ExportFileService)(); };
ExportFileService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: ExportFileService, factory: ExportFileService.ɵfac });


/***/ }),

/***/ 16889:
/*!***************************************************!*\
  !*** ./src/app/services/firebase-auth.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FirebaseAuthService": () => (/* binding */ FirebaseAuthService)
/* harmony export */ });
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase */ 37584);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/auth */ 59549);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 13252);






class FirebaseAuthService {
    constructor(afAuth, 
    // private db: AngularFirestore,
    router) {
        this.afAuth = afAuth;
        this.router = router;
        this.authState = null;
        this.tokenData = '';
        this.afAuth.authState.subscribe((auth) => {
            this.authState = auth;
        });
    }
    get token() {
        this.setToken(this.afAuth.idToken);
        return this.afAuth.idToken;
    }
    setToken(tokenObservable) {
        tokenObservable.subscribe(res => {
            this.tokenData = res;
        });
    }
    getTokenString() {
        return this.tokenData;
    }
    // Returns true if user is logged in
    get authenticated() {
        return this.authState !== null;
    }
    // Returns current user data
    get currentUser() {
        return this.authenticated ? this.authState : null;
    }
    // Returns
    get currentUserObservable() {
        return this.afAuth.authState;
    }
    // Returns current user UID
    get currentUserId() {
        return this.authenticated ? this.authState.uid : '';
    }
    // Anonymous User
    get currentUserAnonymous() {
        return this.authenticated ? this.authState.isAnonymous : false;
    }
    // Returns current user display name or Guest
    get currentUserDisplayName() {
        if (!this.authState) {
            return 'Guest';
        }
        if (this.currentUserAnonymous) {
            return 'Anonymous';
        }
        return this.authState.displayName || 'User without a Name';
    }
    //// Social Auth ////
    githubLogin() {
        const provider = new firebase__WEBPACK_IMPORTED_MODULE_0__.auth.GithubAuthProvider();
        return this.socialSignIn(provider);
    }
    googleLogin() {
        const provider = new firebase__WEBPACK_IMPORTED_MODULE_0__.auth.GoogleAuthProvider();
        return this.socialSignIn(provider);
    }
    facebookLogin() {
        const provider = new firebase__WEBPACK_IMPORTED_MODULE_0__.auth.FacebookAuthProvider();
        return this.socialSignIn(provider);
    }
    twitterLogin() {
        const provider = new firebase__WEBPACK_IMPORTED_MODULE_0__.auth.TwitterAuthProvider();
        return this.socialSignIn(provider);
    }
    socialSignIn(provider) {
        return this.afAuth.auth.signInWithPopup(provider)
            .then((credential) => {
            this.authState = credential.user;
            this.updateUserData();
        })
            .catch(error => console.log(error));
    }
    //// Anonymous Auth ////
    anonymousLogin() {
        return this.afAuth.auth.signInAnonymously()
            .then((user) => {
            this.authState = user;
            this.updateUserData();
        })
            .catch(error => console.log(error));
    }
    customLogin(token) {
        return this.afAuth.auth.signInWithCustomToken(token)
            .then((user) => {
            console.log(user);
            this.authState = user;
            this.updateUserData();
        }).catch(error => console.log(error));
    }
    //// Email/Password Auth ////
    emailSignUp(email, password) {
        return this.afAuth.auth.createUserWithEmailAndPassword(email, password)
            .then((user) => {
            this.authState = user;
            this.updateUserData();
        })
            .catch(error => console.log(error));
    }
    emailLogin(email, password) {
        return this.afAuth.auth.signInWithEmailAndPassword(email, password)
            .then((user) => {
            this.authState = user;
            this.updateUserData();
        })
            .catch(error => console.log(error));
    }
    // Sends email allowing user to reset password
    resetPassword(email) {
        const auth = firebase__WEBPACK_IMPORTED_MODULE_0__.auth();
        return auth.sendPasswordResetEmail(email)
            .then(() => console.log('email sent'))
            .catch((error) => console.log(error));
    }
    //// Sign Out ////
    signOut() {
        this.afAuth.auth.signOut();
        this.router.navigate(['/']);
    }
    //// Helpers ////
    updateUserData() {
        // Writes user name and email to realtime db
        // useful if your app displays information about users or for admin features
        const path = `users/${this.currentUserId}`; // Endpoint on firebase
        const data = {
            email: this.authState.email,
            name: this.authState.displayName
        };
    }
}
FirebaseAuthService.ɵfac = function FirebaseAuthService_Factory(t) { return new (t || FirebaseAuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__.AngularFireAuth), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router)); };
FirebaseAuthService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: FirebaseAuthService, factory: FirebaseAuthService.ɵfac });


/***/ }),

/***/ 24773:
/*!**********************************************!*\
  !*** ./src/app/services/firebase.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeedBaseService": () => (/* binding */ FeedBaseService)
/* harmony export */ });
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase */ 37584);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);


class FeedBaseService {
    constructor() {
    }
    /**
     * Method used to used get all document in collection
     * @param collectionName: Name of collection want to get data
     * @return Promise<SnapshotChange>: List of document in collection
     */
    getAllDocument(collectionName) {
        return firebase__WEBPACK_IMPORTED_MODULE_0__.firestore().collection(collectionName).get();
    }
    getDocumentByRef(path) {
        return firebase__WEBPACK_IMPORTED_MODULE_0__.firestore().doc(path).get();
    }
    getCollectionByPath(path) {
        return firebase__WEBPACK_IMPORTED_MODULE_0__.firestore().collection(path).get();
    }
    getAllDocumentWithCondition(collectionName, fieldName, fieldValue, operator = '==') {
        return firebase__WEBPACK_IMPORTED_MODULE_0__.firestore().collection(collectionName).where(fieldName, operator, fieldValue).get();
    }
    createDocumentAutoGenerateName(collectionName, data) {
        return firebase__WEBPACK_IMPORTED_MODULE_0__.firestore().collection(collectionName).add(data);
    }
}
FeedBaseService.ɵfac = function FeedBaseService_Factory(t) { return new (t || FeedBaseService)(); };
FeedBaseService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: FeedBaseService, factory: FeedBaseService.ɵfac });


/***/ }),

/***/ 72856:
/*!********************************************!*\
  !*** ./src/app/services/navbar.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavbarService": () => (/* binding */ NavbarService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);


class NavbarService {
    constructor() {
        this.onGetData = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        this.show = true;
    }
    showNavbar() {
        this.show = true;
    }
    hideNavbar() {
        this.show = false;
    }
    getData() {
        this.onGetData.emit(this.storeId);
    }
}
NavbarService.ɵfac = function NavbarService_Factory(t) { return new (t || NavbarService)(); };
NavbarService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: NavbarService, factory: NavbarService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 48410:
/*!**************************************************!*\
  !*** ./src/app/services/notification.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationService": () => (/* binding */ NotificationService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);

class NotificationService {
    showNotification(message, type = 1) {
        let color = '';
        let textColor = '';
        switch (type) {
            case 1:
                textColor = 'text-success';
                color = 'success';
                break;
            case 2:
                color = 'danger';
                textColor = 'text-danger';
                break;
            case 3:
                color = 'warning';
                break;
        }
        $.notify({
            message
        }, {
            delay: 3000,
            timer: 500,
            z_index: 7777799,
            animate: {
                enter: 'animated fadeInDown',
                exit: 'animated fadeOutUp'
            },
            placement: {
                from: 'top',
                align: 'right'
            },
            template: '<div data-notify="container" class="alert alert-' + color + ' alert-dismissible fade show d-inline-block fixed left bottom" role="alert" style="width: 350px;">' +
                '<div style="line-height: 20px">' +
                '<span class="pd-icon-check-circle ' + textColor + '" style="font-size:20px"></span> {2} ' +
                '</div>' +
                '<button type="button" class="close" data-dismiss="alert" aria-label="Close" style="line-height: 16px">' +
                '<span aria-hidden="true">&times;</span>' +
                '</button>' +
                '</div>'
        });
    }
}
NotificationService.ɵfac = function NotificationService_Factory(t) { return new (t || NotificationService)(); };
NotificationService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: NotificationService, factory: NotificationService.ɵfac });


/***/ }),

/***/ 88585:
/*!***************************************************!*\
  !*** ./src/app/services/organize-info.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrganizeInfoService": () => (/* binding */ OrganizeInfoService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 58824);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 28433);
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./api.service */ 67118);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 14001);




class OrganizeInfoService {
    constructor(apiService) {
        this.apiService = apiService;
        this._organizeInfo = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
        this.organizeInfo$ = this._organizeInfo.asObservable();
    }
    set organizeInfo(val) {
        if (val) {
            this._organizeInfo.next(val);
        }
        else {
            this._organizeInfo.next(null);
        }
    }
    get organizeInfo() {
        return this._organizeInfo.getValue();
    }
    setStocks(value) {
        this.organizeInfo = value;
    }
    fetchAll() {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(this._organizeInfo.getValue());
    }
}
OrganizeInfoService.ɵfac = function OrganizeInfoService_Factory(t) { return new (t || OrganizeInfoService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_api_service__WEBPACK_IMPORTED_MODULE_0__.ApiService)); };
OrganizeInfoService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: OrganizeInfoService, factory: OrganizeInfoService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 23782:
/*!************************************************************!*\
  !*** ./src/app/shared/components/excel/excel.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExcelComponent": () => (/* binding */ ExcelComponent)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../constants */ 4338);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! xlsx */ 97684);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 28267);





function ExcelComponent_label_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "label", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "i", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2, " M\u1EDF file ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function ExcelComponent_input_3_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "input", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("change", function ExcelComponent_input_3_Template_input_change_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r5.onFileChange($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function ExcelComponent_label_4_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "label", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ExcelComponent_label_4_Template_label_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r7.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "i", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2, " L\u00E0m m\u1EDBi ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function ExcelComponent_label_5_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "label", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ExcelComponent_label_5_Template_label_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r9.handleImport(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "i", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2, " Import ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function ExcelComponent_div_6_div_8_table_1_tr_2_td_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const val_r18 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", val_r18, " ");
} }
function ExcelComponent_div_6_div_8_table_1_tr_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, ExcelComponent_div_6_div_8_table_1_tr_2_td_1_Template, 2, 1, "td", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const row_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", row_r16);
} }
function ExcelComponent_div_6_div_8_table_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "table", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, ExcelComponent_div_6_div_8_table_1_tr_2_Template, 2, 1, "tr", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const sheet_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", sheet_r13);
} }
function ExcelComponent_div_6_div_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, ExcelComponent_div_6_div_8_table_1_Template, 3, 1, "table", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx_r11.excelData);
} }
function ExcelComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ExcelComponent_div_6_Template_div_click_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r21); const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r20.toggleDisplay(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "h4", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5, "N\u1ED9i dung file");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](7, "i", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](8, ExcelComponent_div_6_div_8_Template, 2, 1, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx_r4.excelData.length > 0);
} }
class ExcelComponent {
    constructor() {
        this.excelData = [];
        this.data = [];
        this.wopts = { bookType: 'xlsx', type: 'array' };
        this.fileName = 'SheetJS.xlsx';
        this.loading = false;
        this.readData = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        this.load = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        this.showUpload = true;
        this.listHeader = [];
    }
    ngOnInit() {
    }
    cancel() {
        this.excelData = [];
        this.uploadFile = null;
        this.showUpload = true;
    }
    onFileChange(evt) {
        this.excelData = [];
        this.uploadFile = null;
        setTimeout(() => {
            if (evt.target.files.length > 0) {
                this.loading = true;
                /* wire up file reader */
                this.showUpload = false;
                this.uploadFile = evt.target.files;
                const target = (evt.target);
                if (target.files.length !== 1) {
                    throw new Error('Cannot use multiple files');
                }
                const reader = new FileReader();
                reader.onload = (e) => {
                    /* read workbook */
                    const bstr = e.target.result;
                    const wb = xlsx__WEBPACK_IMPORTED_MODULE_1__.read(bstr, { type: 'binary' });
                    const arrayAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split('').map(d => `${d}1`);
                    const sheetNames = wb.SheetNames;
                    // const key = wb.Sheets[sheetNames[0]]["!autofilter"].ref.split(':');
                    // const indexfirst = arrayAlphabet.findIndex(d => d === key[0]);
                    // const indexlast = arrayAlphabet.findIndex(d => d === key[1]);
                    // const arrayHeader = arrayAlphabet.slice(indexfirst, indexlast + 1);
                    // const listHeader = [];
                    // for(let item of arrayHeader) {
                    //   listHeader.push(wb.Sheets.Sheet1[item].r);
                    //   // delete wb.Sheets.Sheet1[item]
                    // }
                    // this.listHeader = listHeader;
                    // for (let i = 0; i < wb.SheetNames.length; i++) {
                    //   // Read all data in onesheet
                    // }
                    const wsname = wb.SheetNames[0];
                    const ws = wb.Sheets[wsname];
                    /* save data */
                    this.data = (xlsx__WEBPACK_IMPORTED_MODULE_1__.utils.sheet_to_json(ws, { header: 1 }));
                    // Save data to list sheet
                    this.excelData.push(this.data);
                    this.readData.emit(this.excelData);
                    this.loading = false;
                };
                reader.readAsBinaryString(target.files[0]);
            }
        }, 500);
    }
    export() {
        /* generate worksheet */
        const ws = xlsx__WEBPACK_IMPORTED_MODULE_1__.utils.aoa_to_sheet(this.data);
        /* generate workbook and add the worksheet */
        const wb = xlsx__WEBPACK_IMPORTED_MODULE_1__.utils.book_new();
        xlsx__WEBPACK_IMPORTED_MODULE_1__.utils.book_append_sheet(wb, ws, 'Sheet1');
        /* save to file */
        xlsx__WEBPACK_IMPORTED_MODULE_1__.writeFile(wb, this.fileName);
    }
    toggleDisplay() {
        jQuery('#excelcontent').slideToggle();
    }
    handleImport() {
        if (this.uploadFile) {
            const fileToUpload = this.uploadFile[0];
            const formData = new FormData();
            formData.append('formFile', fileToUpload, fileToUpload.name);
            this.load.emit(formData);
        }
        else {
            alert(_constants__WEBPACK_IMPORTED_MODULE_0__.CONSTANTS.MESSAGE.CHOOSE_FILE);
        }
    }
}
ExcelComponent.ɵfac = function ExcelComponent_Factory(t) { return new (t || ExcelComponent)(); };
ExcelComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: ExcelComponent, selectors: [["app-sheet"]], outputs: { readData: "readData", load: "load" }, decls: 7, vars: 5, consts: [[1, "row"], [1, "col-sm-12", "text-right"], ["for", "file-upload", "class", "custom-file-upload", 4, "ngIf"], ["id", "file-upload", "type", "file", "accept", ".xlsx, .xls", "multiple", "false", 3, "change", 4, "ngIf"], ["class", "custom-file-upload ml-1 ", "style", "background-color: red;", 3, "click", 4, "ngIf"], ["class", "custom-file-upload ml-1", 3, "click", 4, "ngIf"], ["class", "col-md-12 title", 4, "ngIf"], ["for", "file-upload", 1, "custom-file-upload"], ["aria-hidden", "true", 1, "pi", "pi-upload"], ["id", "file-upload", "type", "file", "accept", ".xlsx, .xls", "multiple", "false", 3, "change"], [1, "custom-file-upload", "ml-1", 2, "background-color", "red", 3, "click"], ["aria-hidden", "true", 1, "pi", "pi-times"], [1, "custom-file-upload", "ml-1", 3, "click"], ["aria-hidden", "true", 1, "pi", "pi-plus"], [1, "col-md-12", "title"], [1, "row", 3, "click"], [1, "col-sm-11"], [1, "text-green"], [1, "col-sm-1", "text-right"], ["aria-hidden", "true", 1, "fa", "fa-arrows", "cursor-pointer", "mr-1", "toggle"], ["class", "row col-sm-12 mt-1", "id", "excelcontent", 4, "ngIf"], ["id", "excelcontent", 1, "row", "col-sm-12", "mt-1"], ["class", "table table-import", 4, "ngFor", "ngForOf"], [1, "table", "table-import"], [4, "ngFor", "ngForOf"]], template: function ExcelComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, ExcelComponent_label_2_Template, 3, 0, "label", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, ExcelComponent_input_3_Template, 1, 0, "input", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](4, ExcelComponent_label_4_Template, 3, 0, "label", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](5, ExcelComponent_label_5_Template, 3, 0, "label", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](6, ExcelComponent_div_6_Template, 9, 1, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.showUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.showUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.showUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.showUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.excelData.length > 0);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf], styles: ["input[type=\"file\"][_ngcontent-%COMP%] {\r\n  display: none;\r\n}\r\n.custom-file-upload[_ngcontent-%COMP%] {\r\n  box-shadow: 0 0 3px gray;\r\n  display: inline-block;\r\n  padding: 10px 15px;\r\n  cursor: pointer;\r\n  border-radius: 5px;\r\n  background: rgb(1, 111, 221);\r\n  color: white;\r\n  transition: .4s;\r\n}\r\n.custom-file-upload[_ngcontent-%COMP%]:hover {\r\n  background: rgb(1, 111, 221);\r\n  color: white;\r\n}\r\ntable[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\r\n  white-space: nowrap\r\n}\r\n.bg-blue-color[_ngcontent-%COMP%] {\r\n  background: rgb(1, 111, 221);\r\n}\r\n.text-white[_ngcontent-%COMP%] {\r\n  color : rgb(1, 111, 221);\r\n}\r\n.text-green[_ngcontent-%COMP%] {\r\n  color: rgb(1, 111, 221);\r\n  font-weight: bold;\r\n}\r\n.align-right-item[_ngcontent-%COMP%] {\r\n  display: flex !important;\r\n  flex-direction: row-reverse !important;\r\n}\r\n.modal-content[_ngcontent-%COMP%] {\r\n  opacity: 0.9 !important;\r\n}\r\n#excelcontent[_ngcontent-%COMP%] {\r\n  height: 500px;\r\n  overflow: auto;\r\n}\r\n.toggle[_ngcontent-%COMP%] {\r\n  animation: scale 2s ease-in-out infinite;\r\n}\r\n@keyframes scale {\r\n  0% {\r\n    transform: scale(1);\r\n    color: rgb(1, 111, 221);\r\n  }\r\n  100% {\r\n    transform: scale(1.2);\r\n  }\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImV4Y2VsLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0FBQ2Y7QUFDQTtFQUNFLHdCQUF3QjtFQUN4QixxQkFBcUI7RUFDckIsa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsNEJBQTRCO0VBQzVCLFlBQVk7RUFDWixlQUFlO0FBQ2pCO0FBRUE7RUFDRSw0QkFBNEI7RUFDNUIsWUFBWTtBQUNkO0FBRUE7RUFDRTtBQUNGO0FBR0E7RUFDRSw0QkFBNEI7QUFDOUI7QUFFQTtFQUNFLHdCQUF3QjtBQUMxQjtBQUVBO0VBQ0UsdUJBQXVCO0VBQ3ZCLGlCQUFpQjtBQUNuQjtBQUNBO0VBQ0Usd0JBQXdCO0VBQ3hCLHNDQUFzQztBQUN4QztBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCO0FBRUE7RUFDRSxhQUFhO0VBQ2IsY0FBYztBQUNoQjtBQUVBO0VBQ0Usd0NBQXdDO0FBQzFDO0FBRUE7RUFDRTtJQUNFLG1CQUFtQjtJQUNuQix1QkFBdUI7RUFDekI7RUFDQTtJQUNFLHFCQUFxQjtFQUN2QjtBQUNGIiwiZmlsZSI6ImV4Y2VsLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpbnB1dFt0eXBlPVwiZmlsZVwiXSB7XHJcbiAgZGlzcGxheTogbm9uZTtcclxufVxyXG4uY3VzdG9tLWZpbGUtdXBsb2FkIHtcclxuICBib3gtc2hhZG93OiAwIDAgM3B4IGdyYXk7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIHBhZGRpbmc6IDEwcHggMTVweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIGJhY2tncm91bmQ6IHJnYigxLCAxMTEsIDIyMSk7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIHRyYW5zaXRpb246IC40cztcclxufVxyXG5cclxuLmN1c3RvbS1maWxlLXVwbG9hZDpob3ZlciB7XHJcbiAgYmFja2dyb3VuZDogcmdiKDEsIDExMSwgMjIxKTtcclxuICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbnRhYmxlIHRib2R5IHRyIHRkIHtcclxuICB3aGl0ZS1zcGFjZTogbm93cmFwXHJcbn1cclxuXHJcblxyXG4uYmctYmx1ZS1jb2xvciB7XHJcbiAgYmFja2dyb3VuZDogcmdiKDEsIDExMSwgMjIxKTtcclxufVxyXG5cclxuLnRleHQtd2hpdGUge1xyXG4gIGNvbG9yIDogcmdiKDEsIDExMSwgMjIxKTtcclxufVxyXG5cclxuLnRleHQtZ3JlZW4ge1xyXG4gIGNvbG9yOiByZ2IoMSwgMTExLCAyMjEpO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcbi5hbGlnbi1yaWdodC1pdGVtIHtcclxuICBkaXNwbGF5OiBmbGV4ICFpbXBvcnRhbnQ7XHJcbiAgZmxleC1kaXJlY3Rpb246IHJvdy1yZXZlcnNlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5tb2RhbC1jb250ZW50IHtcclxuICBvcGFjaXR5OiAwLjkgIWltcG9ydGFudDtcclxufVxyXG5cclxuI2V4Y2VsY29udGVudCB7XHJcbiAgaGVpZ2h0OiA1MDBweDtcclxuICBvdmVyZmxvdzogYXV0bztcclxufVxyXG5cclxuLnRvZ2dsZSB7XHJcbiAgYW5pbWF0aW9uOiBzY2FsZSAycyBlYXNlLWluLW91dCBpbmZpbml0ZTtcclxufVxyXG5cclxuQGtleWZyYW1lcyBzY2FsZSB7XHJcbiAgMCUge1xyXG4gICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcclxuICAgIGNvbG9yOiByZ2IoMSwgMTExLCAyMjEpO1xyXG4gIH1cclxuICAxMDAlIHtcclxuICAgIHRyYW5zZm9ybTogc2NhbGUoMS4yKTtcclxuICB9XHJcbn1cclxuIl19 */"] });


/***/ }),

/***/ 51849:
/*!*********************************************************!*\
  !*** ./src/app/shared/components/excel/excel.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExcelModule": () => (/* binding */ ExcelModule)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _excel_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./excel.component */ 23782);
/* harmony import */ var _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ag-grid-community/angular */ 11775);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);






class ExcelModule {
}
ExcelModule.ɵfac = function ExcelModule_Factory(t) { return new (t || ExcelModule)(); };
ExcelModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: ExcelModule });
ExcelModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule,
            _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_5__.AgGridModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](ExcelModule, { declarations: [_excel_component__WEBPACK_IMPORTED_MODULE_0__.ExcelComponent], imports: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule,
        _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_5__.AgGridModule], exports: [_excel_component__WEBPACK_IMPORTED_MODULE_0__.ExcelComponent] }); })();


/***/ }),

/***/ 4338:
/*!*************************************!*\
  !*** ./src/app/shared/constants.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CONSTANTS": () => (/* binding */ CONSTANTS),
/* harmony export */   "KEYBUTTON": () => (/* binding */ KEYBUTTON)
/* harmony export */ });
const CONSTANTS = {
    MESSAGE: {
        IMPORT_SUCCESS: 'Import thành công',
        IMPORT_FAIL: 'Import thất bại',
        CHOOSE_FILE: 'Vui lòng chọn file'
    },
    MESSAGE_TYPE: {
        SUCCESS: 1,
        DANGER: 2,
        WARNING: 3
    },
    CONFIRM: {
        DELETE: 'Bạn có chắc chắn muốn xóa'
    }
};
const KEYBUTTON = {
    'THEM_MOI': 'them_moi',
    'XEM_CHI_TIET_DETAIL': 'xem-chi-tiet-detail',
    'XOA_CHI_TIET_DETAIL': 'xoa-tiet-detail',
    'XEMCHITIET': 'view',
    'SUA_PHU_LUC': 'sua-phu-luc',
    'CAP_NHAT': 'cap_nhat',
    'XEM_CHINH_SACH_NHA_CUNG_CAP': 'xem-chinh-sach-ncc',
    'XEM_CHINH_SACH_KHACH_HANG': 'xem-chinh-sach-khach-hang',
    'XEM_CHINH_SACH_GIAO_DICH': 'xem-chinh-sach-giao-dich',
    'SUPPLIER_TO_PRODUCT': 'supplier-to-product',
    'QUY_DOI_DON_VI_TINH': 'quy-doi-don-vi-tinh',
    'KE_HOACH_GIA': 'ke-hoach-gia',
    'THONG_TIN_THE_KHO': 'thong-tin-the-kho',
    'DUPLICATE': 'duplicate',
    'TAI_DON_HANG': 'tai-don-hang',
    'XEM_CHI_TIET_KIEM_KHO': 'xem-chi-tiet-kiem-kho',
    'THEM_NHA_CUNG_CAP_VAO_SP': 'them-nha-cung-cap-vao-sp',
    'THEM_CHINH_SACH_HANG_HOA': 'them-chinh-sach-hang-hoa',
    'THEM_CHINH_SACH_HOA_DON': 'them-chinh-sach-hoa-don',
    'CHUYEN_NHA_CUNG_CAP': 'chuyen-nha-cung-cap',
    'CHUYEN_PHE_DUYET': 'chuyen-phe-duyet',
    'PHE_DUYET': 'phe-duyet',
    'CHUYEN_LAI_PHE_DUYET': 'chuyen-lai-phe-duyet',
    'CHI_TIET_GIAO_DICH_HANG_HOA': 'chi-tiet-giao-dich-hang-hoa',
    'THEM_CHINH_SACH_BAN_HANG_HOA_DON': 'them-chinh-sach-ban-hang-hoa-don',
    'THEMMOI': 'add',
    'XOATHONGTIN': 'remove',
    'THEM_PHU_LUC': 'them-phu-luc',
    'DOWLOAD': 'dowload',
    'COPY': 'copy',
    'TAIPHIEUNHAP': 'tai-phieu-nhap',
    'TRADONHANG': 'tra-don-hang',
    'TAIPHIEUXUATTRATUNCC': 'tai-phieu-xuat-tra-tu-ncc',
    'TAIPHIEUNHAPHANGTRALAI': 'tai-phieu-nhap-hang-tra-lai',
    'TAIPHIEUXUATHUYHANG': 'tai-phieu-xuat-huy-hang',
    'TAIPHIEUXUATBEP': 'tai-phieu-xuat-bep',
    'TAIPHIEUNHAPHANGKYGUI': 'tai-phieu-nhap-hang-ky-gui',
    'TAIPHIEUXUATHANGKYGUI': 'tai-phieu-xuat-hang-ky-gui',
    'HUYKHOA': 'huy-khoa',
    'XEM_SAN_PHAM_NCC': 'xem-san-pham-ncc',
    'XEM_PHU_LUC_NCC': 'xem-phu-luc-ncc',
    'XEM_CHI_TIET_NCC': 'xem-chi-tiet-ncc',
    'XOA_KHACH_HANG': 'xoa-khach-hang'
};


/***/ }),

/***/ 18874:
/*!******************************************************************!*\
  !*** ./src/app/shared/directives/toggle-fullscreen.directive.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ToggleFullscreenDirective": () => (/* binding */ ToggleFullscreenDirective)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);

class ToggleFullscreenDirective {
    onClick() {
        // if (screenfull.enabled) {
        //   screenfull.toggle();
        // }
    }
}
ToggleFullscreenDirective.ɵfac = function ToggleFullscreenDirective_Factory(t) { return new (t || ToggleFullscreenDirective)(); };
ToggleFullscreenDirective.ɵdir = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: ToggleFullscreenDirective, selectors: [["", "appToggleFullscreen", ""]], hostBindings: function ToggleFullscreenDirective_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ToggleFullscreenDirective_click_HostBindingHandler() { return ctx.onClick(); });
    } } });


/***/ }),

/***/ 62791:
/*!***************************************************!*\
  !*** ./src/app/shared/footer/footer.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FooterComponent": () => (/* binding */ FooterComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 28267);


class FooterComponent {
    constructor() {
        this.currentDate = new Date();
    }
}
FooterComponent.ɵfac = function FooterComponent_Factory(t) { return new (t || FooterComponent)(); };
FooterComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FooterComponent, selectors: [["app-footer"]], decls: 11, vars: 4, consts: [["id", "stackFooter", 1, "footer", "footer-static", "footer-light", "navbar-border"], [1, "clearfix", "blue-grey", "lighten-2", "text-sm-center", "mb-0", "px-2"], [1, "float-md-left", "d-block", "d-md-inline-block"], ["href", "https://themeforest.net/user/pixinvent/portfolio?ref=pixinvent", "target", "_blank", 1, "text-bold-800", "grey", "darken-2"], [1, "float-md-right", "d-block", "d-md-inline-blockd-none", "d-lg-block"], [1, "ft-heart", "pink"]], template: function FooterComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "footer", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "date");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "a", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "PIXINVENT ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, ", All rights reserved. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Hand-crafted & Made with ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "i", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Copyright \u00A9 ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](4, 1, ctx.currentDate, "yyyy"), " ");
    } }, pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.DatePipe], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb290ZXIuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 28949:
/*!*********************************************!*\
  !*** ./src/app/shared/margin-round.pipe.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MarginRoundPipe": () => (/* binding */ MarginRoundPipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);

class MarginRoundPipe {
    transform(value, digit = 2) {
        if (typeof (value) === 'number') {
            return (value * 100).toFixed(digit);
        }
        else {
            const toNumber = +value;
            return (toNumber * 100).toFixed(digit);
        }
    }
}
MarginRoundPipe.ɵfac = function MarginRoundPipe_Factory(t) { return new (t || MarginRoundPipe)(); };
MarginRoundPipe.ɵpipe = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({ name: "marginRound", type: MarginRoundPipe, pure: true });


/***/ }),

/***/ 5471:
/*!***************************************!*\
  !*** ./src/app/shared/margin.pipe.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MarginPipe": () => (/* binding */ MarginPipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);

class MarginPipe {
    transform(value, digit = 2) {
        if (typeof (value) === 'number') {
            return (Math.trunc(value * Math.pow(10, digit)) / Math.pow(10, digit)).toString();
        }
        else {
            const toNumber = +value;
            return (Math.trunc(toNumber * Math.pow(10, digit)) / Math.pow(10, digit)).toString();
        }
    }
}
MarginPipe.ɵfac = function MarginPipe_Factory(t) { return new (t || MarginPipe)(); };
MarginPipe.ɵpipe = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({ name: "margin", type: MarginPipe, pure: true });


/***/ }),

/***/ 31614:
/*!***************************************************!*\
  !*** ./src/app/shared/navbar/navbar.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavbarComponent": () => (/* binding */ NavbarComponent)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/auth.service */ 36636);
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api.service */ 67118);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_toolbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/toolbar */ 7225);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_avatar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/avatar */ 72189);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/dropdown */ 45596);






















function NavbarComponent_div_11_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "p-dropdown", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onChange", function NavbarComponent_div_11_Template_p_dropdown_onChange_2_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r7.changeOragi($event); })("ngModelChange", function NavbarComponent_div_11_Template_p_dropdown_ngModelChange_2_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r8); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r9.organizeRole = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("baseZIndex", 100)("disabled", ctx_r0.chooseOrga)("options", ctx_r0.detailOrganizes)("ngModel", ctx_r0.organizeRole)("filter", true);
} }
function NavbarComponent_div_37_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Password b\u1EAFt bu\u1ED9c nh\u1EADp! ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function NavbarComponent_div_37_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, NavbarComponent_div_37_div_1_Template, 2, 0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r4.modelPass.userPassword);
} }
function NavbarComponent_div_48_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Nh\u1EADp l\u1EA1i m\u1EADt kh\u1EA9u kh\u00F4ng \u0111\u00FAng ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function NavbarComponent_div_48_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, NavbarComponent_div_48_div_1_Template, 2, 0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r6.modelPass.userPassCf || ctx_r6.confimPassword);
} }
const _c0 = function () { return { "z-index": 9999 }; };
const _c1 = function () { return { width: "600px", height: "auto" }; };
const queryString = __webpack_require__(/*! query-string */ 31808);
class NavbarComponent {
    constructor(route, router, authService, apiService, apiHrm, messageService, organizeInfoService, changeDetector) {
        this.route = route;
        this.router = router;
        this.authService = authService;
        this.apiService = apiService;
        this.apiHrm = apiHrm;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.changeDetector = changeDetector;
        this.userName = '';
        this.avatarUrl = '';
        this.items = [];
        this.isShowChangePassword = false;
        this.modelPass = {
            userLogin: '',
            userPassword: '',
            userPassCf: ''
        };
        this.chooseOrga = false;
        this.confimPassword = false;
        this.submitPass = false;
        this.organizeRole = null;
        this.listmenuChecks = [];
        this.menuItems = [];
        this.urlsForDisableOrgan = [];
        this.isShowPass = false;
        this.isShowRepass = false;
        // changeTheme(theme: string) {
        //     this.themeService.switchTheme(theme);
        // }
        this.detailOrganizes = [];
        this.router.events.subscribe((val) => {
            if (val instanceof _angular_router__WEBPACK_IMPORTED_MODULE_5__.NavigationStart) {
                this.checkDisableOrgan(val.url);
            }
            this.checkDisableOrgan(this.router.url);
        });
        this.items = [
            {
                label: 'Thay đổi mật khẩu',
                icon: 'pi pi-user-edit',
                command: () => {
                    this.changePassword();
                }
            },
            {
                label: 'Logout',
                icon: 'pi pi-refresh',
                command: () => {
                    this.logout();
                }
                // items: [{
                //     label: 'Logout',
                // },
                // {
                //     label: 'Delete',
                //     icon: 'pi pi-times',
                //     command: () => {
                //         this.delete();
                //     }
                // }
            },
        ];
    }
    checkPasswordcf() {
        if (this.modelPass.userPassword === this.modelPass.userPassCf) {
            this.confimPassword = false;
        }
        else {
            this.confimPassword = true;
        }
    }
    changePassword() {
        this.isShowChangePassword = true;
        this.modelPass.userLogin = '';
        this.modelPass.userPassword = '';
        this.modelPass.userPassCf = '';
    }
    saveChangePass() {
        let userLogin = this.authService.getClaims();
        this.submitPass = true;
        if ((this.modelPass.userPassword && !this.modelPass.userPassCf) || this.confimPassword) {
            return;
        }
        this.modelPass.userLogin = userLogin.preferred_username;
        const params = Object.assign({}, this.modelPass);
        delete params.userPassCf;
        this.apiService.setResetPassword(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Sửa thông tin tài khoản thành công !' });
                this.isShowChangePassword = false;
            }
            if (results.status === 'error') {
                this.messageService.add({ severity: 'error', summary: results.message, detail: results.data });
            }
        });
    }
    logout() {
        this.authService.signout();
        localStorage.removeItem('organizes');
    }
    ngOnInit() {
        this.userName = this.authService.getUserName();
        this.getOragin();
    }
    update() {
    }
    delete() {
    }
    getOragin() {
        this.detailOrganizes = [];
        this.organizeRole = null;
        this.apiHrm.getUserOrganizeRole().subscribe((results) => {
            if (results.status === "success") {
                if (results.data && results.data && results.data.length > 0) {
                    this.detailOrganizes = results.data
                        .map(d => {
                        return {
                            label: d.name,
                            value: d.value
                        };
                    });
                    let organizesStorage = localStorage.getItem("organizes");
                    if (organizesStorage === "null" || organizesStorage === null) {
                        this.organizeRole = this.detailOrganizes[0].value;
                        localStorage.setItem('organizes', this.organizeRole);
                        this.organizeInfoService.setStocks(this.organizeRole);
                    }
                    else {
                        this.organizeRole = organizesStorage;
                        this.organizeInfoService.setStocks(this.organizeRole);
                        this.changeDetector.detectChanges();
                    }
                }
            }
        }),
            error => { };
    }
    ngAfterViewChecked() {
    }
    goToHome() {
        this.router.navigate(['/home']);
        // const pathname = window.location.pathname;
        //   let pathUrl = pathname.split("/");
        //   let pathUrl1 = '/';
        //   pathUrl1 = pathUrl1.concat(pathUrl["1"])
        //   if(pathUrl[2]){
        //       pathUrl1 = pathUrl1.concat("/").concat(pathUrl["2"])
        //   }
        //   this.organizeInfoService.organizeInfo$.subscribe((results: any) => {
        //       if(results && results.length>0){
        //        const queryParams = queryString.stringify({ organizeIds: results });
        //         this.apiService.getUserMenus(queryParams).subscribe(results => {
        //              if (results.status === 'success') {
        //                  this.menuItems = results.data;
        //                  this.convetArry(this.menuItems);
        //                   if(this.listmenuChecks.map(d => d.path).indexOf(pathUrl1) < 0) {
        //                       this.router.navigate(['/404']);
        //                   }else{
        //                     // this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Không có quyền truy cập' });
        //                     this.router.navigate(['/home']);
        //                   }
        //                  this.menuItems = [...this.menuItems];
        //              }
        //          });
        //       }else{
        //           this.router.navigate(['/404']);
        //       }
        //   });
    }
    convetArry(datas) {
        for (let item of datas) {
            this.listmenuChecks.push(item);
            if (item.submenus.length > 0) {
                this.convetArry(item.submenus);
            }
        }
    }
    changeOragi(e) {
        this.organizeRole = e.value;
        this.organizeInfoService.setStocks(e.value);
        localStorage.setItem('organizes', e.value);
    }
    checkDisableOrgan(currentUrl) {
        this.urlsForDisableOrgan = [
            '/tuyen-dung/ds-tuyen-dung/them-moi-tuyen-dung',
            '/tuyen-dung/ds-tuyen-dung/chi-tiet-tuyen-dung',
            '/tuyen-dung/vi-tri-tuyen-dung/them-moi-vi-tri-tuyen-dung',
            '/tuyen-dung/vi-tri-tuyen-dung/chi-tiet-vi-tri-tuyen-dung',
            '/tuyen-dung/chuyen-mon/them-moi-linh-vuc-tuyen-dung',
            '/tuyen-dung/chuyen-mon/chi-tiet-linh-vuc-tuyen-dung',
            '/nhan-su/ho-so-nhan-su/chi-tiet-ho-so-nhan-su',
            '/nhan-su/xu-ly-hop-dong/chi-tiet-xu-ly-hop-dong',
            '/nhan-su/ho-so-nghi-viec/chi-tiet-ho-so-nghi-viec',
            '/nhan-su/phe-duyet/chi-tiet-phe-duyet',
            '/nhan-su/thai-san/them-moi-thai-san',
            '/nhan-su/thai-san/chi-tiet-thai-san',
            '/chinh-sach/an-ca/chi-tiet-danh-sach-an-ca',
            '/chinh-sach/phep-bu/them-moi-phep-bu',
            '/chinh-sach/phep-bu/chi-tiet-phep-bu',
            '/chinh-sach/thue-thu-nhap/chi-tiet-thue-thu-nhap',
            '/chinh-sach/cham-cong/chi-tiet-cham-cong',
            '/chinh-sach/tien-luong/chi-tiet-tien-luong',
            '/cai-dat/thong-bao/chi-tiet-thong-bao',
            '/cai-dat/cai-dat-lich-hop/them-moi-lich-hop',
            '/cai-dat/cai-dat-lich-hop/chi-tiet-lich-hop',
            '/hoat-dong/lich-hop/danh-sach-phong-hop/them-moi-phong-hop',
            '/hoat-dong/lich-hop/danh-sach-phong-hop/chi-tiet-phong-hop',
            '/gop-y/chi-tiet-gop-y',
            '/phan-quyen/the-nhan-vien/them-moi-the-nhan-vien',
            '/cai-dat/lich-lam-viec/them-moi-lich-lam-viec',
            '/cai-dat/lich-lam-viec/chi-tiet-lich-lam-viec',
            '/cai-dat/tham-so-chung/',
            '/cai-dat/cai-dat-to-chuc/chi-tiet-to-chuc',
            '/cai-dat/cai-dat-ngay-nghi-le/them-moi-ngay-nghi',
            '/cai-dat/cai-dat-ngay-nghi-le/chi-tiet-ngay-nghi',
            '/cai-dat/chuc-vu/chi-tiet-chuc-vu',
            '/cai-dat/chuc-vu/them-moi-chuc-vu',
            '/cai-dat/noi-lam-viec/them-moi-noi-lam-viec',
            '/cai-dat/noi-lam-viec/chi-tiet-noi-lam-viec',
            '/cai-dat/ly-do-nghi/them-moi-ly-do-nghi',
            '/cai-dat/ly-do-nghi/chi-tiet-ly-do-nghi',
            '/cai-dat/cai-dat-cong-ty/them-moi-cong-ty',
            '/cai-dat/cai-dat-cong-ty/chi-tiet-cong-ty',
            '/cai-dat/quan-ly-hop-dong/them-moi-hop-dong',
            '/cai-dat/quan-ly-hop-dong/chi-tiet-hop-dong',
            '/cai-dat/thiet-lap-wifi/them-moi',
            '/cai-dat/thiet-lap-wifi/chi-tiet',
            '/chinh-sach/an-ca/chi-tiet-an-ca',
            '/nhan-su/qua-trinh-thay-doi-luong/chi-tiet-qua-trinh-thay-doi-luong'
        ];
        let url = currentUrl.split('?');
        this.chooseOrga = this.urlsForDisableOrgan.some(d => d === url[0]);
    }
}
NavbarComponent.ɵfac = function NavbarComponent_Factory(t) { return new (t || NavbarComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_api_service__WEBPACK_IMPORTED_MODULE_1__.ApiService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_6__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_3__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef)); };
NavbarComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: NavbarComponent, selectors: [["app-navbar"]], decls: 53, vars: 25, consts: [[1, "p-toolbar-group-left"], [1, "go-to-home", 3, "click"], ["width", "113", "height", "48", "viewBox", "0 0 113 48", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["clip-path", "url(#clip0_920_8698)"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M13.0689 23.0402L10.0875 28.4547L5.12142 37.4728C6.01455 37.4728 13.0991 37.4774 15.2478 37.5L23.1866 23.0719L13.0689 23.0402ZM15.0536 19.4366H25.1843L29.9735 28.1378L35 19.414L30.1029 10.5H19.9636L15.0536 19.4366ZM16.0028 10.5H0L4.91864 19.4366H11.0842L16.0028 10.5Z", "fill", "white"], ["d", "M48.176 37.288C46.736 37.288 45.512 37.032 44.504 36.52C43.512 36.008 42.656 35.336 41.936 34.504L44.072 32.44C44.648 33.112 45.288 33.624 45.992 33.976C46.712 34.328 47.504 34.504 48.368 34.504C49.344 34.504 50.08 34.296 50.576 33.88C51.072 33.448 51.32 32.872 51.32 32.152C51.32 31.592 51.16 31.136 50.84 30.784C50.52 30.432 49.92 30.176 49.04 30.016L47.456 29.776C44.112 29.248 42.44 27.624 42.44 24.904C42.44 24.152 42.576 23.472 42.848 22.864C43.136 22.256 43.544 21.736 44.072 21.304C44.6 20.872 45.232 20.544 45.968 20.32C46.72 20.08 47.568 19.96 48.512 19.96C49.776 19.96 50.88 20.168 51.824 20.584C52.768 21 53.576 21.616 54.248 22.432L52.088 24.472C51.672 23.96 51.168 23.544 50.576 23.224C49.984 22.904 49.24 22.744 48.344 22.744C47.432 22.744 46.744 22.92 46.28 23.272C45.832 23.608 45.608 24.088 45.608 24.712C45.608 25.352 45.792 25.824 46.16 26.128C46.528 26.432 47.12 26.656 47.936 26.8L49.496 27.088C51.192 27.392 52.44 27.936 53.24 28.72C54.056 29.488 54.464 30.568 54.464 31.96C54.464 32.76 54.32 33.488 54.032 34.144C53.76 34.784 53.352 35.344 52.808 35.824C52.28 36.288 51.624 36.648 50.84 36.904C50.072 37.16 49.184 37.288 48.176 37.288ZM67.7919 29.92H60.8079V37H57.6399V20.248H60.8079V27.112H67.7919V20.248H70.9599V37H67.7919V29.92ZM78.0579 37H74.8899V20.248H82.4499C83.2179 20.248 83.9059 20.368 84.5139 20.608C85.1219 20.848 85.6339 21.2 86.0499 21.664C86.4819 22.112 86.8099 22.656 87.0339 23.296C87.2739 23.936 87.3939 24.648 87.3939 25.432C87.3939 26.584 87.1299 27.576 86.6019 28.408C86.0899 29.24 85.3139 29.832 84.2739 30.184L87.7059 37H84.1779L81.0579 30.544H78.0579V37ZM82.1379 27.88C82.7459 27.88 83.2259 27.72 83.5779 27.4C83.9299 27.064 84.1059 26.592 84.1059 25.984V24.88C84.1059 24.272 83.9299 23.808 83.5779 23.488C83.2259 23.168 82.7459 23.008 82.1379 23.008H78.0579V27.88H82.1379ZM103.475 24.976H103.379L102.083 27.64L98.6514 33.976L95.2194 27.64L93.9234 24.976H93.8274V37H90.8274V20.248H94.4034L98.6994 28.432H98.7954L103.043 20.248H106.475V37H103.475V24.976Z", "fill", "white"], ["id", "clip0_920_8698"], ["width", "35", "height", "27", "fill", "white", "transform", "translate(0 10.5)"], [1, "d-flex", "gap12", "end", "col-6", "middle", "pd-0"], ["class", "col-4 pd-0", 4, "ngIf"], [1, "p-toolbar-group-right", "profile"], [1, "card", "flex", "align-items-center", 3, "click"], ["image", "../../../assets/images/walter.jpg", "severity", "danger", "shape", "circle", 1, "img-avatar"], [1, "ml-12", "mr-15", "text-color", "name"], ["styleClass", "my-account-menu", 3, "popup", "model"], ["menu", ""], ["width", "12", "height", "8", "viewBox", "0 0 12 8", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M10.59 0.294922L6 4.87492L1.41 0.294922L0 1.70492L6 7.70492L12 1.70492L10.59 0.294922Z", "fill", "white", "fill-opacity", "0.6"], [3, "visible", "modal", "visibleChange"], [1, "form-horizontal", "change-password"], ["editSMSF", "ngForm"], [1, "box-body", 2, "padding", "10px"], [1, "form-row", 2, "margin", "10px 0px"], [1, "col-sm-4", "control-label"], [2, "color", "red"], [1, "col-sm-8"], [1, "input-group"], ["name", "userPassword", "autocomplete", "off", "required", "", "value", "", "placeholder", "Password", 1, "form-control", 3, "type", "ngModel", "change", "ngModelChange"], ["userPassword", "ngModel"], [3, "click"], ["class", "alert-validation alert-danger", 4, "ngIf"], ["name", "userPassCf", "autocomplete", "off", "required", "", "id", "userPassCf", "placeholder", "Nh\u1EADp l\u1EA1i Password", 1, "form-control", 3, "type", "ngModel", "change", "ngModelChange"], ["userPassCf", "ngModel"], [1, "col-md-12", "text-right"], ["label", "L\u01B0u l\u1EA1i", "styleClass", "mr-1", 3, "click"], ["label", "H\u1EE7y", "styleClass", "p-button-secondary", 3, "click"], [1, "col-4", "pd-0"], [1, "field-group", "select", "mb-0", 2, "background", "#fff"], ["panelStyleClass", "nav-select-oragin", "appendTo", "body", "name", "organizeRole", 3, "baseZIndex", "disabled", "options", "ngModel", "filter", "onChange", "ngModelChange"], [1, "alert-validation", "alert-danger"], [4, "ngIf"]], template: function NavbarComponent_Template(rf, ctx) { if (rf & 1) {
        const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-toolbar");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function NavbarComponent_Template_a_click_2_listener() { return ctx.goToHome(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "svg", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "g", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](5, "path", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "path", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "defs");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "clipPath", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "rect", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, NavbarComponent_div_11_Template, 3, 5, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function NavbarComponent_Template_div_click_13_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r12); const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](18); return _r1.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](14, "p-avatar", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](17, "p-menu", 14, 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](20, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "p-dialog", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function NavbarComponent_Template_p_dialog_visibleChange_21_listener($event) { return ctx.isShowChangePassword = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "p-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "form", 19, 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "label", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](29, "M\u1EADt kh\u1EA9u ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](30, "span", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](31, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](32, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](33, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](34, "input", 27, 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("change", function NavbarComponent_Template_input_change_34_listener() { return ctx.checkPasswordcf(); })("ngModelChange", function NavbarComponent_Template_input_ngModelChange_34_listener($event) { return ctx.modelPass.userPassword = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](36, "span", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function NavbarComponent_Template_span_click_36_listener() { return ctx.isShowPass = !ctx.isShowPass; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](37, NavbarComponent_div_37_Template, 2, 1, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](38, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](39, "label", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](40, "Nh\u1EADp l\u1EA1i m\u1EADt kh\u1EA9u ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](41, "span", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](42, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](43, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](44, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](45, "input", 31, 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("change", function NavbarComponent_Template_input_change_45_listener() { return ctx.checkPasswordcf(); })("ngModelChange", function NavbarComponent_Template_input_ngModelChange_45_listener($event) { return ctx.modelPass.userPassCf = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](47, "span", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function NavbarComponent_Template_span_click_47_listener() { return ctx.isShowRepass = !ctx.isShowRepass; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](48, NavbarComponent_div_48_Template, 2, 1, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](49, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](50, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](51, "p-button", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function NavbarComponent_Template_p_button_click_51_listener() { return ctx.saveChangePass(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](52, "p-button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function NavbarComponent_Template_p_button_click_52_listener() { return ctx.isShowChangePassword = !ctx.isShowChangePassword; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.detailOrganizes.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](23, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx.userName, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("popup", true)("model", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](24, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.isShowChangePassword)("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" C\u1EADp nh\u1EADt m\u1EADt kh\u1EA9u t\u00E0i kho\u1EA3n [", ctx.userName, "] ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("type", ctx.isShowPass ? "text" : "password");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx.modelPass.userPassword);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassMapInterpolate1"]("pi pi-eye-pass ", ctx.isShowPass ? "pi-eye-slash" : "pi-eye", " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.submitPass && !ctx.modelPass.userPassword);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("type", ctx.isShowRepass ? "text" : "password");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx.modelPass.userPassCf);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassMapInterpolate1"]("pi pi-eye-pass ", ctx.isShowRepass ? "pi-eye-slash" : "pi-eye", "");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.submitPass && (ctx.confimPassword || !ctx.modelPass.userPassCf));
    } }, directives: [primeng_toolbar__WEBPACK_IMPORTED_MODULE_7__.Toolbar, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, primeng_avatar__WEBPACK_IMPORTED_MODULE_9__.Avatar, primeng_menu__WEBPACK_IMPORTED_MODULE_10__.Menu, primeng_dialog__WEBPACK_IMPORTED_MODULE_11__.Dialog, primeng_api__WEBPACK_IMPORTED_MODULE_6__.Header, _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgForm, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_13__.Button, primeng_dropdown__WEBPACK_IMPORTED_MODULE_14__.Dropdown], styles: [".logo[_ngcontent-%COMP%] {\n  min-height: 52px;\n  height: auto;\n}\n.logo[_ngcontent-%COMP%]:hover {\n  cursor: pointer;\n}\n.logo[_ngcontent-%COMP%]:focus {\n  outline: none;\n}\n.change-password[_ngcontent-%COMP%]   .input-group[_ngcontent-%COMP%] {\n  margin-bottom: 25px;\n}\n[_nghost-%COMP%]  [styleclass=my-account-menu] .p-menu {\n  top: 100% !important;\n}\n.go-to-home[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n[_nghost-%COMP%]  p-toolbar .field-group.select .p-disabled {\n  background: #d9d9d9;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5hdmJhci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVFLGdCQUFBO0VBQ0EsWUFBQTtBQUFGO0FBQ0U7RUFDSSxlQUFBO0FBQ047QUFDRTtFQUNJLGFBQUE7QUFDTjtBQUlFO0VBQ0UsbUJBQUE7QUFESjtBQU1JO0VBQ0Usb0JBQUE7QUFITjtBQU9BO0VBQ0UsZUFBQTtBQUpGO0FBTWdCO0VBQ1osbUJBQUE7QUFISiIsImZpbGUiOiJuYXZiYXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubG9nb3tcclxuICAvLyBtYXgtd2lkdGg6IDE0OHB4O1xyXG4gIG1pbi1oZWlnaHQ6IDUycHg7XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG4gICY6aG92ZXJ7XHJcbiAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICB9XHJcbiAgJjpmb2N1c3tcclxuICAgICAgb3V0bGluZTogbm9uZTtcclxuICB9XHJcbn1cclxuXHJcbi5jaGFuZ2UtcGFzc3dvcmR7XHJcbiAgLmlucHV0LWdyb3Vwe1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMjVweDtcclxuICB9XHJcbn1cclxuOmhvc3Q6Om5nLWRlZXB7XHJcbiAgW3N0eWxlY2xhc3M9XCJteS1hY2NvdW50LW1lbnVcIl17XHJcbiAgICAucC1tZW51e1xyXG4gICAgICB0b3A6IDEwMCUgIWltcG9ydGFudDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuLmdvLXRvLWhvbWV7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbjpob3N0OjpuZy1kZWVweyBwLXRvb2xiYXIgLmZpZWxkLWdyb3VwLnNlbGVjdCAucC1kaXNhYmxlZHtcclxuICAgIGJhY2tncm91bmQ6ICNkOWQ5ZDk7XHJcbiAgfVxyXG59Il19 */"] });


/***/ }),

/***/ 51382:
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SharedModule": () => (/* binding */ SharedModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./footer/footer.component */ 62791);
/* harmony import */ var _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./navbar/navbar.component */ 31614);
/* harmony import */ var _sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sidebar/sidebar.component */ 96263);
/* harmony import */ var _directives_toggle_fullscreen_directive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./directives/toggle-fullscreen.directive */ 18874);
/* harmony import */ var _utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/common/button-renderer.component */ 75137);
/* harmony import */ var _utils_common_normal_button_renderer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/common/normal-button-renderer.component */ 31914);
/* harmony import */ var _utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils/common/button-renderer.component-1 */ 90457);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/splitbutton */ 71494);
/* harmony import */ var _utils_common_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utils/common/button-renderermutibuttons.component */ 91861);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var _margin_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./margin.pipe */ 5471);
/* harmony import */ var _margin_round_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./margin-round.pipe */ 28949);
/* harmony import */ var _utils_common_numeric_editor_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/common/numeric-editor.component */ 78959);
/* harmony import */ var _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @ag-grid-community/angular */ 11775);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_menubar__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/menubar */ 24580);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_avatar__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/avatar */ 72189);
/* harmony import */ var primeng_toolbar__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/toolbar */ 7225);
/* harmony import */ var _common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var _common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var _common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var _common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../common/pipe/currency-pipe.module */ 44093);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/multiselect */ 92487);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 14001);































class SharedModule {
}
SharedModule.ɵfac = function SharedModule_Factory(t) { return new (t || SharedModule)(); };
SharedModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineNgModule"]({ type: SharedModule });
SharedModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineInjector"]({ imports: [[
            _angular_router__WEBPACK_IMPORTED_MODULE_16__.RouterModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_17__.CommonModule,
            primeng_splitbutton__WEBPACK_IMPORTED_MODULE_18__.SplitButtonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_19__.FormsModule,
            primeng_dropdown__WEBPACK_IMPORTED_MODULE_20__.DropdownModule,
            primeng_calendar__WEBPACK_IMPORTED_MODULE_21__.CalendarModule,
            primeng_paginator__WEBPACK_IMPORTED_MODULE_22__.PaginatorModule,
            primeng_avatar__WEBPACK_IMPORTED_MODULE_23__.AvatarModule,
            primeng_menubar__WEBPACK_IMPORTED_MODULE_24__.MenubarModule,
            primeng_toolbar__WEBPACK_IMPORTED_MODULE_25__.ToolbarModule,
            _common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_14__.CurrencyFormatPipeModule,
            primeng_menu__WEBPACK_IMPORTED_MODULE_26__.MenuModule,
            primeng_dialog__WEBPACK_IMPORTED_MODULE_27__.DialogModule,
            primeng_multiselect__WEBPACK_IMPORTED_MODULE_28__.MultiSelectModule,
            _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_29__.AgGridModule.withComponents([
                _utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_4__.ButtonRendererComponent,
                _common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_13__.CustomTooltipComponent,
                _utils_common_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_7__.ButtonRendererMutiComponent,
                _utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_6__.ButtonRendererComponent1,
                _utils_common_numeric_editor_component__WEBPACK_IMPORTED_MODULE_10__.NumericEditor
            ]),
        ], _angular_common__WEBPACK_IMPORTED_MODULE_17__.CommonModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵsetNgModuleScope"](SharedModule, { declarations: [_footer_footer_component__WEBPACK_IMPORTED_MODULE_0__.FooterComponent,
        _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_1__.NavbarComponent,
        _sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_2__.SidebarComponent,
        _directives_toggle_fullscreen_directive__WEBPACK_IMPORTED_MODULE_3__.ToggleFullscreenDirective,
        _utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_4__.ButtonRendererComponent,
        _utils_common_normal_button_renderer_component__WEBPACK_IMPORTED_MODULE_5__.NormalButtonRendererComponent,
        _utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_6__.ButtonRendererComponent1,
        _common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_11__.AvatarFullComponent,
        _utils_common_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_7__.ButtonRendererMutiComponent,
        _margin_pipe__WEBPACK_IMPORTED_MODULE_8__.MarginPipe,
        _margin_round_pipe__WEBPACK_IMPORTED_MODULE_9__.MarginRoundPipe,
        _utils_common_numeric_editor_component__WEBPACK_IMPORTED_MODULE_10__.NumericEditor,
        _common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_12__.ButtonAgGridComponent], imports: [_angular_router__WEBPACK_IMPORTED_MODULE_16__.RouterModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_17__.CommonModule,
        primeng_splitbutton__WEBPACK_IMPORTED_MODULE_18__.SplitButtonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_19__.FormsModule,
        primeng_dropdown__WEBPACK_IMPORTED_MODULE_20__.DropdownModule,
        primeng_calendar__WEBPACK_IMPORTED_MODULE_21__.CalendarModule,
        primeng_paginator__WEBPACK_IMPORTED_MODULE_22__.PaginatorModule,
        primeng_avatar__WEBPACK_IMPORTED_MODULE_23__.AvatarModule,
        primeng_menubar__WEBPACK_IMPORTED_MODULE_24__.MenubarModule,
        primeng_toolbar__WEBPACK_IMPORTED_MODULE_25__.ToolbarModule,
        _common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_14__.CurrencyFormatPipeModule,
        primeng_menu__WEBPACK_IMPORTED_MODULE_26__.MenuModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_27__.DialogModule,
        primeng_multiselect__WEBPACK_IMPORTED_MODULE_28__.MultiSelectModule, _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_29__.AgGridModule], exports: [_angular_common__WEBPACK_IMPORTED_MODULE_17__.CommonModule,
        _footer_footer_component__WEBPACK_IMPORTED_MODULE_0__.FooterComponent,
        _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_1__.NavbarComponent,
        _sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_2__.SidebarComponent,
        _directives_toggle_fullscreen_directive__WEBPACK_IMPORTED_MODULE_3__.ToggleFullscreenDirective,
        _utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_4__.ButtonRendererComponent,
        _utils_common_normal_button_renderer_component__WEBPACK_IMPORTED_MODULE_5__.NormalButtonRendererComponent,
        _utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_6__.ButtonRendererComponent1,
        _utils_common_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_7__.ButtonRendererMutiComponent,
        _common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_11__.AvatarFullComponent,
        _margin_pipe__WEBPACK_IMPORTED_MODULE_8__.MarginPipe,
        _margin_round_pipe__WEBPACK_IMPORTED_MODULE_9__.MarginRoundPipe,
        _utils_common_numeric_editor_component__WEBPACK_IMPORTED_MODULE_10__.NumericEditor,
        _common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_12__.ButtonAgGridComponent] }); })();


/***/ }),

/***/ 96263:
/*!*****************************************************!*\
  !*** ./src/app/shared/sidebar/sidebar.component.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SidebarComponent": () => (/* binding */ SidebarComponent)
/* harmony export */ });
/* harmony import */ var E_uni_frontend_uni_hrm_sunshineapp_vn_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ 62783);
/* harmony import */ var oidc_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! oidc-client */ 48725);
/* harmony import */ var oidc_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(oidc_client__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 31569);
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api.service */ 67118);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 36636);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ 18260);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var src_app_services_firebase_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/firebase-auth.service */ 16889);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_menubar__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/menubar */ 24580);





















class SidebarComponent {
  constructor(router, authService, apiService, firebaseAuthService, organizeInfoService, messageService, spinner) {
    this.router = router;
    this.authService = authService;
    this.apiService = apiService;
    this.firebaseAuthService = firebaseAuthService;
    this.organizeInfoService = organizeInfoService;
    this.messageService = messageService;
    this.spinner = spinner;
    this.menuItems = [];
    this.manager = new oidc_client__WEBPACK_IMPORTED_MODULE_1__.UserManager(src_environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.authenSettings);
    this.listmenuChecks = [];
    this.isWarning = 0;
    router.events.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.filter)(event => event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_9__.NavigationEnd)).subscribe(e => {
      var _a;

      let fullUrl = window.location.pathname.split("?");
      let pathUrl = fullUrl[0].split("/");
      let pathDepth1 = '';
      let pathDepth2 = '';
      let pathDepth3 = '';

      if (pathUrl[1]) {
        pathDepth1 = '/' + pathUrl["1"];
      }

      if (pathUrl[2]) {
        pathDepth2 = '/' + pathUrl["1"] + '/' + pathUrl["2"];
      }

      if (pathUrl[3]) {
        pathDepth3 = '/' + pathUrl["1"] + '/' + pathUrl["2"] + '/' + pathUrl["3"];
      }

      if (this.listmenuChecks.length > 0) {
        let canActive = false;

        for (let i = 0; i < this.listmenuChecks.length; i++) {
          let currentPath = this.listmenuChecks[i].path || '';
          currentPath = currentPath.split("/");
          let baseCurrentPath = '';

          if (currentPath[0]) {
            baseCurrentPath = '/' + currentPath[0];
          }

          if (currentPath[1]) {
            baseCurrentPath = '/' + currentPath[1];
          }

          if (currentPath[2]) {
            baseCurrentPath = '/' + currentPath[2];
          }

          if (baseCurrentPath === pathDepth1 || baseCurrentPath === pathDepth2 || baseCurrentPath === pathDepth3) {
            canActive = true;
            break;
          }
        }

        if (!canActive) {
          // neu khong có quyền thì quay về trang đầu tiên
          if (this.menuItems[0].submenus && ((_a = this.menuItems[0].submenus[0]) === null || _a === void 0 ? void 0 : _a.path)) {
            this.router.navigate([this.menuItems[0].submenus[0].path]);
          } else {
            this.router.navigate(['/404']);
          }
        }

        const pathname = window.location.pathname;
        this.parseObjectProperties(this.menuItems, pathname);
        this.menuItems = [...this.menuItems];
      } else {
        this.router.navigate['/404'];
      }
    });
  } // checkMenuActive(listmenuChecks) {
  //     listmenuChecks.forEach(menu => {
  //         let fullUrl =  menu.path.split("/");
  //         if(pathUrl[1]){
  //             pathDepth1 = '/' + pathUrl["1"]
  //         }
  //         if(pathUrl[2]){
  //             pathDepth2 = '/' + pathUrl["1"] + '/' + pathUrl["2"]
  //         }
  //     });
  // }


  ngOnInit() {
    var _this = this;

    return (0,E_uni_frontend_uni_hrm_sunshineapp_vn_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const pathname = window.location.pathname;
      let fullUrl = pathname.split("?");
      let pathUrl = fullUrl[0].split("/");
      let pathDepth1 = '';
      let pathDepth2 = '';
      let pathDepth3 = '';

      if (pathUrl[1]) {
        pathDepth1 = '/' + pathUrl["1"];
      }

      if (pathUrl[2]) {
        pathDepth2 = '/' + pathUrl["1"] + '/' + pathUrl["2"];
      }

      if (pathUrl[3]) {
        pathDepth3 = '/' + pathUrl["1"] + '/' + pathUrl["2"] + '/' + pathUrl["3"];
      }

      const token = _this.authService.getAccessTokenValue();

      if (!_this.firebaseAuthService.authenticated) {
        const customToken = yield _this.authService.getCustomToken(token);

        if (customToken) {
          _this.firebaseAuthService.customLogin(customToken);
        }
      }

      _this.organizeInfoService.organizeInfo$.subscribe(results => {
        if (results && results.length > 0) {
          const queryParams = querystring__WEBPACK_IMPORTED_MODULE_7__.stringify({
            organizeIds: results
          });
          const queryMeny = querystring__WEBPACK_IMPORTED_MODULE_7__.stringify({
            userId: _this.authService.getClaims().sub,
            webId: '70e930b0-ffea-43d3-b3a9-0e6b03f2b433'
          }); //  this.apiService.getUserMenus(queryParams).subscribe(results => {
          //     console.log('menu old', results)
          //  })

          _this.apiService.clientMenuGetListByUserId(queryMeny).subscribe(results => {
            var _a; //   this.apiService.getUserMenus(queryParams).subscribe(results => {


            if (results.status === 'success') {
              _this.menuItems = results.data;

              _this.convetArry(_this.menuItems);

              if (_this.listmenuChecks.length > 0) {
                let canActive = false;

                for (let i = 0; i < _this.listmenuChecks.length; i++) {
                  let currentPath = _this.listmenuChecks[i].path || '';
                  currentPath = currentPath.split("/");
                  let baseCurrentPath = '';

                  if (currentPath[0]) {
                    baseCurrentPath = '/' + currentPath[0];
                  }

                  if (currentPath[1]) {
                    baseCurrentPath = '/' + currentPath[1];
                  }

                  if (currentPath[2]) {
                    baseCurrentPath = '/' + currentPath[2];
                  }

                  if (baseCurrentPath === pathDepth1 || baseCurrentPath === pathDepth2 || baseCurrentPath === pathDepth3) {
                    canActive = true;
                    break;
                  }
                }

                if (!canActive) {
                  // neu khong có quyền thì quay về trang đầu tiên
                  if (_this.menuItems[0].submenus && ((_a = _this.menuItems[0].submenus[0]) === null || _a === void 0 ? void 0 : _a.path)) {
                    _this.router.navigate([_this.menuItems[0].submenus[0].path]);
                  } else {
                    _this.router.navigate(['/404']);
                  }
                }

                const pathname = window.location.pathname;

                _this.parseObjectProperties(_this.menuItems, pathname);

                _this.menuItems = [..._this.menuItems];
              } else {
                _this.router.navigate['/404'];
              }

              localStorage.setItem('menuItems', JSON.stringify(results.data));

              _this.parseObjectProperties(_this.menuItems, pathDepth1);

              _this.menuItems = [..._this.menuItems];
            }
          });
        } else {
          _this.router.navigate(['/404']);
        }
      }); // this.menuItems = ROUTES.filter(menuItem => menuItem);
      //         this.parseObjectProperties(this.menuItems, pathname);
      //         this.menuItems = [...this.menuItems];

    })();
  }

  convetArry(datas) {
    for (let item of datas) {
      this.listmenuChecks.push(item);

      if (item.submenus && item.submenus.length > 0) {
        this.convetArry(item.submenus);
      }
    }
  }

  parseObjectProperties(obj, pathname) {
    for (let k of obj) {
      k.label = k.title;

      if (k.path && k.classs !== 'navigation-header') {
        k.routerLink = k.path;
        k.styleClass = 'nav-item';
        k.class = 'nav-item';
      }

      if (k.submenus && k.submenus.length > 0) {
        k.items = k.submenus.filter(d => d.classs && d.classs.indexOf("hidden") < 0);
      }

      if (k.routerLink) {
        // active menu con
        if (k.isExternalLink) {
          if (k.routerLink && pathname.includes(k.routerLink)) {
            k.styleClass = 'parent_active' + ' ' + k.class;
          } else {
            k.styleClass = 'parent_no_active' + ' ' + k.class;
          }
        } else {
          if (k.routerLink && pathname.includes(k.routerLink)) {
            k.styleClass = k.class + ' active' + ' ' + k.class;
            k.icon = '';
          } else {
            k.styleClass = k.class + ' no-active';
            +' ' + k.class;
            k.icon = '';
          }
        }
      } else {
        //active cha
        if (k.path && pathname && pathname.split('/').indexOf(k.path) > -1 && k.class === 'navigation-header') {
          k.styleClass = k.class + " parent_active" + ' ' + k.class;
        } else {
          k.styleClass = k.class + " parent_no_active" + ' ' + k.class;
        }
      }

      if (k.hasOwnProperty('items') && Array.isArray(k.items) && k.items.length > 0) {
        this.parseObjectProperties(k.items, pathname);
      }
    }
  }

}

SidebarComponent.ɵfac = function SidebarComponent_Factory(t) {
  return new (t || SidebarComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__.ApiService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_services_firebase_auth_service__WEBPACK_IMPORTED_MODULE_5__.FirebaseAuthService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_6__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_12__.NgxSpinnerService));
};

SidebarComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
  type: SidebarComponent,
  selectors: [["app-sidebar"]],
  decls: 1,
  vars: 1,
  consts: [["styleClass", "sidebarBody", "id", "sidebarBody", 3, "model"]],
  template: function SidebarComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "p-menubar", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("model", ctx.menuItems);
    }
  },
  directives: [primeng_menubar__WEBPACK_IMPORTED_MODULE_13__.Menubar],
  encapsulation: 2
});

/***/ }),

/***/ 82115:
/*!************************************************!*\
  !*** ./src/app/sunshine/sunshine.component.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SunshineComponent": () => (/* binding */ SunshineComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _shared_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../shared/navbar/navbar.component */ 31614);
/* harmony import */ var _shared_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../shared/sidebar/sidebar.component */ 96263);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 13252);





class SunshineComponent {
    constructor(renderer) {
        this.renderer = renderer;
        this.renderer.addClass(document.body, 'sunshine');
        this.renderer.setAttribute(document.body, 'data-col', 'sunshine');
    }
    ngOnDestroy() {
        this.renderer.removeClass(document.body, 'sunshine');
    }
}
SunshineComponent.ɵfac = function SunshineComponent_Factory(t) { return new (t || SunshineComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.Renderer2)); };
SunshineComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: SunshineComponent, selectors: [["app-sunshine"]], decls: 6, vars: 0, consts: [[1, "app-body"], [1, "header"], [1, "main"]], template: function SunshineComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "app-navbar");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](4, "app-sidebar");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](5, "router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } }, directives: [_shared_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_0__.NavbarComponent, _shared_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_1__.SidebarComponent, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterOutlet], styles: [".ngx-datepicker-calendar-container[_ngcontent-%COMP%] {\n  z-index: 9 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1bnNoaW5lLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7QUFDSiIsImZpbGUiOiJzdW5zaGluZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5uZ3gtZGF0ZXBpY2tlci1jYWxlbmRhci1jb250YWluZXIge1xyXG4gICAgei1pbmRleDogOSAhaW1wb3J0YW50O1xyXG59Il19 */"] });


/***/ }),

/***/ 59752:
/*!**********************************!*\
  !*** ./src/app/theme.service.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ThemeService": () => (/* binding */ ThemeService)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);


class ThemeService {
    constructor(document) {
        this.document = document;
    }
    switchTheme(theme) {
        let themeLink = this.document.getElementById('app-theme');
        if (themeLink) {
            themeLink.href = theme + '.css';
        }
    }
}
ThemeService.ɵfac = function ThemeService_Factory(t) { return new (t || ThemeService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common__WEBPACK_IMPORTED_MODULE_1__.DOCUMENT)); };
ThemeService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: ThemeService, factory: ThemeService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 90457:
/*!*************************************************************!*\
  !*** ./src/app/utils/common/button-renderer.component-1.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ButtonRendererComponent1": () => (/* binding */ ButtonRendererComponent1)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 28267);


function ButtonRendererComponent1_ng_container_1_button_1_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ButtonRendererComponent1_ng_container_1_button_1_Template_button_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r6); const i_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().index; const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r4.onClick($event, i_r2); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMapInterpolate1"]("btn ", item_r1.class, " btn-sm");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("title", item_r1.label);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](item_r1.icon);
} }
function ButtonRendererComponent1_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ButtonRendererComponent1_ng_container_1_button_1_Template, 2, 7, "button", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const item_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r1 == null ? null : item_r1.show);
} }
class ButtonRendererComponent1 {
    agInit(params) {
        this.params = params;
        this.label = this.params.label || null;
    }
    refresh(params) {
        return true;
    }
    onClick($event, idx) {
        console.log(this.params);
        if (this.params.buttons[idx].onClick instanceof Function) {
            // put anything into params u want pass into parents component
            const params = {
                event: $event,
                rowData: this.params.node.data,
                index: this.params.rowIndex
                // ...something
            };
            this.params.buttons[idx].onClick(params);
        }
    }
}
ButtonRendererComponent1.ɵfac = function ButtonRendererComponent1_Factory(t) { return new (t || ButtonRendererComponent1)(); };
ButtonRendererComponent1.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ButtonRendererComponent1, selectors: [["app-button-renderer"]], decls: 2, vars: 1, consts: [[2, "display", "flex"], [4, "ngFor", "ngForOf"], ["style", "padding:5px; color:red", "type", "button", 3, "title", "class", "click", 4, "ngIf"], ["type", "button", 2, "padding", "5px", "color", "red", 3, "title", "click"]], template: function ButtonRendererComponent1_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ButtonRendererComponent1_ng_container_1_Template, 2, 1, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.params.buttons);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf], encapsulation: 2 });


/***/ }),

/***/ 75137:
/*!***********************************************************!*\
  !*** ./src/app/utils/common/button-renderer.component.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ButtonRendererComponent": () => (/* binding */ ButtonRendererComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 28267);


function ButtonRendererComponent_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ButtonRendererComponent_ng_container_1_Template_button_click_1_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4); const i_r2 = restoredCtx.index; const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r3.onClick($event, i_r2); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "i");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const item_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMapInterpolate1"]("btn ", item_r1.class, " btn-sm");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("title", item_r1.label);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", item_r1 == null ? null : item_r1.hide);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](item_r1.icon);
} }
class ButtonRendererComponent {
    agInit(params) {
        this.params = params;
        this.label = this.params.label || null;
    }
    refresh(params) {
        return true;
    }
    onClick($event, idx) {
        console.log(this.params);
        if (this.params.buttons[idx].onClick instanceof Function) {
            // put anything into params u want pass into parents component
            const params = {
                event: $event,
                rowData: this.params.node.data,
                index: this.params.rowIndex
                // ...something
            };
            this.params.buttons[idx].onClick(params);
        }
    }
}
ButtonRendererComponent.ɵfac = function ButtonRendererComponent_Factory(t) { return new (t || ButtonRendererComponent)(); };
ButtonRendererComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ButtonRendererComponent, selectors: [["app-button-renderer"]], decls: 2, vars: 1, consts: [[2, "display", "flex"], [4, "ngFor", "ngForOf"], ["type", "button", 2, "padding", "5px", 3, "title", "hidden", "click"]], template: function ButtonRendererComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ButtonRendererComponent_ng_container_1_Template, 3, 8, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.params.buttons);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf], encapsulation: 2 });


/***/ }),

/***/ 91861:
/*!**********************************************************************!*\
  !*** ./src/app/utils/common/button-renderermutibuttons.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ButtonRendererMutiComponent": () => (/* binding */ ButtonRendererMutiComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/splitbutton */ 71494);


// import { ICellRendererParams, IAfterGuiAttachedParams } from 'ag-grid';
class ButtonRendererMutiComponent {
    constructor() {
        this.items = [];
    }
    agInit(params) {
        this.params = params;
        for (let index in this.params.buttons) {
            if (!this.params.buttons[index].hide) {
                const object = { label: this.params.buttons[index].label, icon: this.params.buttons[index].icon, command: ($event) => {
                        this.onClick($event, index);
                    } };
                this.items.push(object);
            }
        }
    }
    conddd(e) {
        console.log(e);
    }
    refresh(params) {
        return true;
    }
    onClick($event, idx) {
        console.log(this.params);
        if (this.params.buttons[idx].onClick instanceof Function) {
            // put anything into params u want pass into parents component
            const params = {
                event: $event,
                rowData: this.params.node.data,
                index: this.params.rowIndex
                // ...something
            };
            this.params.buttons[idx].onClick(params);
        }
    }
}
ButtonRendererMutiComponent.ɵfac = function ButtonRendererMutiComponent_Factory(t) { return new (t || ButtonRendererMutiComponent)(); };
ButtonRendererMutiComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ButtonRendererMutiComponent, selectors: [["app-button-renderer"]], decls: 1, vars: 2, consts: [["icon", "pi pi-bars", "styleClass", "p-button-sm", 3, "appendTo", "model", "onDropdownClick"]], template: function ButtonRendererMutiComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p-splitButton", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("onDropdownClick", function ButtonRendererMutiComponent_Template_p_splitButton_onDropdownClick_0_listener($event) { return ctx.conddd($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("appendTo", "body")("model", ctx.items);
    } }, directives: [primeng_splitbutton__WEBPACK_IMPORTED_MODULE_1__.SplitButton], encapsulation: 2 });


/***/ }),

/***/ 69558:
/*!***********************************************************!*\
  !*** ./src/app/utils/common/checkbox-editor.component.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CheckboxEditorComponent": () => (/* binding */ CheckboxEditorComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);

class CheckboxEditorComponent {
    constructor() { }
    agInit(params) {
        this.value = params.value;
    }
    ngOnInit() {
    }
    onchange(event) {
        console.log(event);
    }
}
CheckboxEditorComponent.ɵfac = function CheckboxEditorComponent_Factory(t) { return new (t || CheckboxEditorComponent)(); };
CheckboxEditorComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CheckboxEditorComponent, selectors: [["app-checkbox-renderer"]], decls: 1, vars: 1, consts: [["type", "checkbox", 1, "my-custom-input-class", 2, "width", "100%", "justify-content", "center", 3, "checked", "change"]], template: function CheckboxEditorComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function CheckboxEditorComponent_Template_input_change_0_listener($event) { return ctx.onchange($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("checked", ctx.value);
    } }, encapsulation: 2 });


/***/ }),

/***/ 9221:
/*!****************************************************!*\
  !*** ./src/app/utils/common/currency.directive.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CurrencyDirective": () => (/* binding */ CurrencyDirective)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var numeral__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! numeral */ 89714);
/* harmony import */ var numeral__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(numeral__WEBPACK_IMPORTED_MODULE_0__);



class CurrencyDirective {
    constructor(el) {
        this.el = el;
        this.rawChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    }
    ngAfterViewInit() {
    }
    ngOnInit() {
    }
    ngAfterContentChecked() {
    }
    onInputChange(event, backspace) {
        if (event) {
            if (event.target) {
                if (numeral__WEBPACK_IMPORTED_MODULE_0__(event.target.value).value() % 1 >= 0) {
                    const newVal = numeral__WEBPACK_IMPORTED_MODULE_0__(event.target.value).format('0,0[.][00]');
                    // // var myNumeral2 = numeral(newVal);
                    // // var value2 = myNumeral2.value();
                    const rawValue = newVal;
                    event.target.value = newVal;
                    // this.model = newVal
                    this.rawChange.emit(rawValue);
                }
                else {
                    event.target.value = 0;
                    this.rawChange.emit('0');
                }
            }
        }
    }
}
CurrencyDirective.ɵfac = function CurrencyDirective_Factory(t) { return new (t || CurrencyDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef)); };
CurrencyDirective.ɵdir = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({ type: CurrencyDirective, selectors: [["", "currency", ""]], hostBindings: function CurrencyDirective_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("change", function CurrencyDirective_change_HostBindingHandler($event) { return ctx.onInputChange($event); })("keydown.backspace", function CurrencyDirective_keydown_backspace_HostBindingHandler($event) { return ctx.onInputChange($event.target.value, true); });
    } }, outputs: { rawChange: "rawChange" } });


/***/ }),

/***/ 87082:
/*!*************************************************!*\
  !*** ./src/app/utils/common/currency.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CurrencyDirectiveModule": () => (/* binding */ CurrencyDirectiveModule)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _currency_directive__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./currency.directive */ 9221);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);





class CurrencyDirectiveModule {
}
CurrencyDirectiveModule.ɵfac = function CurrencyDirectiveModule_Factory(t) { return new (t || CurrencyDirectiveModule)(); };
CurrencyDirectiveModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: CurrencyDirectiveModule });
CurrencyDirectiveModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule,
            // BrowserModule,
            // BrowserAnimationsModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](CurrencyDirectiveModule, { declarations: [_currency_directive__WEBPACK_IMPORTED_MODULE_0__.CurrencyDirective], imports: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule], exports: [_currency_directive__WEBPACK_IMPORTED_MODULE_0__.CurrencyDirective] }); })();


/***/ }),

/***/ 91469:
/*!*********************************************************!*\
  !*** ./src/app/utils/common/customtooltip.component.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomTooltipComponent": () => (/* binding */ CustomTooltipComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _shared_margin_round_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../shared/margin-round.pipe */ 28949);



function CustomTooltipComponent_div_0_p_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r1.data[ctx_r1.params.colDef == null ? null : ctx_r1.params.colDef.field]);
} }
function CustomTooltipComponent_div_0_p_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "p", 8);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("innerHTML", ctx_r2.data[ctx_r2.params.colDef == null ? null : ctx_r2.params.colDef.field], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeHtml"]);
} }
function CustomTooltipComponent_div_0_p_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "marginRound");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](2, 1, ctx_r3.data[ctx_r3.params.colDef == null ? null : ctx_r3.params.colDef.field], 2));
} }
function CustomTooltipComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "h3", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, CustomTooltipComponent_div_0_p_6_Template, 2, 1, "p", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](7, CustomTooltipComponent_div_0_p_7_Template, 1, 1, "p", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](8, CustomTooltipComponent_div_0_p_8_Template, 3, 4, "p", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", "panel panel-" + (ctx_r0.data == null ? null : ctx_r0.data.type));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.params.colDef == null ? null : ctx_r0.params.colDef.headerName);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !ctx_r0.isAmount && !ctx_r0.isHtml && (ctx_r0.params.colDef == null ? null : ctx_r0.params.colDef.field.indexOf("margin")) === -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !ctx_r0.isAmount && ctx_r0.isHtml);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !ctx_r0.isAmount && !ctx_r0.isHtml && (ctx_r0.params.colDef == null ? null : ctx_r0.params.colDef.field.indexOf("margin")) > -1);
} }
// <p *ngIf="isAmount">{{ data[params.colDef?.field] | currencyFormat  }}</p>
class CustomTooltipComponent {
    constructor() {
        this.isAmount = false;
        this.isHtml = false;
    }
    agInit(params) {
        var _a, _b;
        this.params = params;
        if (this.params.rowIndex === 0) {
            this.data = this.params.api.getDisplayedRowAtIndex(0).data;
            this.data.type = ((_a = this.params) === null || _a === void 0 ? void 0 : _a.type) || 'primary';
            this.pipeCheckTransform();
        }
        if (this.params.rowIndex) {
            this.data = this.params.api.getDisplayedRowAtIndex(this.params.rowIndex).data;
            this.data.type = ((_b = this.params) === null || _b === void 0 ? void 0 : _b.type) || 'primary';
            this.pipeCheckTransform();
        }
    }
    pipeCheckTransform() {
        if (this.params.colDef.field.indexOf('amount') > -1 || this.params.colDef.field.indexOf('price') > -1 ||
            this.params.colDef.field.indexOf('profit') > -1 || this.params.colDef.field.indexOf('revenue') > -1 || this.params.colDef.field.indexOf('promotion_by_value') > -1
            || this.params.colDef.field.indexOf('promotion_value') > -1) {
            this.isAmount = true;
        }
        else {
            this.isAmount = false;
            if (typeof (this.data[this.params.colDef.field]) === 'string' && this.data[this.params.colDef.field].indexOf('<span') > -1) {
                this.isHtml = true;
            }
            else {
                this.isHtml = false;
            }
        }
    }
}
CustomTooltipComponent.ɵfac = function CustomTooltipComponent_Factory(t) { return new (t || CustomTooltipComponent)(); };
CustomTooltipComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: CustomTooltipComponent, selectors: [["app-custom-tooltip"]], decls: 1, vars: 1, consts: [["class", "custom-tooltip", 4, "ngIf"], [1, "custom-tooltip"], [3, "ngClass"], [1, "panel-heading"], [1, "panel-title"], [1, "panel-body"], [4, "ngIf"], [3, "innerHTML", 4, "ngIf"], [3, "innerHTML"]], template: function CustomTooltipComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, CustomTooltipComponent_div_0_Template, 9, 5, "div", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.data);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgClass], pipes: [_shared_margin_round_pipe__WEBPACK_IMPORTED_MODULE_0__.MarginRoundPipe], styles: ["[_nghost-%COMP%] {\n  position: absolute;\n  pointer-events: none;\n  transition: opacity 1s;\n}\n\n.ag-tooltip-hiding[_nghost-%COMP%] {\n  opacity: 0;\n}\n\n.custom-tooltip[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 5px;\n  white-space: normal;\n  word-wrap: break-word;\n}\n\n.custom-tooltip[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]:first-of-type {\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbXRvb2x0aXAuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNNO0VBQ0Usa0JBQUE7RUFDQSxvQkFBQTtFQUNBLHNCQUFBO0FBQVI7O0FBR007RUFDRSxVQUFBO0FBQVI7O0FBR007RUFDRSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtBQUFSOztBQUdNO0VBQ0UsaUJBQUE7QUFBUiIsImZpbGUiOiJjdXN0b210b29sdGlwLmNvbXBvbmVudC50cyIsInNvdXJjZXNDb250ZW50IjpbIlxuICAgICAgOmhvc3Qge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgICAgICB0cmFuc2l0aW9uOiBvcGFjaXR5IDFzO1xuICAgICAgfVxuXG4gICAgICA6aG9zdC5hZy10b29sdGlwLWhpZGluZyB7XG4gICAgICAgIG9wYWNpdHk6IDA7XG4gICAgICB9XG5cbiAgICAgIC5jdXN0b20tdG9vbHRpcCBwIHtcbiAgICAgICAgbWFyZ2luOiA1cHg7XG4gICAgICAgIHdoaXRlLXNwYWNlOiBub3JtYWw7XG4gICAgICAgIHdvcmQtd3JhcDogYnJlYWstd29yZDtcbiAgICAgIH1cblxuICAgICAgLmN1c3RvbS10b29sdGlwIHA6Zmlyc3Qtb2YtdHlwZSB7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgfVxuICAgICJdfQ== */"] });


/***/ }),

/***/ 30958:
/*!*************************************************************!*\
  !*** ./src/app/utils/common/dropdown-renderer.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DropdownRendererComponent": () => (/* binding */ DropdownRendererComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);

class DropdownRendererComponent {
    agInit(params) {
        this.value = params.value;
    }
}
DropdownRendererComponent.ɵfac = function DropdownRendererComponent_Factory(t) { return new (t || DropdownRendererComponent)(); };
DropdownRendererComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: DropdownRendererComponent, selectors: [["app-dropdown-renderer"]], decls: 2, vars: 1, template: function DropdownRendererComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.value);
    } }, encapsulation: 2 });


/***/ }),

/***/ 31914:
/*!******************************************************************!*\
  !*** ./src/app/utils/common/normal-button-renderer.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NormalButtonRendererComponent": () => (/* binding */ NormalButtonRendererComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 28267);


function NormalButtonRendererComponent_button_0_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function NormalButtonRendererComponent_button_0_Template_button_click_0_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4); const i_r2 = restoredCtx.index; const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r3.onClick($event, i_r2); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMapInterpolate1"]("btn ", item_r1.class, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("title", item_r1.label);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", item_r1.hidden ? item_r1.hidden : false);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("data-toggle", item_r1.isModal ? "modal" : "")("data-target", item_r1.isModal ? item_r1.target : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMapInterpolate1"]("fa ", item_r1.icon, "");
} }
class NormalButtonRendererComponent {
    agInit(params) {
        this.params = params;
        this.label = this.params.label || null;
    }
    refresh(params) {
        return true;
    }
    onClick($event, idx) {
        if (this.params.buttons[idx].onClick instanceof Function) {
            // put anything into params u want pass into parents component
            const params = {
                event: $event,
                rowData: this.params.node.data,
                index: this.params.rowIndex
                // ...something
            };
            this.params.buttons[idx].onClick(params);
        }
    }
}
NormalButtonRendererComponent.ɵfac = function NormalButtonRendererComponent_Factory(t) { return new (t || NormalButtonRendererComponent)(); };
NormalButtonRendererComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: NormalButtonRendererComponent, selectors: [["app-normal-button-renderer"]], decls: 1, vars: 1, consts: [["style", "padding:4px", "type", "button", 3, "title", "hidden", "class", "click", 4, "ngFor", "ngForOf"], ["type", "button", 2, "padding", "4px", 3, "title", "hidden", "click"]], template: function NormalButtonRendererComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, NormalButtonRendererComponent_button_0_Template, 2, 10, "button", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.params.buttons);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf], encapsulation: 2 });


/***/ }),

/***/ 67438:
/*!***********************************************************!*\
  !*** ./src/app/utils/common/number-renderer.component.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumberCellRenderer": () => (/* binding */ NumberCellRenderer)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);

class NumberCellRenderer {
    constructor() { }
    agInit(params) {
        console.log(params);
        this.value = params.value;
    }
    ngOnInit() {
    }
}
NumberCellRenderer.ɵfac = function NumberCellRenderer_Factory(t) { return new (t || NumberCellRenderer)(); };
NumberCellRenderer.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: NumberCellRenderer, selectors: [["child-number"]], decls: 1, vars: 0, consts: [["type", "number", "value", "TotalQty", 1, "my-custom-input-class", 2, "width", "100%"]], template: function NumberCellRenderer_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "input", 0);
    } }, encapsulation: 2 });


/***/ }),

/***/ 78959:
/*!**********************************************************!*\
  !*** ./src/app/utils/common/numeric-editor.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumericEditor": () => (/* binding */ NumericEditor)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 18346);



const _c0 = ["input"];
const KEY_BACKSPACE = 8;
const KEY_DELETE = 46;
const KEY_F2 = 113;
const KEY_ENTER = 13;
const KEY_TAB = 9;
class NumericEditor {
    constructor() {
        this.highlightAllOnFocus = true;
        this.cancelBeforeStart = false;
    }
    agInit(params) {
        this.params = params;
        this.setInitialState(this.params);
        // only start edit if key pressed is a number, not a letter
        this.cancelBeforeStart =
            params.charPress && '1234567890'.indexOf(params.charPress) < 0;
    }
    setInitialState(params) {
        let startValue;
        let highlightAllOnFocus = true;
        if (params.keyPress === KEY_BACKSPACE || params.keyPress === KEY_DELETE) {
            // if backspace or delete pressed, we clear the cell
            startValue = '';
        }
        else if (params.charPress) {
            // if a letter was pressed, we start with the letter
            startValue = params.charPress;
            highlightAllOnFocus = false;
        }
        else {
            // otherwise we start with the current value
            startValue = params.value;
            if (params.keyPress === KEY_F2) {
                highlightAllOnFocus = false;
            }
        }
        this.value = startValue;
        this.highlightAllOnFocus = highlightAllOnFocus;
    }
    getValue() {
        return this.value;
    }
    isCancelBeforeStart() {
        return this.cancelBeforeStart;
    }
    // will reject the number if it greater than 1,000,000
    // not very practical, but demonstrates the method.
    isCancelAfterEnd() {
        return this.value > 1000000;
    }
    onKeyDown(event) {
        // if (this.isLeftOrRight(event) || this.deleteOrBackspace(event)) {
        //   event.stopPropagation();
        //   return;
        // }
        // if (
        //   !this.finishedEditingPressed(event) &&
        //   !this.isKeyPressedNumeric(event)
        // ) {
        //   if (event.preventDefault) event.preventDefault();
        // }
    }
    // dont use afterGuiAttached for post gui events - hook into ngAfterViewInit instead for this
    ngAfterViewInit() {
        window.setTimeout(() => {
            this.input.element.nativeElement.focus();
            if (this.highlightAllOnFocus) {
                this.input.element.nativeElement.select();
                this.highlightAllOnFocus = false;
            }
            else {
                // when we started editing, we want the carot at the end, not the start.
                // this comes into play in two scenarios: a) when user hits F2 and b)
                // when user hits a printable character, then on IE (and only IE) the carot
                // was placed after the first character, thus 'apply' would end up as 'pplea'
                const length = this.input.element.nativeElement.value
                    ? this.input.element.nativeElement.value.length
                    : 0;
                if (length > 0) {
                    // this.input.element.nativeElement.setSelectionRange(length, length);
                }
            }
            this.input.element.nativeElement.focus();
        });
    }
    getCharCodeFromEvent(event) {
        event = event || window.event;
        return typeof event.which == 'undefined' ? event.keyCode : event.which;
    }
    isCharNumeric(charStr) {
        return !!/\d/.test(charStr);
    }
    isKeyPressedNumeric(event) {
        const charCode = this.getCharCodeFromEvent(event);
        const charStr = event.key ? event.key : String.fromCharCode(charCode);
        return this.isCharNumeric(charStr);
    }
    deleteOrBackspace(event) {
        return ([KEY_DELETE, KEY_BACKSPACE].indexOf(this.getCharCodeFromEvent(event)) > -1);
    }
    isLeftOrRight(event) {
        return [37, 39].indexOf(this.getCharCodeFromEvent(event)) > -1;
    }
    finishedEditingPressed(event) {
        const charCode = this.getCharCodeFromEvent(event);
        return charCode === KEY_ENTER || charCode === KEY_TAB;
    }
}
NumericEditor.ɵfac = function NumericEditor_Factory(t) { return new (t || NumericEditor)(); };
NumericEditor.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: NumericEditor, selectors: [["numeric-cell"]], viewQuery: function NumericEditor_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 5, _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewContainerRef);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.input = _t.first);
    } }, decls: 2, vars: 1, consts: [["type", "number", 2, "width", "100%", 3, "ngModel", "keydown", "ngModelChange"], ["input", ""]], template: function NumericEditor_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keydown", function NumericEditor_Template_input_keydown_0_listener($event) { return ctx.onKeyDown($event); })("ngModelChange", function NumericEditor_Template_input_ngModelChange_0_listener($event) { return ctx.value = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.value);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgModel], encapsulation: 2 });


/***/ }),

/***/ 78560:
/*!*******************************************************!*\
  !*** ./src/app/utils/common/text-editor.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TextEditorComponent": () => (/* binding */ TextEditorComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);

class TextEditorComponent {
    constructor() { }
    agInit(params) {
        this.value = params.value;
    }
    ngOnInit() {
    }
}
TextEditorComponent.ɵfac = function TextEditorComponent_Factory(t) { return new (t || TextEditorComponent)(); };
TextEditorComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: TextEditorComponent, selectors: [["app-text-editor"]], decls: 1, vars: 0, consts: [["type", "text", "value", "TotalQty", 1, "my-custom-input-class", 2, "width", "100%"]], template: function TextEditorComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "input", 0);
    } }, encapsulation: 2 });


/***/ }),

/***/ 16868:
/*!**************************************************************!*\
  !*** ./src/app/utils/common/tooltip-suggestion.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TooltipSuggestionComponent": () => (/* binding */ TooltipSuggestionComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 28267);


function TooltipSuggestionComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "h3", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.content);
} }
class TooltipSuggestionComponent {
    constructor() {
        this.content = '';
    }
    agInit(params) {
        this.params = params;
        if (this.params.rowIndex === 0) {
            this.data = this.params.api.getDisplayedRowAtIndex(0).data;
        }
        if (this.params.rowIndex) {
            this.data = params.api.getDisplayedRowAtIndex(this.params.rowIndex).data;
        }
        this.content = this.params.content || '';
    }
}
TooltipSuggestionComponent.ɵfac = function TooltipSuggestionComponent_Factory(t) { return new (t || TooltipSuggestionComponent)(); };
TooltipSuggestionComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: TooltipSuggestionComponent, selectors: [["app-tooltip-suggestion"]], decls: 1, vars: 1, consts: [["class", "custom-tooltip", 4, "ngIf"], [1, "custom-tooltip"], [1, "panel", "panel-suggestion"], [1, "panel-heading"], [1, "panel-title"], [1, "panel-body"]], template: function TooltipSuggestionComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, TooltipSuggestionComponent_div_0_Template, 6, 1, "div", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.data);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf], styles: ["[_nghost-%COMP%] {\n  position: absolute;\n  overflow: visible;\n  pointer-events: none;\n  transition: opacity 1s;\n}\n\n.ag-tooltip-hiding[_nghost-%COMP%] {\n  opacity: 0;\n}\n\n.custom-tooltip[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 5px;\n  white-space: nowrap;\n}\n\n.custom-tooltip[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]:first-of-type {\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRvb2x0aXAtc3VnZ2VzdGlvbi5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ007RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxzQkFBQTtBQUFSOztBQUdNO0VBQ0UsVUFBQTtBQUFSOztBQUdNO0VBQ0UsV0FBQTtFQUNBLG1CQUFBO0FBQVI7O0FBR007RUFDRSxpQkFBQTtBQUFSIiwiZmlsZSI6InRvb2x0aXAtc3VnZ2VzdGlvbi5jb21wb25lbnQudHMiLCJzb3VyY2VzQ29udGVudCI6WyJcbiAgICAgIDpob3N0IHtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBvdmVyZmxvdzogdmlzaWJsZTtcbiAgICAgICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XG4gICAgICAgIHRyYW5zaXRpb246IG9wYWNpdHkgMXM7XG4gICAgICB9XG5cbiAgICAgIDpob3N0LmFnLXRvb2x0aXAtaGlkaW5nIHtcbiAgICAgICAgb3BhY2l0eTogMDtcbiAgICAgIH1cblxuICAgICAgLmN1c3RvbS10b29sdGlwIHAge1xuICAgICAgICBtYXJnaW46IDVweDtcbiAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICAgIH1cblxuICAgICAgLmN1c3RvbS10b29sdGlwIHA6Zmlyc3Qtb2YtdHlwZSB7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgfVxuICAgICJdfQ== */"] });


/***/ }),

/***/ 18260:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
const host = {
    socketServer: 'wss://localhost:6999',
    authServer: 'https://dev-auth.unicloudgroup.com.vn',
    apiServer: 'https://dev.api.unicloudgroup.com.vn',
    apShomeServer: 'https://dev.api.apiresident.unicloudgroup.com.vn',
    apiCoreServer: 'https://dev.api.core.unicloudgroup.com.vn',
    apiHrmServer: 'https://dev.api.hrm.unicloudgroup.com.vn',
    apiHrmConfig: 'https://dev.api.hrmconfig.unicloudgroup.com.vn',
    uploadServer: 'https://data.sunshinegroup.vn/api/v1/FileHandler',
    // cloudFunction: 'https://us-central1-sunshine-super-app.cloudfunctions.net' //dev
    cloudFunction: 'https://asia-northeast1-sunshine-app-production.cloudfunctions.net' //product
};
const authenSettings = {
    authority: host.authServer,
    client_id: 'web_s_hrm_prod',
    redirect_uri: 'https://dev-web-hrm.unicloudgroup.com.vn/auth-callback',
    post_logout_redirect_uri: 'https://dev-web-hrm.unicloudgroup.com.vn',
    response_type: 'id_token token',
    scope: 'openid profile api_sre api_home_service api_core_bigtec api_hrm_bigtec',
    filterProtocolClaims: true,
    loadUserInfo: true,
    automaticSilentRenew: true,
    silent_redirect_uri: 'https://dev-web-hrm.unicloudgroup.com.vn/silent-refresh.html'
};
const firebase = {
    apiKey: 'AIzaSyAb3orVc8nnGT0L2JgbdzXrRND393mFiFU',
    authDomain: 'sunshine-app-production.firebaseapp.com',
    databaseURL: 'https://sunshine-app-production.firebaseio.com',
    projectId: 'sunshine-app-production',
    storageBucket: 'sunshine-app-production.appspot.com'
    // apiKey: 'AIzaSyAczqJoNnTDPPLktoPtQ694IH38sR8wX6w',
    // authDomain: 'sunshine-super-app.firebaseapp.com',
    // databaseURL: 'https://sunshine-super-app.firebaseio.com',
    // projectId: 'sunshine-super-app',
    // storageBucket: 'sunshine-super-app.appspot.com',
    // messagingSenderId: '504497996884',
    // appId: '1:504497996884:web:e07732b704e759529819c1',
};
const environment = {
    production: true,
    apiBase: host.apiServer,
    apiHrmBase: host.apiHrmServer,
    apiHrmConfig: host.apiHrmConfig,
    apiShomeBase: host.apShomeServer,
    apiCoreBase: host.apiCoreServer,
    socketServer: host.socketServer,
    cloudFunctionServer: host.cloudFunction,
    authenSettings: authenSettings,
    uploadServer: host.uploadServer,
    firebase
};


/***/ }),

/***/ 90271:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ 86219);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 34750);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 18260);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);





_ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_2__.LicenseManager.setLicenseKey("CompanyName=UNICLOUD TECHNOLOGY GROUP .,JSC,LicensedGroup=UNICLOUD TECHNOLOGY GROUP .,JSC,LicenseType=MultipleApplications,LicensedConcurrentDeveloperCount=1,LicensedProductionInstancesCount=0,AssetReference=AG-023179,ExpiryDate=9_December_2022_[v2]_MTY3MDU0NDAwMDAwMA==114a22b36a8d0e5fcb7da758d74b875c");
if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.enableProdMode)();
}
// var enterprise = require("@ag-grid-enterprise/core");
// enterprise.LicenseManager.setLicenseKey("CompanyName=UNICLOUD TECHNOLOGY GROUP .,JSC,LicensedGroup=UNICLOUD TECHNOLOGY GROUP .,JSC,LicenseType=MultipleApplications,LicensedConcurrentDeveloperCount=1,LicensedProductionInstancesCount=0,AssetReference=AG-023179,ExpiryDate=9_December_2022_[v2]_MTY3MDU0NDAwMDAwMA==114a22b36a8d0e5fcb7da758d74b875c");
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.error(err));


/***/ }),

/***/ 46700:
/*!***************************************************!*\
  !*** ./node_modules/moment/locale/ sync ^\.\/.*$ ***!
  \***************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./af": 32139,
	"./af.js": 32139,
	"./ar": 22600,
	"./ar-dz": 81001,
	"./ar-dz.js": 81001,
	"./ar-kw": 99842,
	"./ar-kw.js": 99842,
	"./ar-ly": 9826,
	"./ar-ly.js": 9826,
	"./ar-ma": 15452,
	"./ar-ma.js": 15452,
	"./ar-sa": 11802,
	"./ar-sa.js": 11802,
	"./ar-tn": 4094,
	"./ar-tn.js": 4094,
	"./ar.js": 22600,
	"./az": 96375,
	"./az.js": 96375,
	"./be": 2086,
	"./be.js": 2086,
	"./bg": 85236,
	"./bg.js": 85236,
	"./bm": 81704,
	"./bm.js": 81704,
	"./bn": 94506,
	"./bn-bd": 34466,
	"./bn-bd.js": 34466,
	"./bn.js": 94506,
	"./bo": 47891,
	"./bo.js": 47891,
	"./br": 93348,
	"./br.js": 93348,
	"./bs": 84848,
	"./bs.js": 84848,
	"./ca": 35928,
	"./ca.js": 35928,
	"./cs": 31839,
	"./cs.js": 31839,
	"./cv": 59151,
	"./cv.js": 59151,
	"./cy": 35761,
	"./cy.js": 35761,
	"./da": 56686,
	"./da.js": 56686,
	"./de": 85177,
	"./de-at": 2311,
	"./de-at.js": 2311,
	"./de-ch": 54407,
	"./de-ch.js": 54407,
	"./de.js": 85177,
	"./dv": 79729,
	"./dv.js": 79729,
	"./el": 60430,
	"./el.js": 60430,
	"./en-au": 28430,
	"./en-au.js": 28430,
	"./en-ca": 61139,
	"./en-ca.js": 61139,
	"./en-gb": 56747,
	"./en-gb.js": 56747,
	"./en-ie": 79466,
	"./en-ie.js": 79466,
	"./en-il": 52121,
	"./en-il.js": 52121,
	"./en-in": 41167,
	"./en-in.js": 41167,
	"./en-nz": 62030,
	"./en-nz.js": 62030,
	"./en-sg": 43646,
	"./en-sg.js": 43646,
	"./eo": 73126,
	"./eo.js": 73126,
	"./es": 38819,
	"./es-do": 69293,
	"./es-do.js": 69293,
	"./es-mx": 65304,
	"./es-mx.js": 65304,
	"./es-us": 66068,
	"./es-us.js": 66068,
	"./es.js": 38819,
	"./et": 23291,
	"./et.js": 23291,
	"./eu": 1400,
	"./eu.js": 1400,
	"./fa": 70043,
	"./fa.js": 70043,
	"./fi": 16138,
	"./fi.js": 16138,
	"./fil": 11466,
	"./fil.js": 11466,
	"./fo": 76803,
	"./fo.js": 76803,
	"./fr": 65523,
	"./fr-ca": 697,
	"./fr-ca.js": 697,
	"./fr-ch": 69001,
	"./fr-ch.js": 69001,
	"./fr.js": 65523,
	"./fy": 21116,
	"./fy.js": 21116,
	"./ga": 66151,
	"./ga.js": 66151,
	"./gd": 93094,
	"./gd.js": 93094,
	"./gl": 11279,
	"./gl.js": 11279,
	"./gom-deva": 64458,
	"./gom-deva.js": 64458,
	"./gom-latn": 66320,
	"./gom-latn.js": 66320,
	"./gu": 78658,
	"./gu.js": 78658,
	"./he": 52153,
	"./he.js": 52153,
	"./hi": 98732,
	"./hi.js": 98732,
	"./hr": 84960,
	"./hr.js": 84960,
	"./hu": 76339,
	"./hu.js": 76339,
	"./hy-am": 11862,
	"./hy-am.js": 11862,
	"./id": 71068,
	"./id.js": 71068,
	"./is": 61260,
	"./is.js": 61260,
	"./it": 1007,
	"./it-ch": 78063,
	"./it-ch.js": 78063,
	"./it.js": 1007,
	"./ja": 6854,
	"./ja.js": 6854,
	"./jv": 92390,
	"./jv.js": 92390,
	"./ka": 35958,
	"./ka.js": 35958,
	"./kk": 67216,
	"./kk.js": 67216,
	"./km": 61061,
	"./km.js": 61061,
	"./kn": 24060,
	"./kn.js": 24060,
	"./ko": 55216,
	"./ko.js": 55216,
	"./ku": 50894,
	"./ku.js": 50894,
	"./ky": 609,
	"./ky.js": 609,
	"./lb": 3591,
	"./lb.js": 3591,
	"./lo": 38381,
	"./lo.js": 38381,
	"./lt": 56118,
	"./lt.js": 56118,
	"./lv": 67889,
	"./lv.js": 67889,
	"./me": 94274,
	"./me.js": 94274,
	"./mi": 39226,
	"./mi.js": 39226,
	"./mk": 528,
	"./mk.js": 528,
	"./ml": 77720,
	"./ml.js": 77720,
	"./mn": 35456,
	"./mn.js": 35456,
	"./mr": 94393,
	"./mr.js": 94393,
	"./ms": 93647,
	"./ms-my": 33049,
	"./ms-my.js": 33049,
	"./ms.js": 93647,
	"./mt": 26097,
	"./mt.js": 26097,
	"./my": 66277,
	"./my.js": 66277,
	"./nb": 67245,
	"./nb.js": 67245,
	"./ne": 3988,
	"./ne.js": 3988,
	"./nl": 44940,
	"./nl-be": 20478,
	"./nl-be.js": 20478,
	"./nl.js": 44940,
	"./nn": 9046,
	"./nn.js": 9046,
	"./oc-lnc": 83131,
	"./oc-lnc.js": 83131,
	"./pa-in": 51731,
	"./pa-in.js": 51731,
	"./pl": 8409,
	"./pl.js": 8409,
	"./pt": 41178,
	"./pt-br": 56558,
	"./pt-br.js": 56558,
	"./pt.js": 41178,
	"./ro": 84138,
	"./ro.js": 84138,
	"./ru": 73380,
	"./ru.js": 73380,
	"./sd": 42889,
	"./sd.js": 42889,
	"./se": 22774,
	"./se.js": 22774,
	"./si": 53776,
	"./si.js": 53776,
	"./sk": 9597,
	"./sk.js": 9597,
	"./sl": 93871,
	"./sl.js": 93871,
	"./sq": 44228,
	"./sq.js": 44228,
	"./sr": 40774,
	"./sr-cyrl": 61928,
	"./sr-cyrl.js": 61928,
	"./sr.js": 40774,
	"./ss": 83176,
	"./ss.js": 83176,
	"./sv": 52422,
	"./sv.js": 52422,
	"./sw": 52530,
	"./sw.js": 52530,
	"./ta": 5731,
	"./ta.js": 5731,
	"./te": 18025,
	"./te.js": 18025,
	"./tet": 53934,
	"./tet.js": 53934,
	"./tg": 99958,
	"./tg.js": 99958,
	"./th": 84251,
	"./th.js": 84251,
	"./tk": 65494,
	"./tk.js": 65494,
	"./tl-ph": 38568,
	"./tl-ph.js": 38568,
	"./tlh": 73158,
	"./tlh.js": 73158,
	"./tr": 49574,
	"./tr.js": 49574,
	"./tzl": 64311,
	"./tzl.js": 64311,
	"./tzm": 99990,
	"./tzm-latn": 42380,
	"./tzm-latn.js": 42380,
	"./tzm.js": 99990,
	"./ug-cn": 52356,
	"./ug-cn.js": 52356,
	"./uk": 54934,
	"./uk.js": 54934,
	"./ur": 84515,
	"./ur.js": 84515,
	"./uz": 40058,
	"./uz-latn": 41875,
	"./uz-latn.js": 41875,
	"./uz.js": 40058,
	"./vi": 13325,
	"./vi.js": 13325,
	"./x-pseudo": 39208,
	"./x-pseudo.js": 39208,
	"./yo": 18742,
	"./yo.js": 18742,
	"./zh-cn": 42378,
	"./zh-cn.js": 42378,
	"./zh-hk": 4569,
	"./zh-hk.js": 4569,
	"./zh-mo": 74671,
	"./zh-mo.js": 74671,
	"./zh-tw": 20259,
	"./zh-tw.js": 20259
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 46700;

/***/ }),

/***/ 55382:
/*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ 72095:
/*!********************!*\
  !*** fs (ignored) ***!
  \********************/
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ 61219:
/*!************************!*\
  !*** stream (ignored) ***!
  \************************/
/***/ (() => {

/* (ignored) */

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(90271)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.01b13322225010d1.js.map