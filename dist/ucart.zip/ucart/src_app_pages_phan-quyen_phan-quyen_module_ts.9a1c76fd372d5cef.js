"use strict";
(self["webpackChunkucart"] = self["webpackChunkucart"] || []).push([["src_app_pages_phan-quyen_phan-quyen_module_ts"],{

/***/ 38118:
/*!***********************************************************************************************************!*\
  !*** ./src/app/components/pq-quyen-nguoi-dung/chi-tiet-cai-dat-quyen/chi-tiet-cai-dat-quyen.component.ts ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietCaiDatQuyenComponent": () => (/* binding */ ChiTietCaiDatQuyenComponent)
/* harmony export */ });
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api.service */ 67118);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var src_app_components_pq_quyen_nguoi_dung_danh_sach_menu_danh_sach_menu_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/components/pq-quyen-nguoi-dung/danh-sach-menu/danh-sach-menu.component */ 38309);
/* harmony import */ var src_app_components_pq_quyen_nguoi_dung_danh_sach_action_danh_sach_action_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/pq-quyen-nguoi-dung/danh-sach-action/danh-sach-action.component */ 57619);
/* harmony import */ var src_app_components_pq_quyen_nguoi_dung_danh_sach_role_danh_sach_role_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/pq-quyen-nguoi-dung/danh-sach-role/danh-sach-role.component */ 17594);



















function ChiTietCaiDatQuyenComponent_app_danh_sach_menu_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "app-danh-sach-menu");
} }
function ChiTietCaiDatQuyenComponent_app_danh_sach_action_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "app-danh-sach-action");
} }
function ChiTietCaiDatQuyenComponent_app_danh_sach_role_15_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "app-danh-sach-role");
} }
class ChiTietCaiDatQuyenComponent {
    constructor(confirmationService, messageService, spinner, route, apiService) {
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.spinner = spinner;
        this.route = route;
        this.apiService = apiService;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subject();
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__.AgGridFn;
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_0__.AllModules;
        this.dataRouter = null;
        this.optionsButon = [
            { label: 'Lưu lại', value: 'Update', class: '', icon: 'pi pi-plus' }
        ];
        this.indexTab = 0;
        this.query = {
            webId: '',
            filter: '',
            gridWith: 0,
            offSet: 0,
            pageSize: 10000000
        };
        this.columnDefs = [];
        this.displayaddFunctions = false;
        this.detailWebSmart = {};
        this.isEdit = false;
        this.titlePage = null;
        this.paramsObject = null;
        this.itemsBreadcrumb = [];
        // data grid for tab
        this.menusTab = {};
        this.rolesTab = {};
        this.clientactionGrid = [];
        this.dataFieldsInfo = null;
        this.listViewWebInfo = [];
        this.listViews = [];
        this.detailInfo = null;
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
        };
        this.getRowHeight1 = (params) => {
            if (params.node.master) {
                return 40;
            }
            else {
                return 300;
            }
        };
    }
    ngOnInit() {
        this.titlePage = this.route.data['_value'].title;
        this.itemsBreadcrumb = [
            { label: 'Trang chủ' },
            { label: 'Quyền người dùng', routerLink: '/phan-quyen/quyen-nguoi-dung' },
            { label: `${this.titlePage}` },
        ];
        this.handleParams();
        this.GetMenuConfigInfo();
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    onFirstDataRendered(params) {
        params.api.sizeColumnsToFit();
    }
    handleParams() {
        this.route.queryParamMap
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.unsubscribe$))
            .subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.query.webId = this.paramsObject.params.id || null;
            // this.callApiGetInfo(0);
        });
    }
    ;
    GetMenuConfigInfo() {
        const query = {};
        this.apiService.getMenuConfigInfo(querystring__WEBPACK_IMPORTED_MODULE_3__.stringify(query)).subscribe((results) => {
            if (results.status === 'success') {
                this.menusTab.data = results.data.menus;
                this.menusTab.menutree = results.data.menutree;
                this.menusTab.gridflexs = results.data.view_grids_menu;
                this.rolesTab.data = results.data.roles;
                this.rolesTab.gridflexs = results.data.view_grids_roles;
                this.rolesTab.data = results.data.clientaction;
                this.rolesTab.gridflexs = results.data.view_grids_action;
            }
        });
    }
    // callApiGetInfo(index = 0) {
    //   this.spinner.show();
    //   const queryParams = queryString.stringify({ webId: this.query.webId });
    //   const getClientWebInfoManager = this.apiService.getClientWebInfoManager(queryParams);
    //   forkJoin([getClientWebInfoManager])
    //     .pipe(takeUntil(this.unsubscribe$))
    //     .subscribe((results: any) => {
    //       if (results && results[0].status === 'success') {
    //         this.listViewWebInfo = cloneDeep(results[0].data.group_fields);
    //         this.dataFieldsInfo = results[0].data;
    //         this.spinner.hide();
    //       }
    //     })
    // }
    handleChange(index) {
        this.indexTab = index;
    }
}
ChiTietCaiDatQuyenComponent.ɵfac = function ChiTietCaiDatQuyenComponent_Factory(t) { return new (t || ChiTietCaiDatQuyenComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_12__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__.ApiService)); };
ChiTietCaiDatQuyenComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({ type: ChiTietCaiDatQuyenComponent, selectors: [["app-chi-tiet-cai-dat-quyen"]], decls: 16, vars: 5, consts: [[1, "bread-crumb"], [1, "d-flex"], [1, "col-8"], [3, "items"], [1, "col-4", "justify-content-end", "d-flex"], [1, "custom-detail-fields"], [1, "khachHangWrapper"], [1, "grid", "d-flex", "justify-content-start"], [1, "col-12", "section"], ["styleClass", "tab-customer-detail", 3, "activeIndex", "activeIndexChange", "onChange"], ["header", "Danh s\u00E1ch c\u00E1c menu"], [4, "ngIf"], ["header", "Danh s\u00E1ch c\u00E1c Action"], ["header", "Danh s\u00E1ch c\u00E1c quy\u1EC1n"]], template: function ChiTietCaiDatQuyenComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "main", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](8, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "p-tabView", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("activeIndexChange", function ChiTietCaiDatQuyenComponent_Template_p_tabView_activeIndexChange_9_listener($event) { return ctx.indexTab = $event; })("onChange", function ChiTietCaiDatQuyenComponent_Template_p_tabView_onChange_9_listener($event) { return ctx.handleChange($event.index); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](10, "p-tabPanel", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](11, ChiTietCaiDatQuyenComponent_app_danh_sach_menu_11_Template, 1, 0, "app-danh-sach-menu", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](12, "p-tabPanel", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](13, ChiTietCaiDatQuyenComponent_app_danh_sach_action_13_Template, 1, 0, "app-danh-sach-action", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](14, "p-tabPanel", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](15, ChiTietCaiDatQuyenComponent_app_danh_sach_role_15_Template, 1, 0, "app-danh-sach-role", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("items", ctx.itemsBreadcrumb);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("activeIndex", ctx.indexTab);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.indexTab === 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.indexTab === 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.indexTab === 2);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__.HrmBreadCrumbComponent, primeng_tabview__WEBPACK_IMPORTED_MODULE_14__.TabView, primeng_tabview__WEBPACK_IMPORTED_MODULE_14__.TabPanel, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, src_app_components_pq_quyen_nguoi_dung_danh_sach_menu_danh_sach_menu_component__WEBPACK_IMPORTED_MODULE_5__.DanhSachMenuComponent, src_app_components_pq_quyen_nguoi_dung_danh_sach_action_danh_sach_action_component__WEBPACK_IMPORTED_MODULE_6__.DanhSachActionComponent, src_app_components_pq_quyen_nguoi_dung_danh_sach_role_danh_sach_role_component__WEBPACK_IMPORTED_MODULE_7__.DanhSachRoleComponent], styles: ["[_nghost-%COMP%]  .control-btn-save .wrap-btn {\n  right: 50px !important;\n  top: 20px !important;\n}\n[_nghost-%COMP%]  .control-btn-save .p-picklist .p-picklist-list .p-picklist-item {\n  border-bottom: 1px solid #e9e9e9;\n  display: flex;\n  justify-content: space-between;\n  padding: 0.5rem 0.5rem;\n}\n[_nghost-%COMP%]  .checktree {\n  padding-left: 0px;\n}\n[_nghost-%COMP%]  .checktree input[type=number] {\n  width: 42px;\n  border: 1px solid #ccc;\n  border-radius: 4px;\n  padding: 5px;\n  text-align: center;\n}\n[_nghost-%COMP%]  .checktree li {\n  list-style: none;\n  margin-bottom: 4px;\n  margin-top: 3px;\n}\n[_nghost-%COMP%]  .checktree li ul {\n  padding-left: 10px;\n  margin-top: 6px;\n}\n[_nghost-%COMP%]  .danh-sach-chuc-nang-sidebar .p-sidebar-header {\n  position: absolute;\n  top: 6px;\n  right: 2px;\n  z-index: 1;\n  padding-top: 0px;\n  padding-bottom: 0px;\n}\n[_nghost-%COMP%]  .ag-theme-alpine .ag-header-row:not(:first-child) .ag-header-cell {\n  border-top: 1px solid #f7f0f0;\n  border-radius: 0;\n}\n[_nghost-%COMP%]  .tab-customer-detail {\n  position: relative;\n}\n[_nghost-%COMP%]  .tab-customer-detail .btn-addnew {\n  position: absolute;\n  top: 10px;\n  right: 0px;\n}\n[_nghost-%COMP%]     .p-button {\n  margin: 0 0.5rem 0 0;\n  min-width: 0;\n}\np[_ngcontent-%COMP%] {\n  margin: 0;\n}\n.confirmation-content[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n[_nghost-%COMP%]     .p-dialog .p-button {\n  min-width: 6rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoaS10aWV0LWNhaS1kYXQtcXV5ZW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRVE7RUFDSSxzQkFBQTtFQUNBLG9CQUFBO0FBRFo7QUFHUTtFQUNJLGdDQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0Esc0JBQUE7QUFEWjtBQUlJO0VBQ0ksaUJBQUE7QUFGUjtBQUdRO0VBQ0ksV0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFEWjtBQUdRO0VBQ0ksZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFEWjtBQUVZO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0FBQWhCO0FBS1E7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxVQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFIWjtBQU1JO0VBQ0ksNkJBQUE7RUFDQSxnQkFBQTtBQUpSO0FBTUk7RUFDSSxrQkFBQTtBQUpSO0FBS1E7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FBSFo7QUFRQTtFQUNJLG9CQUFBO0VBQ0EsWUFBQTtBQUxKO0FBUUE7RUFDSSxTQUFBO0FBTEo7QUFRQTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FBTEo7QUFRQTtFQUNJLGVBQUE7QUFMSiIsImZpbGUiOiJjaGktdGlldC1jYWktZGF0LXF1eWVuLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Q6Om5nLWRlZXB7XHJcbiAgLmNvbnRyb2wtYnRuLXNhdmV7XHJcbiAgICAgICAgLndyYXAtYnRue1xyXG4gICAgICAgICAgICByaWdodDogNTBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB0b3A6IDIwcHggIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnAtcGlja2xpc3QgLnAtcGlja2xpc3QtbGlzdCAucC1waWNrbGlzdC1pdGVte1xyXG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U5ZTllOTtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwLjVyZW0gMC41cmVtO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5jaGVja3RyZWV7XHJcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAwcHg7XHJcbiAgICAgICAgaW5wdXRbdHlwZT1cIm51bWJlclwiXXtcclxuICAgICAgICAgICAgd2lkdGg6IDQycHg7XHJcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgICAgICAgICAgcGFkZGluZzogNXB4O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxpe1xyXG4gICAgICAgICAgICBsaXN0LXN0eWxlOiBub25lO1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDNweDtcclxuICAgICAgICAgICAgdWx7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA2cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAuZGFuaC1zYWNoLWNodWMtbmFuZy1zaWRlYmFye1xyXG4gICAgICAgIC5wLXNpZGViYXItaGVhZGVye1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHRvcDogNnB4O1xyXG4gICAgICAgICAgICByaWdodDogMnB4O1xyXG4gICAgICAgICAgICB6LWluZGV4OiAxO1xyXG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogMHB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogMHB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5hZy10aGVtZS1hbHBpbmUgLmFnLWhlYWRlci1yb3c6bm90KDpmaXJzdC1jaGlsZCkgLmFnLWhlYWRlci1jZWxse1xyXG4gICAgICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZjdmMGYwO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDA7XHJcbiAgICB9XHJcbiAgICAudGFiLWN1c3RvbWVyLWRldGFpbHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgLmJ0bi1hZGRuZXd7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgdG9wOiAxMHB4O1xyXG4gICAgICAgICAgICByaWdodDogMHB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIC5wLWJ1dHRvbiB7XHJcbiAgICBtYXJnaW46IDAgLjVyZW0gMCAwO1xyXG4gICAgbWluLXdpZHRoOiAwO1xyXG59XHJcblxyXG5wIHtcclxuICAgIG1hcmdpbjogMDtcclxufVxyXG5cclxuLmNvbmZpcm1hdGlvbi1jb250ZW50IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCAucC1kaWFsb2cgLnAtYnV0dG9uIHtcclxuICAgIG1pbi13aWR0aDogNnJlbTtcclxufSJdfQ== */"] });


/***/ }),

/***/ 57619:
/*!***********************************************************************************************!*\
  !*** ./src/app/components/pq-quyen-nguoi-dung/danh-sach-action/danh-sach-action.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DanhSachActionComponent": () => (/* binding */ DanhSachActionComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api.service */ 67118);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);


















function DanhSachActionComponent_app_list_grid_angular_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "app-list-grid-angular", 18);
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("listsData", ctx_r0.listsData)("height", ctx_r0.heightGrid)("columnDefs", ctx_r0.columnDefs);
} }
function DanhSachActionComponent_app_config_grid_table_form_28_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "app-config-grid-table-form", 19);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r1.gridKey);
} }
const _c0 = function () { return { width: "800px", height: "auto" }; };
const _c1 = function () { return { width: "50vw" }; };
const queryString = __webpack_require__(/*! query-string */ 31808);
class DanhSachActionComponent {
    constructor(activatedRoute, apiService, spinner, confirmationService, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.router = router;
        this.detailInfo = null;
        this.callback = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.optionsButon = [
            // { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: '', icon: 'pi pi-plus' }
        ];
        this.columnDefs = [];
        this.listsData = [];
        this.heightGrid = 500;
        this.gridKey = 'view_sysconfig_actions';
        this.displaySetting = false;
        this.displayInfo = false;
        this.modelAction = {
            actionId: null,
            actionCd: '',
            actionName: '',
        };
        this.listViews = [];
    }
    cauhinh() {
        this.displaySetting = true;
    }
    ngOnInit() {
        this.getClientActions();
        this.getActions();
    }
    getClientActionListByWebId() {
        // this.columnDefs = []
        // const queryParams = queryString.stringify({ webId: this.detailInfo.webId });
        // this.apiService.getClientActionListByWebId(queryParams).subscribe(results => {
        //   if (results.status === 'success') {
        //     this.listsData = cloneDeep(results.data.dataList.data);
        //     this.initGrid(results.data.gridflexs);
        //     this.gridKey = results.data.dataList.gridKey
        //   }
        // })
    }
    getClientActions() {
        this.columnDefs = [];
        const query = {};
        this.apiService.getMenuConfigInfo(queryString.stringify(query)).subscribe((results) => {
            var _a;
            if (results.status === 'success') {
                this.listsData = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)((_a = results === null || results === void 0 ? void 0 : results.data) === null || _a === void 0 ? void 0 : _a.clientaction);
                if (results.data && results.data.view_grids_action) {
                    this.initGrid(results.data.view_grids_action);
                }
            }
        });
    }
    getActions() {
        // this.apiService.getConfigActionList().subscribe((results: any) => {
        //   if (results.status === 'success') {
        //     this.listsData = cloneDeep(results?.data);
        //   }
        // })
    }
    create() {
        this.modelAction = {
            actionId: 0,
            actionCd: "",
            actionName: ""
        };
        this.displayInfo = true;
    }
    saveAction() {
        this.apiService.setConfigMenuAction(this.modelAction).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Thêm mới action thành công' });
                this.displayInfo = false;
                this.getClientActions();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Thêm action không thành công' });
                this.displayInfo = false;
            }
        });
    }
    initGrid(gridflexs) {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.AgGridFn)(gridflexs),
            {
                headerName: '',
                field: 'button',
                filter: '',
                pinned: 'right',
                width: 90,
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right'],
                cellRendererParams: params => {
                    return {
                        buttons: [
                            {
                                onClick: this.suaThongTin.bind(this),
                                label: 'Xem thông tin',
                                key: 'chinhsualaixuat',
                                icon: 'fa fa-edit',
                                class: 'btn-primary mr5',
                            },
                            {
                                onClick: this.delete.bind(this),
                                label: 'Xóa',
                                key: 'xoalaixuat',
                                icon: 'pi pi-trash',
                                class: 'btn-primary mr5',
                            },
                        ]
                    };
                },
            },
        ];
    }
    suaThongTin(event) {
        this.displayInfo = true;
        this.modelAction = {
            actionId: event.rowData.actionId,
            actionCd: event.rowData.actionCd,
            actionName: event.rowData.actionName,
        };
    }
    delete(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện hành động này?',
            accept: () => {
                const queryParams = queryString.stringify({ actionId: event.rowData.actionId });
                this.apiService.delConfigMenuAction(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                        this.getActions();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
                    }
                });
            }
        });
    }
    setClientMenuInfo(data) {
        this.spinner.show();
        // this.apiService.setClientMenuInfo(params).subscribe((results: any) => {
        //   if (results.status === 'success') {
        //     this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data });
        //     this.spinner.hide();
        //     this.getClientActionListByWebId();
        //     this.displayInfo = false;
        //   } else {
        //     this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
        //     this.spinner.hide();
        //   }
        // }), error => {
        //   this.spinner.hide();
        // };
    }
}
DanhSachActionComponent.ɵfac = function DanhSachActionComponent_Factory(t) { return new (t || DanhSachActionComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__.ApiService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_7__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router)); };
DanhSachActionComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: DanhSachActionComponent, selectors: [["app-danh-sach-action"]], inputs: { detailInfo: "detailInfo" }, outputs: { callback: "callback" }, decls: 29, vars: 22, consts: [[1, "d-flex", "are-tab-btns", "mt-2", "mb-2"], ["styleClass", "p-button-sm btn-tab", "label", "Th\u00EAm m\u1EDBi", "icon", "pi pi-icon", 3, "click"], ["label", "C\u1EA5u h\u00ECnh", "icon", "pi pi-cog", "styleClass", "p-button-sm ml-2 addNew", 3, "click"], [1, "grid-default", "border"], [3, "listsData", "height", "columnDefs", 4, "ngIf"], [3, "visible", "autoZIndex", "modal", "visibleChange"], [1, "row"], [1, "col-md-12"], [1, "field-group", "text", 3, "ngClass"], ["for", ""], [2, "color", "red"], ["type", "text", "required", "", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "row", "mt-1"], [1, "col-md-12", "text-right"], ["pButton", "", "type", "button", "label", "L\u01B0u l\u1EA1i", "icon", "pi pi-check", 1, "p-button-info", "mr-1", "p-button-sm", 3, "disabled", "click"], ["pButton", "", "type", "button", "icon", "pi pi-times", "label", "\u0110\u00F3ng", 1, "p-button-secondary", "p-button-sm", 3, "click"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh ", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "listsData", "height", "columnDefs"], [3, "typeConfig", "gridKey"]], template: function DanhSachActionComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "p-button", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function DanhSachActionComponent_Template_p_button_click_1_listener() { return ctx.create(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "p-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function DanhSachActionComponent_Template_p_button_click_2_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](4, DanhSachActionComponent_app_list_grid_angular_4_Template, 1, 3, "app-list-grid-angular", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "p-dialog", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("visibleChange", function DanhSachActionComponent_Template_p_dialog_visibleChange_5_listener($event) { return ctx.displayInfo = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "p-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7, " Th\u00F4ng tin action\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "label", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](12, "M\u00E3 action");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](13, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](14, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function DanhSachActionComponent_Template_input_ngModelChange_15_listener($event) { return ctx.modelAction.actionCd = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](16, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](17, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "label", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](19, "T\u00EAn action");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](20, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](21, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](22, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function DanhSachActionComponent_Template_input_ngModelChange_22_listener($event) { return ctx.modelAction.actionName = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](24, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](25, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function DanhSachActionComponent_Template_button_click_25_listener() { return ctx.saveAction(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function DanhSachActionComponent_Template_button_click_26_listener() { return ctx.displayInfo = !ctx.displayInfo; });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](27, "p-dialog", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("visibleChange", function DanhSachActionComponent_Template_p_dialog_visibleChange_27_listener($event) { return ctx.displaySetting = $event; })("onHide", function DanhSachActionComponent_Template_p_dialog_onHide_27_listener() { return ctx.getClientActions(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](28, DanhSachActionComponent_app_config_grid_table_form_28_Template, 1, 2, "app-config-grid-table-form", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](20, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("visible", ctx.displayInfo)("autoZIndex", true)("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngClass", ctx.modelAction.actionCd ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngModel", ctx.modelAction.actionCd);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngClass", ctx.modelAction.actionName ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngModel", ctx.modelAction.actionName);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", ctx.modelAction.actionCd === "" || ctx.modelAction.actionName === "");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](21, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [primeng_button__WEBPACK_IMPORTED_MODULE_9__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, primeng_dialog__WEBPACK_IMPORTED_MODULE_11__.Dialog, primeng_api__WEBPACK_IMPORTED_MODULE_8__.Header, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_9__.ButtonDirective, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_3__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_4__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkYW5oLXNhY2gtYWN0aW9uLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 38309:
/*!*******************************************************************************************!*\
  !*** ./src/app/components/pq-quyen-nguoi-dung/danh-sach-menu/danh-sach-menu.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DanhSachMenuComponent": () => (/* binding */ DanhSachMenuComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api.service */ 67118);
/* harmony import */ var src_app_utils_common_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/utils/common/customtooltip.component */ 91469);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_shared_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/constants */ 4338);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_picklist__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/picklist */ 32536);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);






















function DanhSachMenuComponent_app_list_grid_angular_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-list-grid-angular", 12);
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("height", ctx_r0.heightGrid)("detailCellRendererParams", ctx_r0.detailCellRendererParams)("columnDefs", ctx_r0.columnDefs)("listsData", ctx_r0.listsData);
} }
function DanhSachMenuComponent_app_edit_detail_8_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "app-edit-detail", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("callback", function DanhSachMenuComponent_app_edit_detail_8_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return ctx_r4.setConfigMenu($event); })("callbackcancel", function DanhSachMenuComponent_app_edit_detail_8_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r5); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return ctx_r6.cancelUpdate($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("menus", ctx_r1.listsData)("detail", ctx_r1.detailDetailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r1.optionsButon)("dataView", ctx_r1.listViews);
} }
function DanhSachMenuComponent_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](1, "span", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](4, "p", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"]("+ ", car_r7.actionName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"]("[", car_r7.actionCd, "]");
} }
function DanhSachMenuComponent_app_config_grid_table_form_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "app-config-grid-table-form", 19);
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r3.gridKey);
} }
const _c0 = function () { return { width: "1300px", height: "auto" }; };
const _c1 = function () { return { "height": "30rem" }; };
const _c2 = function () { return { width: "50vw" }; };
const queryString = __webpack_require__(/*! query-string */ 31808);
class DanhSachMenuComponent {
    constructor(activatedRoute, apiService, spinner, confirmationService, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.router = router;
        this.detailInfo = null;
        this.callback = new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter();
        this.optionsButon = [
            // { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: '', icon: 'pi pi-plus' }
        ];
        this.columnDefs = [];
        this.listsData = [];
        this.heightGrid = 500;
        this.gridKey = 'view_sysconfig_menus';
        this.displaySetting = false;
        this.listActions = [];
        this.sourceActions = [];
        this.targetActions = [];
        this.expanded = null;
        this.listViews = [];
        this.detailDetailInfo = null;
        this.displayInfo = false;
    }
    cauhinh() {
        this.displaySetting = true;
    }
    ngOnInit() {
        this.getMenuConfigInfo();
        // this.getClientActionListByWebId()
    }
    getMenuConfigInfo(id = null) {
        this.columnDefs = [];
        let query = {};
        if (id) {
            query = { gridWidth: id };
        }
        else {
            query = {};
        }
        this.apiService.getMenuConfigInfo(queryString.stringify(query)).subscribe((results) => {
            var _a;
            if (results.status === 'success') {
                this.listsData = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)((_a = results === null || results === void 0 ? void 0 : results.data) === null || _a === void 0 ? void 0 : _a.menutree);
                this.sourceActions = results.data.actions;
                this.targetActions = results.data.clientaction;
                if (results.data && results.data.view_grids_menu) {
                    this.cols = results.data.view_grids_menu;
                    this.initGrid(results.data.view_grids_menu);
                }
            }
        });
    }
    // getClientActionListByWebId() {
    //   this.columnDefs = []
    //   const queryParams = queryString.stringify({ webId: this.detailInfo.webId });
    //   this.apiService.getClientActionListByWebId(queryParams).subscribe(results => {
    //     if (results.status === 'success') {
    //       this.listActions = cloneDeep(results.data.dataList.data);
    //       this.targetActions = cloneDeep(this.listActions);
    //     }
    //   })
    // }
    onTargetFilter(event) {
        if (event.query === "") {
            this.targetActions = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(this.listActions);
        }
        else {
            this.targetActions = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(event.value);
        }
    }
    create() {
        this.getConfigMenu(null);
    }
    initGrid(gridflexs) {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.AgGridFn)(gridflexs),
            {
                headerName: 'Thứ tự',
                pinned: 'right',
                field: 'intPosEdit',
                onCellValueChanged: params => {
                    this.onCellValueChanged(params);
                },
                cellRenderer: params => {
                    return params.data.intPos;
                },
                width: 90,
                editable: true,
                cellClass: ['border-right', 'bg-f7ff7']
            },
            {
                headerName: '',
                field: 'button',
                filter: '',
                pinned: 'right',
                width: 90,
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right'],
                cellRendererParams: params => {
                    return {
                        buttons: [
                            {
                                onClick: this.suaThongTin.bind(this),
                                label: 'Xem thông tin',
                                key: 'chinhsualaixuat',
                                icon: 'fa fa-edit',
                                class: 'btn-primary mr5',
                            },
                            {
                                onClick: this.delete.bind(this),
                                label: 'Xóa',
                                key: 'xoalaixuat',
                                icon: 'pi pi-trash',
                                class: 'btn-primary mr5',
                            },
                        ]
                    };
                },
            },
        ];
        this.detailCellRendererParams = {
            detailGridOptions: {
                frameworkComponents: {
                    customTooltip: src_app_utils_common_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__.CustomTooltipComponent,
                    buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__.ButtonAgGridComponent,
                },
                getRowHeight: (params) => {
                    return 40;
                },
                columnDefs: [
                    ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
                    {
                        headerName: 'Thao tác',
                        field: 'button',
                        filter: '',
                        pinned: 'right',
                        width: 100,
                        cellRenderer: 'buttonAgGridComponent',
                        cellClass: ['border-right'],
                        cellRendererParams: params => {
                            return {
                                buttons: [
                                    {
                                        onClick: this.OnClickRow.bind(this),
                                        label: 'Xem chi tiết',
                                        icon: 'pi pi-pencil',
                                        class: 'btn-primary mr5',
                                        key: src_app_shared_constants__WEBPACK_IMPORTED_MODULE_5__.KEYBUTTON.XEMCHITIET
                                    },
                                    {
                                        onClick: this.OnClickRow.bind(this),
                                        label: 'Xóa',
                                        icon: 'pi pi-trash',
                                        class: 'btn-danger',
                                        key: src_app_shared_constants__WEBPACK_IMPORTED_MODULE_5__.KEYBUTTON.XOATHONGTIN
                                    },
                                ]
                            };
                        },
                    },
                ],
                defaultColDef: {
                    tooltipComponent: 'customTooltip',
                    resizable: true,
                },
                enableCellTextSelection: true,
                onFirstDataRendered(params) {
                    let allColumnIds = [];
                    params.columnApi.getAllColumns()
                        .forEach((column) => {
                        if (column.colDef.cellClass.indexOf('no-auto') < 0) {
                            allColumnIds.push(column);
                        }
                        else {
                            column.colDef.suppressSizeToFit = true;
                            allColumnIds.push(column);
                        }
                    });
                    params.api.sizeColumnsToFit(allColumnIds);
                },
            },
            getDetailRowData(params) {
                params.successCallback(params.data.submenus);
            },
            template: function (params) {
                var personName = params.data.Name;
                return ('<div style="height: 100%; background-color: #EDF6FF; padding: 20px; box-sizing: border-box;">' +
                    `  <div style="height: 10%; padding: 2px; font-weight: bold;"> Danh sách (${params.data.submenus.length})` +
                    '</div>' +
                    '  <div ref="eDetailGrid" style="height: 90%;"></div>' +
                    '</div>');
            },
        };
    }
    OnClickRow(event) {
        if (event.event.item.key === src_app_shared_constants__WEBPACK_IMPORTED_MODULE_5__.KEYBUTTON.XEMCHITIET) {
            this.btnEdit(event);
        }
        else {
            this.btnDelete(event);
        }
    }
    btnEdit(e) {
        this.getConfigMenu(e.rowData.menuId);
    }
    btnDelete(e) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện hành động này?',
            accept: () => {
                const queryParams = queryString.stringify({ menuId: e.rowData.menuId });
                this.apiService.delConfigMenu(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                        this.getMenuConfigInfo();
                        this.displayInfo = false;
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
                    }
                });
            }
        });
    }
    onCellValueChanged(event) {
        if (event.colDef.field === 'intPosEdit' || event.colDef.field === 'intPosEditParent') {
            this.spinner.show();
            const queryParams = queryString.stringify({ menuId: event.data.menuId, webId: this.detailInfo.webId });
            this.apiService.getConfigMenu(queryParams).subscribe(results => {
                if (results.status === 'success') {
                    const listViews = results.data.group_fields.forEach(element => {
                        element.fields.forEach(element1 => {
                            if (element1.field_name === 'intPos') {
                                element1.columnValue = event.newValue;
                            }
                            else if (element1.field_name === 'parentId' && event.colDef.field === 'intPosEdit') {
                                this.expanded = element1.columnValue ? element1.columnValue : null;
                            }
                        });
                    });
                    this.spinner.hide();
                    this.listViews = [...listViews];
                    this.detailDetailInfo = results.data;
                    this.setConfigMenu(this.listViews);
                }
                else {
                    this.spinner.hide();
                }
            });
        }
    }
    suaThongTin(event) {
        this.getConfigMenu(event.rowData.menuId);
    }
    getConfigMenu(menuId) {
        console.log('listsData', this.listsData);
        const query = {};
        if (menuId) {
            query.menuId = menuId;
        }
        this.listViews = [];
        const queryParams = queryString.stringify(query);
        this.apiService.getConfigMenu(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(results.data.group_fields);
                this.detailDetailInfo = results.data;
                this.sourceActions = results.data.actions;
                this.displayInfo = true;
            }
        });
    }
    delete(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện hành động này?',
            accept: () => {
                const queryParams = queryString.stringify({ menuId: event.rowData.menuId });
                this.apiService.delConfigMenu(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                        this.getMenuConfigInfo();
                        this.displayInfo = false;
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
                    }
                });
            }
        });
    }
    setConfigMenu(data) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailDetailInfo), { group_fields: data, actions: this.sourceActions });
        this.apiService.setConfigMenu(params).subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.getMenuConfigInfo();
                this.displayInfo = false;
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    cancelUpdate(data) {
        if (data === 'CauHinh') {
            this.getConfigMenu(this.detailDetailInfo.menuId);
        }
    }
}
DanhSachMenuComponent.ɵfac = function DanhSachMenuComponent_Factory(t) { return new (t || DanhSachMenuComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__.ApiService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_11__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_12__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_12__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.Router)); };
DanhSachMenuComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: DanhSachMenuComponent, selectors: [["app-danh-sach-menu"]], inputs: { detailInfo: "detailInfo" }, outputs: { callback: "callback" }, decls: 14, vars: 28, consts: [[1, "d-flex", "are-tab-btns", "mt-2", "mb-2"], ["styleClass", "p-button-sm btn-tab", "label", "Th\u00EAm m\u1EDBi", "icon", "pi pi-icon", 3, "click"], ["label", "C\u1EA5u h\u00ECnh", "icon", "pi pi-cog", "styleClass", "p-button-sm ml-2 addNew", 3, "click"], [1, "grid-default", "border"], [3, "height", "detailCellRendererParams", "columnDefs", "listsData", 4, "ngIf"], [3, "visible", "autoZIndex", "modal", "visibleChange"], [3, "menus", "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [1, "text-right", "mt-1"], ["sourceHeader", "Danh s\u00E1ch action \u0111\u01B0\u1EE3c ch\u1ECDn", "targetHeader", "Danh s\u00E1ch action ch\u01B0a ch\u1ECDn", "filterBy", "actionName", "sourceFilterPlaceholder", "T\u00ECm theo t\u00EAn actionCd", "targetFilterPlaceholder", "T\u00ECm theo t\u00EAn actionCd", 3, "source", "target", "targetStyle", "sourceStyle", "showSourceControls", "showTargetControls", "responsive", "dragdrop", "onTargetFilter"], ["pTemplate", "item"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh ", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "height", "detailCellRendererParams", "columnDefs", "listsData"], [3, "menus", "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"], [1, "image-container"], [2, "font-weight", "600"], [1, "ui-helper-clearfix"], [2, "display", "inline-block", "margin", "2px 0 2px 2px"], [2, "font-size", "14px", "float", "right", "margin", "2px 0 2px 2px"], [3, "typeConfig", "gridKey"]], template: function DanhSachMenuComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "p-button", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function DanhSachMenuComponent_Template_p_button_click_1_listener() { return ctx.create(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "p-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function DanhSachMenuComponent_Template_p_button_click_2_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](4, DanhSachMenuComponent_app_list_grid_angular_4_Template, 1, 4, "app-list-grid-angular", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "p-dialog", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("visibleChange", function DanhSachMenuComponent_Template_p_dialog_visibleChange_5_listener($event) { return ctx.displayInfo = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "p-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](7, " Th\u00F4ng tin menu ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](8, DanhSachMenuComponent_app_edit_detail_8_Template, 1, 5, "app-edit-detail", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](10, "p-pickList", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("onTargetFilter", function DanhSachMenuComponent_Template_p_pickList_onTargetFilter_10_listener($event) { return ctx.onTargetFilter($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](11, DanhSachMenuComponent_ng_template_11_Template, 7, 2, "ng-template", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](12, "p-dialog", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("visibleChange", function DanhSachMenuComponent_Template_p_dialog_visibleChange_12_listener($event) { return ctx.displaySetting = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](13, DanhSachMenuComponent_app_config_grid_table_form_13_Template, 1, 2, "app-config-grid-table-form", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", (ctx.columnDefs == null ? null : ctx.columnDefs.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](24, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("visible", ctx.displayInfo)("autoZIndex", true)("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0 && ctx.listsData.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("source", ctx.sourceActions)("target", ctx.targetActions)("targetStyle", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](25, _c1))("sourceStyle", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](26, _c1))("showSourceControls", false)("showTargetControls", false)("responsive", true)("dragdrop", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction0"](27, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [primeng_button__WEBPACK_IMPORTED_MODULE_13__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, primeng_dialog__WEBPACK_IMPORTED_MODULE_15__.Dialog, primeng_api__WEBPACK_IMPORTED_MODULE_12__.Header, primeng_picklist__WEBPACK_IMPORTED_MODULE_16__.PickList, primeng_api__WEBPACK_IMPORTED_MODULE_12__.PrimeTemplate, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_6__.ListGridAngularComponent, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_7__.EditDetailComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_8__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkYW5oLXNhY2gtbWVudS5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 17594:
/*!*******************************************************************************************!*\
  !*** ./src/app/components/pq-quyen-nguoi-dung/danh-sach-role/danh-sach-role.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DanhSachRoleComponent": () => (/* binding */ DanhSachRoleComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api.service */ 67118);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_sidebar__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/sidebar */ 65357);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/forms */ 18346);






















function DanhSachRoleComponent_app_list_grid_angular_4_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "app-list-grid-angular", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("rowDoubleClicked", function DanhSachRoleComponent_app_list_grid_angular_4_Template_app_list_grid_angular_rowDoubleClicked_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r4.clickRowRoleGetMenu($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("listsData", ctx_r0.listsData)("height", ctx_r0.heightGrid)("columnDefs", ctx_r0.columnDefs);
} }
function DanhSachRoleComponent_app_edit_detail_8_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "app-edit-detail", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("callback", function DanhSachRoleComponent_app_edit_detail_8_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r6.setConfigMenu($event); })("callbackcancel", function DanhSachRoleComponent_app_edit_detail_8_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r7); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r8.cancelUpdate($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("detail", ctx_r1.detailDetailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r1.optionsButon)("dataView", ctx_r1.listViews);
} }
function DanhSachRoleComponent_app_config_grid_table_form_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "app-config-grid-table-form", 16);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r2.gridKey);
} }
const _c0 = function (a0) { return { "bg-dropbox": a0 }; };
function DanhSachRoleComponent_li_16_li_6_ul_5_li_1_Template(rf, ctx) { if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "li", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function DanhSachRoleComponent_li_16_li_6_ul_5_li_1_Template_input_change_1_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r21); const actionIdx_r18 = restoredCtx.index; const idx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](2).index; const i_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]().index; const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r19.changeActionChirlden(i_r10, idx_r14, actionIdx_r18); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "label", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "span", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](5, "Action");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const action_r17 = ctx.$implicit;
    const actionIdx_r18 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("id", "president_", action_r17.id, "_", actionIdx_r18, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("name", "", action_r17 == null ? null : action_r17.actionName, "_", actionIdx_r18, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("checked", action_r17 == null ? null : action_r17.isCheck);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("for", "president_", action_r17.id, "_", actionIdx_r18, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", action_r17 == null ? null : action_r17.actionName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](9, _c0, action_r17 == null ? null : action_r17.isCheck));
} }
function DanhSachRoleComponent_li_16_li_6_ul_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ul", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](1, DanhSachRoleComponent_li_16_li_6_ul_5_li_1_Template, 6, 11, "li", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const menuChirlden_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", menuChirlden_r13.actions);
} }
function DanhSachRoleComponent_li_16_li_6_Template(rf, ctx) { if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "li", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function DanhSachRoleComponent_li_16_li_6_Template_input_change_1_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r26); const idx_r14 = restoredCtx.index; const i_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]().index; const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r24.changeMenuChirlden(i_r10, idx_r14); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "input", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function DanhSachRoleComponent_li_16_li_6_Template_input_change_2_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r26); const idx_r14 = restoredCtx.index; const i_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]().index; const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r27.changeModelintPosChilrden($event, i_r10, idx_r14); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](3, "label", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](5, DanhSachRoleComponent_li_16_li_6_ul_5_Template, 2, 1, "ul", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const menuChirlden_r13 = ctx.$implicit;
    const idx_r14 = ctx.index;
    const menu_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]().$implicit;
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("id", "president_", menuChirlden_r13.menuId, "_", idx_r14, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("name", "", menuChirlden_r13 == null ? null : menuChirlden_r13.title, "_", idx_r14, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("disabled", ctx_r11.roleType !== 1 && menuChirlden_r13.path === "/phan-quyen/quyen-nguoi-dung")("checked", menuChirlden_r13 == null ? null : menuChirlden_r13.isCheck);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("name", "intPos_", menuChirlden_r13.intPos, "_", menu_r9.menuId, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", menuChirlden_r13.intPos);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("for", "president_", menuChirlden_r13.menuId, "_", idx_r14, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", menuChirlden_r13 == null ? null : menuChirlden_r13.title, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", menuChirlden_r13 == null ? null : menuChirlden_r13.isCheck);
} }
function DanhSachRoleComponent_li_16_ul_7_li_1_Template(rf, ctx) { if (rf & 1) {
    const _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "li", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function DanhSachRoleComponent_li_16_ul_7_li_1_Template_input_change_1_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r35); const actionIdx_r32 = restoredCtx.index; const i_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](2).index; const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r33.changeActionAdministration(i_r10, actionIdx_r32); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "label", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "span", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](5, "Action");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const action_r31 = ctx.$implicit;
    const actionIdx_r32 = ctx.index;
    const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](2);
    const menu_r9 = ctx_r36.$implicit;
    const i_r10 = ctx_r36.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("id", "president_", action_r31.id, "_", actionIdx_r32, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("name", "", action_r31 == null ? null : action_r31.actionName, "_", actionIdx_r32, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("checked", action_r31 == null ? null : action_r31.isCheck);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("for", "president_", menu_r9.menuId, "_", i_r10, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", action_r31 == null ? null : action_r31.actionName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](9, _c0, action_r31 == null ? null : action_r31.isCheck));
} }
function DanhSachRoleComponent_li_16_ul_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ul", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](1, DanhSachRoleComponent_li_16_ul_7_li_1_Template, 6, 11, "li", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const menu_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", menu_r9.actions);
} }
function DanhSachRoleComponent_li_16_Template(rf, ctx) { if (rf & 1) {
    const _r39 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "li", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "input", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function DanhSachRoleComponent_li_16_Template_input_change_1_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r39); const menu_r9 = restoredCtx.$implicit; const i_r10 = restoredCtx.index; const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r38.changeMenuParent(menu_r9, i_r10); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "input", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function DanhSachRoleComponent_li_16_Template_input_change_2_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r39); const i_r10 = restoredCtx.index; const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r40.changeModelintPosParent($event, i_r10); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](3, "label", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "ul", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](6, DanhSachRoleComponent_li_16_li_6_Template, 6, 13, "li", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](7, DanhSachRoleComponent_li_16_ul_7_Template, 2, 1, "ul", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const menu_r9 = ctx.$implicit;
    const i_r10 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("id", "administration_", menu_r9.menuId, "_", i_r10, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("name", "", menu_r9 == null ? null : menu_r9.title, "_", i_r10, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("checked", menu_r9 == null ? null : menu_r9.isCheck);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("name", "intPos_", menu_r9.intPos, "_", menu_r9.menuId, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", menu_r9.intPos);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate2"]("for", "administration_", menu_r9.menuId, "_", i_r10, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", menu_r9 == null ? null : menu_r9.title, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", menu_r9.submenus);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (menu_r9 == null ? null : menu_r9.actions == null ? null : menu_r9.actions.length) > 0);
} }
const _c1 = function () { return { width: "700px", height: "auto" }; };
const _c2 = function () { return { width: "50vw" }; };
const queryString = __webpack_require__(/*! query-string */ 31808);
class DanhSachRoleComponent {
    constructor(activatedRoute, apiService, spinner, confirmationService, messageService, organizeInfoService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.detailInfo = null;
        this.callback = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter();
        this.optionsButon = [
            // { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: '', icon: 'pi pi-plus' }
        ];
        this.columnDefs = [];
        this.listsData = [];
        this.heightGrid = 500;
        this.gridKey = 'view_sysconfig_roles';
        this.displaySetting = false;
        this.dataMenuActionRole = [];
        this.organizeIds = '';
        this.listMenuTree = [];
        this.listActions = [];
        this.sourceActions = [];
        this.targetActions = [];
        this.menus = [];
        this.listViews = [];
        this.detailDetailInfo = null;
        this.displayInfo = false;
        this.displayMenuRole = false;
        this.roleType = null;
        this.listMenuRoles = [];
    }
    cauhinh() {
        this.displaySetting = true;
    }
    ngOnInit() {
        // this.getClientRolePageByWebId()
        // this.getWebMenuTree()
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.organizeIds = results;
                this.getRoles();
            }
        });
    }
    getRoles() {
        this.columnDefs = [];
        const query = { organizeIds: this.organizeIds };
        this.apiService.getMenuConfigInfo(queryString.stringify(query)).subscribe((results) => {
            var _a, _b;
            if (results.status === 'success') {
                this.listsData = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)((_a = results === null || results === void 0 ? void 0 : results.data) === null || _a === void 0 ? void 0 : _a.roles);
                this.dataMenuActionRole = results.data;
                this.listMenuTree = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)((_b = results === null || results === void 0 ? void 0 : results.data) === null || _b === void 0 ? void 0 : _b.menutree);
                this.menus = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(this.listMenuTree);
                if (results.data && results.data.view_grids_action) {
                    this.initGrid(results.data.view_grids_roles);
                }
            }
        });
    }
    getClientRolePageByWebId() {
        this.columnDefs = [];
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                const queryParams = queryString.stringify({ organizeIds: results });
                this.apiService.getUserMenus(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.listsData = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(results.data.dataList.roles);
                        this.initGrid(results.data.gridflexs);
                    }
                });
            }
        });
    }
    // getWebMenuTree() {
    //   this.columnDefs = []
    //   const queryParams = queryString.stringify({ webId: this.detailInfo.webId });
    //   this.apiService.getWebMenuTree(queryParams).subscribe(results => {
    //     if (results.status === 'success') {
    //       this.menus = cloneDeep(results.data);
    //     }
    //   })
    // }
    onTargetFilter(event) {
        if (event.query === "") {
            this.targetActions = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(this.listActions);
        }
        else {
            this.targetActions = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(event.value);
        }
    }
    create() {
        this.getRoleInfo();
    }
    initGrid(gridflexs) {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.AgGridFn)(gridflexs),
            {
                headerName: '',
                field: 'button',
                filter: '',
                pinned: 'right',
                width: 80,
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right'],
                cellRendererParams: params => {
                    return {
                        buttons: [
                            {
                                onClick: this.suaThongTin.bind(this),
                                label: 'Xem thông tin',
                                icon: 'fa fa-edit',
                                class: 'btn-primary mr5',
                            },
                            {
                                onClick: this.delete.bind(this),
                                label: 'Xóa',
                                icon: 'pi pi-trash',
                                class: 'btn-primary mr5',
                            },
                        ]
                    };
                },
            },
        ];
    }
    suaThongTin(event) {
        this.getRoleInfo(event.rowData.roleId);
    }
    getRoleInfo(id = null) {
        this.listViews = [];
        this.displayInfo = true;
        const queryParams = queryString.stringify({ id: id });
        this.apiService.getRoleInfo(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(results.data.group_fields);
                this.detailDetailInfo = results.data;
                this.sourceActions = results.data.actions;
            }
        });
    }
    delete(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện hành động này?',
            accept: () => {
                const queryParams = queryString.stringify({ id: event.rowData.roleId });
                this.apiService.deleteRole(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                        this.callback.emit();
                        this.getRoles();
                        this.displayInfo = false;
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
                    }
                });
            }
        });
    }
    setConfigMenu(data) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailDetailInfo), { group_fields: data });
        const queryParams = queryString.stringify({ organizeIds: this.organizeIds });
        this.apiService.SetRoleInfo(params, queryParams).subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.getRoles();
                this.displayInfo = false;
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    onHideMenuRole(e) {
        this.confirmationService.confirm({
            message: 'Bạn có muốn lưu lại danh sách menu không?',
            accept: () => {
                const arrayMenus = [];
                this.menus.forEach(res => {
                    if (res.isCheck) {
                        arrayMenus.push({
                            menuRoleId: res.menuRoleId,
                            menuId: res.menuId,
                            menuCd: res.menuCd,
                            webId: res.webId,
                            webRoleId: res.webRoleId,
                            userId: res.userId,
                            roleCd: res.roleCd,
                            title: res.title,
                            tabId: res.tabId,
                            tabCd: res.tabCd,
                            intPos: res.intPos,
                            actions: res.actions && res.actions.length > 0 ? res.actions.filter(action => action.isCheck) : []
                        });
                    }
                    if (res.submenus) {
                        res.submenus.forEach(element => {
                            if (element.isCheck) {
                                arrayMenus.push({
                                    menuRoleId: element.menuRoleId,
                                    menuId: element.menuId,
                                    menuCd: element.menuCd,
                                    webId: element.webId,
                                    webRoleId: element.webRoleId,
                                    userId: element.userId,
                                    roleCd: element.roleCd,
                                    title: element.title,
                                    tabId: element.tabId,
                                    tabCd: element.tabCd,
                                    intPos: element.intPos,
                                    actions: element.actions && element.actions.length > 0 ? element.actions.filter(action => action.isCheck) : []
                                });
                            }
                        });
                    }
                });
                this.detailDetailInfo.rolemenu = arrayMenus;
                this.setConfigMenu(this.detailDetailInfo.group_fields);
            },
            reject: () => {
                this.displayMenuRole = false;
            }
        });
    }
    changeModelintPosParent(event, index) {
        this.menus[index].intPos = event.target.value;
        this.menus.sort(this.compare_qty);
    }
    changeModelintPosChilrden(event, idxParent, index) {
        this.menus[idxParent].submenus[index].intPos = event.target.value;
        this.menus[idxParent].submenus.sort(this.compare_qty);
    }
    changeActionChirlden(idxParent, index, actionIdx) {
        this.menus[idxParent].submenus[index].actions[actionIdx].isCheck = !this.menus[idxParent].submenus[index].actions[actionIdx].isCheck;
    }
    changeActionAdministration(index, actionIdx) {
        this.menus[index].actions[actionIdx].isCheck = !this.menus[index].actions[actionIdx].isCheck;
    }
    changeMenuParent(menu, index) {
        // this.menus[index].isCheck = !this.menus[index].isCheck;
        // if (this.menus[index].isCheck) {
        //   if(this.menus[index].submenus){
        //     this.menus[index].submenus = this.menus[index].submenus.map(result => {
        //       return { ...result, isCheck: true };
        //     })
        //   }
        // } else {
        //   if(this.menus[index].submenus){
        //     this.menus[index].submenus = this.menus[index].submenus.map(result => {
        //       return { ...result, isCheck: false };
        //     })
        //   }
        // }
        // this.menus = [...this.menus];
        this.menus[index].isCheck = !this.menus[index].isCheck;
        if (this.menus[index].isCheck) {
            // this.menus[index].submenus = this.menus[index].submenus.map(result => {
            //   return { ...result, isCheck: true };
            // });
            this.menus[index].submenus.forEach(submenu => {
                submenu.isCheck = true;
                submenu.actions = submenu.actions.map(action => {
                    return Object.assign(Object.assign({}, action), { isCheck: true });
                });
            });
        }
        else {
            // this.menus[index].submenus = this.menus[index].submenus.map(result => {
            //   return { ...result, isCheck: false };
            // })
            this.menus[index].submenus.forEach(submenu => {
                submenu.isCheck = false;
                submenu.actions = submenu.actions.map(action => {
                    return Object.assign(Object.assign({}, action), { isCheck: false });
                });
            });
        }
        this.menus = [...this.menus];
    }
    changeMenuChirlden(idxParent, index) {
        this.menus[idxParent].submenus[index].isCheck = !this.menus[idxParent].submenus[index].isCheck;
        if (this.menus[idxParent].submenus[index].isCheck) {
            this.menus[idxParent].isCheck = true;
        }
        else {
            let arrChecks = this.menus[idxParent].submenus.map(res => res.isCheck);
            if (arrChecks.includes(true)) {
                this.menus[idxParent].isCheck = true;
            }
            else {
                this.menus[idxParent].isCheck = false;
            }
        }
        if (this.menus[idxParent].submenus[index].isCheck) {
            this.menus[idxParent].submenus[index].actions = this.menus[idxParent].submenus[index].actions.map(result => {
                return Object.assign(Object.assign({}, result), { isCheck: true });
            });
        }
        else {
            this.menus[idxParent].submenus[index].actions = this.menus[idxParent].submenus[index].actions.map(result => {
                return Object.assign(Object.assign({}, result), { isCheck: false });
            });
        }
        // this.menus[idxParent].listmenu[index] = [...this.menus[idxParent].listmenu[index]];
    }
    clickRowRoleGetMenu(event) {
        this.detailDetailInfo = null;
        this.menus = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(this.listMenuTree);
        this.menus.forEach(m => {
            m.isCheck = false;
            m.isCheckAll = false;
            if (m.submenus) {
                m.submenus.forEach(d => {
                    d.isCheck = false;
                });
            }
        });
        // this.detailRole = event.data
        this.getRoleInfoSidebar(event.data.roleId);
        this.displayMenuRole = true;
        this.roleType = event.data.roleType;
    }
    getRoleInfoSidebar(id) {
        const queryParams = queryString.stringify({ id: id });
        this.apiService.getRoleInfo(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.detailDetailInfo = results.data;
                this.listMenuRoles = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(this.detailDetailInfo.rolemenu);
                this.menus.forEach(m => {
                    if (this.listMenuRoles.map(q => q.menuId).indexOf(m.menuId) > -1) {
                        m.isCheck = true;
                        this.listMenuRoles.forEach(a => {
                            if (m.menuId === a.menuId) {
                                if (a.actions && a.actions.length > 0) {
                                    m.actions.forEach(action => {
                                        a.actions.forEach(action1 => {
                                            if (action.actionId === action1.actionId) {
                                                action.isCheck = true;
                                            }
                                        });
                                    });
                                    console.log(m);
                                }
                                else {
                                    m.actions.forEach(action => action.isCheck = false);
                                }
                            }
                        });
                    }
                    else {
                        m.isCheck = false;
                    }
                    if (m.submenus) {
                        m.submenus.forEach(d => {
                            if (this.listMenuRoles.map(q => q.menuId).indexOf(d.menuId) > -1) {
                                d.isCheck = true;
                                //load is check action
                                this.listMenuRoles.forEach(a => {
                                    if (d.menuId === a.menuId) {
                                        if (a.actions && a.actions.length > 0) {
                                            d.actions.forEach(action => {
                                                a.actions.forEach(action1 => {
                                                    if (action.actionId === action1.actionId) {
                                                        action.isCheck = true;
                                                    }
                                                });
                                            });
                                        }
                                        else {
                                            d.actions.forEach(action => action.isCheck = false);
                                        }
                                    }
                                });
                            }
                            else {
                                d.isCheck = false;
                            }
                            this.listMenuRoles.forEach(g => {
                                if (g.menuId === d.menuId) {
                                    d.intPos = g.intPos;
                                }
                            });
                            if (this.roleType !== 1 && d.path === "/phan-quyen/quyen-nguoi-dung") {
                                d.isCheck = false;
                                d.actions.forEach(actionD => {
                                    actionD.isCheck = false;
                                });
                            }
                        });
                        m.submenus.sort(this.compare_qty);
                        this.listMenuRoles.forEach(g => {
                            if (g.menuId === m.menuId) {
                                m.intPos = g.intPos;
                            }
                        });
                    }
                });
                this.menus = [...this.menus].sort(this.compare_qty);
            }
        });
    }
    // this.menus.forEach(element => {
    //   if(element.path === "phan-quyen") {
    //     element.submenus.forEach(element2 => {
    //       if(element2.path === "/phan-quyen/quyen-nguoi-dung") {
    //         element2.isCheck = false;
    //         console.log('fjdosjfodij 111')
    //       }
    //     });
    //   }
    // });
    compare_qty(a, b) {
        // a should come before b in the sorted order
        if (a.intPos < b.intPos) {
            return -1;
            // a should come after b in the sorted order
        }
        else if (a.intPos > b.intPos) {
            return 1;
            // a and b are the same
        }
        else {
            return 0;
        }
    }
    cancelUpdate(data) {
        if (data === 'CauHinh') {
            this.getRoleInfo(this.detailDetailInfo.roleId);
        }
    }
}
DanhSachRoleComponent.ɵfac = function DanhSachRoleComponent_Factory(t) { return new (t || DanhSachRoleComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__.ApiService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_9__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_3__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router)); };
DanhSachRoleComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({ type: DanhSachRoleComponent, selectors: [["app-danh-sach-role"]], inputs: { detailInfo: "detailInfo" }, outputs: { callback: "callback" }, decls: 17, vars: 21, consts: [[1, "d-flex", "are-tab-btns", "mt-2", "mb-2"], ["styleClass", "p-button-sm btn-tab", "label", "Th\u00EAm m\u1EDBi", "icon", "pi pi-icon", 3, "click"], ["label", "C\u1EA5u h\u00ECnh", "icon", "pi pi-cog", "styleClass", "p-button-sm ml-2 addNew", 3, "click"], [1, "grid-default", "border"], [3, "listsData", "height", "columnDefs", "rowDoubleClicked", 4, "ngIf"], ["styleClass", "popup-content-w", 3, "visible", "autoZIndex", "modal", "visibleChange"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh ", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "danh-sach-chuc-nang-sidebar sidebar-role", "position", "right", 3, "visible", "baseZIndex", "visibleChange", "onHide"], [1, "d-flex", "align-items-center"], [1, "pi", "pi-cog", "mr-2"], [1, "checktree", "mt-2"], ["title", "Menu Cha", 4, "ngFor", "ngForOf"], [3, "listsData", "height", "columnDefs", "rowDoubleClicked"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"], [3, "typeConfig", "gridKey"], ["title", "Menu Cha"], ["type", "checkbox", 2, "margin-right", "5px", 3, "id", "checked", "name", "change"], ["type", "number", 3, "ngModel", "name", "change"], [2, "font-weight", "600", "margin-left", "5px", "font-size", "13px", 3, "for"], [2, "margin-left", "5px"], ["title", "Menu con", 4, "ngFor", "ngForOf"], ["style", "margin-left:35px", 4, "ngIf"], ["title", "Menu con"], ["type", "checkbox", 2, "margin-right", "5px", 3, "disabled", "id", "name", "checked", "change"], ["style", "margin-left:5px", 4, "ngIf"], ["title", "Action con", 4, "ngFor", "ngForOf"], ["title", "Action con"], ["type", "checkbox", 2, "margin-right", "5px", 3, "id", "name", "checked", "change"], [3, "for"], ["_ngcontent-bpg-c6", "", 1, "noti-number", "text-white", "pointer", "ng-star-inserted", 3, "ngClass"], [2, "margin-left", "35px"], ["title", "Action cha", 4, "ngFor", "ngForOf"], ["title", "Action cha"]], template: function DanhSachRoleComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "p-button", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function DanhSachRoleComponent_Template_p_button_click_1_listener() { return ctx.create(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "p-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function DanhSachRoleComponent_Template_p_button_click_2_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](4, DanhSachRoleComponent_app_list_grid_angular_4_Template, 1, 3, "app-list-grid-angular", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "p-dialog", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("visibleChange", function DanhSachRoleComponent_Template_p_dialog_visibleChange_5_listener($event) { return ctx.displayInfo = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](6, "p-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](7, " Th\u00F4ng tin nh\u00F3m quy\u1EC1n ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](8, DanhSachRoleComponent_app_edit_detail_8_Template, 1, 4, "app-edit-detail", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](9, "p-dialog", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("visibleChange", function DanhSachRoleComponent_Template_p_dialog_visibleChange_9_listener($event) { return ctx.displaySetting = $event; })("onHide", function DanhSachRoleComponent_Template_p_dialog_onHide_9_listener() { return ctx.getRoles(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](10, DanhSachRoleComponent_app_config_grid_table_form_10_Template, 1, 2, "app-config-grid-table-form", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](11, "p-sidebar", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("visibleChange", function DanhSachRoleComponent_Template_p_sidebar_visibleChange_11_listener($event) { return ctx.displayMenuRole = $event; })("onHide", function DanhSachRoleComponent_Template_p_sidebar_onHide_11_listener($event) { return ctx.onHideMenuRole($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](12, "h3", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](13, "i", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](14, "Danh s\u00E1ch ch\u1EE9c n\u0103ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](15, "ul", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](16, DanhSachRoleComponent_li_16_Template, 8, 13, "li", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](19, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("visible", ctx.displayInfo)("autoZIndex", true)("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](20, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("visible", ctx.displayMenuRole)("baseZIndex", 10000);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.menus);
    } }, directives: [primeng_button__WEBPACK_IMPORTED_MODULE_11__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, primeng_dialog__WEBPACK_IMPORTED_MODULE_13__.Dialog, primeng_api__WEBPACK_IMPORTED_MODULE_10__.Header, primeng_sidebar__WEBPACK_IMPORTED_MODULE_14__.Sidebar, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgForOf, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_4__.ListGridAngularComponent, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__.EditDetailComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_6__.ConfigGridTableFormComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_15__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_15__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_15__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_15__.NgModel, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgClass], styles: ["[_nghost-%COMP%]  .control-btn-save .wrap-btn {\n  right: 50px !important;\n  top: 20px !important;\n}\n[_nghost-%COMP%]  .control-btn-save .p-picklist .p-picklist-list .p-picklist-item {\n  border-bottom: 1px solid #e9e9e9;\n  display: flex;\n  justify-content: space-between;\n  padding: 0.5rem 0.5rem;\n}\n[_nghost-%COMP%]  .checktree {\n  padding-left: 0px;\n}\n[_nghost-%COMP%]  .checktree input[type=number] {\n  width: 42px;\n  border: 1px solid #ccc;\n  border-radius: 4px;\n  padding: 5px;\n  text-align: center;\n}\n[_nghost-%COMP%]  .checktree li {\n  list-style: none;\n  margin-bottom: 4px;\n  margin-top: 3px;\n}\n[_nghost-%COMP%]  .checktree li ul {\n  padding-left: 10px;\n  margin-top: 6px;\n}\n[_nghost-%COMP%]  .danh-sach-chuc-nang-sidebar .p-sidebar-header {\n  position: absolute;\n  top: 6px;\n  right: 2px;\n  z-index: 1;\n  padding-top: 0px;\n  padding-bottom: 0px;\n}\n[_nghost-%COMP%]  .ag-theme-alpine .ag-header-row:not(:first-child) .ag-header-cell {\n  border-top: 1px solid #f7f0f0;\n  border-radius: 0;\n}\n[_nghost-%COMP%]  .tab-customer-detail {\n  position: relative;\n}\n[_nghost-%COMP%]  .tab-customer-detail .btn-addnew {\n  position: absolute;\n  top: 10px;\n  right: 0px;\n}\n[_nghost-%COMP%]  .popup-content-w app-edit-detail .border-section {\n  width: 100%;\n}\n[_nghost-%COMP%]     .p-button {\n  margin: 0 0.5rem 0 0;\n  min-width: 10rem;\n}\np[_ngcontent-%COMP%] {\n  margin: 0;\n}\n.confirmation-content[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n[_nghost-%COMP%]     .p-dialog .p-button {\n  min-width: 6rem;\n}\n[_nghost-%COMP%]  .p-sidebar-right {\n  width: 31rem !important;\n  overflow: scroll;\n}\n[_nghost-%COMP%]  .p-picklist-item {\n  justify-content: space-between !important;\n  display: flex !important;\n  align-items: flex-end !important;\n  border: 1px solid #ccc;\n}\nselect[_ngcontent-%COMP%] {\n  height: calc(2.3rem + 2px) !important;\n}\nul[_ngcontent-%COMP%] {\n  list-style-type: none;\n  margin: 3px;\n  \n}\nul.checktree[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:before {\n  height: 1em;\n  width: 12px;\n  border-bottom: 1px dashed;\n  content: \"\";\n  display: inline-block;\n  top: -0.3em;\n}\nul.checktree[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  border-left: 1px dashed;\n}\nul.checktree[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:last-child:before {\n  border-left: 1px dashed;\n}\nul.checktree[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:last-child {\n  border-left: none;\n}\ninput[type=number][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=number][_ngcontent-%COMP%]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRhbmgtc2FjaC1yb2xlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVVO0VBQ0ksc0JBQUE7RUFDQSxvQkFBQTtBQURkO0FBR1U7RUFDSSxnQ0FBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0FBRGQ7QUFJTTtFQUNJLGlCQUFBO0FBRlY7QUFHVTtFQUNJLFdBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBRGQ7QUFHVTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBRGQ7QUFFYztFQUNJLGtCQUFBO0VBQ0EsZUFBQTtBQUFsQjtBQUtVO0VBQ0ksa0JBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBSGQ7QUFNTTtFQUNJLDZCQUFBO0VBQ0EsZ0JBQUE7QUFKVjtBQU1NO0VBQ0ksa0JBQUE7QUFKVjtBQUtVO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtBQUhkO0FBUVk7RUFDSSxXQUFBO0FBTmhCO0FBWUU7RUFDSSxvQkFBQTtFQUNBLGdCQUFBO0FBVE47QUFZRTtFQUNJLFNBQUE7QUFUTjtBQVlFO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUFUTjtBQVlFO0VBQ0ksZUFBQTtBQVROO0FBWUE7RUFDSSx1QkFBQTtFQUNBLGdCQUFBO0FBVEo7QUFXQTtFQUNFLHlDQUFBO0VBQ0Esd0JBQUE7RUFDQSxnQ0FBQTtFQUNBLHNCQUFBO0FBUkY7QUFXRTtFQUNFLHFDQUFBO0FBUko7QUFXQTtFQUNFLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLHdCQUFBO0FBUkY7QUFXQTtFQUNFLFdBQUE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0FBUkY7QUFVQTtFQUFpQix1QkFBQTtBQU5qQjtBQU9BO0VBQW1DLHVCQUFBO0FBSG5DO0FBSUE7RUFBNEIsaUJBQUE7QUFBNUI7QUFFQTs7RUFFRSx3QkFBQTtFQUNBLFNBQUE7QUFDRiIsImZpbGUiOiJkYW5oLXNhY2gtcm9sZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0OjpuZy1kZWVwe1xyXG4gICAgLmNvbnRyb2wtYnRuLXNhdmV7XHJcbiAgICAgICAgICAud3JhcC1idG57XHJcbiAgICAgICAgICAgICAgcmlnaHQ6IDUwcHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICB0b3A6IDIwcHggIWltcG9ydGFudDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5wLXBpY2tsaXN0IC5wLXBpY2tsaXN0LWxpc3QgLnAtcGlja2xpc3QtaXRlbXtcclxuICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U5ZTllOTtcclxuICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgICBwYWRkaW5nOiAwLjVyZW0gMC41cmVtO1xyXG4gICAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIC5jaGVja3RyZWV7XHJcbiAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDBweDtcclxuICAgICAgICAgIGlucHV0W3R5cGU9XCJudW1iZXJcIl17XHJcbiAgICAgICAgICAgICAgd2lkdGg6IDQycHg7XHJcbiAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgICAgICAgcGFkZGluZzogNXB4O1xyXG4gICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGxpe1xyXG4gICAgICAgICAgICAgIGxpc3Qtc3R5bGU6IG5vbmU7XHJcbiAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG4gICAgICAgICAgICAgIG1hcmdpbi10b3A6IDNweDtcclxuICAgICAgICAgICAgICB1bHtcclxuICAgICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA2cHg7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIC5kYW5oLXNhY2gtY2h1Yy1uYW5nLXNpZGViYXJ7XHJcbiAgICAgICAgICAucC1zaWRlYmFyLWhlYWRlcntcclxuICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgdG9wOiA2cHg7XHJcbiAgICAgICAgICAgICAgcmlnaHQ6IDJweDtcclxuICAgICAgICAgICAgICB6LWluZGV4OiAxO1xyXG4gICAgICAgICAgICAgIHBhZGRpbmctdG9wOiAwcHg7XHJcbiAgICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDBweDtcclxuICAgICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAuYWctdGhlbWUtYWxwaW5lIC5hZy1oZWFkZXItcm93Om5vdCg6Zmlyc3QtY2hpbGQpIC5hZy1oZWFkZXItY2VsbHtcclxuICAgICAgICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZjdmMGYwO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogMDtcclxuICAgICAgfVxyXG4gICAgICAudGFiLWN1c3RvbWVyLWRldGFpbHtcclxuICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICAgIC5idG4tYWRkbmV3e1xyXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgICB0b3A6IDEwcHg7XHJcbiAgICAgICAgICAgICAgcmlnaHQ6IDBweDtcclxuICAgICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAucG9wdXAtY29udGVudC13e1xyXG4gICAgICAgIGFwcC1lZGl0LWRldGFpbHtcclxuICAgICAgICAgICAgLmJvcmRlci1zZWN0aW9ue1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICB9XHJcbiAgXHJcbiAgOmhvc3QgOjpuZy1kZWVwIC5wLWJ1dHRvbiB7XHJcbiAgICAgIG1hcmdpbjogMCAuNXJlbSAwIDA7XHJcbiAgICAgIG1pbi13aWR0aDogMTByZW07XHJcbiAgfVxyXG4gIFxyXG4gIHAge1xyXG4gICAgICBtYXJnaW46IDA7XHJcbiAgfVxyXG4gIFxyXG4gIC5jb25maXJtYXRpb24tY29udGVudCB7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIH1cclxuICBcclxuICA6aG9zdCA6Om5nLWRlZXAgLnAtZGlhbG9nIC5wLWJ1dHRvbiB7XHJcbiAgICAgIG1pbi13aWR0aDogNnJlbTtcclxuICB9XHJcbiAgXHJcbjpob3N0OjpuZy1kZWVwIC5wLXNpZGViYXItcmlnaHR7XHJcbiAgICB3aWR0aDogMzFyZW0gIWltcG9ydGFudDsgXHJcbiAgICBvdmVyZmxvdzogc2Nyb2xsO1xyXG4gIH1cclxuOmhvc3Q6Om5nLWRlZXAgLnAtcGlja2xpc3QtaXRlbXtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW4gIWltcG9ydGFudDtcclxuICBkaXNwbGF5OiBmbGV4ICFpbXBvcnRhbnQ7XHJcbiAgYWxpZ24taXRlbXM6IGZsZXgtZW5kICFpbXBvcnRhbnQ7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICB9XHJcblxyXG4gIHNlbGVjdCB7XHJcbiAgICBoZWlnaHQ6IGNhbGMoMi4zcmVtICsgMnB4KSAhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbnVsIHtcclxuICBsaXN0LXN0eWxlLXR5cGU6bm9uZTtcclxuICBtYXJnaW46M3B4O1xyXG4gIC8qIG1hcmdpbi1sZWZ0OiAtMzZweDsgKi9cclxufVxyXG4gXHJcbnVsLmNoZWNrdHJlZSBsaTpiZWZvcmUge1xyXG4gIGhlaWdodDoxZW07XHJcbiAgd2lkdGg6MTJweDtcclxuICBib3JkZXItYm90dG9tOjFweCBkYXNoZWQ7XHJcbiAgY29udGVudDpcIlwiO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICB0b3A6LTAuM2VtO1xyXG59XHJcbnVsLmNoZWNrdHJlZSBsaSB7Ym9yZGVyLWxlZnQ6MXB4IGRhc2hlZDsgfVxyXG51bC5jaGVja3RyZWUgbGk6bGFzdC1jaGlsZDpiZWZvcmUge2JvcmRlci1sZWZ0OjFweCBkYXNoZWQ7IH1cclxudWwuY2hlY2t0cmVlIGxpOmxhc3QtY2hpbGQge2JvcmRlci1sZWZ0Om5vbmU7IH1cclxuXHJcbmlucHV0W3R5cGU9bnVtYmVyXTo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbiwgXHJcbmlucHV0W3R5cGU9bnVtYmVyXTo6LXdlYmtpdC1vdXRlci1zcGluLWJ1dHRvbiB7IFxyXG4gIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTsgXHJcbiAgbWFyZ2luOiAwOyBcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 99161:
/*!*********************************************************************************!*\
  !*** ./src/app/components/pq-quyen-nguoi-dung/pq-quyen-nguoi-dung.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PqQuyenNguoiDungComponent": () => (/* binding */ PqQuyenNguoiDungComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api.service */ 67118);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_types_addUser__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/types/addUser */ 54956);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/multiselect */ 92487);
/* harmony import */ var primeng_panel__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/panel */ 53581);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/autocomplete */ 17611);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);





































function PqQuyenNguoiDungComponent_app_list_grid_angular_29_Template(rf, ctx) { if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-list-grid-angular", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("gridReady", function PqQuyenNguoiDungComponent_app_list_grid_angular_29_Template_app_list_grid_angular_gridReady_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r23); const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r22.onGridReady($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function PqQuyenNguoiDungComponent_div_44_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1, " Vui l\u00F2ng \u0111i\u1EC1n t\u00EAn \u0111\u0103ng nh\u1EADp ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqQuyenNguoiDungComponent_div_52_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1, " Vui l\u00F2ng \u0111i\u1EC1n m\u1EADt kh\u1EA9u ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqQuyenNguoiDungComponent_div_60_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1, " Vui l\u00F2ng \u0111i\u1EC1n h\u1ECD v\u00E0 t\u00EAn ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqQuyenNguoiDungComponent_div_68_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1, " Vui l\u00F2ng \u0111i\u1EC1n s\u1ED1 \u0111i\u1EC7n tho\u1EA1i ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqQuyenNguoiDungComponent_div_76_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1, " Vui l\u00F2ng \u0111i\u1EC1n Email ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqQuyenNguoiDungComponent_div_84_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1, " Vui l\u00F2ng ch\u1ECDn t\u1ED5 ch\u1EE9c ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqQuyenNguoiDungComponent_div_97_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1, " Vui L\u00F2ng ch\u1ECDn quy\u1EC1n ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqQuyenNguoiDungComponent_ng_template_98_Template(rf, ctx) { if (rf & 1) {
    const _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "p-button", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_ng_template_98_Template_p_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r25); const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r24.save(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqQuyenNguoiDungComponent_ng_template_107_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r26 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r26 == null ? null : item_r26.label);
} }
function PqQuyenNguoiDungComponent_ng_template_108_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r27 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](car_r27 == null ? null : car_r27.label);
} }
function PqQuyenNguoiDungComponent_app_list_grid_angular_115_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "app-list-grid-angular", 82);
} if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("listsData", ctx_r12.managerInfoList)("height", 400)("columnDefs", ctx_r12.columnDefs1);
} }
function PqQuyenNguoiDungComponent_ng_template_116_Template(rf, ctx) { if (rf & 1) {
    const _r29 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "p-button", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_ng_template_116_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r29); const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r28.seachManager = !ctx_r28.seachManager; });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqQuyenNguoiDungComponent_app_config_grid_table_form_118_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "app-config-grid-table-form", 84);
} if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r14.gridKey);
} }
function PqQuyenNguoiDungComponent_div_135_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1, " Password b\u1EAFt bu\u1ED9c nh\u1EADp! ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqQuyenNguoiDungComponent_div_135_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, PqQuyenNguoiDungComponent_div_135_div_1_Template, 2, 0, "div", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", !ctx_r17.modelPass.userPassword);
} }
function PqQuyenNguoiDungComponent_div_146_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1, " Nh\u1EADp l\u1EA1i m\u1EADt kh\u1EA9u kh\u00F4ng \u0111\u00FAng ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqQuyenNguoiDungComponent_div_146_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, PqQuyenNguoiDungComponent_div_146_div_1_Template, 2, 0, "div", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", !ctx_r19.modelPass.userPassCf || ctx_r19.confimPassword);
} }
function PqQuyenNguoiDungComponent_ng_template_153_Template(rf, ctx) { if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "div", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](4, "div", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "div", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "label", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](7, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](8, "span", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "p-button", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_ng_template_153_Template_p_button_click_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r33); const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r32.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](10, "p-button", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_ng_template_153_Template_p_button_click_10_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r33); const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r34.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "1000px", height: "auto" }; };
const _c3 = function () { return { width: "50vw" }; };
const _c4 = function () { return { width: "600px", height: "auto" }; };
const _c5 = function () { return { width: "700px" }; };
class PqQuyenNguoiDungComponent {
    constructor(apiService, api, route, confirmationService, messageService, changeDetector, spinner, organizeInfoService, fileService, router) {
        this.apiService = apiService;
        this.api = api;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.changeDetector = changeDetector;
        this.spinner = spinner;
        this.organizeInfoService = organizeInfoService;
        this.fileService = fileService;
        this.router = router;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.ACTIONS;
        this.addUserQuery = new src_app_types_addUser__WEBPACK_IMPORTED_MODULE_9__.addUser();
        this.userIdS = [];
        this.modelPass = {
            userLogin: '',
            userPassword: '',
            userPassCf: ''
        };
        this.saveAddUser = false;
        this.confimPassword = false;
        this.isShowPass = false;
        this.isShowRepass = false;
        this.pagingComponent = {
            total: 0
        };
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_2__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.loading = false;
        this.companies = [];
        this.displaySetting = false;
        this.gridKey = '';
        this.listsData = [];
        this.isShowChangePassword = false;
        this.submitPass = false;
        this.loadjs = 0;
        this.heightGrid = 450;
        this.titleForm = 'Thêm mới quyền người dùng';
        this.isEditUser = false;
        this.listJobTitles = [];
        this.seachManager = false;
        this.managerLists = null;
        this.dataPositionList = [];
        this.organizes = [];
        this.orgId = null;
        this.listUser = [];
        this.listUserDetail = [];
        this.managerInfoList = [];
        this.columnDefs1 = [];
        this.displayAdd = false;
        this.roles = [];
        this.detailOrganizes = [];
        this.chiTietNguoiDUng = {
            userLogin: '',
            fullName: '',
            phone: '',
            email: '',
        };
        this.modelAdd = {
            fullName: '',
            phone: '',
            email: '',
            ord_ids: [],
            roles: [],
            userId: '',
            loginName: '',
            password: ''
        };
        this.roleids = [];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__.AvatarFullComponent,
        };
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    cancel() {
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds,
        };
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getUserPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.XemChiTiet.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    // hide: CheckHideAction(MENUACTIONROLEAPI.GetUserPage.url, ACTIONS.VIEW)
                },
                {
                    onClick: this.changePassWord.bind(this),
                    label: 'Thay đổi mật khẩu',
                    icon: 'pi pi-user-edit',
                    class: 'btn-primary mr5',
                },
                {
                    onClick: this.lockUser.bind(this),
                    label: 'Khóa người dùng',
                    icon: 'pi pi-lock',
                    class: 'btn-primary mr5',
                    hide: (event.data.lock_st === true || event.data.lock_st)
                },
                {
                    onClick: this.unLockUser.bind(this),
                    label: 'Mở khóa người dùng',
                    icon: 'pi pi-lock-open',
                    class: 'btn-primary mr5',
                    hide: (event.data.lock_st === false || !event.data.lock_st)
                },
                {
                    onClick: this.xoaNguoiDung.bind(this),
                    label: 'Xóa tài khoản',
                    icon: 'pi pi-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.MENUACTIONROLEAPI.GetUserPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.ACTIONS.DELETE)
                },
            ]
        };
    }
    lockUser(event) {
        console.log('event');
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn khóa người dùng?',
            accept: () => {
                this.apiService.lockUser(event.rowData.userId).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Đã khóa người dùng!' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    unLockUser(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn mở khóa khóa người dùng?',
            accept: () => {
                this.apiService.unLockUser(event.rowData.userId).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Mở khóa thành công!' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    changePassWord(event) {
        this.submitPass = false;
        this.isShowChangePassword = true;
        this.modelPass = {
            userLogin: '',
            userPassword: '',
            userPassCf: ''
        };
        this.modelPass.userLogin = event.rowData.loginName;
    }
    checkPasswordcf() {
        if (this.modelPass.userPassword === this.modelPass.userPassCf) {
            this.confimPassword = false;
        }
        else {
            this.confimPassword = true;
        }
    }
    saveChangePass() {
        this.submitPass = true;
        if ((this.modelPass.userPassword && !this.modelPass.userPassCf) || this.confimPassword) {
            return;
        }
        const params = Object.assign({}, this.modelPass);
        delete params.userPassCf;
        this.api.setResetPassword(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Sửa thông tin tài khoản thành công !' });
                this.isShowChangePassword = false;
            }
            if (results.status === 'error') {
                this.messageService.add({ severity: 'error', summary: results.message, detail: results.data });
            }
        });
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    xoaNguoiDung(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện mở tài khoản?',
            accept: () => {
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ userId: event.rowData.userId });
                this.apiService.removeUser(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa thành công quyền người dùng' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    XemChiTiet({ rowData }) {
        this.isEditUser = true;
        this.displayAdd = true;
        this.addUserQuery.fullName = rowData.fullName;
        this.addUserQuery.phone = rowData.phone;
        this.addUserQuery.email = rowData.email;
        if (rowData.org_id) {
            this.addUserQuery.ord_ids = rowData.org_id.split(',');
            this.addUserQuery.ord_ids = this.addUserQuery.ord_ids.map((d) => { return d.toLowerCase(); });
        }
        if (rowData.role_id) {
            this.addUserQuery.roles = rowData.role_id.split(',');
        }
        if (rowData.companyId) {
            this.addUserQuery.companyIds = rowData.companyId.split(',');
        }
        console.log('rowData', rowData);
        this.addUserQuery.userId = rowData.userId;
        this.addUserQuery.loginName = rowData.loginName;
        this.addUserQuery.password = "true";
        this.titleForm = 'Chỉnh sửa quyền người dùng';
        this.getRoleActive(rowData.role_id);
        this.getOrganizes();
        this.getPositionList();
        this.getRoles();
        this.getCompany();
    }
    themmoi2() {
        this.addUserQuery.fullName = "";
        this.addUserQuery.phone = "";
        this.addUserQuery.email = "";
        this.addUserQuery.ord_ids = [];
        this.addUserQuery.roles = [];
        this.addUserQuery.companyIds = [];
        this.addUserQuery.userId = "";
        this.addUserQuery.loginName = "";
        this.addUserQuery.password = "";
        this.addUserQuery.isAdd = true;
        this.displayAdd = true;
        this.saveAddUser = false;
        this.isEditUser = false;
        this.titleForm = 'Thêm mới quyền người dùng';
        this.getOrganizes();
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Phân quyền' },
            { label: 'Danh sách người dùng' },
        ];
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
            }
        });
        this.getOrganize();
        this.getJobTitles();
        this.getPositionList();
        this.getManagerList();
    }
    getJobTitles() {
        this.apiService.getJobTitles().subscribe(results => {
            if (results.status === 'success') {
                this.listJobTitles = results.data.map(d => {
                    return {
                        label: d.job_name,
                        value: d.jobId
                    };
                });
            }
        });
    }
    themmoi() {
        this.addUserQuery = new src_app_types_addUser__WEBPACK_IMPORTED_MODULE_9__.addUser();
        this.seachManager = true;
        this.orgId = null;
        this.valueSearchUser = null;
        this.managerInfoList = [];
        this.getOrganizes();
        this.initAgrid();
    }
    getManagerList() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ userRole: 1, byReport: 1 });
        this.apiService.getManagerList(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.managerLists = results.data.map(d => {
                    return {
                        label: d.fullName + ' [' + d.loginName + ']',
                        value: d.userId
                    };
                });
                this.managerLists.push({ label: 'Chọn người duyệt', value: '' });
            }
        });
    }
    getPositionList() {
        let oriID = this.modelAdd.ord_ids;
        if (!oriID) {
            oriID = this.orgId;
        }
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '', orgId: oriID });
        this.apiService.getPositionList(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.dataPositionList = results.data.map(d => {
                    return {
                        label: d.positionName,
                        value: d.positionId
                    };
                });
            }
        });
    }
    changeOragin() {
        this.getPositionList();
    }
    onGridReady1(params) {
        this.gridApi1 = params.api;
        this.gridColumnApi1 = params.columnApi;
    }
    callApi(custId) {
        this.spinner.show();
        this.apiService.getUserSearchPage(custId).subscribe((result) => {
            if (result.status === 'success') {
                // this.gridApi1.setRowData(result.data.dataList.data);
                // this.managerInfoList = result.data.dataList.data;
                this.managerInfoList = [];
                let listUserOfUser = result.data.dataList.data;
                listUserOfUser.forEach(user => {
                    let userLoginName = user.loginName.substring(0, 4);
                    if (userLoginName !== 'shrm') {
                        this.managerInfoList.push(user);
                    }
                });
                this.initAgrid();
                this.spinner.hide();
            }
        });
    }
    getOrganize() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams)
            .subscribe((results) => {
            this.organizes = results.data
                .map(d => {
                return {
                    label: d.organizationName || d.organizationCd,
                    value: d.organizeId
                };
            });
        }),
            error => { };
    }
    getListUserMaster(event) {
        this.apiService.getEmployeeSearch(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: event.query, orgId: this.orgId })).subscribe((result) => {
            this.listUserDetail = result.data;
            this.listUser = this.listUserDetail.map(res => {
                return Object.assign({ label: `${res.phone}---${res.email}`, value: res.custId }, res);
            });
        });
    }
    onSelectUser(event) {
        this.detailUser = event;
        this.callApi(event.phone);
    }
    getRoles() {
        let organizeIds = '';
        if (this.addUserQuery.ord_ids.length > 0) {
            organizeIds = this.addUserQuery.ord_ids.toString();
        }
        const query = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({
            filter: '',
            organizeIds: organizeIds
        });
        this.api.getRolePage(query).subscribe((results) => {
            if (results.status === "success")
                this.roles = results.data.dataList.data
                    .map(d => {
                    return {
                        label: d.name,
                        code: d.id.toUpperCase()
                    };
                });
            let rolesActive = this.roles.filter(roles => this.addUserQuery.roles.some(roleActive => roles.code === roleActive));
            this.addUserQuery.roles = rolesActive.map(role => role.code);
        }),
            error => { };
    }
    getCompany() {
        let organizeIds = '';
        if (this.addUserQuery.ord_ids.length > 0) {
            organizeIds = this.addUserQuery.ord_ids.toString();
        }
        const query = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({
            organizeId: organizeIds
        });
        this.apiService.getCompaniesByUserOrganize(query).subscribe((results) => {
            if (results.status === "success") {
                this.companies = results.data
                    .map(d => {
                    return {
                        label: d.name,
                        code: d.value.toUpperCase()
                    };
                });
                if (this.addUserQuery.companyIds) {
                    let companyActive = this.companies.filter(compan => this.addUserQuery.companyIds.some(companActive => compan.code === companActive));
                    this.addUserQuery.companyIds = companyActive.map(compan => compan.code);
                }
            }
        }),
            error => { };
    }
    getRoleActive(data) {
        this.modelAdd.roles = [];
        if (data) {
            let roleIds = data.split(',');
            for (let i = 0; i < roleIds.length; i++) {
                for (let j = 0; j < this.roles.length; j++) {
                    if (roleIds[i].toLowerCase() === this.roles[j].code) {
                        this.modelAdd.roles.push(this.roles[j]);
                    }
                }
            }
        }
    }
    getOrganizes() {
        this.apiService.getUserOrganizeRole().subscribe((results) => {
            if (results.status === "success") {
                if (results.data) {
                    this.detailOrganizes = results.data
                        .map(d => {
                        return {
                            label: d.name,
                            value: d.value
                        };
                    });
                }
            }
        }),
            error => { };
    }
    initAgrid() {
        this.columnDefs1 = [
            {
                headerName: 'Tên đăng nhập',
                field: 'loginName',
                resizable: true,
                cellClass: ['border-right']
            },
            {
                headerName: 'Số điện thoại',
                field: 'phone',
                resizable: true,
                cellClass: ['border-right']
            },
            {
                headerName: 'Email',
                field: 'email',
                resizable: true,
                cellClass: ['border-right']
            },
            {
                headerName: 'Thao tác',
                field: 'button',
                filter: '',
                cellRenderer: 'buttonAgGridComponent',
                cellRendererParams: (params) => this.showbuton(params)
            },
        ];
        this.getRowHeight1 = params => {
            return 40;
        };
    }
    showbuton(e) {
        return {
            buttons: [
                {
                    onClick: this.checkSquare.bind(this),
                    label: 'Chọn',
                    icon: 'fa fa-check-square-o',
                    class: 'btn-primary mg-5',
                },
            ]
        };
    }
    checkSquare(e) {
        this.getPositionList();
        this.displayAdd = true;
        this.seachManager = false;
        let items = this.listUserDetail.filter(res => res.custId === this.detailUser.custId);
        this.titleForm = 'Thêm mới quyền người dùng';
        this.chiTietNguoiDUng = Object.assign(Object.assign({}, items[0]), { loginName: e.rowData.loginName });
        this.modelAdd.ord_ids = this.chiTietNguoiDUng.organizeId;
        this.modelAdd.userId = e.rowData.userId;
    }
    save() {
        this.saveAddUser = true;
        if (!this.addUserQuery.ord_ids && this.addUserQuery.ord_ids.length <= 0) {
            return;
        }
        if (!this.addUserQuery.roles || this.addUserQuery.roles.length <= 0) {
            return;
        }
        if (!this.addUserQuery.phone) {
            return;
        }
        if (!this.addUserQuery.email) {
            return;
        }
        if (!this.addUserQuery.fullName) {
            return;
        }
        if (!this.addUserQuery.password && !this.isEditUser) {
            return;
        }
        if (this.isEditUser) {
            this.addUserQuery.password = '';
            this.addUserQuery.isAdd = false;
        }
        const params = this.addUserQuery;
        // console.log('this.addUserQuery.roles', this.addUserQuery.roles)
        // if(this.addUserQuery.roles.length > 0){
        //   params.roles = this.addUserQuery.roles.map( (d: any) => {
        //     return d.code
        //   })
        // }
        this.spinner.show();
        this.apiService.setUserAdd(params).subscribe(results => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Thêm mới thành công' });
                this.load();
                this.displayAdd = false;
                this.spinner.hide();
            }
            else {
                this.spinner.hide();
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    goToSettingRole() {
        this.router.navigateByUrl('/phan-quyen/quyen-nguoi-dung/chi-tiet-quyen-nguoi-dung');
    }
    onChangeOrgan(event) {
        // this.addUserQuery.roles = [];
        // this.addUserQuery.companyIds = [];
        this.getRoles();
        this.getCompany();
    }
    exportData() {
        this.spinner.show();
        this.query.pageSize = 1000000;
        const query = Object.assign({}, this.query);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query);
        this.apiService.getUserPage(queryParams).subscribe((results) => {
            const dataExport = [];
            let gridflexs = results.data.gridflexs;
            let arrKey = gridflexs.map(elementName => elementName.columnField);
            let dataList = results.data.dataList.data;
            for (let elementValue of dataList) {
                const data = {};
                for (let elementName of gridflexs) {
                    if (arrKey.indexOf(elementName.columnField) > -1 && !elementName.isHide && elementName.columnField !== 'statusName') {
                        let valueColumn = elementValue[elementName.columnField];
                        if (elementName.columnField == 'status_name' || elementName.columnField == 'isContacted' || elementName.columnField == 'isProfileFull' || elementName.columnField == 'lockName') {
                            valueColumn = this.replaceHtmlToText(valueColumn);
                        }
                        data[elementName.columnCaption] = valueColumn || '';
                    }
                }
                dataExport.push(data);
            }
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách người dùng ' + new Date());
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
}
PqQuyenNguoiDungComponent.ɵfac = function PqQuyenNguoiDungComponent_Factory(t) { return new (t || PqQuyenNguoiDungComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_7__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_api_service__WEBPACK_IMPORTED_MODULE_1__.ApiService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_16__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_17__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_17__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_15__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_18__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_10__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_11__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_16__.Router)); };
PqQuyenNguoiDungComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({ type: PqQuyenNguoiDungComponent, selectors: [["app-pq-quyen-nguoi-dung"]], decls: 154, vars: 95, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "end", "bottom", "gap-12", "col-9", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["_ngcontent-gwb-c197", "", "width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["_ngcontent-gwb-c197", "", "fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm mr-1 height-56", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M11 5H9V9H5V11H9V15H11V11H15V9H11V5ZM10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM10 18C5.59 18 2 14.41 2 10C2 5.59 5.59 2 10 2C14.41 2 18 5.59 18 10C18 14.41 14.41 18 10 18Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", "icon", "pi pi-file-excel", "label", "Export", 3, "click"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "20", "height", "17", "viewBox", "0 0 20 17", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M19.5 17V0H0.50855L0.5 17H19.5ZM6.675 15.3187H2.21V6.81868H6.675V15.3187ZM8.575 15.3187V6.81868H17.79V15.3187H8.575ZM2.21 1.68132V5.13736H17.79V1.68132H2.21Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "gridReady", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], [3, "visible", "autoZIndex", "modal", "draggable", "resizable", "visibleChange"], [1, "col-md-12"], [1, "field-group", "text", "label-8"], ["for", ""], [2, "color", "red"], ["type", "text", "name", "loginName", "placeholder", "Nh\u1EADp t\u00EAn \u0111\u0103ng nh\u1EADp", 1, "form-control", 3, "readonly", "ngModel", "ngModelChange"], ["class", "alert-validation alert-danger", 4, "ngIf"], [1, "col-md-12", "mt-1"], ["type", "password", "autocomplete", "false", "name", "password", "placeholder", "Nh\u1EADp m\u1EADt kh\u1EA9u", 1, "form-control", 3, "readonly", "ngModel", "value", "ngModelChange"], ["type", "text", "name", "fullName", "placeholder", "Nh\u1EADp h\u1ECD v\u00E0 t\u00EAn", 1, "form-control", 3, "ngModel", "value", "ngModelChange"], ["type", "text", "name", "phone", "placeholder", "Nh\u1EADp s\u1ED1 \u0111i\u1EC7n tho\u1EA1i", 1, "form-control", 3, "ngModel", "value", "ngModelChange"], ["type", "text", "name", "email", "placeholder", "Nh\u1EADp th\u01B0 \u0111i\u1EC7n t\u1EED", 1, "form-control", 3, "ngModel", "value", "ngModelChange"], [1, "field-group", "multi-select"], ["appendTo", "body", "optionValue", "value", "optionLabel", "label", 3, "options", "ngModel", "ngModelChange", "onChange"], ["appendTo", "body", "optionValue", "code", "optionLabel", "label", 3, "options", "ngModel", "ngModelChange"], [1, "field-group", "multi-select", 3, "ngClass"], ["pTemplate", "footer"], ["header", "Nh\u1EADp t\u00EAn nh\u00E2n vi\u00EAn t\u00ECm ki\u1EBFm"], [1, "field-group", "select", "label-8"], ["appendTo", "body", "name", "orgId", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], ["name", "valueSearchUser", "placeholder", "", "field", "label", 3, "ngModel", "suggestions", "ngModelChange", "onSelect", "completeMethod"], ["header", "Th\u00F4ng tin t\u00E0i kho\u1EA3n"], [1, "grid-default", "border"], [3, "listsData", "height", "columnDefs", 4, "ngIf"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "visible", "modal", "visibleChange"], [1, "form-horizontal", "change-password"], ["editSMSF", "ngForm"], [1, "box-body", 2, "padding", "10px"], [1, "form-row", "row", 2, "margin", "10px 0px"], [1, "col-sm-4", "control-label"], [1, "col-sm-8"], [1, "input-group"], ["name", "userPassword", "autocomplete", "off", "required", "", "value", "", "placeholder", "Nh\u1EADp m\u1EADt kh\u1EA9u", 1, "form-control", 3, "type", "ngModel", "change", "ngModelChange"], ["userPassword", "ngModel"], [3, "click"], ["name", "userPassCf", "autocomplete", "off", "required", "", "id", "userPassCf", "placeholder", "Nh\u1EADp l\u1EA1i m\u1EADt kh\u1EA9u", 1, "form-control", 3, "type", "ngModel", "change", "ngModelChange"], ["userPassCf", "ngModel"], [1, "form-row", 2, "margin", "10px 0px"], [1, "col-md-12", "text-right"], ["label", "L\u01B0u l\u1EA1i", "styleClass", "mr-1", 3, "click"], ["label", "H\u1EE7y", "styleClass", "p-button-secondary", 3, "click"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [3, "listsData", "height", "columnDefs", "gridReady"], [1, "alert-validation", "alert-danger"], [1, "col-md-12", "mt-1", "text-right"], ["label", "L\u01B0u l\u1EA1i", "icon", "pi pi-check", "styleClass", "p-button-sm", 3, "click"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"], [3, "listsData", "height", "columnDefs"], ["label", "\u0110\u00F3ng", "styleClass", "p-button-secondary", 3, "click"], [3, "typeConfig", "gridKey"], [4, "ngIf"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"]], template: function PqQuyenNguoiDungComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("keydown.enter", function PqQuyenNguoiDungComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function PqQuyenNguoiDungComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_Template_p_button_click_15_listener() { return ctx.goToSettingRole(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](16, " C\u00E0i \u0111\u1EB7t quy\u1EC1n ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](17, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_Template_p_button_click_17_listener() { return ctx.themmoi2(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](18, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](19, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](20, " \u00A0 Th\u00EAm m\u1EDBi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](21, "p-button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_Template_p_button_click_21_listener() { return ctx.exportData(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](22, "p-button", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_Template_p_button_click_22_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](23, "svg", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](24, "path", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](25, " \u00A0 C\u1EA5u h\u00ECnh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](26, "section", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](27, "div", 23, 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](29, PqQuyenNguoiDungComponent_app_list_grid_angular_29_Template, 1, 3, "app-list-grid-angular", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](30, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](31, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](33, "p-paginator", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("onPageChange", function PqQuyenNguoiDungComponent_Template_p_paginator_onPageChange_33_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](34, "p-dialog", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function PqQuyenNguoiDungComponent_Template_p_dialog_visibleChange_34_listener($event) { return ctx.displayAdd = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](35, "p-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](36);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](37, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](38, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](39, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](40, "T\u00EAn \u0111\u0103ng nh\u1EADp ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](41, "span", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](42, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](43, "input", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqQuyenNguoiDungComponent_Template_input_ngModelChange_43_listener($event) { return ctx.addUserQuery.loginName = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](44, PqQuyenNguoiDungComponent_div_44_Template, 2, 0, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](45, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](46, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](47, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](48, "M\u1EADt kh\u1EA9u ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](49, "span", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](50, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](51, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqQuyenNguoiDungComponent_Template_input_ngModelChange_51_listener($event) { return ctx.addUserQuery.password = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](52, PqQuyenNguoiDungComponent_div_52_Template, 2, 0, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](53, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](54, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](55, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](56, "H\u1ECD v\u00E0 t\u00EAn ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](57, "span", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](58, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](59, "input", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqQuyenNguoiDungComponent_Template_input_ngModelChange_59_listener($event) { return ctx.addUserQuery.fullName = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](60, PqQuyenNguoiDungComponent_div_60_Template, 2, 0, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](61, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](62, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](63, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](64, "S\u1ED1 \u0111i\u1EC7n tho\u1EA1i ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](65, "span", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](66, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](67, "input", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqQuyenNguoiDungComponent_Template_input_ngModelChange_67_listener($event) { return ctx.addUserQuery.phone = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](68, PqQuyenNguoiDungComponent_div_68_Template, 2, 0, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](69, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](70, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](71, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](72, "Th\u01B0 \u0111i\u1EC7n t\u1EED ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](73, "span", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](74, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](75, "input", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqQuyenNguoiDungComponent_Template_input_ngModelChange_75_listener($event) { return ctx.addUserQuery.email = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](76, PqQuyenNguoiDungComponent_div_76_Template, 2, 0, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](77, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](78, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](79, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](80, "T\u1ED5 ch\u1EE9c ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](81, "span", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](82, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](83, "p-multiSelect", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqQuyenNguoiDungComponent_Template_p_multiSelect_ngModelChange_83_listener($event) { return ctx.addUserQuery.ord_ids = $event; })("onChange", function PqQuyenNguoiDungComponent_Template_p_multiSelect_onChange_83_listener($event) { return ctx.onChangeOrgan($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](84, PqQuyenNguoiDungComponent_div_84_Template, 2, 0, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](85, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](86, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](87, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](88, "C\u00F4ng ty tr\u1EA3 l\u01B0\u01A1ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](89, "p-multiSelect", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqQuyenNguoiDungComponent_Template_p_multiSelect_ngModelChange_89_listener($event) { return ctx.addUserQuery.companyIds = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](90, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](91, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](92, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](93, "Ph\u00E2n nh\u00F3m quy\u1EC1n ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](94, "span", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](95, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](96, "p-multiSelect", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqQuyenNguoiDungComponent_Template_p_multiSelect_ngModelChange_96_listener($event) { return ctx.addUserQuery.roles = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](97, PqQuyenNguoiDungComponent_div_97_Template, 2, 0, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](98, PqQuyenNguoiDungComponent_ng_template_98_Template, 2, 0, "ng-template", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](99, "p-dialog", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function PqQuyenNguoiDungComponent_Template_p_dialog_visibleChange_99_listener($event) { return ctx.seachManager = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](100, "p-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](101, " T\u00ECm ki\u1EBFm T\u00E0i kho\u1EA3n ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](102, "p-panel", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](103, "div", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](104, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](105, "Ch\u1ECDn t\u1ED5 ch\u1EE9c");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](106, "p-dropdown", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqQuyenNguoiDungComponent_Template_p_dropdown_ngModelChange_106_listener($event) { return ctx.orgId = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](107, PqQuyenNguoiDungComponent_ng_template_107_Template, 2, 1, "ng-template", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](108, PqQuyenNguoiDungComponent_ng_template_108_Template, 3, 1, "ng-template", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](109, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](110, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](111, "T\u00ECm ki\u1EBFm t\u00EAn nh\u00E2n vi\u00EAn");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](112, "p-autoComplete", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqQuyenNguoiDungComponent_Template_p_autoComplete_ngModelChange_112_listener($event) { return ctx.valueSearchUser = $event; })("onSelect", function PqQuyenNguoiDungComponent_Template_p_autoComplete_onSelect_112_listener($event) { return ctx.onSelectUser($event); })("completeMethod", function PqQuyenNguoiDungComponent_Template_p_autoComplete_completeMethod_112_listener($event) { return ctx.getListUserMaster($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](113, "p-panel", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](114, "div", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](115, PqQuyenNguoiDungComponent_app_list_grid_angular_115_Template, 1, 3, "app-list-grid-angular", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](116, PqQuyenNguoiDungComponent_ng_template_116_Template, 1, 0, "ng-template", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](117, "p-dialog", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function PqQuyenNguoiDungComponent_Template_p_dialog_visibleChange_117_listener($event) { return ctx.displaySetting = $event; })("onHide", function PqQuyenNguoiDungComponent_Template_p_dialog_onHide_117_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](118, PqQuyenNguoiDungComponent_app_config_grid_table_form_118_Template, 1, 2, "app-config-grid-table-form", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](119, "p-dialog", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function PqQuyenNguoiDungComponent_Template_p_dialog_visibleChange_119_listener($event) { return ctx.isShowChangePassword = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](120, "p-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](121);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](122, "form", 57, 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](124, "div", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](125, "div", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](126, "label", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](127, "M\u1EADt kh\u1EA9u ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](128, "span", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](129, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](130, "div", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](131, "div", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](132, "input", 64, 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("change", function PqQuyenNguoiDungComponent_Template_input_change_132_listener() { return ctx.checkPasswordcf(); })("ngModelChange", function PqQuyenNguoiDungComponent_Template_input_ngModelChange_132_listener($event) { return ctx.modelPass.userPassword = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](134, "span", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_Template_span_click_134_listener() { return ctx.isShowPass = !ctx.isShowPass; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](135, PqQuyenNguoiDungComponent_div_135_Template, 2, 1, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](136, "div", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](137, "label", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](138, "Nh\u1EADp l\u1EA1i m\u1EADt kh\u1EA9u ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](139, "span", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](140, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](141, "div", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](142, "div", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](143, "input", 67, 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("change", function PqQuyenNguoiDungComponent_Template_input_change_143_listener() { return ctx.checkPasswordcf(); })("ngModelChange", function PqQuyenNguoiDungComponent_Template_input_ngModelChange_143_listener($event) { return ctx.modelPass.userPassCf = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](145, "span", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_Template_span_click_145_listener() { return ctx.isShowRepass = !ctx.isShowRepass; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](146, PqQuyenNguoiDungComponent_div_146_Template, 2, 1, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](147, "div", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](148, "div", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](149, "p-button", 71);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_Template_p_button_click_149_listener() { return ctx.saveChangePass(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](150, "p-button", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqQuyenNguoiDungComponent_Template_p_button_click_150_listener() { return ctx.isShowChangePassword = !ctx.isShowChangePassword; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](151, "p-overlayPanel", 73, 74);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](153, PqQuyenNguoiDungComponent_ng_template_153_Template, 11, 0, "ng-template", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](88, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](87, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](90, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.displayAdd)("autoZIndex", true)("modal", true)("draggable", false)("resizable", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", ctx.titleForm, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("readonly", ctx.isEditUser)("ngModel", ctx.addUserQuery.loginName);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", !ctx.addUserQuery.loginName && ctx.saveAddUser);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("readonly", ctx.isEditUser)("ngModel", ctx.addUserQuery.password)("value", ctx.addUserQuery == null ? null : ctx.addUserQuery.password);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", !ctx.addUserQuery.password && ctx.saveAddUser && !ctx.isEditUser);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.addUserQuery.fullName)("value", ctx.addUserQuery == null ? null : ctx.addUserQuery.fullName);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", !ctx.addUserQuery.fullName && ctx.saveAddUser);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.addUserQuery.phone)("value", ctx.addUserQuery == null ? null : ctx.addUserQuery.phone);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", !ctx.addUserQuery.phone && ctx.saveAddUser);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.addUserQuery.email)("value", ctx.addUserQuery == null ? null : ctx.addUserQuery.email);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", !ctx.addUserQuery.email && ctx.saveAddUser);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("options", ctx.detailOrganizes)("ngModel", ctx.addUserQuery.ord_ids);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.addUserQuery.ord_ids && ctx.addUserQuery.ord_ids.length <= 0 && ctx.saveAddUser);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("options", ctx.companies)("ngModel", ctx.addUserQuery.companyIds);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", ctx.addUserQuery.roles ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("options", ctx.roles)("ngModel", ctx.addUserQuery.roles);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.addUserQuery.roles && ctx.addUserQuery.roles.length <= 0 && ctx.saveAddUser);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](91, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.seachManager)("autoZIndex", true)("modal", true)("draggable", false)("resizable", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.organizes)("ngModel", ctx.orgId)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.valueSearchUser)("suggestions", ctx.listUser);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.columnDefs1.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](92, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](93, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.isShowChangePassword)("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" C\u1EADp nh\u1EADt m\u1EADt kh\u1EA9u t\u00E0i kho\u1EA3n [", ctx.modelPass.userLogin, "] ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpropertyInterpolate"]("type", ctx.isShowPass ? "text" : "password");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.modelPass.userPassword);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵclassMapInterpolate1"]("pi pi-eye-pass ", ctx.isShowPass ? "pi-eye-slash" : "pi-eye", " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.submitPass && !ctx.modelPass.userPassword);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpropertyInterpolate"]("type", ctx.isShowRepass ? "text" : "password");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.modelPass.userPassCf);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵclassMapInterpolate1"]("pi pi-eye-pass ", ctx.isShowRepass ? "pi-eye-slash" : "pi-eye", "");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.submitPass && (ctx.confimPassword || !ctx.modelPass.userPassCf));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](94, _c5));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_12__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_21__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_22__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_23__.Dialog, primeng_api__WEBPACK_IMPORTED_MODULE_17__.Header, primeng_multiselect__WEBPACK_IMPORTED_MODULE_24__.MultiSelect, primeng_api__WEBPACK_IMPORTED_MODULE_17__.PrimeTemplate, primeng_panel__WEBPACK_IMPORTED_MODULE_25__.Panel, primeng_dropdown__WEBPACK_IMPORTED_MODULE_26__.Dropdown, primeng_autocomplete__WEBPACK_IMPORTED_MODULE_27__.AutoComplete, _angular_forms__WEBPACK_IMPORTED_MODULE_20__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgForm, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.RequiredValidator, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_28__.OverlayPanel, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_13__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_14__.ConfigGridTableFormComponent], styles: ["input[_ngcontent-%COMP%]:read-only {\n  background: #ebebeb !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBxLXF1eWVuLW5ndW9pLWR1bmcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSw4QkFBQTtBQUNKIiwiZmlsZSI6InBxLXF1eWVuLW5ndW9pLWR1bmcuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpbnB1dDpyZWFkLW9ubHkge1xyXG4gICAgYmFja2dyb3VuZDogI2ViZWJlYiAhaW1wb3J0YW50O1xyXG59Il19 */"] });


/***/ }),

/***/ 44731:
/*!*******************************************************************!*\
  !*** ./src/app/components/pq-thang-may/pq-thang-may.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PqThangMayComponent": () => (/* binding */ PqThangMayComponent)
/* harmony export */ });
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_models_cardinfo_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/cardinfo.model */ 97449);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/autocomplete */ 17611);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_card__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/card */ 33506);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);




















function PqThangMayComponent_app_list_grid_angular_80_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "app-list-grid-angular", 70);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("listsData", ctx_r2.rowData)("height", 500)("domLayout", "autoHeight")("columnDefs", ctx_r2.columnDefs);
} }
function PqThangMayComponent_option_91_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", advert_r21.projectCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", advert_r21.projectName, " ");
} }
function PqThangMayComponent_option_100_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const objBuilding_r23 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", objBuilding_r23.buildCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", objBuilding_r23.buildName, " ");
} }
function PqThangMayComponent_option_109_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r24 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", advert_r24.buildZoneName);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", advert_r24.buildZoneName, " ");
} }
function PqThangMayComponent_option_118_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r26 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", advert_r26.floorNumber);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", advert_r26.floorName, " ");
} }
function PqThangMayComponent_option_127_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r28 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", advert_r28.hardwareId);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", advert_r28.hardwareId, " ");
} }
function PqThangMayComponent_app_list_grid_angular_139_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "app-list-grid-angular", 70);
} if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("listsData", ctx_r14.rowData1)("height", 500)("domLayout", "autoHeight")("columnDefs", ctx_r14.columnDefs1);
} }
function PqThangMayComponent_div_152_option_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const objcardRole_r31 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", objcardRole_r31.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", objcardRole_r31.roleName, " ");
} }
function PqThangMayComponent_div_152_Template(rf, ctx) { if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "label", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, "Quy\u1EC1n c\u1EE7a th\u1EBB");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "select", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function PqThangMayComponent_div_152_Template_select_ngModelChange_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r33); const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r32.cardinfo.cardRole = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, PqThangMayComponent_div_152_option_4_Template, 2, 2, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx_r16.cardinfo.cardRole);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r16.modelCR);
} }
function PqThangMayComponent_div_153_option_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const objCardType_r35 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", objCardType_r35.cardTypeId);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", objCardType_r35.cardTypeName, " ");
} }
function PqThangMayComponent_div_153_Template(rf, ctx) { if (rf & 1) {
    const _r37 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "label", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, "Lo\u1EA1i th\u1EBB");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "select", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function PqThangMayComponent_div_153_Template_select_ngModelChange_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r37); const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r36.cardinfo.cardType = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, PqThangMayComponent_div_153_option_4_Template, 2, 2, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx_r17.cardinfo.cardType);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r17.modelCardType);
} }
function PqThangMayComponent_div_154_option_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const objProject_r39 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", objProject_r39.projectCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", objProject_r39.projectName, " ");
} }
function PqThangMayComponent_div_154_Template(rf, ctx) { if (rf & 1) {
    const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "label", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, "D\u1EF1 \u00E1n");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "select", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function PqThangMayComponent_div_154_Template_select_ngModelChange_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r41); const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r40.cardinfo.projectCd = $event; })("change", function PqThangMayComponent_div_154_Template_select_change_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r41); const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r42.loadGetBuildings(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, PqThangMayComponent_div_154_option_4_Template, 2, 2, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx_r18.cardinfo.projectCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r18.modelProject);
} }
function PqThangMayComponent_div_155_option_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const objBuilding_r44 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", objBuilding_r44.buildCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", objBuilding_r44.buildName, " ");
} }
function PqThangMayComponent_div_155_Template(rf, ctx) { if (rf & 1) {
    const _r46 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "label", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, "T\u00F2a nh\u00E0");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "select", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function PqThangMayComponent_div_155_Template_select_ngModelChange_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r46); const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r45.cardinfo.buildCd = $event; })("change", function PqThangMayComponent_div_155_Template_select_change_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r46); const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r47.loadGetFloors(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "option", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](5, "---");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](6, PqThangMayComponent_div_155_option_6_Template, 2, 2, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx_r19.cardinfo.buildCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r19.modelBuilding);
} }
function PqThangMayComponent_option_162_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const objFloor_r48 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", objFloor_r48.floorNumber);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", objFloor_r48.floorName, " ");
} }
const _c0 = function () { return { width: "800px", height: "auto" }; };
const queryString = __webpack_require__(/*! query-string */ 31808);
class PqThangMayComponent {
    constructor(apiService, messageService, router) {
        this.apiService = apiService;
        this.messageService = messageService;
        this.router = router;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_0__.AllModules;
        this.items = [];
        this.rowData = [];
        this.totalRecord = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.modelCR = [];
        this.builds = [];
        this.modelCardType = [];
        this.modelProject = [];
        this.modelBuilding = [];
        this.modelFloor = [];
        this.listCars = [];
        this.floors = [];
        this.devices = [];
        this.modelElevator = {
            cardCode: '',
            projectCd: '',
            buildZone: '',
            buildCd: '',
            floorNumber: null,
            hardwareId: null,
        };
        this.loading = false;
        this.menuItem = [];
        this.itemsBreadcrumb = [];
        this.isDialog = false;
        this.projects = [];
        this.buildingZones = [];
        this.rowData1 = [];
        this.searchInfo = new src_app_models_cardinfo_model__WEBPACK_IMPORTED_MODULE_1__.SearchInfo('', '', '');
        this.cardinfo = new src_app_models_cardinfo_model__WEBPACK_IMPORTED_MODULE_1__.CardInfo(0, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', null, null, '');
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.itemsBreadcrumb = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Phân quyền' },
            { label: 'Phân quyền thang máy' },
        ];
        this.menuItem = [
            {
                label: 'Thiết bị thang máy',
                icon: 'pi pi-refresh',
                command: () => {
                    this.thietbithangmay();
                }
            },
            {
                label: 'Tầng thang máy',
                icon: 'pi pi-refresh',
                command: () => {
                    this.tangthangmay();
                }
            },
        ];
        this.cardinfo.filter = '';
        // this.pagingComponent.pageSize = 10;
        this.loadElevatorCardRole();
        this.loadCardType();
        this.getProjectCd();
        this.loadGetProjects();
        this.init();
        this.init1();
    }
    thietbithangmay() {
        this.router.navigate(['/phan-quyen/thiet-bi-thang-may']);
    }
    tangthangmay() {
        this.router.navigate(['/phan-quyen/thiet-lap-tang-thang-may']);
    }
    getCardCustomers(event) {
        const queryParams = queryString.stringify({ cardCd: event.query });
        this.apiService.getCardCustomers(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe((result) => {
            this.listCars = result.data.map(data => {
                return Object.assign(Object.assign({}, data), { fullNameAndCar: `${data.fullName}---${data.phoneNumber}---(${data.cardCd})` });
            });
        });
    }
    find() {
        this.apiService.getCardInfo(this.searchInfo.cardCode, this.searchInfo.phoneNumber, this.searchInfo.hardwareId).subscribe((res) => {
            if (res) {
                this.cardinfo = res.data;
            }
        }, error => {
        });
    }
    getBuidingsSearch() {
        this.apiService.getBuildCdByProjectCd(this.modelElevator.projectCd).subscribe((res) => {
            if (res) {
                this.builds = res.data;
                this.buildingZones = [];
                this.floors = [];
                this.devices = [];
                this.modelElevator.buildZone = '';
                this.modelElevator.buildCd = '';
                this.modelElevator.floorNumber = null;
                this.modelElevator.hardwareId = null;
            }
        });
    }
    load() {
        if (this.detailcar.cardCd) {
            this.loading = true;
            this.apiService.getMasElevatorCards(this.detailcar.cardCd, 0, 100000).subscribe((results) => {
                this.rowData = results.data;
                // this.gridApi.setRowData(this.items);
                this.loading = false;
            }, error => {
                this.loading = false;
            });
        }
    }
    getFloors(event) {
        this.apiService.GetBuildFloorByProjectCdBuildCd(event.target.value, this.modelElevator.projectCd, this.modelElevator.buildCd).subscribe((results) => {
            this.floors = results.data;
            this.devices = [];
            this.modelElevator.floorNumber = null;
            this.modelElevator.hardwareId = null;
        }, error => { });
    }
    getHardware() {
        this.apiService.getElevatorDevicePage('', null, null, this.modelElevator.projectCd, this.modelElevator.buildZone, this.modelElevator.buildCd, this.modelElevator.floorNumber).subscribe((results) => {
            this.devices = results.data;
            this.modelElevator.hardwareId = null;
        }, error => { });
    }
    load1() {
        this.loading = true;
        if (this.detailcar.cardCd) {
            this.apiService.getFoorInfoGo(this.detailcar.cardCd, this.modelElevator.projectCd, this.modelElevator.buildZone, this.modelElevator.buildCd, this.modelElevator.hardwareId, null, null).subscribe((results) => {
                this.rowData1 = results.data;
                // this.autoSizeAll1()
                this.loading = false;
            }, error => {
                this.loading = false;
            });
        }
    }
    autoSizeAll() {
        var allColumnIds = [];
        this.gridColumnApi.getAllColumns().forEach(function (column) {
            allColumnIds.push(column.colId);
        });
        this.gridColumnApi.autoSizeColumns(allColumnIds);
    }
    autoSizeAll1() {
        var allColumnIds = [];
        this.gridColumnApi1.getAllColumns().forEach(function (column) {
            allColumnIds.push(column.colId);
        });
        this.gridColumnApi1.autoSizeColumns(allColumnIds);
    }
    AddNew() {
        this.cancelForm();
        this.modelcar = this.detailcar;
        this.cardinfo.fullName = this.detailcar.fullName;
        this.titleModal = 'Thêm gán quyền cho thẻ';
        this.cardinfo.id = 0;
        this.loadCardType();
        this.isDialog = true;
        // jQuery('#createCardRole').modal('show');
    }
    SaveRoleCard(type) {
        this.cardinfo.cardId = this.modelcar.cardId;
        this.apiService.addRoleCard(this.cardinfo).subscribe((results) => {
            if (results.status === 'error') {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Có lỗi!' });
            }
            else {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Thêm mới thành công' });
                this.load();
            }
        }, error => { });
        if (type === 1) {
            // jQuery('#createCardRole').modal('hide');
            this.isDialog = false;
        }
        else {
            this.cancelForm();
        }
    }
    cancel() {
        this.key_car = '';
        this.detailcar = null;
        this.rowData = [];
    }
    cancelTestdevices() {
        this.modelElevator = {
            cardCode: '',
            projectCd: '',
            buildZone: '',
            buildCd: '',
            floorNumber: null,
            hardwareId: null,
        };
        this.rowData1 = [];
    }
    loadElevatorCardRole() {
        this.apiService.getElevatorCardRole().subscribe((res) => {
            if (res) {
                this.modelCR = res.data;
                this.cardinfo.cardRole = this.modelCR[0]['cardRole'];
            }
        });
    }
    loadCardType() {
        this.apiService.getCardTypeList().subscribe((res) => {
            if (res) {
                this.modelCardType = res.data;
                this.cardinfo.cardType = this.modelCardType[0]['cardTypeId'];
            }
        });
    }
    loadGetProjects() {
        this.apiService.getProjects().subscribe((res) => {
            if (res) {
                this.modelProject = res.data;
            }
        });
    }
    loadGetBuildings() {
        this.apiService.getBuildCdByProjectCd(this.cardinfo.projectCd).subscribe((res) => {
            if (res) {
                this.modelBuilding = res.data;
                //  this.cardinfo.buildCd = res.data && res.data.length > 0 ? res.data[0].buildCd : '';
                this.loadGetFloors();
            }
        });
    }
    loadGetFloors() {
        this.modelFloor = [];
        this.apiService.getElevatorFloors(this.cardinfo.buildCd).subscribe((res) => {
            if (res) {
                this.modelFloor = res.data;
                // this.cardinfo.floorNumber = res.data && res.data.length > 0 ? res.data[0].floorNumber : '';
            }
        });
    }
    cancelForm() {
        this.cardinfo = new src_app_models_cardinfo_model__WEBPACK_IMPORTED_MODULE_1__.CardInfo(0, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', null, null, '');
    }
    open(content) {
        this.cancelForm();
        // jQuery('#createCardRole').modal('show');
        this.isDialog = true;
        this.titleModal = 'Sửa gán quyền cho thẻ';
        this.modelcar = this.detailcar;
        this.cardinfo = content;
        this.loadGetBuildings();
        this.loadGetFloors();
    }
    onDeleteRoleCard(id) {
        if (confirm('Bạn có chắc chắn muốn xóa quyền của thẻ này không?')) {
            this.apiService.deleteRoleCard(id).subscribe(results => {
                this.load();
            }, error => {
            });
        }
    }
    onFirstDataRendered(params) {
        params.api.sizeColumnsToFit();
    }
    onFirstDataRendered1(params) {
        params.api.sizeColumnsToFit();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    onGridReady1(params) {
        this.gridApi1 = params.api;
        this.gridColumnApi1 = params.columnApi;
    }
    getProjectCd() {
        this.apiService.getProjects().subscribe((results) => {
            this.projects = results.data;
        });
    }
    getBuildingZones(e) {
        this.apiService.getBuildZoneByBuildCd(this.modelElevator.projectCd, this.modelElevator.buildCd).subscribe((results) => {
            this.buildingZones = results.data;
            this.floors = [];
            this.devices = [];
            this.modelElevator.buildZone = '';
            this.modelElevator.floorNumber = null;
            this.modelElevator.hardwareId = null;
        });
    }
    init() {
        this.frameworkComponents = {
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__.ButtonAgGridComponent,
        };
        this.columnDefs = [
            {
                headerName: 'Mã thẻ',
                field: 'cardNumber',
                resizable: true,
            },
            {
                headerName: 'Quyền',
                field: 'roleName',
            },
            {
                headerName: 'Loại thẻ',
                field: 'cardTypeName',
                resizable: true,
            },
            {
                headerName: 'Dự án',
                field: 'projectName',
                resizable: true,
            },
            {
                headerName: 'Tòa nhà',
                field: 'buildName',
                resizable: true,
            },
            {
                headerName: 'Tầng',
                field: 'floorName',
            },
            {
                headerName: 'Thao tác',
                field: 'button',
                filter: '',
                width: 100,
                cellRenderer: 'buttonAgGridComponent',
                cellRendererParams: {
                    buttons: [
                        {
                            onClick: this.onBtnClick1.bind(this),
                            label: 'Sửa',
                            icon: 'fa-edit',
                            class: 'btn-primary',
                        },
                        {
                            onClick: this.onBtnClick2.bind(this),
                            label: 'Xóa',
                            icon: 'fa-remove',
                            class: 'btn-danger',
                        },
                    ]
                },
            },
        ];
        this.defaultColDef = {
            resizable: true,
            filter: 'agTextColumnFilter',
            sortable: true,
            cellClass: ['border-right']
        };
        this.getRowHeight = (params) => {
            return 40;
        };
    }
    init1() {
        this.columnDefs1 = [
            {
                headerName: 'ID',
                field: 'hardWareId',
                resizable: true,
            },
            {
                headerName: 'Tầng',
                field: 'floorName',
            },
            {
                headerName: 'Loại tầng',
                field: 'floorType',
                resizable: true,
            }
        ];
        this.defaultColDef1 = {
            resizable: true,
            filter: 'agTextColumnFilter',
            sortable: true,
            cellClass: ['border-right']
        };
        this.getRowHeight1 = (params) => {
            return 40;
        };
    }
    onBtnClick1(e) {
        this.open(e.rowData);
    }
    onBtnClick2(e) {
        this.onDeleteRoleCard(e.rowData.id);
    }
    selectedItem(event) {
        this.cardinfo.fullName = event.item.fullName;
    }
    ;
    selectedItem1(event) {
        this.detailcar = event;
        this.load();
    }
    ;
}
PqThangMayComponent.ɵfac = function PqThangMayComponent_Factory(t) { return new (t || PqThangMayComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.Router)); };
PqThangMayComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: PqThangMayComponent, selectors: [["app-pq-thang-may"]], decls: 166, vars: 51, consts: [[1, "main-grid"], [1, "bread-crumb"], [3, "items"], [1, "bread-filter"], [1, "d-flex", "bottom", "gap-16"], [1, "col-item"], [1, "field-group", "text", "mb-0", 3, "ngClass"], ["placeholder", "Nh\u1EADp m\u00E3 th\u1EBB \u0111\u1EC3 t\u00ECm ki\u1EBFm", "name", "key_car", "field", "fullNameAndCar", 3, "ngModel", "suggestions", "ngModelChange", "onSelect", "completeMethod"], [1, "d-flex", "align-items-center", "gap-16"], ["label", "Qu\u1EA3n l\u00FD", "icon", "pi pi-cog", "styleClass", "p-button-sm h-56", 3, "click"], [3, "model", "appendTo", "popup"], ["menuButton", ""], ["header", "Th\u00F4ng tin chi ti\u1EBFt", "styleClass", "card-title-part"], [1, "row"], [1, "col-xl-4", "col-lg-6", "col-md-12"], ["for", ""], [1, "col-xl-2", "col-lg-6", "col-md-12"], [1, "checkbox-default", "d-flex", "mb-0"], ["id", "noi-bo", "name", "isNoiBo", "type", "checkbox", 1, "form-check-input", "mr-2", "ml-0", 3, "checked"], ["for", "noi-bo", 1, ""], ["id", "co-xe", "name", "isCalByMap", "type", "checkbox", "value", "", 1, "form-check-input", "mr-2", "ml-0", 3, "checked"], ["for", "co-xe", 1, ""], ["id", "the-khach", "name", "isTheKhach", "type", "checkbox", "value", "", 1, "form-check-input", "ml-0", "mr-2", 3, "checked"], ["for", "the-khach", 1, ""], [1, "mb-2"], [1, "col-xl-2", "col-lg-6", "col-md-12", "mb-2"], ["label", "Th\u00EAm m\u1EDBi", "styleClass", "p-button-sm", "icon", "pi pi-plus", 3, "disabled", "onClick"], [1, "grid-default", "border"], ["container", ""], [3, "listsData", "height", "domLayout", "columnDefs", 4, "ngIf"], ["header", "Ki\u1EC3m tra quy\u1EC1n"], [1, "row", 2, "margin-top", "10px"], [1, "col-xl-3", "col-lg-2", "col-md-3", "mb-1"], [1, "field-group", "select", "label-8", 3, "ngClass"], ["for", "status"], ["name", "projectCd", "id", "projectCd", 1, "form-control", 3, "ngModel", "change", "ngModelChange"], ["projectCd", "ngModel"], ["value", ""], [3, "value", 4, "ngFor", "ngForOf"], ["name", "buildCd", "id", "buildCd", 1, "form-control", 3, "ngModel", "change", "ngModelChange"], ["buildCd", "ngModel"], ["name", "buildZone", "id", "buildZone", 1, "form-control", 3, "ngModel", "change", "ngModelChange"], ["buildZone", "ngModel"], ["name", "floor", "id", "floor", 1, "form-control", 3, "ngModel", "change", "ngModelChange"], ["floor", "ngModel"], ["value", "null"], ["name", "hardwareId", "id", "hardwareId", 1, "form-control", 3, "ngModel", "change", "ngModelChange"], ["hardwareId", "ngModel"], [1, "col-xl-1", "col-lg-2", "col-md-12", "ssg-btn-search"], [2, "visibility", "hidden"], [1, "group-btns"], ["type", "button", 1, "btn", "btn-primary", "mr-2", "h-56", 3, "click"], ["_ngcontent-c4", "", 1, "fa", "fa-search"], ["type", "button", 1, "btn", "btn-default", "h-56", 3, "click"], ["_ngcontent-c4", "", 1, "fa", "fa-repeat"], [1, "content"], [3, "visible", "header", "autoZIndex", "visibleChange"], [1, "form-horizontal", "ng-pristine", "ng-valid", "ng-scope"], ["createSMSF", "ngForm"], [1, "box-body", 2, "padding", "10px"], [1, "form-row", "input-group", 2, "margin", "10px 0px"], [1, "control-label"], ["name", "modelcar", "placeholder", "Nh\u1EADp m\u00E3 th\u1EBB \u0111\u1EC3 t\u00ECm ki\u1EBFm", "field", "fullNameAndCar", 3, "ngModel", "suggestions", "ngModelChange", "onSelect", "completeMethod"], ["type", "text", "name", "fullNameCust", "id", "fullNameCust", "placeholder", "T\u00EAn ch\u1EE7 th\u1EBB", 1, "form-control", 3, "disabled", "ngModel", "ngModelChange"], ["class", "form-row field-group select", "style", "margin:10px 0px;", 4, "ngIf"], [1, "form-row", "field-group", "select", 2, "margin", "10px 0px"], ["name", "floorNumber", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "form-row", 2, "margin", "10px 0px"], ["styleClass", "p-button-sm mr-1", "icon", "pi pi-check", 3, "click"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", 3, "click"], [3, "listsData", "height", "domLayout", "columnDefs"], [3, "value"], ["name", "cardRole", 1, "form-control", 3, "ngModel", "ngModelChange"], ["name", "cardType", 1, "form-control", 3, "ngModel", "ngModelChange"], ["name", "projectCd", 1, "form-control", 3, "ngModel", "ngModelChange", "change"], ["name", "buildCd", 1, "form-control", 3, "ngModel", "ngModelChange", "change"]], template: function PqThangMayComponent_Template(rf, ctx) { if (rf & 1) {
        const _r49 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](2, "app-hrm-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "section", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "p-autoComplete", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function PqThangMayComponent_Template_p_autoComplete_ngModelChange_7_listener($event) { return ctx.key_car = $event; })("onSelect", function PqThangMayComponent_Template_p_autoComplete_onSelect_7_listener($event) { return ctx.selectedItem1($event); })("completeMethod", function PqThangMayComponent_Template_p_autoComplete_completeMethod_7_listener($event) { return ctx.getCardCustomers($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](8, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "p-button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function PqThangMayComponent_Template_p_button_click_10_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r49); const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵreference"](12); return _r0.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](11, "p-menu", 10, 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](13, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "p-card", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](15, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](16, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](17, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](18, "label", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](19, "M\u00E3 th\u1EBB: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](20, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](23, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](24, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](25, "label", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](26, "N\u1ED9i b\u1ED9 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](27, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](28, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](29, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](30, "label", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](31, "M\u00E3 k\u1EF9 thu\u1EADt: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](32, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](34, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](35, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](36, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](37, "label", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](38, "C\u00F3 xe ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](39, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](40, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](41, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](42, "label", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](43, "Lo\u1EA1i th\u1EBB: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](44, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](45);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](46, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](47, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](48, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](49, "label", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](50, "Th\u1EBB kh\u00E1ch ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](51, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](52, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](53, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](54, "label", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](55, "Ch\u1EE7 th\u1EBB: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](56, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](57);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](58, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](59, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](60, "label", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](61, "Ng\u00E0y c\u1EA5p: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](62, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](63);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](64, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](65, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](66, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](67, "label", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](68, "C\u0103n h\u1ED9: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](69, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](70);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](71, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](72, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](73, "label", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](74, "Tr\u1EA1ng th\u00E1i: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](75, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](76);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](77, "p-button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("onClick", function PqThangMayComponent_Template_p_button_onClick_77_listener() { return ctx.AddNew(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](78, "div", 27, 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](80, PqThangMayComponent_app_list_grid_angular_80_Template, 1, 4, "app-list-grid-angular", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](81, "p-card", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](82, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](83, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](84, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](85, "label", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](86, "D\u1EF1 \u00E1n");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](87, "select", 35, 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PqThangMayComponent_Template_select_change_87_listener() { ctx.getBuidingsSearch(); return ctx.load1(); })("ngModelChange", function PqThangMayComponent_Template_select_ngModelChange_87_listener($event) { return ctx.modelElevator.projectCd = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](89, "option", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](90, "Ch\u1ECDn d\u1EF1 \u00E1n");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](91, PqThangMayComponent_option_91_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](92, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](93, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](94, "label", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](95, "T\u00F2a");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](96, "select", 39, 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PqThangMayComponent_Template_select_change_96_listener($event) { ctx.getBuildingZones($event); return ctx.load1(); })("ngModelChange", function PqThangMayComponent_Template_select_ngModelChange_96_listener($event) { return ctx.modelElevator.buildCd = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](98, "option", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](99, "Ch\u1ECDn t\u00F2a");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](100, PqThangMayComponent_option_100_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](101, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](102, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](103, "label", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](104, "Khu v\u1EF1c");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](105, "select", 41, 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PqThangMayComponent_Template_select_change_105_listener($event) { ctx.getFloors($event); return ctx.load1(); })("ngModelChange", function PqThangMayComponent_Template_select_ngModelChange_105_listener($event) { return ctx.modelElevator.buildZone = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](107, "option", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](108, "Ch\u1ECDn khu v\u1EF1c");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](109, PqThangMayComponent_option_109_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](110, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](111, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](112, "label", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](113, "T\u1EA7ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](114, "select", 43, 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PqThangMayComponent_Template_select_change_114_listener() { ctx.getHardware(); return ctx.load1(); })("ngModelChange", function PqThangMayComponent_Template_select_ngModelChange_114_listener($event) { return ctx.modelElevator.floorNumber = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](116, "option", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](117, "---");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](118, PqThangMayComponent_option_118_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](119, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](120, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](121, "label", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](122, "Thi\u1EBFt b\u1ECB");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](123, "select", 46, 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PqThangMayComponent_Template_select_change_123_listener() { return ctx.load1(); })("ngModelChange", function PqThangMayComponent_Template_select_ngModelChange_123_listener($event) { return ctx.modelElevator.hardwareId = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](125, "option", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](126, "---");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](127, PqThangMayComponent_option_127_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](128, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](129, "label", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](130, "\u00A0");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](131, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](132, "button", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function PqThangMayComponent_Template_button_click_132_listener() { return ctx.load1(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](133, "i", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](134, "button", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function PqThangMayComponent_Template_button_click_134_listener() { return ctx.cancelTestdevices(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](135, "i", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](136, "section", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](137, "div", 27, 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](139, PqThangMayComponent_app_list_grid_angular_139_Template, 1, 4, "app-list-grid-angular", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](140, "p-dialog", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("visibleChange", function PqThangMayComponent_Template_p_dialog_visibleChange_140_listener($event) { return ctx.isDialog = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](141, "form", 57, 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](143, "div", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](144, "div", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](145, "label", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](146, "M\u00E3 th\u1EBB");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](147, "p-autoComplete", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function PqThangMayComponent_Template_p_autoComplete_ngModelChange_147_listener($event) { return ctx.modelcar = $event; })("onSelect", function PqThangMayComponent_Template_p_autoComplete_onSelect_147_listener($event) { return ctx.selectedItem($event); })("completeMethod", function PqThangMayComponent_Template_p_autoComplete_completeMethod_147_listener($event) { return ctx.getCardCustomers($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](148, "div", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](149, "label", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](150, "T\u00EAn ch\u1EE7 th\u1EBB");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](151, "input", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function PqThangMayComponent_Template_input_ngModelChange_151_listener($event) { return ctx.cardinfo.fullName = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](152, PqThangMayComponent_div_152_Template, 5, 2, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](153, PqThangMayComponent_div_153_Template, 5, 2, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](154, PqThangMayComponent_div_154_Template, 5, 2, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](155, PqThangMayComponent_div_155_Template, 7, 2, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](156, "div", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](157, "label", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](158, "T\u1EA7ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](159, "select", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function PqThangMayComponent_Template_select_ngModelChange_159_listener($event) { return ctx.cardinfo.floorNumber = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](160, "option", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](161, "---");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](162, PqThangMayComponent_option_162_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](163, "div", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](164, "p-button", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function PqThangMayComponent_Template_p_button_click_164_listener() { return ctx.SaveRoleCard(1); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](165, "p-button", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function PqThangMayComponent_Template_p_button_click_165_listener() { return ctx.cancelForm(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("items", ctx.itemsBreadcrumb);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", ctx.key_car ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.key_car)("suggestions", ctx.listCars);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("model", ctx.menuItem)("appendTo", "body")("popup", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.detailcar == null ? null : ctx.detailcar.cardCd);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.detailcar == null ? null : ctx.detailcar.isNoiBo);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.detailcar == null ? null : ctx.detailcar.cardNumber);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.detailcar == null ? null : ctx.detailcar.isVehicle);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.detailcar == null ? null : ctx.detailcar.cardTypeName);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.detailcar == null ? null : ctx.detailcar.isTheKhach);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.detailcar == null ? null : ctx.detailcar.fullName);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.detailcar == null ? null : ctx.detailcar.issueDate);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.detailcar == null ? null : ctx.detailcar.roomCode);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.detailcar == null ? null : ctx.detailcar.status);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", !ctx.detailcar);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", ctx.modelElevator.projectCd ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.modelElevator.projectCd);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.projects);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", ctx.modelElevator.buildCd ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.modelElevator.buildCd);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.builds);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", ctx.modelElevator.buildZone ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.modelElevator.buildZone);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.buildingZones);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", ctx.modelElevator.floorNumber ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.modelElevator.floorNumber);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.floors);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", ctx.modelElevator.hardwareId ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.modelElevator.hardwareId);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.devices);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.columnDefs1.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction0"](50, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("header", ctx.titleModal);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("visible", ctx.isDialog)("autoZIndex", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.modelcar)("suggestions", ctx.listCars);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", true)("ngModel", ctx.cardinfo.fullName);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.modelCR);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.modelCardType);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.modelProject);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.modelBuilding);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.cardinfo.floorNumber);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.modelFloor);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgClass, primeng_autocomplete__WEBPACK_IMPORTED_MODULE_12__.AutoComplete, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_14__.Button, primeng_menu__WEBPACK_IMPORTED_MODULE_15__.Menu, primeng_card__WEBPACK_IMPORTED_MODULE_16__.Card, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_13__["ɵNgSelectMultipleOption"], _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgForOf, primeng_dialog__WEBPACK_IMPORTED_MODULE_17__.Dialog, _angular_forms__WEBPACK_IMPORTED_MODULE_13__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgForm, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.DefaultValueAccessor, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_5__.ListGridAngularComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcS10aGFuZy1tYXkuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 36980:
/*!**********************************************************************************!*\
  !*** ./src/app/components/pq-the-nhan-vien/card-detail/card-detail.component.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CardDetailComponent": () => (/* binding */ CardDetailComponent)
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 41082);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 31607);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 72407);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 70980);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 28433);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/autocomplete */ 17611);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/calendar */ 6582);
















function CardDetailComponent_div_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " M\u00E3 th\u1EBB l\u00E0 b\u1EAFt bu\u1ED9c ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function CardDetailComponent_ng_template_19_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](item_r6 == null ? null : item_r6.label);
} }
function CardDetailComponent_ng_template_20_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](car_r7 == null ? null : car_r7.label);
} }
function CardDetailComponent_ng_template_26_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const employee_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](employee_r8 == null ? null : employee_r8.name);
} }
function CardDetailComponent_div_27_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Nh\u00E2n vi\u00EAn l\u00E0 b\u1EAFt bu\u1ED9c ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function CardDetailComponent_ng_container_48_div_21_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " T\u00EAn xe l\u00E0 b\u1EAFt bu\u1ED9c ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function CardDetailComponent_ng_container_48_div_27_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Bi\u1EC3n s\u1ED1 xe l\u00E0 b\u1EAFt bu\u1ED9c ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
const _c0 = function () { return { "width": "100%" }; };
function CardDetailComponent_ng_container_48_div_45_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2, "Ng\u00E0y h\u1EA1n");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](3, "p-calendar", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](2, _c0));
} }
function CardDetailComponent_ng_container_48_Template(rf, ctx) { if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0, 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4, "Lo\u1EA1i xe");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "select", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "option", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7, "\u00D4 t\u00F4");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "option", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](9, "Xe m\u00E1y");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "option", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](11, "Xe m\u00E1y \u0111i\u1EC7n");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "option", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](13, "Xe \u0111\u1EA1p \u0111i\u1EC7n");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "option", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](15, "Xe \u0111\u1EA1p");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](19, "T\u00EAn xe");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](20, "input", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](21, CardDetailComponent_ng_container_48_div_21_Template, 2, 0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](24, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](25, "Bi\u1EC3n s\u1ED1 xe");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](26, "input", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](27, CardDetailComponent_ng_container_48_div_27_Template, 2, 0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](28, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](29, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](30, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](31, "Ng\u00E0y b\u1EAFt \u0111\u1EA7u");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](32, "p-calendar", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](33, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](34, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](35, "Ng\u00E0y h\u1EBFt h\u1EA1n");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](36, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](37, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](38, "label", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](39, "V\u00F4 h\u1EA1n");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](40, "input", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("change", function CardDetailComponent_ng_container_48_Template_input_change_40_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r13); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r12.handleChange($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](41, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](42, "label", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](43, "C\u00F3 h\u1EA1n");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](44, "input", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("change", function CardDetailComponent_ng_container_48_Template_input_change_44_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r13); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r14.handleChange($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](45, CardDetailComponent_ng_container_48_div_45_Template, 4, 3, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    let tmp_11_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx_r5.vehicleForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngValue", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngValue", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngValue", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngValue", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngValue", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ((ctx_r5.vehicleForm == null ? null : ctx_r5.vehicleForm.controls == null ? null : ctx_r5.vehicleForm.controls.vehicleName == null ? null : ctx_r5.vehicleForm.controls.vehicleName.touched) || ctx_r5.submitted) && (ctx_r5.vehicleForm == null ? null : ctx_r5.vehicleForm.controls == null ? null : ctx_r5.vehicleForm.controls.vehicleName == null ? null : ctx_r5.vehicleForm.controls.vehicleName.errors == null ? null : ctx_r5.vehicleForm.controls.vehicleName.errors.required));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ((ctx_r5.vehicleForm == null ? null : ctx_r5.vehicleForm.controls == null ? null : ctx_r5.vehicleForm.controls.vehicleNo == null ? null : ctx_r5.vehicleForm.controls.vehicleNo.touched) || ctx_r5.submitted) && (ctx_r5.vehicleForm == null ? null : ctx_r5.vehicleForm.controls == null ? null : ctx_r5.vehicleForm.controls.vehicleNo == null ? null : ctx_r5.vehicleForm.controls.vehicleNo.errors == null ? null : ctx_r5.vehicleForm.controls.vehicleNo.errors.required));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](13, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("value", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("value", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx_r5.vehicleForm == null ? null : (tmp_11_0 = ctx_r5.vehicleForm.get("endTimeType")) == null ? null : tmp_11_0.value);
} }
class CardDetailComponent {
    constructor(apiService, messageService) {
        this.apiService = apiService;
        this.messageService = messageService;
        this.save = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        this.submitted = false;
        this.organizes = [];
    }
    ngOnInit() {
        this.getOrganize();
        this.initForm();
    }
    initForm() {
        this.cardForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroup({
            employeeId: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(this.employeeId, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]),
            orgId: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]),
            cardName: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('Thẻ S-Service'),
            cardCd: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]),
            issueDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(''),
            expireDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(''),
            cardTypeId: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(0),
            isVip: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(true),
            isCardVehicle: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(false),
        });
        this.vehicleForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroup({
            cardVehicleId: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(0),
            vehicleTypeId: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(1),
            vehicleNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(''),
            vehicleName: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(''),
            serviceId: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(''),
            startTime: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(new Date()),
            endTime: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(new Date(2030, 1, 1)),
            endTimeType: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(false),
            status: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(''),
            custId: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(0)
        });
    }
    handleShowCardVehicle(event) {
        if (this.cardForm.value.isCardVehicle) {
            this.vehicleForm.controls['vehicleNo'].setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]);
            this.vehicleForm.controls['vehicleName'].setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]);
        }
        else {
            this.vehicleForm.controls['vehicleNo'].clearValidators();
            this.vehicleForm.controls['vehicleName'].clearValidators();
        }
    }
    search(event) {
        if (this.cardForm.value.orgId === null) {
            this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Chọn tổ chức' });
            return;
        }
        this.apiService.getEmployeeSearch(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: event.query, orgId: this.cardForm.value.orgId }))
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.debounceTime)(500), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.switchMap)(t => (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(t)))
            .subscribe((res) => {
            this.results = res.data.map(item => ({
                name: item.fullName + '-' + item.phone || item.employeeName + '-' + item.phone, code: item.code, empId: item.empId, custId: item.custId, phone: item.phone, email: item.email, departmentName: item.departmentName
            }));
        });
    }
    handleSave() {
        this.submitted = true;
        if (!this.cardForm.valid || !this.vehicleForm.valid) {
            return;
        }
        const cardFormValue = Object.assign({}, this.cardForm.value);
        const vehicleFormValue = Object.assign({}, this.vehicleForm.value);
        let custId = '';
        if (typeof cardFormValue.employeeId !== 'string') {
            custId = cardFormValue.employeeId.custId;
            cardFormValue.employeeId = cardFormValue.employeeId.empId;
        }
        if (cardFormValue.isCardVehicle) {
            this.apiService.setCardVip(cardFormValue.cardCd, cardFormValue.employeeId, cardFormValue.cardName)
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.concatMap)(response => {
                return this.apiService.setCardVehicle(vehicleFormValue.cardVehicleId, cardFormValue.cardCd, vehicleFormValue.vehicleTypeId, vehicleFormValue.vehicleNo, null, vehicleFormValue.vehicleName, this.dateToString(vehicleFormValue.startTime), this.dateToString(vehicleFormValue.endTime), null, custId);
            })).subscribe((response) => {
                if (response.status === 'success') {
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Thêm mới thẻ thành công' });
                    this.save.emit();
                }
                else {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: response.message });
                }
            }, error => {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Thêm mới thẻ thất bại' });
            });
        }
        else {
            this.apiService.setCardVip(cardFormValue.cardCd, cardFormValue.employeeId, cardFormValue.cardName)
                .subscribe((response) => {
                if (response.status === 'success') {
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Thêm mới thẻ thành công' });
                    this.save.emit();
                }
                else {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: response.message });
                }
            }, error => {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Thêm mới thẻ thất bại' });
            });
        }
    }
    dateToString(date) {
        let dd = date.getDate();
        let mm = date.getMonth() + 1; // January is 0!
        const yyyy = date.getFullYear();
        if (dd < 10) {
            dd = '0' + dd;
        }
        if (mm < 10) {
            mm = '0' + mm;
        }
        const datestring = dd + '/' + mm + '/' + yyyy;
        return datestring;
    }
    handleChange(event) {
        if (this.vehicleForm.value.endTimeType) {
        }
    }
    getOrganize() {
        this.apiService.getOrgRoots()
            .subscribe((results) => {
            this.organizes = results.data
                .map(d => {
                return {
                    label: d.org_name,
                    value: d.orgId
                };
            });
        }, error => { });
    }
}
CardDetailComponent.ɵfac = function CardDetailComponent_Factory(t) { return new (t || CardDetailComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService)); };
CardDetailComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: CardDetailComponent, selectors: [["app-card-detail"]], inputs: { employeeId: "employeeId" }, outputs: { save: "save" }, decls: 52, vars: 21, consts: [[1, "modal-body", "row"], [3, "formGroup"], [1, "col-sm-6", "form-group"], [1, "field-group", "text", "label-8"], ["type", "text", "name", "cardName", "formControlName", "cardName", "placeholder", "Lo\u1EA1i th\u1EBB", 1, "form-control", 3, "disabled"], ["type", "text", "name", "cardCd", "formControlName", "cardCd", "placeholder", "M\u00E3 th\u1EBB", 1, "form-control"], ["class", "text-danger", 4, "ngIf"], [1, "field-group", "select", "label-8"], ["for", ""], ["appendTo", "body", "formControlName", "orgId", 3, "baseZIndex", "autoDisplayFirst", "options", "filter"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], ["formControlName", "employeeId", "field", "name", 3, "suggestions", "inputStyle", "completeMethod"], ["placeholder", "S\u1ED1 \u0111i\u1EC7n tho\u1EA1i", "type", "text", "name", "phone", 1, "form-control", 3, "disabled", "value"], ["placeholder", "Th\u01B0 \u0111i\u1EC7n t\u1EED", "type", "text", "name", "email", 1, "form-control", 3, "disabled", "value"], [1, "field-group", "label-8", "text"], ["placeholder", "Ph\u00F2ng ban", "type", "text", "name", "departmentName", 1, "form-control", 3, "disabled", "value"], [1, "checkbox-default", "d-flex"], ["for", "isCardVehicle"], ["id", "isCardVehicle", "type", "checkbox", "name", "isCardVehicle", "formControlName", "isCardVehicle", "placeholder", "V\u00E9 g\u1EEDi xe", 3, "change"], [3, "formGroup", 4, "ngIf"], [1, "row"], [1, "col-md-12", "text-right"], ["label", "X\u00E1c nh\u1EADn", "styleClass", "p-button-sm", "icon", "pi pi-check", 3, "click"], [1, "text-danger"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"], [1, "country-item"], [1, "col-sm-6", "form-group", 2, "clear", "left"], ["name", "vehicleTypeId", "formControlName", "vehicleTypeId", 1, "form-control"], [3, "ngValue"], ["type", "text", "name", "vehicleName", "formControlName", "vehicleName", "placeholder", "T\u00EAn xe", 1, "form-control"], ["type", "text", "name", "vehicleNo", "formControlName", "vehicleNo", "placeholder", "Bi\u1EC3n s\u1ED1 xe", 1, "form-control"], [1, "field-group", "date", "label-8"], ["formControlName", "startTime", "name", "startTime", "dateFormat", "dd/mm/yy"], [1, "d-flex", "mt-2"], [1, "radio-default", "mr-3"], ["for", "vo-han"], ["id", "vo-han", "type", "radio", "name", "endTimeType", "formControlName", "endTimeType", 3, "value", "change"], [1, "radio-default"], ["for", "co-han"], ["id", "co-han", "type", "radio", "name", "endTimeType", "formControlName", "endTimeType", 3, "value", "change"], ["class", "field-group date mt-3 label-8", 4, "ngIf"], [1, "field-group", "date", "mt-3", "label-8"], ["formControlName", "endTime", "name", "endTime", "dateFormat", "dd/mm/yy"]], template: function CardDetailComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "form");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](2, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "Lo\u1EA1i th\u1EBB");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](7, "input", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](11, "M\u00E3 th\u1EBB");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](12, "input", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](13, CardDetailComponent_div_13_Template, 2, 0, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "label", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](17, "Ch\u1ECDn t\u1ED5 ch\u1EE9c");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "p-dropdown", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](19, CardDetailComponent_ng_template_19_Template, 2, 1, "ng-template", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](20, CardDetailComponent_ng_template_20_Template, 3, 1, "ng-template", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](21, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](24, "T\u00ECm ki\u1EBFm t\u00EAn nh\u00E2n vi\u00EAn");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](25, "p-autoComplete", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("completeMethod", function CardDetailComponent_Template_p_autoComplete_completeMethod_25_listener($event) { return ctx.search($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](26, CardDetailComponent_ng_template_26_Template, 3, 1, "ng-template", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](27, CardDetailComponent_div_27_Template, 2, 0, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](28, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](29, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](30, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](31, "S\u1ED1 \u0111i\u1EC7n tho\u1EA1i");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](32, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](33, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](34, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](35, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](36, "Th\u01B0 \u0111i\u1EC7n t\u1EED");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](37, "input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](38, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](39, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](40, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](41, "Ph\u00F2ng ban");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](42, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](43, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](44, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](45, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](46, "V\u00E9 g\u1EEDi xe");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](47, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("change", function CardDetailComponent_Template_input_change_47_listener($event) { return ctx.handleShowCardVehicle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](48, CardDetailComponent_ng_container_48_Template, 46, 14, "ng-container", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](49, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](50, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](51, "p-button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function CardDetailComponent_Template_p_button_click_51_listener() { return ctx.handleSave(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        let tmp_17_0;
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.cardForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ((ctx.cardForm == null ? null : ctx.cardForm.controls == null ? null : ctx.cardForm.controls.cardCd == null ? null : ctx.cardForm.controls.cardCd.touched) || ctx.submitted) && (ctx.cardForm == null ? null : ctx.cardForm.controls == null ? null : ctx.cardForm.controls.cardCd == null ? null : ctx.cardForm.controls.cardCd.errors == null ? null : ctx.cardForm.controls.cardCd.errors.required));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.organizes)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](19, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("suggestions", ctx.results)("inputStyle", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](20, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ((ctx.cardForm == null ? null : ctx.cardForm.controls == null ? null : ctx.cardForm.controls.employeeId == null ? null : ctx.cardForm.controls.employeeId.touched) || ctx.submitted) && (ctx.cardForm == null ? null : ctx.cardForm.controls == null ? null : ctx.cardForm.controls.employeeId == null ? null : ctx.cardForm.controls.employeeId.errors == null ? null : ctx.cardForm.controls.employeeId.errors.required));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", true)("value", ctx.cardForm.value == null ? null : ctx.cardForm.value.employeeId == null ? null : ctx.cardForm.value.employeeId.phone);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", true)("value", ctx.cardForm.value == null ? null : ctx.cardForm.value.employeeId == null ? null : ctx.cardForm.value.employeeId.email);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", true)("value", ctx.cardForm.value == null ? null : ctx.cardForm.value.employeeId == null ? null : ctx.cardForm.value.employeeId.departmentName);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.cardForm == null ? null : (tmp_17_0 = ctx.cardForm.get("isCardVehicle")) == null ? null : tmp_17_0.value);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgForm, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControlName, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, primeng_dropdown__WEBPACK_IMPORTED_MODULE_11__.Dropdown, primeng_api__WEBPACK_IMPORTED_MODULE_9__.PrimeTemplate, primeng_autocomplete__WEBPACK_IMPORTED_MODULE_12__.AutoComplete, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.CheckboxControlValueAccessor, primeng_button__WEBPACK_IMPORTED_MODULE_13__.Button, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgSelectMultipleOption"], primeng_calendar__WEBPACK_IMPORTED_MODULE_14__.Calendar, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.RadioControlValueAccessor], styles: [".bg-blue-color[_ngcontent-%COMP%] {\r\n    background: #1087dd;\r\n}\r\n\r\nform[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%] {\r\n    margin-bottom: 1rem !important;\r\n}\r\n\r\n.custom-select[_ngcontent-%COMP%] {\r\n    height: 2.5rem !important;\r\n}\r\n\r\n.text-danger[_ngcontent-%COMP%]{\r\n    color: red;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcmQtZGV0YWlsLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxtQkFBbUI7QUFDdkI7O0FBRUE7SUFDSSw4QkFBOEI7QUFDbEM7O0FBRUE7SUFDSSx5QkFBeUI7QUFDN0I7O0FBQ0E7SUFDSSxVQUFVO0FBQ2QiLCJmaWxlIjoiY2FyZC1kZXRhaWwuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5iZy1ibHVlLWNvbG9yIHtcclxuICAgIGJhY2tncm91bmQ6ICMxMDg3ZGQ7XHJcbn1cclxuXHJcbmZvcm0gLmZvcm0tZ3JvdXAge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMXJlbSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uY3VzdG9tLXNlbGVjdCB7XHJcbiAgICBoZWlnaHQ6IDIuNXJlbSAhaW1wb3J0YW50O1xyXG59XHJcbi50ZXh0LWRhbmdlcntcclxuICAgIGNvbG9yOiByZWQ7XHJcbn0iXX0= */"] });


/***/ }),

/***/ 63602:
/*!********************************************************************************************************!*\
  !*** ./src/app/components/pq-the-nhan-vien/chi-tiet-the-nhan-vien/chi-tiet-the-nhan-vien.component.ts ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietTheNhanVienComponent": () => (/* binding */ ChiTietTheNhanVienComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);













function ChiTietTheNhanVienComponent_app_edit_detail_4_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "app-edit-detail", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("callback", function ChiTietTheNhanVienComponent_app_edit_detail_4_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r1.SetEmployeeCardInfo($event); })("callbackcancel", function ChiTietTheNhanVienComponent_app_edit_detail_4_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r3.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
const queryString = __webpack_require__(/*! query-string */ 31808);
class ChiTietTheNhanVienComponent {
    constructor(activatedRoute, apiService, spinner, confirmationService, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: '', icon: 'pi pi-check' }
        ];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subject();
        this.modelEdit = {
            carCode: null,
        };
        this.titlePage = '';
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Phân quyền' },
            { label: 'Danh sách thẻ nhân viên', routerLink: '/phan-quyen/the-nhan-vien' },
            { label: `${this.titlePage}` },
        ];
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.takeUntil)(this.unsubscribe$))
            .subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.modelEdit.carCode = this.paramsObject.params.canId || null;
            this.GetEmployeeCardInfo();
        });
    }
    ;
    GetEmployeeCardInfo() {
        const queryParams = queryString.stringify(this.modelEdit);
        this.apiService.getEmployeeCardInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                this.listViews = [...results.data.group_fields];
                this.detailInfo = results.data;
            }
        });
    }
    SetEmployeeCardInfo(data) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setEmployeeCardInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.router.navigate(['/phan-quyen/the-nhan-vien']);
                this.spinner.hide();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.GetEmployeeCardInfo();
        }
        else {
            this.router.navigate(['/phan-quyen/the-nhan-vien']);
        }
    }
}
ChiTietTheNhanVienComponent.ɵfac = function ChiTietTheNhanVienComponent_Factory(t) { return new (t || ChiTietTheNhanVienComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_0__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_7__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router)); };
ChiTietTheNhanVienComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: ChiTietTheNhanVienComponent, selectors: [["app-chi-tiet-the-nhan-vien"]], decls: 5, vars: 2, consts: [[1, "main-grid", "product-detail"], [3, "items"], [1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function ChiTietTheNhanVienComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "app-hrm-breadcrumb", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, ChiTietTheNhanVienComponent_app_edit_detail_4_Template, 1, 4, "app-edit-detail", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_1__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_2__.EditDetailComponent], styles: ["[_nghost-%COMP%]  .product-detail .row {\n  margin-left: -15px;\n  margin-right: -15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoaS10aWV0LXRoZS1uaGFuLXZpZW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRVE7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0FBRFoiLCJmaWxlIjoiY2hpLXRpZXQtdGhlLW5oYW4tdmllbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0OjpuZy1kZWVwe1xyXG4gICAgLnByb2R1Y3QtZGV0YWlse1xyXG4gICAgICAgIC5yb3d7XHJcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAtMTVweDtcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAtMTVweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iXX0= */"] });


/***/ }),

/***/ 73019:
/*!****************************************************************************************************!*\
  !*** ./src/app/components/pq-the-nhan-vien/import-the-nhan-vien/import-the-nhan-vien.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ImportTheNhanVienComponent": () => (/* binding */ ImportTheNhanVienComponent)
/* harmony export */ });
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/tooltip */ 39243);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/fileupload */ 83735);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);


















function ImportTheNhanVienComponent_p_button_8_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportTheNhanVienComponent_p_button_8_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r5.getTemfileImport(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportTheNhanVienComponent_p_fileUpload_9_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-fileUpload", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onSelect", function ImportTheNhanVienComponent_p_fileUpload_9_Template_p_fileUpload_onSelect_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r7.onSelectFile($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("showCancelButton", true);
} }
function ImportTheNhanVienComponent_p_button_10_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportTheNhanVienComponent_p_button_10_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r9.back(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportTheNhanVienComponent_p_button_11_Template(rf, ctx) { if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportTheNhanVienComponent_p_button_11_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r12); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r11.refetchFile(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportTheNhanVienComponent_div_13_app_list_grid_angular_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-list-grid-angular", 21);
} if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("listsData", ctx_r14.listsData)("height", ctx_r14.heightGrid)("getContextMenuItems", ctx_r14.getContextMenuItems)("columnDefs", ctx_r14.columnDefs);
} }
function ImportTheNhanVienComponent_div_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 17, 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, ImportTheNhanVienComponent_div_13_app_list_grid_angular_2_Template, 1, 4, "app-list-grid-angular", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r4.columnDefs.length > 0 && ctx_r4.heightGrid > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" T\u1ED5ng s\u1ED1 ", ctx_r4.listsData.length, " ");
} }
class ImportTheNhanVienComponent {
    constructor(spinner, apiService, changeDetector, router, messageService) {
        this.spinner = spinner;
        this.apiService = apiService;
        this.changeDetector = changeDetector;
        this.router = router;
        this.messageService = messageService;
        this.items = [];
        this.isFullScreen = false;
        this.heightGrid = 0;
        this.isShowUpload = true;
        this.listsData = [];
        this.columnDefs = [];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Danh thẻ nhân viên', routerLink: '/phan-quyen/the-nhan-vien' },
            { label: 'Import thẻ nhân viên' },
        ];
    }
    toggleGrid() {
        this.isFullScreen = !this.isFullScreen;
        if (this.isFullScreen) {
            this.heightGrid = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.ShowFullScreen)();
        }
        else {
            this.heightGrid = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.HideFullScreen)();
        }
    }
    onSelectFile(event) {
        if (event.currentFiles.length > 0) {
            this.spinner.show();
            this.isShowUpload = false;
            let fomrData = new FormData();
            fomrData.append('formFile', event.currentFiles[0]);
            this.apiService.importCards(fomrData)
                .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.takeUntil)(this.unsubscribe$))
                .subscribe(results => {
                var _a, _b;
                if (results.status === 'success') {
                    this.cols = (_a = results === null || results === void 0 ? void 0 : results.data) === null || _a === void 0 ? void 0 : _a.gridflexs;
                    this.initGrid();
                    const a = document.querySelector(".header");
                    const b = document.querySelector(".sidebarBody");
                    const c = document.querySelector(".bread-filter");
                    const d = document.querySelector(".bread-crumb");
                    const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + 80;
                    this.heightGrid = window.innerHeight - totalHeight;
                    this.changeDetector.detectChanges();
                    // this.onInitAgGrid();
                    this.listsData = (_b = results === null || results === void 0 ? void 0 : results.data) === null || _b === void 0 ? void 0 : _b.data;
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                    this.spinner.hide();
                }
                else {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    this.spinner.hide();
                }
            });
        }
    }
    initGrid() {
        this.columnDefs = [
            { headerName: 'Tên nhân viên', cellClass: [], field: 'empName' },
            { headerName: 'Loại thẻ', cellClass: [], field: 'cardType' },
            { headerName: 'Mã thẻ', cellClass: [], field: 'checkbox' },
            { headerName: 'Tổ chức', cellClass: [], field: 'organizeName' },
            { headerName: 'Số điện thoại', cellClass: [], field: 'empPhone' },
            { headerName: 'Thư điện tử', cellClass: [], field: 'empEmail' },
            { headerName: 'Ngày hết hạn', cellClass: [], field: 'expireDate' },
            { headerName: 'Vé gửi xe', cellClass: [], field: 'isVehicle' },
            { headerName: 'Tên xe', cellClass: [], field: 'vehicleName' },
            { headerName: 'Biển số xe', cellClass: [], field: 'vehicleNo' },
            { headerName: 'Loại xe máy', cellClass: [], field: 'vehicleType' },
            { headerName: 'Thông báo', cellClass: [], field: 'error',
                width: 200,
                resizable: true,
                sortable: true,
                autoHeight: true,
                wrapText: true,
                flex: 1,
                cellRenderer: (params) => {
                    return `<span class="${(params.value.toLowerCase() === 'ok') ? '' : 'bg-red'}">${params.value}
        </span>`;
                },
            },
        ];
    }
    back() {
        const main = document.querySelector(".main");
        main.className = 'main';
        this.router.navigate(['/phan-quyen/the-nhan-vien']);
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    getContextMenuItems(params) {
        var result = [
            'copy',
            'paste',
            'separator',
            'excelExport'
        ];
        return result;
    }
    refetchFile() {
        this.isShowUpload = true;
        this.listsData = [];
        this.columnDefs = [];
    }
    getTemfileImport() {
        this.apiService.exportReportLocalhost('assets/tpl-import-file/import_the_nhan_vien.xlsx').subscribe((data) => {
            this.createImageFromBlob(data);
        });
    }
    createImageFromBlob(image) {
        var blob = new Blob([image]);
        var url = window.URL.createObjectURL(blob);
        var anchor = document.createElement("a");
        anchor.download = "file_mau_import_the_nhan_vien.xlsx";
        anchor.href = url;
        anchor.click();
    }
}
ImportTheNhanVienComponent.ɵfac = function ImportTheNhanVienComponent_Factory(t) { return new (t || ImportTheNhanVienComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_7__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService)); };
ImportTheNhanVienComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: ImportTheNhanVienComponent, selectors: [["app-import-the-nhan-vien"]], decls: 14, vars: 7, consts: [[1, "main-grid"], [1, "bread-crumb"], [3, "items"], [1, "bread-filter"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "col-item"], [1, "d-flex", "middle", "gap-16"], ["type", "button", "icon", "pi pi-th-large", "tooltipPosition", "top", 1, "p-button-sm", 3, "pTooltip", "click"], ["styleClass", "p-button-sm", "icon", "pi pi-download", "label", "T\u1EA3i file m\u1EABu", 3, "click", 4, "ngIf"], ["mode", "basic", "name", "demo[]", "chooseLabel", "T\u1EA1o m\u1EDBi import", "accept", ".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel", 3, "showCancelButton", "onSelect", 4, "ngIf"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "Quay l\u1EA1i", 3, "click", 4, "ngIf"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "l\u00E0m m\u1EDBi", 3, "click", 4, "ngIf"], ["class", "grid-default", 4, "ngIf"], ["styleClass", "p-button-sm", "icon", "pi pi-download", "label", "T\u1EA3i file m\u1EABu", 3, "click"], ["mode", "basic", "name", "demo[]", "chooseLabel", "T\u1EA1o m\u1EDBi import", "accept", ".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel", 3, "showCancelButton", "onSelect"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "Quay l\u1EA1i", 3, "click"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "l\u00E0m m\u1EDBi", 3, "click"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "getContextMenuItems", "columnDefs", 4, "ngIf"], [1, "paginator", 2, "margin-top", "10px", "text-align", "right", "margin-right", "25px", "font-weight", "600"], [3, "listsData", "height", "getContextMenuItems", "columnDefs"]], template: function ImportTheNhanVienComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "app-hrm-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "section", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "p-button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportTheNhanVienComponent_Template_p_button_click_7_listener() { return ctx.toggleGrid(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, ImportTheNhanVienComponent_p_button_8_Template, 1, 0, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, ImportTheNhanVienComponent_p_fileUpload_9_Template, 1, 1, "p-fileUpload", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, ImportTheNhanVienComponent_p_button_10_Template, 1, 0, "p-button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, ImportTheNhanVienComponent_p_button_11_Template, 1, 0, "p-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, ImportTheNhanVienComponent_div_13_Template, 5, 2, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("pTooltip", ctx.isFullScreen ? "\u1EA8n to\u00E0n m\u00E0n h\u00ECnh" : "Hi\u1EC3n th\u1ECB to\u00E0n m\u00E0n h\u00ECnh");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.listsData && ctx.listsData.length > 0);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_2__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_10__.Button, primeng_tooltip__WEBPACK_IMPORTED_MODULE_11__.Tooltip, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, primeng_fileupload__WEBPACK_IMPORTED_MODULE_13__.FileUpload, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_3__.ListGridAngularComponent], styles: ["[_nghost-%COMP%]  .bg-red {\n  background: red;\n  color: #fff;\n  padding: 4px;\n  max-width: 600px;\n  overflow: auto;\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImltcG9ydC10aGUtbmhhbi12aWVuLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtBQUFSIiwiZmlsZSI6ImltcG9ydC10aGUtbmhhbi12aWVuLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Q6Om5nLWRlZXB7XHJcbiAgICAuYmctcmVke1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHJlZDtcclxuICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICBwYWRkaW5nOiA0cHg7XHJcbiAgICAgICAgbWF4LXdpZHRoOiA2MDBweDtcclxuICAgICAgICBvdmVyZmxvdzogYXV0bztcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIH1cclxufSJdfQ== */"] });


/***/ }),

/***/ 94440:
/*!***************************************************************************!*\
  !*** ./src/app/components/pq-the-nhan-vien/pq-the-nhan-vien.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PqTheNhanVienComponent": () => (/* binding */ PqTheNhanVienComponent)
/* harmony export */ });
/* harmony import */ var src_app_services_notification_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/notification.service */ 48410);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var src_app_components_pq_the_nhan_vien_card_detail_card_detail_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/components/pq-the-nhan-vien/card-detail/card-detail.component */ 36980);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/dropdown */ 45596);




































function PqTheNhanVienComponent_app_list_grid_angular_35_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-list-grid-angular", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("showConfig", function PqTheNhanVienComponent_app_list_grid_angular_35_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r7.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function PqTheNhanVienComponent_app_card_detail_43_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-card-detail", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("save", function PqTheNhanVienComponent_app_card_detail_43_Template_app_card_detail_save_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r9.displaythenv = !ctx_r9.displaythenv; });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} }
function PqTheNhanVienComponent_app_config_grid_table_form_45_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "app-config-grid-table-form", 45);
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r3.gridKey);
} }
function PqTheNhanVienComponent_ng_template_48_ng_template_15_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "span", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r17.label);
} }
function PqTheNhanVienComponent_ng_template_48_ng_template_16_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r18 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](car_r18.label);
} }
function PqTheNhanVienComponent_ng_template_48_ng_template_22_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r19 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r19.label);
} }
function PqTheNhanVienComponent_ng_template_48_ng_template_23_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r20 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](car_r20.label);
} }
function PqTheNhanVienComponent_ng_template_48_ng_template_29_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r21.label);
} }
function PqTheNhanVienComponent_ng_template_48_ng_template_30_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r22 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](car_r22.label);
} }
const _c0 = function (a0) { return [a0]; };
function PqTheNhanVienComponent_ng_template_48_Template(rf, ctx) { if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](8, "B\u1ED9 ph\u1EADn");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "p-treeSelect", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqTheNhanVienComponent_ng_template_48_Template_p_treeSelect_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r24); const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r23.model.orgId = $event; })("onNodeSelect", function PqTheNhanVienComponent_ng_template_48_Template_p_treeSelect_onNodeSelect_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r24); const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r25.onChangeTree($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](10, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](11, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](12, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](13, "Tr\u1EA1ng th\u00E1i");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](14, "p-dropdown", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqTheNhanVienComponent_ng_template_48_Template_p_dropdown_ngModelChange_14_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r24); const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r26.model.status = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](15, PqTheNhanVienComponent_ng_template_48_ng_template_15_Template, 2, 1, "ng-template", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](16, PqTheNhanVienComponent_ng_template_48_ng_template_16_Template, 3, 1, "ng-template", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](17, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](18, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](19, "label", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](20, "Ch\u1EE9c v\u1EE5");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](21, "p-dropdown", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqTheNhanVienComponent_ng_template_48_Template_p_dropdown_ngModelChange_21_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r24); const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r27.model.positionCd = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](22, PqTheNhanVienComponent_ng_template_48_ng_template_22_Template, 2, 1, "ng-template", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](23, PqTheNhanVienComponent_ng_template_48_ng_template_23_Template, 3, 1, "ng-template", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](24, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](25, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](26, "label", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](27, "N\u01A1i l\u00E0m vi\u1EC7c");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](28, "p-dropdown", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function PqTheNhanVienComponent_ng_template_48_Template_p_dropdown_ngModelChange_28_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r24); const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r28.model.workplaceId = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](29, PqTheNhanVienComponent_ng_template_48_ng_template_29_Template, 2, 1, "ng-template", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](30, PqTheNhanVienComponent_ng_template_48_ng_template_30_Template, 3, 1, "ng-template", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](31, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](32, "label", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](33, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](34, "span", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](35, "p-button", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqTheNhanVienComponent_ng_template_48_Template_p_button_click_35_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r24); const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r29.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](36, "p-button", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqTheNhanVienComponent_ng_template_48_Template_p_button_click_36_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r24); const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r30.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx_r5.model.orgId)("filterInputAutoFocus", true)("filter", true)("metaKeySelection", false)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](21, _c0, ctx_r5.departmentFiltes.length <= 0 ? "tree-empty" : ""))("options", ctx_r5.departmentFiltes);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r5.listStatus)("ngModel", ctx_r5.model.status)("filter", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("filter", true)("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r5.dataPositionList)("ngModel", ctx_r5.model.positionCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("filter", true)("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r5.workplaceOptions)("ngModel", ctx_r5.model.workplaceId);
} }
const _c1 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c2 = function () { return { showAll: "ALL" }; };
const _c3 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c4 = function () { return { width: "1200px", height: "auto" }; };
const _c5 = function () { return { width: "50vw" }; };
const _c6 = function () { return { width: "700px" }; };
class PqTheNhanVienComponent {
    constructor(apiService, fileService, spinner, changeDetector, confirmationService, messageService, organizeInfoService, router, notificationService) {
        this.apiService = apiService;
        this.fileService = fileService;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.notificationService = notificationService;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.ACTIONS;
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_3__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn;
        this.loading = false;
        this.cards = [];
        this.organizes = [];
        this.departmentFiltes = [];
        this.listStatus = [
            { label: 'Tất cả', value: -1 },
            { label: 'Mới tạo', value: 0 },
            { label: 'Hoạt động', value: 1 },
            { label: 'Khóa thẻ', value: 3 },
        ];
        this.first = 0;
        this.model = {
            organizeId: '',
            orgId: '',
            filter: '',
            positionCd: '',
            workplaceId: '',
            status: -1,
            offSet: 0,
            pageSize: 15,
            // organizeIds: ""
        };
        this.totalRecord = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.pagingComponent = {
            total: 0
        };
        this.itemsToolOfGrid = [];
        this.items = [];
        this.displaySetting = false;
        this.gridKey = '';
        this.listsData = [];
        this.dataPositionList = [];
        this.workplaceOptions = [];
        this.loadjs = 0;
        this.heightGrid = 0;
        this.displaythenv = false;
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 38;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_5__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_6__.ButtonAgGridComponent,
        };
        this.initFilter();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                // this.model.organizeIds = results;
                this.model.organizeId = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Phân quyền' },
            { label: 'Danh sách thẻ nhân viên' },
        ];
        this.getOrganize();
        this.getPositionList();
        this.getWorkplaces();
        this.itemsToolOfGrid = [
            {
                label: 'Import file',
                code: 'Import',
                icon: 'pi pi-upload',
                disabled: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.MENUACTIONROLEAPI.GetEmployeeCardPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.ACTIONS.IMPORT),
                command: () => {
                    this.importFileExel();
                }
            },
            {
                label: 'Export file',
                code: 'Import',
                icon: 'pi pi-download',
                disabled: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.MENUACTIONROLEAPI.GetEmployeeCardPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.ACTIONS.EXPORT),
                command: () => {
                    this.exportexcel();
                }
            },
        ];
    }
    initFilter() {
        this.model = {
            organizeId: '',
            orgId: '',
            filter: '',
            positionCd: '',
            workplaceId: '',
            status: -1,
            offSet: 0,
            pageSize: 15,
            // organizeIds: this.model.organizeIds
        };
    }
    handleChangeOrganize() {
        this.model.orgId = '';
        this.getOrganizeTree();
        // this.find();
    }
    exportexcel() {
        this.spinner.show();
        const query = Object.assign({}, this.model);
        query.offSet = 0;
        query.pageSize = 1000000;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify(query);
        this.apiService.getEmployeeCardPage(queryParams)
            .subscribe((results) => {
            const dataExport = [];
            results.data.dataList.data.forEach(element => {
                const data = {};
                data['Mã thẻ'] = element.cardCd || '';
                data['Tên nhân viên'] = element.fullName || '';
                data['Tổ chức'] = element.orgName || '';
                data['Phòng'] = element.departmentName || '';
                data['Số điện thoại'] = element.phone || '';
                data['Ngày tạo thẻ'] = element.issueDate || '';
                data['Tài khoản tạo thẻ'] = element.created_by || '';
                data['Trạng thái'] = element.status === 3 ? 'Khóa' : (element.status === 1 ? 'Hoạt động' : '');
                data['Số lượng xe'] = element.countVehicle || '0';
                dataExport.push(data);
            });
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách thẻ nhân viên - ' + new Date());
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
            console.error(error);
        });
    }
    importFileExel() {
        this.router.navigate(['/phan-quyen/the-nhan-vien/import']);
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const query = Object.assign({}, this.model);
        query.organizeId = query.organizeId;
        query.orgId = query.orgId.orgId;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify(query);
        this.apiService.getEmployeeCardPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.model.offSet === 0) {
                this.gridflexs = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.model.offSet = 0 : this.model.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.model.offSet) > this.model.pageSize) {
                this.countRecord.currentRecordEnd = this.model.offSet + Number(this.model.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.lockCard.bind(this),
                    label: 'Khóa',
                    icon: 'fa fa-lock',
                    class: 'btn-primary mr5',
                    hide: this.CheckHidelockCard(event)
                },
                {
                    onClick: this.unlockCard.bind(this),
                    label: 'Mở khóa',
                    icon: 'fa fa-unlock',
                    class: 'btn-primary mr5',
                    hide: this.CheckHideunlockCard(event)
                },
                {
                    onClick: this.deleteCard.bind(this),
                    label: 'Xóa thẻ',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    hide: this.CheckHidedeleteCard(event)
                }
            ]
        };
    }
    CheckHidelockCard(event) {
        let checkValue = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.MENUACTIONROLEAPI.GetEmployeeCardPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.ACTIONS.LOCK_CARD);
        if (checkValue) {
            return true;
        }
        else {
            if (event.data.status === 3) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    CheckHideunlockCard(event) {
        let checkValue = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.MENUACTIONROLEAPI.GetEmployeeCardPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.ACTIONS.UNLOCK_CARD);
        if (checkValue) {
            return true;
        }
        else {
            if (event.data.status !== 3) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    CheckHidedeleteCard(event) {
        let checkValue = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.MENUACTIONROLEAPI.GetEmployeeCardPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.ACTIONS.DELETE);
        if (checkValue) {
            return true;
        }
        else {
            if (event.data.status !== 3) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn)(this.gridflexs.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    paginate(event) {
        this.model.offSet = event.first;
        this.first = event.first;
        this.model.pageSize = event.rows;
        this.load();
    }
    getOrganize() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams)
            .subscribe((results) => {
            this.organizes = results.data
                .map(d => {
                return {
                    label: d.organizationName || d.organizationCd,
                    value: d.organizeId
                };
            });
            this.organizes = [{ label: 'Chọn tổ chức', value: '' }, ...this.organizes];
        }),
            error => { };
    }
    getOrganizeTree() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ parentId: this.model.organizeId });
        this.apiService.getOrganizeTree(queryParams)
            .subscribe((results) => {
            if (results && results.status === 'success') {
                this.departmentFiltes = results.data;
            }
        }, error => { });
    }
    getPositionList() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ objKey: 'positiontype_group' });
        this.apiService.getCustObjectListNew(false, queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.dataPositionList = results.data.map(d => {
                    return {
                        label: d.objName,
                        value: d.objCode
                    };
                });
            }
        });
    }
    getWorkplaces() {
        this.apiService.getWorkplaces().subscribe(results => {
            if (results.status === 'success') {
                this.workplaceOptions = results.data.map(d => {
                    return {
                        label: d.workplaceName,
                        value: d.workplaceId
                    };
                });
            }
        });
    }
    lockCard(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện Khóa thẻ này?',
            accept: () => {
                this.spinner.show();
                this.apiService.lockCardNV(event.rowData.cardCd)
                    .subscribe(results => {
                    this.load();
                    this.spinner.hide();
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Khóa thẻ thành công' });
                }, error => this.handlerError(error));
            }
        });
    }
    handlerError(error) {
        console.log(error);
        this.spinner.hide();
        if (error.status === 401) {
            this.router.navigate(['/home']);
        }
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    unlockCard(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện Mở khóa thẻ này?',
            accept: () => {
                this.spinner.show();
                this.apiService.unlockCardNV(event.rowData.cardCd)
                    .subscribe(results => {
                    this.load();
                    this.spinner.hide();
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Mở khóa thẻ thành công' });
                }, error => this.handlerError(error));
            }
        });
    }
    deleteCard(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện xóa thẻ xe này?',
            accept: () => {
                this.spinner.show();
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ cardCd: event.rowData.cardCd });
                this.apiService.deleteCard(queryParams)
                    .subscribe(results => {
                    this.load();
                    this.spinner.hide();
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Xóa thẻ xe thành công' });
                }, error => this.handlerError(error));
            }
        });
    }
    find() {
        this.load();
    }
    cancel() {
        this.initFilter();
        this.load();
    }
    changePageSize() {
        this.load();
    }
    handleAdd() {
        // this.displaythenv = true;
        const params = {
            canId: null
        };
        this.router.navigate(['/phan-quyen/the-nhan-vien/them-moi-the-nhan-vien'], { queryParams: params });
    }
    onChangeTree(a) {
        // this.find();
    }
}
PqTheNhanVienComponent.ɵfac = function PqTheNhanVienComponent_Factory(t) { return new (t || PqTheNhanVienComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_7__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_1__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_16__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_15__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_17__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_17__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_9__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_18__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_notification_service__WEBPACK_IMPORTED_MODULE_0__.NotificationService)); };
PqTheNhanVienComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({ type: PqTheNhanVienComponent, selectors: [["app-pq-the-nhan-vien"]], decls: 51, vars: 43, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "end", "bottom", "gap-12", "col-9", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm m\u00E3 th\u1EBB, T\u00EAn nh\u00E2n vi\u00EAn, s\u0111t", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "18", "height", "18", "viewBox", "0 0 18 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M10.2002 13.2H13.2002V10.2H14.8002V13.2H17.8002V14.8H14.8002V17.7999H13.2002V14.8H10.2002V13.2Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 0.199951H7.8002V7.79995H0.200195V0.199951ZM6.2002 1.79995H1.8002V6.19995H6.2002V1.79995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.8002 7.79995H10.2002V0.199951H17.8002V7.79995ZM11.8002 6.19995H16.2002V1.79995H11.8002V6.19995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 10.2H7.8002V17.7999H0.200195V10.2ZM6.2002 11.8H1.8002V16.2H6.2002V11.8Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", 3, "CheckHideActions", "click"], ["d", "M11 5H9V9H5V11H9V15H11V11H15V9H11V5ZM10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM10 18C5.59 18 2 14.41 2 10C2 5.59 5.59 2 10 2C14.41 2 18 5.59 18 10C18 14.41 14.41 18 10 18Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], [3, "visible", "draggable", "resizable", "autoZIndex", "modal", "visibleChange"], [3, "save", 4, "ngIf"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], ["styleClass", "menu-option-right", 3, "model", "appendTo", "popup"], ["menuButton", ""], [3, "listsData", "height", "columnDefs", "showConfig"], [3, "save"], [3, "typeConfig", "gridKey"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", "mb-0", "label-8"], ["selectionMode", "single", "name", "orgId", "placeholder", "Ch\u1ECDn ph\u00F2ng ban", 3, "ngModel", "filterInputAutoFocus", "filter", "metaKeySelection", "ngClass", "options", "ngModelChange", "onNodeSelect"], [1, "field-group", "select", "valid"], ["appendTo", "body", "name", "status", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], ["for", ""], ["placeholder", "Ch\u1ECDn ch\u1EE9c v\u1EE5", "appendTo", "body", "name", "position", 3, "filter", "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange"], ["placeholder", "N\u01A1i l\u00E0m vi\u1EC7c", "appendTo", "body", "name", "position", 3, "filter", "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [2, "vertical-align", "middle"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"]], template: function PqTheNhanVienComponent_Template(rf, ctx) { if (rf & 1) {
        const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("keydown.enter", function PqTheNhanVienComponent_Template_input_keydown_enter_8_listener() { ctx.model.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function PqTheNhanVienComponent_Template_input_ngModelChange_8_listener($event) { return ctx.model.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqTheNhanVienComponent_Template_span_click_9_listener() { ctx.model.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqTheNhanVienComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqTheNhanVienComponent_Template_p_button_click_15_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r31); const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](47); return _r4.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](21, "p-button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqTheNhanVienComponent_Template_p_button_click_21_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r31); const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](50); return _r6.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](22, "svg", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](23, "path", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](24, "path", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](25, "path", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](26, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](27, " \u00A0 Ti\u1EC7n \u00EDch ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](28, "p-button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function PqTheNhanVienComponent_Template_p_button_click_28_listener() { return ctx.handleAdd(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](29, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](30, "path", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](31, " \u00A0 Th\u00EAm m\u1EDBi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](32, "section", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](33, "div", 29, 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](35, PqTheNhanVienComponent_app_list_grid_angular_35_Template, 1, 3, "app-list-grid-angular", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](36, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](37, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](38);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](39, "p-paginator", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("onPageChange", function PqTheNhanVienComponent_Template_p_paginator_onPageChange_39_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](40, "p-dialog", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function PqTheNhanVienComponent_Template_p_dialog_visibleChange_40_listener($event) { return ctx.displaythenv = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](41, "p-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](42, " Th\u00EAm m\u1EDBi th\u1EBB nh\u00E2n vi\u00EAn ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](43, PqTheNhanVienComponent_app_card_detail_43_Template, 1, 0, "app-card-detail", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](44, "p-dialog", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function PqTheNhanVienComponent_Template_p_dialog_visibleChange_44_listener($event) { return ctx.displaySetting = $event; })("onHide", function PqTheNhanVienComponent_Template_p_dialog_onHide_44_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](45, PqTheNhanVienComponent_app_config_grid_table_form_45_Template, 1, 2, "app-config-grid-table-form", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](46, "p-overlayPanel", 38, 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](48, PqTheNhanVienComponent_ng_template_48_Template, 37, 23, "ng-template", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](49, "p-menu", 41, 42);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", ctx.model.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.model.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction2"](34, _c1, ctx.MENUACTIONROLEAPI.GetEmployeeCardPage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("rows", ctx.model.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](38, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](37, _c2)));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](40, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.displaythenv)("draggable", false)("resizable", false)("autoZIndex", true)("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.displaythenv);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](41, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](42, _c6));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("model", ctx.itemsToolOfGrid)("appendTo", "body")("popup", true);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_10__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_21__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_11__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_22__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_23__.Dialog, primeng_api__WEBPACK_IMPORTED_MODULE_17__.Header, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_24__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_17__.PrimeTemplate, primeng_menu__WEBPACK_IMPORTED_MODULE_25__.Menu, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_12__.ListGridAngularComponent, src_app_components_pq_the_nhan_vien_card_detail_card_detail_component__WEBPACK_IMPORTED_MODULE_13__.CardDetailComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_14__.ConfigGridTableFormComponent, primeng_treeselect__WEBPACK_IMPORTED_MODULE_26__.TreeSelect, primeng_dropdown__WEBPACK_IMPORTED_MODULE_27__.Dropdown], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcS10aGUtbmhhbi12aWVuLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 28219:
/*!*************************************************************************************************!*\
  !*** ./src/app/components/pq-xe-nhan-vien/import-xe-nhan-vien/import-xe-nhan-vien.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ImportXeNhanVienComponent": () => (/* binding */ ImportXeNhanVienComponent)
/* harmony export */ });
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/tooltip */ 39243);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/fileupload */ 83735);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);



















function ImportXeNhanVienComponent_p_button_8_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportXeNhanVienComponent_p_button_8_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r5.getTemfileImport(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportXeNhanVienComponent_p_fileUpload_9_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-fileUpload", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onSelect", function ImportXeNhanVienComponent_p_fileUpload_9_Template_p_fileUpload_onSelect_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r7.onSelectFile($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("showCancelButton", true);
} }
function ImportXeNhanVienComponent_p_button_10_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportXeNhanVienComponent_p_button_10_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r9.back(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportXeNhanVienComponent_p_button_11_Template(rf, ctx) { if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportXeNhanVienComponent_p_button_11_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r12); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r11.refetchFile(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportXeNhanVienComponent_div_12_app_list_grid_angular_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-list-grid-angular", 21);
} if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("listsData", ctx_r14.listsData)("height", ctx_r14.heightGrid)("getContextMenuItems", ctx_r14.getContextMenuItems)("columnDefs", ctx_r14.columnDefs);
} }
function ImportXeNhanVienComponent_div_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 17, 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, ImportXeNhanVienComponent_div_12_app_list_grid_angular_2_Template, 1, 4, "app-list-grid-angular", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r4.columnDefs.length > 0 && ctx_r4.heightGrid > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" T\u1ED5ng s\u1ED1 ", ctx_r4.listsData.length, " ");
} }
class ImportXeNhanVienComponent {
    constructor(spinner, apiService, changeDetector, router, messageService) {
        this.spinner = spinner;
        this.apiService = apiService;
        this.changeDetector = changeDetector;
        this.router = router;
        this.messageService = messageService;
        this.items = [];
        this.isFullScreen = false;
        this.heightGrid = 0;
        this.isShowUpload = true;
        this.listsData = [];
        this.columnDefs = [];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Danh Danh sách xe nhân viên', routerLink: '/phan-quyen/xe-nhan-vien' },
            { label: 'Import xe nhân viên' },
        ];
    }
    toggleGrid() {
        this.isFullScreen = !this.isFullScreen;
        if (this.isFullScreen) {
            this.heightGrid = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.ShowFullScreen)();
        }
        else {
            this.heightGrid = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.HideFullScreen)();
        }
    }
    onSelectFile(event) {
        if (event.currentFiles.length > 0) {
            this.spinner.show();
            this.isShowUpload = false;
            let fomrData = new FormData();
            fomrData.append('formFile', event.currentFiles[0]);
            this.apiService.ImportVehicle(fomrData)
                .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.takeUntil)(this.unsubscribe$))
                .subscribe(results => {
                var _a, _b, _c;
                if (results.status === 'success') {
                    this.cols = (_a = results === null || results === void 0 ? void 0 : results.data) === null || _a === void 0 ? void 0 : _a.gridflexs;
                    this.initGrid();
                    const a = document.querySelector(".header");
                    const b = document.querySelector(".sidebarBody");
                    const c = document.querySelector(".bread-filter");
                    // const d: any = document.querySelector(".filterInput");
                    const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + 80;
                    this.heightGrid = window.innerHeight - totalHeight;
                    this.changeDetector.detectChanges();
                    // this.onInitAgGrid();
                    this.listsData = (_c = (_b = results === null || results === void 0 ? void 0 : results.data) === null || _b === void 0 ? void 0 : _b.dataList) === null || _c === void 0 ? void 0 : _c.data;
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                    this.spinner.hide();
                }
                else {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    this.spinner.hide();
                }
            });
        }
    }
    initGrid() {
        if (this.cols) {
            this.columnDefs = [
                ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.AgGridFn)(this.cols.filter((d) => !d.isHide))
            ];
        }
    }
    back() {
        const main = document.querySelector(".main");
        main.className = 'main';
        this.router.navigate(['/phan-quyen/xe-nhan-vien']);
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    getContextMenuItems(params) {
        var result = [
            'copy',
            'paste',
            'separator',
            'excelExport'
        ];
        return result;
    }
    refetchFile() {
        this.isShowUpload = true;
        this.listsData = [];
        this.columnDefs = [];
    }
    getTemfileImport() {
        this.apiService.exportReportLocalhost('assets/tpl-import-file/import_xe_nhan_vien.xlsx').subscribe((data) => {
            this.createImageFromBlob(data);
        });
    }
    createImageFromBlob(image) {
        var blob = new Blob([image]);
        var url = window.URL.createObjectURL(blob);
        var anchor = document.createElement("a");
        anchor.download = "file_mau_import_xe_nhan_vien.xlsx";
        anchor.href = url;
        anchor.click();
    }
}
ImportXeNhanVienComponent.ɵfac = function ImportXeNhanVienComponent_Factory(t) { return new (t || ImportXeNhanVienComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_7__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService)); };
ImportXeNhanVienComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: ImportXeNhanVienComponent, selectors: [["app-import-xe-nhan-vien"]], decls: 13, vars: 7, consts: [[1, "main-grid"], [1, "bread-crumb"], [3, "items"], [1, "bread-filter"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "col-item"], [1, "d-flex", "align-items-center", "gap-16"], ["type", "button", "icon", "pi pi-th-large", "tooltipPosition", "top", 1, "p-button-sm", "mr-2", 3, "pTooltip", "click"], ["styleClass", "p-button-sm mr-2", "icon", "pi pi-download", "label", "T\u1EA3i file m\u1EABu", 3, "click", 4, "ngIf"], ["mode", "basic", "name", "demo[]", "chooseLabel", "T\u1EA1o m\u1EDBi import", "accept", ".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel", 3, "showCancelButton", "onSelect", 4, "ngIf"], ["styleClass", "p-button-sm p-button-secondary ml-2", "icon", "pi pi-times", "label", "Quay l\u1EA1i", 3, "click", 4, "ngIf"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "l\u00E0m m\u1EDBi", 3, "click", 4, "ngIf"], ["class", "grid-default", 4, "ngIf"], ["styleClass", "p-button-sm mr-2", "icon", "pi pi-download", "label", "T\u1EA3i file m\u1EABu", 3, "click"], ["mode", "basic", "name", "demo[]", "chooseLabel", "T\u1EA1o m\u1EDBi import", "accept", ".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel", 3, "showCancelButton", "onSelect"], ["styleClass", "p-button-sm p-button-secondary ml-2", "icon", "pi pi-times", "label", "Quay l\u1EA1i", 3, "click"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "l\u00E0m m\u1EDBi", 3, "click"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "getContextMenuItems", "columnDefs", 4, "ngIf"], [1, "paginator", 2, "margin-top", "10px", "text-align", "right", "margin-right", "25px", "font-weight", "600"], [3, "listsData", "height", "getContextMenuItems", "columnDefs"]], template: function ImportXeNhanVienComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "app-hrm-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "section", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "p-button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportXeNhanVienComponent_Template_p_button_click_7_listener() { return ctx.toggleGrid(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, ImportXeNhanVienComponent_p_button_8_Template, 1, 0, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, ImportXeNhanVienComponent_p_fileUpload_9_Template, 1, 1, "p-fileUpload", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, ImportXeNhanVienComponent_p_button_10_Template, 1, 0, "p-button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, ImportXeNhanVienComponent_p_button_11_Template, 1, 0, "p-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](12, ImportXeNhanVienComponent_div_12_Template, 5, 2, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("pTooltip", ctx.isFullScreen ? "\u1EA8n to\u00E0n m\u00E0n h\u00ECnh" : "Hi\u1EC3n th\u1ECB to\u00E0n m\u00E0n h\u00ECnh");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.listsData && ctx.listsData.length > 0);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_2__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_10__.Button, primeng_tooltip__WEBPACK_IMPORTED_MODULE_11__.Tooltip, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, primeng_fileupload__WEBPACK_IMPORTED_MODULE_13__.FileUpload, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_3__.ListGridAngularComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpbXBvcnQteGUtbmhhbi12aWVuLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 23063:
/*!*************************************************************************!*\
  !*** ./src/app/components/pq-xe-nhan-vien/pq-xe-nhan-vien.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PqXeNhanVienComponent": () => (/* binding */ PqXeNhanVienComponent)
/* harmony export */ });
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! firebase */ 37584);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var primeng_image__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/image */ 98907);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/fileupload */ 83735);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/treeselect */ 90238);




































function PqXeNhanVienComponent_app_list_grid_angular_35_Template(rf, ctx) { if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "app-list-grid-angular", 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("showConfig", function PqXeNhanVienComponent_app_list_grid_angular_35_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r31); const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r30.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function PqXeNhanVienComponent_ng_template_52_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r32 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](item_r32.label);
} }
function PqXeNhanVienComponent_ng_template_53_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r33 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](car_r33.label);
} }
function PqXeNhanVienComponent_ng_template_59_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r34 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](item_r34.label);
} }
function PqXeNhanVienComponent_ng_template_60_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r35 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](car_r35.label);
} }
function PqXeNhanVienComponent_span_65_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1, "*");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} }
function PqXeNhanVienComponent_ng_template_68_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r36 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](item_r36.label);
} }
function PqXeNhanVienComponent_ng_template_69_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r37 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](car_r37.label);
} }
function PqXeNhanVienComponent_div_70_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1, "Tr\u01B0\u1EDDng n\u00E0y b\u1EAFt bu\u1ED9c nh\u1EADp");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} }
function PqXeNhanVienComponent_div_70_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](1, PqXeNhanVienComponent_div_70_div_1_Template, 2, 0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](67);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _r8.errors.required);
} }
function PqXeNhanVienComponent_option_77_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const i_r40 = ctx.index;
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpropertyInterpolate"]("value", ctx_r13.vehicleTypes[i_r40].vehicleTypeId);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("selected", i_r40 == 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", ctx_r13.vehicleTypes[i_r40].vehicleTypeName, " ");
} }
function PqXeNhanVienComponent_div_86_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1, "Tr\u01B0\u1EDDng n\u00E0y b\u1EAFt bu\u1ED9c nh\u1EADp");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} }
function PqXeNhanVienComponent_div_86_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](1, PqXeNhanVienComponent_div_86_div_1_Template, 2, 0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](85);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _r14.errors.required);
} }
function PqXeNhanVienComponent_div_95_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1, "Tr\u01B0\u1EDDng n\u00E0y b\u1EAFt bu\u1ED9c nh\u1EADp");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} }
function PqXeNhanVienComponent_div_95_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](1, PqXeNhanVienComponent_div_95_div_1_Template, 2, 0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](94);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _r16.errors.required);
} }
function PqXeNhanVienComponent_div_115_Template(rf, ctx) { if (rf & 1) {
    const _r44 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](2, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](3, "Ng\u00E0y h\u1EA1n");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](4, "p-calendar", 108);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_div_115_Template_p_calendar_ngModelChange_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r44); const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r43.modelTM.endTimeTM = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngClass", ctx_r18.modelTM.endTimeTM ? "valid" : "date-invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx_r18.modelTM.endTimeTM)("baseZIndex", 100);
} }
function PqXeNhanVienComponent_div_129_span_6_Template(rf, ctx) { if (rf & 1) {
    const _r50 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span", 114);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_div_129_span_6_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r50); const indexImg_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]().index; const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r48.deleteImg(indexImg_r46); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} }
function PqXeNhanVienComponent_div_129_Template(rf, ctx) { if (rf & 1) {
    const _r52 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 109);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "h4");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "div", 110);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](4, "p-image", 111);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "p-fileUpload", 112);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("onSelect", function PqXeNhanVienComponent_div_129_Template_p_fileUpload_onSelect_5_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r52); const indexImg_r46 = restoredCtx.index; const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r51.uploadImageVehicle($event, indexImg_r46); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](6, PqXeNhanVienComponent_div_129_span_6_Template, 1, 0, "span", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const imgUrl_r45 = ctx.$implicit;
    const indexImg_r46 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](indexImg_r46 === 0 || indexImg_r46 === 1 ? "\u1EA2nh gi\u1EA5y ch\u1EE9ng nh\u1EADn \u0111\u0103ng k\u00FD xe" : "\u1EA2nh bi\u1EC3n s\u1ED1 xe");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpropertyInterpolate"]("src", (imgUrl_r45 == null ? null : imgUrl_r45.url) ? imgUrl_r45 == null ? null : imgUrl_r45.url : "/../../../../assets/images/file.png");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("preview", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("chooseIcon", "pi pi-upload")("maxFileSize", 10000000);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", imgUrl_r45 == null ? null : imgUrl_r45.url);
} }
function PqXeNhanVienComponent_div_149_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1, "Tr\u01B0\u1EDDng n\u00E0y b\u1EAFt bu\u1ED9c nh\u1EADp");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} }
function PqXeNhanVienComponent_div_149_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](1, PqXeNhanVienComponent_div_149_div_1_Template, 2, 0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](148);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _r23.errors.required);
} }
function PqXeNhanVienComponent_div_161_Template(rf, ctx) { if (rf & 1) {
    const _r55 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 115);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](2, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](3, "Ng\u00E0y h\u1EA1n");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](4, "p-calendar", 116);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_div_161_Template_p_calendar_ngModelChange_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r55); const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r54.modelTM.endTime = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngClass", ctx_r25.modelTM.endTime ? "valid" : "date-invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx_r25.modelTM.endTime)("baseZIndex", 100);
} }
function PqXeNhanVienComponent_app_config_grid_table_form_168_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "app-config-grid-table-form", 117);
} if (rf & 2) {
    const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r26.gridKey);
} }
function PqXeNhanVienComponent_ng_template_171_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r64 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](item_r64.label);
} }
function PqXeNhanVienComponent_ng_template_171_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r65 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](car_r65.label);
} }
function PqXeNhanVienComponent_ng_template_171_ng_template_22_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r66 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](item_r66.label);
} }
function PqXeNhanVienComponent_ng_template_171_ng_template_23_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r67 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](car_r67.label);
} }
function PqXeNhanVienComponent_ng_template_171_ng_template_29_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r68 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](item_r68.label);
} }
function PqXeNhanVienComponent_ng_template_171_ng_template_30_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r69 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](car_r69.label);
} }
function PqXeNhanVienComponent_ng_template_171_ng_template_36_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r70 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](item_r70.label);
} }
function PqXeNhanVienComponent_ng_template_171_ng_template_37_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r71 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](car_r71.label);
} }
const _c0 = function (a0) { return [a0]; };
function PqXeNhanVienComponent_ng_template_171_Template(rf, ctx) { if (rf & 1) {
    const _r73 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "div", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](4, "div", 120);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "div", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](6, "div", 122);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](7, "label", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](8, " T\u1ED5 ch\u1EE9c: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](9, "p-dropdown", 123);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_ng_template_171_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r72.model.organizeId = $event; })("onChange", function PqXeNhanVienComponent_ng_template_171_Template_p_dropdown_onChange_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r74.handleChangeOrganize(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](10, PqXeNhanVienComponent_ng_template_171_ng_template_10_Template, 2, 1, "ng-template", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](11, PqXeNhanVienComponent_ng_template_171_ng_template_11_Template, 3, 1, "ng-template", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](12, "div", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](13, "div", 124);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](14, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](15, "B\u1ED9 ph\u1EADn");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](16, "p-treeSelect", 125);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_ng_template_171_Template_p_treeSelect_ngModelChange_16_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r75.model.orgId = $event; })("onNodeSelect", function PqXeNhanVienComponent_ng_template_171_Template_p_treeSelect_onNodeSelect_16_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r76 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r76.onChangeTree($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](17, "div", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](18, "div", 122);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](19, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](20, "Tr\u1EA1ng th\u00E1i");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](21, "p-dropdown", 126);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("onChange", function PqXeNhanVienComponent_ng_template_171_Template_p_dropdown_onChange_21_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r77.find(); })("ngModelChange", function PqXeNhanVienComponent_ng_template_171_Template_p_dropdown_ngModelChange_21_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r78 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r78.model.status = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](22, PqXeNhanVienComponent_ng_template_171_ng_template_22_Template, 2, 1, "ng-template", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](23, PqXeNhanVienComponent_ng_template_171_ng_template_23_Template, 3, 1, "ng-template", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](24, "div", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](25, "div", 122);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](26, "label", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](27, "Ch\u1EE9c v\u1EE5");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](28, "p-dropdown", 127);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("onChange", function PqXeNhanVienComponent_ng_template_171_Template_p_dropdown_onChange_28_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r79 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r79.find(); })("ngModelChange", function PqXeNhanVienComponent_ng_template_171_Template_p_dropdown_ngModelChange_28_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r80.model.positionCd = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](29, PqXeNhanVienComponent_ng_template_171_ng_template_29_Template, 2, 1, "ng-template", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](30, PqXeNhanVienComponent_ng_template_171_ng_template_30_Template, 3, 1, "ng-template", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](31, "div", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](32, "div", 122);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](33, "label", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](34, "N\u01A1i l\u00E0m vi\u1EC7c");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](35, "p-dropdown", 128);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("onChange", function PqXeNhanVienComponent_ng_template_171_Template_p_dropdown_onChange_35_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r81 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r81.find(); })("ngModelChange", function PqXeNhanVienComponent_ng_template_171_Template_p_dropdown_ngModelChange_35_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r82 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r82.model.workplaceId = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](36, PqXeNhanVienComponent_ng_template_171_ng_template_36_Template, 2, 1, "ng-template", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](37, PqXeNhanVienComponent_ng_template_171_ng_template_37_Template, 3, 1, "ng-template", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](38, "div", 129);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](39, "label", 130);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](40, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](41, "span", 131);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](42, "p-button", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_ng_template_171_Template_p_button_click_42_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r83 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r83.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](43, "p-button", 133);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_ng_template_171_Template_p_button_click_43_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r73); const ctx_r84 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](); return ctx_r84.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r28.organizes)("ngModel", ctx_r28.model.organizeId);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx_r28.model.orgId)("filterInputAutoFocus", true)("metaKeySelection", true)("filter", true)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](25, _c0, ctx_r28.departmentFiltes.length <= 0 ? "tree-empty" : ""))("options", ctx_r28.departmentFiltes);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r28.listStatus)("ngModel", ctx_r28.model.status)("filter", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("filter", true)("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r28.dataPositionList)("ngModel", ctx_r28.model.positionCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("filter", true)("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r28.workplaceOptions)("ngModel", ctx_r28.model.workplaceId);
} }
const _c1 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c2 = function () { return { showAll: "ALL" }; };
const _c3 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c4 = function () { return { width: "1000px", height: "auto" }; };
const _c5 = function () { return { width: "600px", height: "auto" }; };
const _c6 = function () { return { width: "50vw" }; };
const _c7 = function () { return { width: "700px" }; };
class PqXeNhanVienComponent {
    constructor(apiService, route, confirmationService, spinner, messageService, changeDetector, fileService, router) {
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.changeDetector = changeDetector;
        this.fileService = fileService;
        this.router = router;
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_0__.AllModules;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.modelTM = {};
        this.showVehicleCard = false;
        this.modelApprove = {};
        this.show = false;
        this.vehicleTypes = [];
        this.departmentList = [];
        this.listEmployees = [];
        this.displayVehicleApprove = false;
        this.imageLinksCard = [
            {
                cardVehicleId: null,
                id: null,
                type: "LICENSE",
                url: '',
            },
            {
                cardVehicleId: null,
                id: null,
                type: "LICENSE",
                url: '',
            },
            {
                cardVehicleId: null,
                id: null,
                type: "LICENSE_PLATE",
                url: '',
            },
        ];
        this.listStatus = [
            { label: 'Tất cả', value: -1 },
            { label: 'Mới tạo', value: 0 },
            { label: 'Hoạt động', value: 1 },
            { label: 'Khóa thẻ', value: 3 },
        ];
        this.cusId = null;
        this.first = 0;
        this.model = {
            organizeId: '',
            workplaceId: '',
            positionCd: '',
            orgId: '',
            filter: '',
            status: -1,
            offSet: 0,
            pageSize: 15
        };
        this.totalRecord = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.displayCreateVehicleCard = false;
        this.pagingComponent = {
            total: 0
        };
        this.loading = false;
        this.results = [];
        this.departmentFiltes = [];
        this.organizes = [];
        this.itemsBreadcrumb = [];
        this.itemsToolOfGrid = [];
        this.organizesAdds = [];
        this.displaySetting = false;
        this.gridKey = '';
        this.listsData = [];
        this.dataPositionList = [];
        this.workplaceOptions = [];
        this.multipleImage = true;
        this.listCard = [];
        this.loadjs = 0;
        this.heightGrid = 0;
        this.listUsers = [];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 38;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_4__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_5__.ButtonAgGridComponent,
        };
    }
    ngOnInit() {
        this.itemsBreadcrumb = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Phân quyền' },
            { label: 'Danh sách xe nhân viên' },
        ];
        this.model = {
            organizeId: '',
            orgId: '',
            filter: '',
            status: -1,
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.loadVehicelTypes();
        this.getOrganize();
        this.load();
        this.getPositionList();
        this.getWorkplaces();
        this.itemsToolOfGrid = [
            {
                label: 'Import file',
                code: 'Import',
                icon: 'pi pi-upload',
                disabled: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetEmployeeVehiclePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.IMPORT),
                command: () => {
                    this.importFileExel();
                }
            },
            {
                label: 'Export file',
                code: 'Import',
                icon: 'pi pi-download',
                disabled: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetEmployeeVehiclePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.EXPORT),
                command: () => {
                    this.exportExel();
                }
            },
        ];
    }
    onChangeUser(event) {
        this.GetHrmCardByCustId();
    }
    handleChangeOrganize() {
        this.model.orgId = '';
        this.getOrganizeTree();
        this.find();
    }
    getOrganize() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams)
            .subscribe((results) => {
            this.organizes = results.data
                .map(d => {
                return Object.assign({ label: d.organizationName || d.organizationCd, value: d.organizeId }, d);
            });
            this.organizesAdds = results.data
                .map(d => {
                return Object.assign({ label: d.organizationName || d.organizationCd, value: d.organizeId }, d);
            });
            this.modelTM.organizeId = this.organizesAdds[0].value;
            this.getUserByPush();
            this.organizes = [{ label: 'Tất cả', value: '' }, ...this.organizes];
        }),
            error => { };
    }
    getOrganizeTree() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify({ parentId: this.model.organizeId });
        this.apiService.getOrganizeTree(queryParams)
            .subscribe((results) => {
            if (results && results.status === 'success') {
                this.departmentFiltes = results.data;
            }
        }, error => { });
    }
    onChangeTree(a) {
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const query = Object.assign({}, this.model);
        // query.organizeId = typeof query.organizeId === 'string' ? query.organizeId : query.organizeId.org_cd;
        query.orgId = typeof query.orgId === 'string' ? query.orgId : query.orgId.orgId;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify(query);
        this.apiService.getEmployeeVehiclePage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.model.offSet === 0) {
                this.gridflexs = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.model.offSet = 0 : this.model.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.model.offSet) > this.model.pageSize) {
                this.countRecord.currentRecordEnd = this.model.offSet + Number(this.model.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.addVehicleApprove.bind(this),
                    label: 'Phê duyệt',
                    icon: 'fa fa-thumbs-up',
                    class: 'btn-primary mr5',
                    hide: this.CheckHideApprove(event)
                },
                {
                    onClick: this.editVehicleCard.bind(this),
                    label: 'Sửa xe',
                    icon: 'fa fa-edit',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetEmployeeVehiclePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.VIEW)
                },
                {
                    onClick: this.deleteCardVehicle.bind(this),
                    label: 'Xóa xe',
                    icon: 'pi pi-trash',
                    class: 'btn-danger mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetEmployeeVehiclePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.DELETE)
                },
                {
                    onClick: this.lockCardVehicle.bind(this),
                    label: 'Khóa',
                    icon: 'fa fa-lock',
                    class: 'btn-primary mr5',
                    hide: this.CheckHideLock(event)
                },
                {
                    onClick: this.unlockCardVehicle.bind(this),
                    label: 'Mở khóa',
                    icon: 'fa fa-unlock',
                    class: 'btn-primary mr5',
                    hide: this.CheckHideUnLock(event)
                },
            ]
        };
    }
    CheckHideUnLock(event) {
        let checkValue = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetEmployeeVehiclePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.KHOA_XE);
        if (checkValue) {
            return true;
        }
        else {
            if (event.data.statusId !== 3) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    CheckHideLock(event) {
        let checkValue = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetEmployeeVehiclePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.MO_KHOA_XE);
        if (checkValue) {
            return true;
        }
        else {
            if (event.data.statusId !== 1) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    CheckHideApprove(event) {
        let checkValue = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetEmployeeVehiclePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.PHE_DUYET);
        if (checkValue) {
            return true;
        }
        else {
            if (event.data.statusId !== 0) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    getPositionList() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify({ objKey: 'positiontype_group' });
        this.apiService.getCustObjectListNew(false, queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.dataPositionList = results.data.map(d => {
                    return {
                        label: d.objName,
                        value: d.objCode
                    };
                });
            }
        });
    }
    getWorkplaces() {
        this.apiService.getWorkplaces().subscribe(results => {
            if (results.status === 'success') {
                this.workplaceOptions = results.data.map(d => {
                    return {
                        label: d.workplaceName,
                        value: d.workplaceId
                    };
                });
            }
        });
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.gridflexs.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    paginate(event) {
        this.model.offSet = event.first;
        this.first = event.first;
        this.model.pageSize = event.rows;
        this.load();
    }
    search(event, type = 'add') {
        const params = {
            filter: event.query,
            departmentCd: '',
            isUser: -1,
            isApprove: -1,
            intVehicle: 0,
            isLock: -1,
            offSet: null,
            pageSize: null
        };
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify(params);
        this.apiService.getEmployeeList(queryParams).subscribe((repo) => {
            this.results = repo.data;
            if (type === 'edit') {
                const objcusId = this.results.filter(d => d.custId === this.modelTM.cusId);
                this.cusId = objcusId.length > 0 ? objcusId[0] : null;
            }
        });
    }
    onSelectCus(event) {
        this.modelTM.cusId = event.custId;
        // this.getOwnInfo(event.cif_No);
    }
    checkEnddate(isSend) {
        this.show = !isSend;
        if (this.show === false) {
            this.modelApprove.endTime = '';
        }
        else {
            this.modelApprove.endTime = new Date('01/01/2030');
        }
    }
    handlerError(error) {
        if (error.status === 401) {
            this.router.navigate(['/home']);
        }
    }
    datetostring(date) {
        let dd = date.getDate();
        let mm = date.getMonth() + 1; // January is 0!
        const yyyy = date.getFullYear();
        if (dd < 10) {
            dd = '0' + dd;
        }
        if (mm < 10) {
            mm = '0' + mm;
        }
        return dd + '/' + mm + '/' + yyyy;
    }
    // editVehicleCard(event): void {
    //   const cardVehicleId = event.rowData.cardVehicleId;
    //   if (cardVehicleId === null || cardVehicleId === 0) {
    //     alert('Cần phê duyệt');
    //   } else {
    //     this.apiService.getCardVehicleDetail(cardVehicleId).subscribe(
    //       (results: any) => {
    //         this.modelTM.type = 2;
    //         this.modelTM.cardVehicleId = results.data.cardVehicleId;
    //         this.modelTM.vehicleNoTM = results.data.vehicleNo;
    //         this.modelTM.organizeId = event.rowData.organizeId;
    //         this.modelTM.vehicleNameTM = results.data.vehicleName;
    //         this.modelTM.vehicleTypeIdTM = results.data.vehicleTypeId;
    //         this.modelTM.vehiclecardCd = results.data.cardCd;
    //         this.modelTM.startTimeTM = stringtodate(results.data.startTime);
    //         this.modelTM.endTimeTM = results.data.endTime ? stringtodate(results.data.endTime) : '';
    //         this.showVehicleCard = this.modelTM.endTimeTM ? true : false;
    //         this.displayCreateVehicleCard = true;
    //         this.modelTM.cusId = event.rowData.custId;
    //         this.getUserByPush();
    //         old --- this.search({ query: results.data.fullName }, 'edit');
    //         old --- this.show_dialogcreate = true;
    //       }, error => this.handlerError(error));
    //   }
    // }
    editVehicleCard(event) {
        console.log('event event event event', event);
        const cardVehicleId = event.rowData.cardVehicleId;
        this.modelTM.imageLinks = (0,lodash__WEBPACK_IMPORTED_MODULE_7__.cloneDeep)(this.imageLinksCard);
        if (cardVehicleId === null || cardVehicleId === 0) {
            alert('Cần phê duyệt');
        }
        else {
            this.apiService.getDetailEmployeeVehicleInfo(cardVehicleId).subscribe((results) => {
                this.modelTM.type = 2;
                this.modelTM.cardVehicleId = results.data.cardVehicleId;
                this.modelTM.vehicleNoTM = results.data.vehicleNo;
                this.modelTM.organizeId = event.rowData.organizeId;
                this.modelTM.vehicleNameTM = results.data.vehicleName;
                this.modelTM.vehicleTypeIdTM = results.data.vehicleTypeId;
                this.modelTM.vehiclecardCd = results.data.cardId;
                this.modelTM.startTimeTM = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.stringtodate)(results.data.startTime);
                this.modelTM.endTimeTM = results.data.endTime ? (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.stringtodate)(results.data.endTime) : '';
                this.showVehicleCard = this.modelTM.endTimeTM ? true : false;
                this.displayCreateVehicleCard = true;
                this.modelTM.noteTM = results.data.note;
                this.modelTM.vehicleColorTM = results.data.vehicleColor;
                this.imageLinksCard[0].cardVehicleId = this.modelTM.cardVehicleId;
                this.imageLinksCard[1].cardVehicleId = this.modelTM.cardVehicleId;
                this.imageLinksCard[2].cardVehicleId = this.modelTM.cardVehicleId;
                this.modelTM.cusId = event.rowData.custId;
                // this.modelTM.cardId = results.data.cardId;
                this.getImageUrl(results.data.imageLinks);
                this.getUserByPush();
                this.GetHrmCardByCustId();
                // this.search({ query: results.data.fullName }, 'edit');
                // this.show_dialogcreate = true;
            }, error => this.handlerError(error));
        }
    }
    getImageUrl(datas) {
        if (datas[0]) {
            this.modelTM.imageLinks[0] = datas[0];
        }
        else {
            this.modelTM.imageLinks[0] = this.imageLinksCard[0];
        }
        if (datas[1]) {
            this.modelTM.imageLinks[1] = datas[1];
        }
        else {
            this.modelTM.imageLinks[1] = this.imageLinksCard[1];
        }
        if (datas[2]) {
            this.modelTM.imageLinks[2] = datas[2];
        }
        else {
            this.modelTM.imageLinks[2] = this.imageLinksCard[2];
        }
    }
    SaveVehicleCard() {
        let startTimeTm = null;
        let endTimeTm = null;
        if (this.modelTM.endTimeTM === '') {
            startTimeTm = null;
            endTimeTm = null;
        }
        else {
            startTimeTm = this.datetostring(this.modelTM.startTimeTM);
            endTimeTm = this.datetostring(this.modelTM.endTimeTM);
        }
        if (!this.modelTM.imageLinks[0].url || !this.modelTM.imageLinks[1].url || !this.modelTM.imageLinks[2].url) {
            this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Vui lòng upload ảnh' });
            return;
        }
        this.apiService.setCardVehicle(this.modelTM.cardVehicleId, null, this.modelTM.vehicleTypeIdTM, this.modelTM.vehicleNoTM, this.modelTM.vehicleColorTM, this.modelTM.vehicleNameTM, startTimeTm, endTimeTm, this.modelTM.noteTM, this.modelTM.cusId, this.modelTM.imageLinks).subscribe((results) => {
            if (results.status === 'error') {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
            }
            else {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Cập nhật vé xe thành công' });
                this.displayCreateVehicleCard = false;
                this.load();
            }
        }, error => { });
        // if(this.imageLinksCard[0].url && this.imageLinksCard[1].url && this.imageLinksCard[2].url) {
        // }
        // else{
        // this.displayCreateVehicleCard = false;
        //   this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Vui lòng cập nhật ảnh' });
        // }
        // this.loadCardVip(this.model.custId);
    }
    GetHrmCardByCustId() {
        const queryParam = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify({ custId: this.modelTM.cusId });
        this.apiService.getHrmCardByCustId(queryParam).subscribe((results) => {
            if (results.status === 'success') {
                this.listCard = results.data.map(d => {
                    return { label: d.cardCd, value: d.cardId };
                });
            }
        }, error => this.handlerError(error));
    }
    uploadImageVehicle(event, index) {
        if (event.currentFiles.length > 0) {
            for (let file of event.currentFiles) {
                const getDAte = new Date();
                const getTime = getDAte.getTime();
                const storageRef = firebase__WEBPACK_IMPORTED_MODULE_8__.storage().ref();
                const uploadTask = storageRef.child(`s-hrm/file-attach/${getTime}-${file.name}`).put(file);
                uploadTask.on('state_changed', (snapshot) => {
                }, (error) => {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: error.message });
                    this.spinner.hide();
                }, () => {
                    uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
                        if (downloadURL) {
                            this.spinner.hide();
                            if (this.modelTM.imageLinks[index]) {
                                this.modelTM.imageLinks[index].url = downloadURL;
                            }
                        }
                    });
                });
            }
        }
        else {
            this.spinner.hide();
        }
    }
    deleteImg(index) {
        this.modelTM.imageLinks[index].url = '';
    }
    addVehicleApprove(event) {
        this.modelApprove.cardCd = '';
        this.modelApprove.cardVehicleId = event.rowData.cardVehicleId;
        this.modelApprove.endTime = new Date();
        this.displayVehicleApprove = true;
    }
    SaveVehicleApprove() {
        const dataSave = { cardVehicleId: this.modelApprove.cardVehicleId, cardCd: this.modelApprove.cardCd, endTime: '' };
        if (this.show) {
            dataSave.endTime = this.datetostring(this.modelApprove.endTime);
        }
        this.apiService.setVehicleApprove(dataSave).
            subscribe((response) => {
            if (response.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Phê duyệt vé xe thành công' });
                this.displayVehicleApprove = false;
                this.load();
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: response.message || 'Phê duyệt vé xe thất bại' });
            }
        }, error => {
            this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Phê duyệt vé xe thất bại' });
            console.error(error);
        });
    }
    lockCardVehicle(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện Khóa dịch vụ gửi xe này?',
            accept: () => {
                this.apiService.lockCardVehicle(event.rowData.cardVehicleId)
                    .subscribe((results) => {
                    if (results.status === 'success') {
                        this.load();
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Khóa dịch vụ gửi xe thành công' });
                    }
                    else {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                    }
                }, error => this.handlerError(error));
            }
        });
    }
    approveCardVehicle(event) {
        this.apiService.approveCardVehicle(event.rowData.cardVehicleId).then((results) => {
            if (results.status === 'success') {
                this.load();
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Thành công' });
            }
            else {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
            }
        }, error => this.handlerError(error));
    }
    unlockCardVehicle(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện Mở khóa dịch vụ gửi xe này?',
            accept: () => {
                this.apiService.unlockCardVehicle(event.rowData.cardVehicleId)
                    .subscribe((results) => {
                    if (results.status === 'success') {
                        this.load();
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Mở khóa dịch vụ gửi xe thành công' });
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results.message });
                    }
                }, error => this.handlerError(error));
            }
        });
    }
    deleteCardVehicle(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện xóa dịch vụ gửi xe này?',
            accept: () => {
                this.apiService.setVehicleRemove({ cardVehicleId: event.rowData.cardVehicleId })
                    .subscribe(response => {
                    if (response.status === 'success') {
                        this.load();
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Xóa dịch vụ xe thành công' });
                    }
                    else {
                        this.messageService.add({
                            severity: 'error', summary: 'Thông báo',
                            detail: response.message || 'Xóa dịch vụ gửi xe thất bại'
                        });
                    }
                }, error => {
                    this.handlerError(error);
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Xóa dịch vụ gửi xe thất bại' });
                });
            }
        });
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
        this.changeDetector.detectChanges();
    }
    loadVehicelTypes() {
        this.apiService.getVehicleTypes().subscribe((results) => {
            this.vehicleTypes = results.data;
            // this.loadCardVip(this.model.custId);
        }, error => { });
    }
    find() {
        this.load();
    }
    cancel() {
        this.model = {
            organizeId: '',
            workplaceId: '',
            positionCd: '',
            orgId: '',
            filter: '',
            status: -1,
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.model.filter = '';
        this.model.status = -1;
        this.model.departmentCd = '';
        this.load();
    }
    addVehicleCard() {
        this.modelTM.type = 1;
        this.modelTM.organizeId = this.organizesAdds[0].value;
        this.modelTM.cardVehicleId = 0;
        this.modelTM.vehicleNoTM = '';
        this.modelTM.vehicleNameTM = '';
        this.modelTM.vehicleTypeIdTM = 1;
        this.modelTM.vehiclecardCd = this.model.cardId;
        this.modelTM.startTimeTM = new Date();
        this.modelTM.endTimeTM = new Date();
        this.modelTM.cusId = '';
        this.displayCreateVehicleCard = true;
        this.modelTM.vehicleColorTM = '';
        this.modelTM.noteTM = '';
        this.modelTM.imageLinks = (0,lodash__WEBPACK_IMPORTED_MODULE_7__.cloneDeep)(this.imageLinksCard);
    }
    getEmployeeVehicleInfo() {
    }
    checkEnddateVehicleCard(isSend) {
        this.showVehicleCard = !isSend;
        if (this.showVehicleCard === false) {
            this.modelTM.endTimeTM = '';
        }
        else {
            this.modelTM.endTimeTM = new Date('01/01/2030');
        }
    }
    changePageSize() {
        this.load();
    }
    exportExel() {
        this.spinner.show();
        this.model.pageSize = 1000000;
        const query = Object.assign({}, this.model);
        query.organizeId = typeof query.organizeId === 'string' ? query.organizeId : query.organizeId.org_cd;
        query.orgId = typeof query.orgId === 'string' ? query.orgId : query.orgId.orgId;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify(query);
        this.apiService.getEmployeeVehiclePage(queryParams).subscribe((results) => {
            const dataExport = [];
            let gridflexs = results.data.gridflexs;
            let arrKey = gridflexs.map(elementName => elementName.columnField);
            let dataList = results.data.dataList.data;
            for (let elementValue of dataList) {
                const data = {};
                for (let elementName of gridflexs) {
                    if (arrKey.indexOf(elementName.columnField) > -1 && !elementName.isHide && elementName.columnField !== 'statusName') {
                        data[elementName.columnCaption] = elementValue[elementName.columnField] || '';
                    }
                }
                data['Trạng thái'] = elementValue.statusId === 0 ? 'Mới tạo' : elementValue.statusId === 1 ? 'Hoạt động' : 'Khóa thẻ';
                dataExport.push(data);
            }
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách xe nhân viên ' + new Date());
            this.spinner.hide();
        });
    }
    importFileExel() {
        this.router.navigate(['/phan-quyen/xe-nhan-vien/import']);
    }
    getUserByPush() {
        this.spinner.show();
        this.listUsers = [];
        this.apiService.getEmployeeSearch(querystring__WEBPACK_IMPORTED_MODULE_1__.stringify({ organizeId: this.modelTM.organizeId })).subscribe(results => {
            if (results.status === 'success') {
                this.listUsers = results.data.map(d => {
                    return Object.assign({ label: d.fullName + '-' + d.phone + '-' + d.code, value: d.custId, roleName: 'user' }, d);
                });
                this.modelTM.cusId = this.modelTM.cusId ? this.modelTM.cusId : this.listUsers[0].value;
                this.spinner.hide();
            }
            else {
                this.spinner.hide();
            }
        });
    }
}
PqXeNhanVienComponent.ɵfac = function PqXeNhanVienComponent_Factory(t) { return new (t || PqXeNhanVienComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_15__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_16__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_17__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_16__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_14__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_6__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_15__.Router)); };
PqXeNhanVienComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({ type: PqXeNhanVienComponent, selectors: [["app-pq-xe-nhan-vien"]], decls: 174, vars: 84, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "end", "bottom", "gap-12", "col-9", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["_ngcontent-gwb-c197", "", "width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["_ngcontent-gwb-c197", "", "fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56 ml-1", 3, "click"], ["width", "18", "height", "18", "viewBox", "0 0 18 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M10.2002 13.2H13.2002V10.2H14.8002V13.2H17.8002V14.8H14.8002V17.7999H13.2002V14.8H10.2002V13.2Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 0.199951H7.8002V7.79995H0.200195V0.199951ZM6.2002 1.79995H1.8002V6.19995H6.2002V1.79995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.8002 7.79995H10.2002V0.199951H17.8002V7.79995ZM11.8002 6.19995H16.2002V1.79995H11.8002V6.19995Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M0.200195 10.2H7.8002V17.7999H0.200195V10.2ZM6.2002 11.8H1.8002V16.2H6.2002V11.8Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", 3, "CheckHideActions", "click"], ["d", "M11 5H9V9H5V11H9V15H11V11H15V9H11V5ZM10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM10 18C5.59 18 2 14.41 2 10C2 5.59 5.59 2 10 2C14.41 2 18 5.59 18 10C18 14.41 14.41 18 10 18Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], [3, "visible", "baseZIndex", "modal", "visibleChange"], ["action", ""], ["createSMSF1", "ngForm"], [1, "box-body"], [1, "row"], [1, "col-sm-6", "form-group"], [1, "field-group", "select", "label-8"], ["for", ""], ["appendTo", "body", "name", "organizeId", 3, "baseZIndex", "options", "ngModel", "autoDisplayFirst", "filter", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "field-group", "select", 3, "ngClass"], ["appendTo", "body", "name", "cusId", 3, "baseZIndex", "options", "ngModel", "autoDisplayFirst", "filter", "ngModelChange", "onChange"], [1, "col-sm-6"], ["style", "color:red", 4, "ngIf"], ["appendTo", "body", "name", "vehiclecardCd", 3, "required", "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange"], ["vehiclecardCd", "ngModel"], ["class", "alert-validation alert-danger", 4, "ngIf"], ["name", "vehicleTypeIdTM", "id", "vehicleTypeIdTM", 1, "form-control", 3, "disabled", "ngModel", "ngModelChange"], ["vehicleTypeIdTM", "ngModel"], [3, "value", "selected", 4, "ngFor", "ngForOf"], [1, "field-group", "text", "label-8"], [2, "color", "red"], ["type", "text", "name", "vehicleNoTM", "id", "vehicleNoTM", "required", "", "placeholder", "Bi\u1EC3n s\u1ED1 xe", 1, "form-control", 3, "ngModel", "ngModelChange"], ["vehicleNoTM", "ngModel"], ["type", "text", "name", "vehicleNameTM", "id", "vehicleNameTM", "required", "", "placeholder", "T\u00EAn xe", 1, "form-control", 3, "ngModel", "ngModelChange"], ["vehicleNameTM", "ngModel"], [1, "field-group", "date", "label-8"], [1, "datepicker-container"], ["appendTo", "body", "name", "startTimeTM", "dateFormat", "dd/mm/yy", 3, "ngModel", "baseZIndex", "ngModelChange"], [1, "col-sm-6", "mb-5"], [1, "mb-1", 2, "margin-bottom", "10px", "font-weight", "500", "display", "block"], [1, "checkbox-default", "d-flex", "mb-0"], ["id", "vo-han", "name", "isEnddateVehicleCard", "type", "radio", 3, "checked", "click"], ["for", "vo-han", 1, "mb-0"], ["id", "ngay-het-han", "name", "isEnddateVehicleCard", "type", "radio", 3, "checked", "click"], ["for", "ngay-het-han", 1, "mb-0"], ["class", "datepicker-container", 4, "ngIf"], ["type", "text", "name", "vehicleColorTM", "id", "vehicleColorTM", "placeholder", "Nh\u1EADp m\u00E0u xe", 1, "form-control", 3, "ngModel", "ngModelChange"], ["vehicleColorTM", "ngModel"], [1, "field-group", "textarea", "label-8"], ["name", "noteTM", "id", "noteTM", "placeholder", "Nh\u1EADp ghi ch\u00FA", 1, "form-control", 3, "ngModel", "ngModelChange"], ["noteTM", "ngModel"], [1, "d-flex"], ["class", "col-md-4 image-vehicle", 4, "ngFor", "ngForOf"], [1, "row", "mt-1"], [1, "col-md-6"], [1, "col-md-6", "text-right"], ["icon", "pi pi-check", "styleClass", "p-button-sm mr-1", 3, "label", "onClick"], ["label", "\u0110\u00F3ng", "icon", "pi pi-times", "styleClass", "p-button-sm p-button-secondary mr-1", 3, "onClick"], ["createSMSF", "ngForm"], [1, "col-md-12"], ["type", "text", "name", "cardCd", "id", "cardCd", "required", "", "placeholder", "M\u00E3 th\u1EBB", 1, "form-control", 3, "ngModel", "ngModelChange"], ["cardCd", "ngModel"], [1, "control-label", 2, "margin-bottom", "10px", "font-weight", "500", "display", "block"], ["id", "vo-han", "name", "isEnddate", "type", "radio", "checked", "", 3, "click"], ["for", "het-han-ngay"], ["id", "het-han-ngay", "name", "isEnddate", "type", "radio", 3, "click"], ["label", "T\u1EA1o th\u1EBB", "icon", "pi pi-check", "styleClass", "p-button-sm mr-1", 3, "onClick"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], ["styleClass", "menu-option-right", 3, "model", "appendTo", "popup"], ["menuButton", ""], [3, "listsData", "height", "columnDefs", "showConfig"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"], [2, "vertical-align", "middle"], [1, "alert-validation", "alert-danger"], [4, "ngIf"], [3, "value", "selected"], [1, "field-group", "date", "label-8", 3, "ngClass"], ["appendTo", "body", "name", "endTimeTM", "dateFormat", "dd/mm/yy", 3, "ngModel", "baseZIndex", "ngModelChange"], [1, "col-md-4", "image-vehicle"], [1, "img"], ["alt", "Image", 3, "src", "preview"], ["mode", "basic", "name", "demo[]", "accept", "image/*", 3, "chooseIcon", "maxFileSize", "onSelect"], ["class", "pi pi-times delete-image", 3, "click", 4, "ngIf"], [1, "pi", "pi-times", "delete-image", 3, "click"], [1, "field-group", "date", 3, "ngClass"], ["appendTo", "body", "name", "endTime", "dateFormat", "dd/mm/yy", 3, "ngModel", "baseZIndex", "ngModelChange"], [3, "typeConfig", "gridKey"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", "valid"], ["appendTo", "body", "name", "organizeId", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange", "onChange"], [1, "field-group", "select", "mb-0", "label-8"], ["selectionMode", "single", "name", "orgId", "placeholder", "Ch\u1ECDn ph\u00F2ng ban", 3, "ngModel", "filterInputAutoFocus", "metaKeySelection", "filter", "ngClass", "options", "ngModelChange", "onNodeSelect"], ["appendTo", "body", "name", "status", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "onChange", "ngModelChange"], ["placeholder", "Ch\u1ECDn ch\u1EE9c v\u1EE5", "appendTo", "body", "name", "position", 3, "filter", "baseZIndex", "autoDisplayFirst", "options", "ngModel", "onChange", "ngModelChange"], ["placeholder", "N\u01A1i l\u00E0m vi\u1EC7c", "appendTo", "body", "name", "position", 3, "filter", "baseZIndex", "autoDisplayFirst", "options", "ngModel", "onChange", "ngModelChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"]], template: function PqXeNhanVienComponent_Template(rf, ctx) { if (rf & 1) {
        const _r85 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("keydown.enter", function PqXeNhanVienComponent_Template_input_keydown_enter_8_listener() { ctx.model.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function PqXeNhanVienComponent_Template_input_ngModelChange_8_listener($event) { return ctx.model.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_Template_span_click_9_listener() { ctx.model.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_Template_p_button_click_15_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r85); const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](170); return _r27.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](21, "p-button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_Template_p_button_click_21_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r85); const _r29 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](173); return _r29.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](22, "svg", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](23, "path", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](24, "path", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](25, "path", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](26, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](27, " \u00A0 Ti\u1EC7n \u00EDch ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](28, "p-button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_Template_p_button_click_28_listener() { return ctx.addVehicleCard(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](29, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](30, "path", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](31, " \u00A0 Th\u00EAm m\u1EDBi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](32, "section", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](33, "div", 29, 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](35, PqXeNhanVienComponent_app_list_grid_angular_35_Template, 1, 3, "app-list-grid-angular", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](36, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](37, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](38);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](39, "p-paginator", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("onPageChange", function PqXeNhanVienComponent_Template_p_paginator_onPageChange_39_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](40, "p-dialog", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("visibleChange", function PqXeNhanVienComponent_Template_p_dialog_visibleChange_40_listener($event) { return ctx.displayCreateVehicleCard = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](41, "p-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](42);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](43, "form", 35, 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](45, "div", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](46, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](47, "div", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](48, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](49, "label", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](50, "Ch\u1ECDn t\u1ED5 ch\u1EE9c");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](51, "p-dropdown", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_Template_p_dropdown_ngModelChange_51_listener($event) { return ctx.modelTM.organizeId = $event; })("onChange", function PqXeNhanVienComponent_Template_p_dropdown_onChange_51_listener() { return ctx.getUserByPush(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](52, PqXeNhanVienComponent_ng_template_52_Template, 2, 1, "ng-template", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](53, PqXeNhanVienComponent_ng_template_53_Template, 3, 1, "ng-template", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](54, "div", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](55, "div", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](56, "label", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](57, "Nh\u00E2n vi\u00EAn");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](58, "p-dropdown", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_Template_p_dropdown_ngModelChange_58_listener($event) { return ctx.modelTM.cusId = $event; })("onChange", function PqXeNhanVienComponent_Template_p_dropdown_onChange_58_listener($event) { return ctx.onChangeUser($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](59, PqXeNhanVienComponent_ng_template_59_Template, 2, 1, "ng-template", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](60, PqXeNhanVienComponent_ng_template_60_Template, 3, 1, "ng-template", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](61, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](62, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](63, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](64, "M\u00E3 th\u1EBB ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](65, PqXeNhanVienComponent_span_65_Template, 2, 0, "span", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](66, "p-dropdown", 49, 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_Template_p_dropdown_ngModelChange_66_listener($event) { return ctx.modelTM.vehiclecardCd = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](68, PqXeNhanVienComponent_ng_template_68_Template, 2, 1, "ng-template", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](69, PqXeNhanVienComponent_ng_template_69_Template, 3, 1, "ng-template", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](70, PqXeNhanVienComponent_div_70_Template, 2, 1, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](71, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](72, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](73, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](74, "Lo\u1EA1i xe");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](75, "select", 52, 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_Template_select_ngModelChange_75_listener($event) { return ctx.modelTM.vehicleTypeIdTM = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](77, PqXeNhanVienComponent_option_77_Template, 2, 3, "option", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](78, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](79, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](80, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](81, "Bi\u1EC3n s\u1ED1 xe ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](82, "span", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](83, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](84, "input", 57, 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_Template_input_ngModelChange_84_listener($event) { return ctx.modelTM.vehicleNoTM = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](86, PqXeNhanVienComponent_div_86_Template, 2, 1, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](87, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](88, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](89, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](90, "T\u00EAn xe ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](91, "span", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](92, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](93, "input", 59, 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_Template_input_ngModelChange_93_listener($event) { return ctx.modelTM.vehicleNameTM = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](95, PqXeNhanVienComponent_div_95_Template, 2, 1, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](96, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](97, "div", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](98, "div", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](99, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](100, "Ng\u00E0y b\u1EAFt \u0111\u1EA7u");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](101, "p-calendar", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_Template_p_calendar_ngModelChange_101_listener($event) { return ctx.modelTM.startTimeTM = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](102, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](103, "div", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](104, "Ng\u00E0y k\u1EBFt th\u00FAc");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](105, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](106, "div", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](107, "input", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_Template_input_click_107_listener() { return ctx.checkEnddateVehicleCard(true); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](108, "label", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](109, "V\u00F4 h\u1EA1n");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](110, "div", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](111, "div", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](112, "input", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_Template_input_click_112_listener() { return ctx.checkEnddateVehicleCard(false); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](113, "label", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](114, "H\u1EBFt h\u1EA1n ng\u00E0y");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](115, PqXeNhanVienComponent_div_115_Template, 5, 3, "div", 71);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](116, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](117, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](118, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](119, "M\u00E0u xe ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](120, "input", 72, 73);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_Template_input_ngModelChange_120_listener($event) { return ctx.modelTM.vehicleColorTM = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](122, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](123, "div", 74);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](124, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](125, "Ghi ch\u00FA ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](126, "textarea", 75, 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_Template_textarea_ngModelChange_126_listener($event) { return ctx.modelTM.noteTM = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](128, "div", 77);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](129, PqXeNhanVienComponent_div_129_Template, 7, 6, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](130, "div", 79);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](131, "div", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](132, "div", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](133, "p-button", 82);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("onClick", function PqXeNhanVienComponent_Template_p_button_onClick_133_listener() { return ctx.SaveVehicleCard(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](134, "p-button", 83);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("onClick", function PqXeNhanVienComponent_Template_p_button_onClick_134_listener() { return ctx.displayCreateVehicleCard = !ctx.displayCreateVehicleCard; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](135, "p-dialog", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("visibleChange", function PqXeNhanVienComponent_Template_p_dialog_visibleChange_135_listener($event) { return ctx.displayVehicleApprove = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](136, "p-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](137, " Ph\u00EA duy\u1EC7t v\u00E9 xe ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](138, "form", 35, 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](140, "div", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](141, "div", 85);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](142, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](143, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](144, "M\u00E3 th\u1EBB ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](145, "span", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](146, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](147, "input", 86, 87);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function PqXeNhanVienComponent_Template_input_ngModelChange_147_listener($event) { return ctx.modelApprove.cardCd = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](149, PqXeNhanVienComponent_div_149_Template, 2, 1, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](150, "div", 85);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](151, "label", 88);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](152, "Ng\u00E0y h\u1EBFt h\u1EA1n");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](153, "div", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](154, "label", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](155, "V\u00F4 h\u1EA1n");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](156, "input", 89);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_Template_input_click_156_listener() { return ctx.checkEnddate(true); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](157, "div", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](158, "label", 90);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](159, "H\u1EBFt h\u1EA1n ng\u00E0y");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](160, "input", 91);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function PqXeNhanVienComponent_Template_input_click_160_listener() { return ctx.checkEnddate(false); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](161, PqXeNhanVienComponent_div_161_Template, 5, 3, "div", 71);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](162, "div", 79);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](163, "div", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](164, "div", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](165, "p-button", 92);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("onClick", function PqXeNhanVienComponent_Template_p_button_onClick_165_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r85); const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](139); ctx.SaveVehicleApprove(); return _r22.reset(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](166, "p-button", 83);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("onClick", function PqXeNhanVienComponent_Template_p_button_onClick_166_listener() { return ctx.displayVehicleApprove = !ctx.displayVehicleApprove; });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](167, "p-dialog", 93);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("visibleChange", function PqXeNhanVienComponent_Template_p_dialog_visibleChange_167_listener($event) { return ctx.displaySetting = $event; })("onHide", function PqXeNhanVienComponent_Template_p_dialog_onHide_167_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](168, PqXeNhanVienComponent_app_config_grid_table_form_168_Template, 1, 2, "app-config-grid-table-form", 94);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](169, "p-overlayPanel", 95, 96);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](171, PqXeNhanVienComponent_ng_template_171_Template, 44, 27, "ng-template", 97);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](172, "p-menu", 98, 99);
    } if (rf & 2) {
        const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](67);
        const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](85);
        const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](94);
        const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](148);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("items", ctx.itemsBreadcrumb);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngClass", ctx.model.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.model.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction2"](74, _c1, ctx.MENUACTIONROLEAPI.GetEmployeeVehiclePage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("rows", ctx.model.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](78, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](77, _c2)));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](80, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("visible", ctx.displayCreateVehicleCard)("baseZIndex", 99)("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", (ctx.modelTM == null ? null : ctx.modelTM.cardVehicleId) ? "S\u1EEDa v\u00E9 g\u1EEDi xe" : "Th\u00EAm v\u00E9 g\u1EEDi xe", " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("baseZIndex", 100)("options", ctx.organizesAdds)("ngModel", ctx.modelTM.organizeId)("autoDisplayFirst", false)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngClass", (ctx.modelTM == null ? null : ctx.modelTM.cusId) ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("baseZIndex", 100)("options", ctx.listUsers)("ngModel", ctx.modelTM.cusId)("autoDisplayFirst", false)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.modelTM.vehicleTypeIdTM != 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("required", ctx.modelTM.vehicleTypeIdTM != 1)("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.listCard)("ngModel", ctx.modelTM.vehiclecardCd);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _r8.errors && (_r8.dirty || _r8.touched));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("disabled", ctx.modelTM.type == 2)("ngModel", ctx.modelTM.vehicleTypeIdTM);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx.vehicleTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.modelTM.vehicleNoTM);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _r14.errors && (_r14.dirty || _r14.touched));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.modelTM.vehicleNameTM);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _r16.errors && (_r16.dirty || _r16.touched));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.modelTM.startTimeTM)("baseZIndex", 100);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("checked", !ctx.modelTM.endTimeTM);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("checked", ctx.modelTM.endTimeTM);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.showVehicleCard);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.modelTM.vehicleColorTM);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.modelTM.noteTM);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx.modelTM.imageLinks);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpropertyInterpolate"]("label", ctx.modelTM.cardVehicleId ? " C\u1EADp nh\u1EADt " : "T\u1EA1o th\u1EBB");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](81, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("visible", ctx.displayVehicleApprove)("baseZIndex", 99)("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.modelApprove.cardCd);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _r23.errors && (_r23.dirty || _r23.touched));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.show);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](82, _c6));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](83, _c7));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("model", ctx.itemsToolOfGrid)("appendTo", "body")("popup", true);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_10__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_20__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_11__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_21__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_22__.Dialog, primeng_api__WEBPACK_IMPORTED_MODULE_16__.Header, _angular_forms__WEBPACK_IMPORTED_MODULE_19__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgForm, primeng_dropdown__WEBPACK_IMPORTED_MODULE_23__.Dropdown, primeng_api__WEBPACK_IMPORTED_MODULE_16__.PrimeTemplate, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.SelectControlValueAccessor, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgForOf, primeng_calendar__WEBPACK_IMPORTED_MODULE_24__.Calendar, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_25__.OverlayPanel, primeng_menu__WEBPACK_IMPORTED_MODULE_26__.Menu, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_12__.ListGridAngularComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_19__["ɵNgSelectMultipleOption"], primeng_image__WEBPACK_IMPORTED_MODULE_27__.Image, primeng_fileupload__WEBPACK_IMPORTED_MODULE_28__.FileUpload, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_13__.ConfigGridTableFormComponent, primeng_treeselect__WEBPACK_IMPORTED_MODULE_29__.TreeSelect], styles: [".box-body[_ngcontent-%COMP%]   .form-row[_ngcontent-%COMP%]:after {\n  content: \"\";\n  clear: both;\n  display: table;\n}\n\n.result_cus_item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  display: block;\n}\n\n[_nghost-%COMP%]  .search-user-by-phone ul li {\n  padding-top: 5px !important;\n  padding-bottom: 5px !important;\n}\n\n.search-user-by-phone[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  padding-top: 5px !important;\n  padding-bottom: 5px !important;\n}\n\n[_nghost-%COMP%]  .image-vehicle .img {\n  position: relative;\n  max-height: 180px;\n  border: 1px solid #cccc;\n  overflow: hidden;\n  text-align: center;\n}\n\n[_nghost-%COMP%]  .image-vehicle .img img {\n  width: 100%;\n  height: auto;\n  min-height: 160px;\n}\n\n[_nghost-%COMP%]  .image-vehicle .img .p-fileupload-choose {\n  position: absolute;\n  right: 10px;\n  top: 10px;\n  width: 48px;\n  height: 30px;\n}\n\n[_nghost-%COMP%]  .image-vehicle .p-image-mask .ng-trigger {\n  height: calc(100% - 120px);\n}\n\n[_nghost-%COMP%]  .image-vehicle .p-image-mask .ng-trigger img {\n  height: 100%;\n}\n\n[_nghost-%COMP%]  .delete-image {\n  width: 50px;\n  height: 31px;\n  position: absolute;\n  top: 10px;\n  right: 9px;\n  background: #fff;\n  line-height: 31px;\n  color: red;\n  z-index: 7;\n  cursor: pointer;\n  border-radius: 4px;\n  border: 1px solid #ccc;\n  box-shadow: 1px 1px 3px #ccc;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBxLXhlLW5oYW4tdmllbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFUTtFQUNJLFdBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtBQURaOztBQU1JO0VBQ0ksY0FBQTtBQUhSOztBQVNZO0VBQ0ksMkJBQUE7RUFDQSw4QkFBQTtBQU5oQjs7QUFhUTtFQUNJLDJCQUFBO0VBQ0EsOEJBQUE7QUFWWjs7QUFnQkk7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FBYlI7O0FBY1E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FBWlo7O0FBY1E7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNKLFlBQUE7QUFaUjs7QUFnQlE7RUFDSSwwQkFBQTtBQWRaOztBQWVZO0VBQ0ksWUFBQTtBQWJoQjs7QUFtQkk7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLDRCQUFBO0FBaEJSIiwiZmlsZSI6InBxLXhlLW5oYW4tdmllbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ib3gtYm9keXtcclxuICAgIC5mb3JtLXJvd3tcclxuICAgICAgICAmOmFmdGVye1xyXG4gICAgICAgICAgICBjb250ZW50OiAnJztcclxuICAgICAgICAgICAgY2xlYXI6IGJvdGg7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IHRhYmxlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4ucmVzdWx0X2N1c19pdGVte1xyXG4gICAgc3BhbntcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIH1cclxufVxyXG46aG9zdDo6bmctZGVlcHtcclxuICAgIC5zZWFyY2gtdXNlci1ieS1waG9uZXtcclxuICAgICAgICB1bHtcclxuICAgICAgICAgICAgbGl7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLXRvcDogNXB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogNXB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuLnNlYXJjaC11c2VyLWJ5LXBob25le1xyXG4gICAgdWx7XHJcbiAgICAgICAgbGl7XHJcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiA1cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDVweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3Q6Om5nLWRlZXAgLmltYWdlLXZlaGljbGV7XHJcbiAgICAuaW1ne1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICBtYXgtaGVpZ2h0OiAxODBweDtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjY2NjYztcclxuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICBpbWd7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDE2MHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAucC1maWxldXBsb2FkLWNob29zZXtcclxuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICByaWdodDogMTBweDtcclxuICAgICAgICAgICAgdG9wOiAxMHB4O1xyXG4gICAgICAgICAgICB3aWR0aDogNDhweDtcclxuICAgICAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLnAtaW1hZ2UtbWFza3tcclxuICAgICAgICAubmctdHJpZ2dlcntcclxuICAgICAgICAgICAgaGVpZ2h0OiBjYWxjKDEwMCUgLSAxMjBweCk7XHJcbiAgICAgICAgICAgIGltZ3tcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG46aG9zdDo6bmctZGVlcHtcclxuICAgIC5kZWxldGUtaW1hZ2V7XHJcbiAgICAgICAgd2lkdGg6IDUwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiAzMXB4O1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB0b3A6IDEwcHg7XHJcbiAgICAgICAgcmlnaHQ6IDlweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAzMXB4O1xyXG4gICAgICAgIGNvbG9yOiByZWQ7XHJcbiAgICAgICAgei1pbmRleDogNztcclxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgICAgICAgYm94LXNoYWRvdzogMXB4IDFweCAzcHggI2NjYztcclxuICAgIH1cclxufSJdfQ== */"] });


/***/ }),

/***/ 3319:
/*!*******************************************************************************!*\
  !*** ./src/app/components/thiet-bi-thang-may/thiet-bi-thang-may.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ThietBiThangMayComponent": () => (/* binding */ ThietBiThangMayComponent)
/* harmony export */ });
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);




















function ThietBiThangMayComponent_app_list_grid_angular_15_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "app-list-grid-angular", 44);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function ThietBiThangMayComponent_option_33_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "option", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("value", advert_r12.projectCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", advert_r12.projectName, " ");
} }
function ThietBiThangMayComponent_div_37_option_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "option", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const objBuilding_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("value", objBuilding_r15.buildCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", objBuilding_r15.buildName, " ");
} }
function ThietBiThangMayComponent_div_37_Template(rf, ctx) { if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "select", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function ThietBiThangMayComponent_div_37_Template_select_change_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r17); const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r16.getBuildingZones(); })("ngModelChange", function ThietBiThangMayComponent_div_37_Template_select_ngModelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r17); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r18.modelElevator.buildCd = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "option", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3, "Ch\u1ECDn t\u00F2a");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](4, ThietBiThangMayComponent_div_37_option_4_Template, 2, 2, "option", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", ctx_r5.modelElevator.buildCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx_r5.modelBuilding);
} }
function ThietBiThangMayComponent_option_47_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "option", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r19 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("value", advert_r19.buildZoneName);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", advert_r19.buildZoneName, " ");
} }
function ThietBiThangMayComponent_option_64_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "option", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("value", advert_r21.floorNumber);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", advert_r21.floorName, " ");
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { showAll: "ALL" }; };
const _c2 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c3 = function () { return { width: "600px", height: "auto" }; };
class ThietBiThangMayComponent {
    constructor(apiService, route, spinner, changeDetector, organizeInfoService, router) {
        this.apiService = apiService;
        this.route = route;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.items = [];
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_0__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_0__.ACTIONS;
        this.listShafts = [];
        this.model = {
            filter: '',
            projectCd: '',
            buildZone: '',
            buildCd: '',
            floorNumber: null,
            pageSize: 15,
            offset: 0,
            organizeIds: '',
        };
        this.modelElevator = {
            id: 0,
            hardwareId: '',
            floorName: '',
            buildCd: '',
            floorNumber: null,
            elevatorBank: 0,
            elevatorShaftName: '',
            elevatorShaftNumber: 0,
            projectCd: '',
            buildZone: '',
            isActived: false,
            sysDate: new Date(),
        };
        this.totalRecord = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.searchBuildzones = [];
        this.projects = [];
        this.builds = [];
        this.buidings = [];
        this.floors = [];
        this.floorsTypes = [];
        this.modelBuilding = [];
        this.buildzones = [];
        this.buildingZones = [];
        this.floorsCreate = [];
        this.searchFloors = [];
        this.columnDefs = [];
        this.listsData = [];
        this.cols = [];
        // getFloors() {
        //   this.apiService.GetBuildFloorByProjectCdBuildCd(this.modelElevator.projectCd, '').subscribe((results: any) => {
        //     this.floorsCreate = results.data;
        //   },error => { });
        // }
        this.loadjs = 0;
        this.heightGrid = 0;
        this.first = 0;
        this.isDialog = false;
        this.titleModal = 'Thêm thiết Lập';
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.model.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Phân quyền' },
            { label: 'Phân quyền thang máy', routerLink: '/phan-quyen/phan-quyen-thang-may' },
            { label: 'Thiết bị thang máy' },
        ];
        this.getProjectCd();
    }
    getBuidingsSearch() {
        this.apiService.getBuildCdByProjectCd(this.model.projectCd).subscribe((res) => {
            if (res) {
                this.builds = res.data;
            }
        });
    }
    findBuildZone() {
        this.searchBuildzones = [];
        this.apiService.getBuildZoneByBuildCd(this.model.projectCd, this.model.buildCd).subscribe((results) => {
            this.searchBuildzones = results.data;
        });
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        this.apiService.getElevatorDevicePage(this.model.filter, this.model.offset, this.model.pageSize, this.model.projectCd, this.model.buildZone, this.model.buildCd, this.model.floorNumber).subscribe((results) => {
            this.listsData = results.data;
            if (this.model.offset === 0) {
                this.cols = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.recordsTotal;
            this.countRecord.totalRecord = results.recordsTotal;
            this.countRecord.currentRecordStart = this.model.offset + 1;
            if ((results.recordsTotal - this.model.offset) > this.model.pageSize) {
                this.countRecord.currentRecordEnd = this.model.offset + Number(this.model.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.recordsTotal;
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editElevatordevice.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_0__.MENUACTIONROLEAPI.GetElevatorDevicePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_0__.ACTIONS.VIEW)
                },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: 'Mã',
                cellClass: ['border-right'],
                field: 'id',
            },
            {
                headerName: 'Mã dự án',
                cellClass: ['border-right'],
                field: 'projectCd',
            },
            {
                headerName: 'Tên dự án',
                cellClass: ['border-right'],
                field: 'projectName',
            },
            {
                headerName: 'Mã thiết bị',
                cellClass: ['border-right'],
                field: 'hardwareId',
            },
            {
                headerName: 'Khu vực',
                cellClass: ['border-right'],
                field: 'buildZone',
            },
            {
                headerName: 'Tên tầng',
                cellClass: ['border-right'],
                field: 'floorName',
            },
            {
                headerName: 'Thứ tự',
                cellClass: ['border-right'],
                field: 'floorNumber',
            },
            {
                headerName: 'Trạng thái',
                cellClass: ['border-right'],
                field: 'isActived',
            },
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    getProjectCd() {
        this.apiService.getProjects().subscribe((results) => {
            this.projects = results.data;
        });
    }
    getBuildingZones() {
        this.buildingZones = [];
        this.apiService.getBuildZoneByBuildCd(this.modelElevator.projectCd, this.modelElevator.buildCd).subscribe((results) => {
            this.buildingZones = results.data;
        }, error => { });
        // this.apiService.getElevatorBankShafts(this.modelElevator.projectCd).subscribe((results: any) => {
        //   this.listShafts = results.data;
        // },error => { });
    }
    loadGetBuildings() {
        this.apiService.getBuildCdByProjectCd(this.modelElevator.projectCd).subscribe((res) => {
            if (res) {
                this.modelBuilding = res.data;
            }
        });
    }
    loadGetFloors() {
        this.floorsCreate = [];
        this.apiService.getElevatorFloors(this.modelElevator.buildCd).subscribe((res) => {
            if (res) {
                this.floorsCreate = res.data;
            }
        });
    }
    findFloors() {
        this.searchFloors = [];
        this.apiService.getElevatorFloors(this.model.buildCd).subscribe((res) => {
            if (res) {
                this.searchFloors = res.data;
            }
        });
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".breadcrumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + e.clientHeight + 73;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    addThietBi() {
        this.cancelModel();
        this.isDialog = true;
    }
    paginate(event) {
        this.model.offset = event.first;
        this.first = event.first;
        this.model.pageSize = event.rows === 4 ? 100000000 : event.rows;
        this.load();
    }
    find() {
        this.load();
    }
    cancel() {
        this.load();
        this.model = {
            filter: '',
            projectCd: '',
            buildZone: '',
            buildCd: ''
        };
    }
    onSave() {
        const floors = this.floorsCreate.filter(res => res.floorNumber == this.modelElevator.floorNumber);
        // const elevatorShafs = this.listShafts.filter(res => res.elevatorShaftName == this.modelElevator.elevatorShaftName);
        const params = {
            id: this.modelElevator.id,
            projectCd: this.modelElevator.projectCd,
            hardwareId: this.modelElevator.hardwareId,
            buildZone: this.modelElevator.buildZone,
            floorNumber: floors.length > 0 ? parseInt(floors[0].floorNumber) : 0,
            floorName: floors.length > 0 ? floors[0].floorName : '',
            elevatorShaftNumber: null,
            elevatorShaftName: null,
            sysDate: this.modelElevator.sysDate,
            isActived: this.modelElevator.isActived,
            elevatorBank: null,
            buildCd: this.modelElevator.buildCd
        };
        this.apiService.setMasElevatorDevice(params).subscribe((result) => {
            if (result.status === 'success') {
                this.isDialog = false;
                this.load();
            }
        });
    }
    editElevatordevice(event, idx) {
        const item = event.rowData;
        this.cancelModel();
        this.modelElevator.projectCd = item.projectCd;
        this.modelElevator.buildCd = item.buildCd;
        this.loadGetBuildings();
        this.getBuildingZones();
        this.loadGetFloors();
        this.modelElevator.id = item.id;
        this.modelElevator.floorNumber = item.floorNumber;
        this.modelElevator.elevatorBank = item.elevatorBank;
        this.modelElevator.floorName = item.floorName;
        this.modelElevator.elevatorShaftNumber = item.elevatorShaftNumber;
        this.modelElevator.elevatorShaftName = item.elevatorShaftName;
        this.modelElevator.buildZone = item.buildZone;
        this.modelElevator.isActived = item.isActived;
        this.modelElevator.sysDate = item.sysDate;
        this.modelElevator.hardwareId = item.hardwareId;
        this.isDialog = true;
    }
    cancelModel() {
        this.modelElevator = {
            id: 0,
            hardwareId: '',
            floorName: '',
            buildCd: '',
            floorNumber: null,
            elevatorBank: 0,
            elevatorShaftName: '',
            elevatorShaftNumber: 0,
            projectCd: '',
            buildZone: '',
            isActived: false,
            sysDate: new Date(),
        };
        this.modelBuilding = [];
        this.buildingZones = [];
        this.floorsCreate = [];
    }
}
ThietBiThangMayComponent.ɵfac = function ThietBiThangMayComponent_Factory(t) { return new (t || ThietBiThangMayComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_9__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_7__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_3__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router)); };
ThietBiThangMayComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({ type: ThietBiThangMayComponent, selectors: [["app-thiet-bi-thang-may"]], decls: 76, vars: 37, consts: [[1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-4", "pd-0"], [3, "items"], [1, "d-flex", "end", "bottom", "gap-12", "col-8", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["type", "text", "id", "filter", 1, "input-default", 3, "ngModel", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["_ngcontent-xmj-c197", "", "width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["_ngcontent-xmj-c197", "", "fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "p-button-sm height-56", "icon", "pi pi-plus", "label", "Th\u00EAm m\u1EDBi", 3, "CheckHideActions", "click"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], [3, "visible", "header", "visibleChange"], [1, "form-horizontal", "ng-pristine", "ng-valid", "ng-scope"], ["createElevatorfloor", "ngForm"], [1, "box-body", 2, "padding", "10px"], [1, "field-group", "select", "label-8"], [1, "control-label"], [2, "color", "red"], ["name", "projectCd", "id", "projectCd", 1, "form-control", 3, "ngModel", "change", "ngModelChange"], ["projectCd", "ngModel"], ["value", ""], [3, "value", 4, "ngFor", "ngForOf"], [4, "ngIf"], ["name", "buildZone", "id", "buildZone", 1, "form-control", 3, "ngModel", "change", "ngModelChange"], ["buildZone", "ngModel"], [1, "field-group", "text", "label-8", 3, "ngClass"], ["type", "text", "id", "hardwareId", "required", "", "name", "hardwareId", "placeholder", "M\u00E3 thi\u1EBFt b\u1ECB", 1, "form-control", 3, "ngModel", "ngModelChange"], ["hardwareId", "ngModel"], ["name", "floorNumber", "id", "floorNumber", 1, "form-control", 3, "ngModel", "ngModelChange"], ["floorNumber", "ngModel"], ["value", "", "selected", "selected"], [1, "checkbox-default", "d-flex"], [1, "form-check"], ["checked", "", "name", "isActived", "id", "isActived", "type", "checkbox", "value", "", 1, "form-check-input", 2, "margin-left", "5px", 3, "ngModel", "ngModelChange"], ["isActived", "ngModel"], [1, "form-row"], ["label", "L\u01B0u l\u1EA1i", "styleClass", "mr-2", 3, "CheckHideActions", "click"], ["label", "\u0110\u00F3ng", 3, "click"], [3, "listsData", "height", "columnDefs"], [3, "value"], ["name", "buildCd", 1, "form-control", 3, "ngModel", "change", "ngModelChange"]], template: function ThietBiThangMayComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](7, "input", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function ThietBiThangMayComponent_Template_input_ngModelChange_7_listener($event) { return ctx.model.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](8, "span", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ThietBiThangMayComponent_Template_span_click_8_listener() { ctx.model.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](9, "svg", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](10, "path", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](11, "p-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ThietBiThangMayComponent_Template_p_button_click_11_listener() { return ctx.addThietBi(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](12, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](13, "div", 12, 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](15, ThietBiThangMayComponent_app_list_grid_angular_15_Template, 1, 3, "app-list-grid-angular", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](16, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](17, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](19, "p-paginator", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("onPageChange", function ThietBiThangMayComponent_Template_p_paginator_onPageChange_19_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](20, "p-dialog", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("visibleChange", function ThietBiThangMayComponent_Template_p_dialog_visibleChange_20_listener($event) { return ctx.isDialog = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](21, "form", 18, 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](23, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](24, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](25, "label", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](26, "M\u00E3 d\u1EF1 \u00E1n ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](27, "span", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](28, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](29, "select", 24, 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function ThietBiThangMayComponent_Template_select_change_29_listener() { return ctx.loadGetBuildings(); })("ngModelChange", function ThietBiThangMayComponent_Template_select_ngModelChange_29_listener($event) { return ctx.modelElevator.projectCd = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](31, "option", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](32, "Ch\u1ECDn d\u1EF1 \u00E1n");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](33, ThietBiThangMayComponent_option_33_Template, 2, 2, "option", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](34, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](35, "label", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](36, "T\u00F2a nh\u00E0");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](37, ThietBiThangMayComponent_div_37_Template, 5, 2, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](38, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](39, "label", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](40, "Khu v\u1EF1c ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](41, "span", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](42, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](43, "select", 29, 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function ThietBiThangMayComponent_Template_select_change_43_listener() { return ctx.loadGetFloors(); })("ngModelChange", function ThietBiThangMayComponent_Template_select_ngModelChange_43_listener($event) { return ctx.modelElevator.buildZone = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](45, "option", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](46, "Ch\u1ECDn khu v\u1EF1c");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](47, ThietBiThangMayComponent_option_47_Template, 2, 2, "option", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](48, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](49, "label", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](50, "M\u00E3 thi\u1EBFt b\u1ECB ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](51, "span", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](52, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](53, "input", 32, 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function ThietBiThangMayComponent_Template_input_ngModelChange_53_listener($event) { return ctx.modelElevator.hardwareId = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](55, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](56, "label", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](57, "T\u1EA7ng ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](58, "span", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](59, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](60, "select", 34, 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function ThietBiThangMayComponent_Template_select_ngModelChange_60_listener($event) { return ctx.modelElevator.floorNumber = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](62, "option", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](63, "Ch\u1ECDn t\u1EA7ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](64, ThietBiThangMayComponent_option_64_Template, 2, 2, "option", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](65, "div", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](66, "label", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](67, "Tr\u1EA1ng th\u00E1i ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](68, "span", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](69, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](70, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](71, "input", 39, 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function ThietBiThangMayComponent_Template_input_ngModelChange_71_listener($event) { return ctx.modelElevator.isActived = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](73, "div", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](74, "p-button", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ThietBiThangMayComponent_Template_p_button_click_74_listener() { return ctx.onSave(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](75, "p-button", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ThietBiThangMayComponent_Template_p_button_click_75_listener() { return ctx.isDialog = !ctx.isDialog; });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngClass", ctx.model.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", ctx.model.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction2"](27, _c0, ctx.MENUACTIONROLEAPI.GetElevatorDevicePage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("rows", ctx.model.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](31, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](30, _c1)));
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](33, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("header", ctx.titleModal);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("visible", ctx.isDialog);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", ctx.modelElevator.projectCd);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.projects);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.modelBuilding);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", ctx.modelElevator.buildZone);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.buildingZones);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngClass", ctx.modelElevator.hardwareId ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", ctx.modelElevator.hardwareId);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", ctx.modelElevator.floorNumber);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.floorsCreate);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", ctx.modelElevator.isActived);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction2"](34, _c0, ctx.MENUACTIONROLEAPI.GetElevatorDevicePage.url, ctx.ACTIONS.EDIT));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_12__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_5__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_13__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_14__.Dialog, _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NgForm, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ɵNgSelectMultipleOption"], _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.CheckboxControlValueAccessor, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_6__.ListGridAngularComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0aGlldC1iaS10aGFuZy1tYXkuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 88466:
/*!*******************************************************************************************!*\
  !*** ./src/app/components/thiet-lap-tang-thang-may/thiet-lap-tang-thang-may.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ThietLapTangThangMayComponent": () => (/* binding */ ThietLapTangThangMayComponent)
/* harmony export */ });
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_models_elevatorfloor_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/models/elevatorfloor.model */ 13266);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);


















function ThietLapTangThangMayComponent_app_list_grid_angular_20_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "app-list-grid-angular", 45);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function ThietLapTangThangMayComponent_option_38_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", advert_r13.projectCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", advert_r13.projectName, " ");
} }
function ThietLapTangThangMayComponent_option_48_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", advert_r15.buildCd);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", advert_r15.buildName, " ");
} }
function ThietLapTangThangMayComponent_option_58_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", advert_r17.buildZoneName);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", advert_r17.buildZoneName, " ");
} }
function ThietLapTangThangMayComponent_option_68_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r19 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", advert_r19.floorNumber);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", advert_r19.floorName, " ");
} }
function ThietLapTangThangMayComponent_option_78_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const advert_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("value", advert_r21.floorTypeName);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", advert_r21.floorTypeName, " ");
} }
const _c0 = function () { return { showAll: "ALL" }; };
const _c1 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c2 = function () { return { width: "600px", height: "auto" }; };
class ThietLapTangThangMayComponent {
    constructor(apiService, route, changeDetector, spinner, router) {
        this.apiService = apiService;
        this.route = route;
        this.changeDetector = changeDetector;
        this.spinner = spinner;
        this.router = router;
        this.items = [];
        this.totalRecord = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_0__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_0__.ACTIONS;
        this.projects = [];
        this.builds = [];
        this.buidings = [];
        this.floors = [];
        this.floorsTypes = [];
        this.buildzones = [];
        this.buildingZones = [];
        this.floorsCreate = [];
        this.elevatorfloorModel = src_app_models_elevatorfloor_model__WEBPACK_IMPORTED_MODULE_2__.ElevatorFloor.createDefault();
        this.loadjs = 0;
        this.heightGrid = 0;
        this.columnDefs = [];
        this.listsData = [];
        this.cols = [];
        this.model = {
            filter: '',
            projectCd: '',
            buildZone: '',
            buildCd: '',
            pageSize: 15,
            offset: 0
        };
        this.isDialog = false;
        this.first = 0;
        this.titleModal = 'Thêm thiết Lập';
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Phân quyền' },
            { label: 'Phân quyền thang máy', routerLink: '/phan-quyen/phan-quyen-thang-may' },
            { label: 'Thiết lập tầng thang máy' },
        ];
        this.load();
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + e.clientHeight + 45;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        this.apiService.GetElevatorFloorPage(this.model.filter, this.model.offset, this.model.pageSize, this.model.projectCd, this.model.buildCd, this.model.buildZone).subscribe((results) => {
            this.listsData = results.data;
            if (this.model.offset === 0) {
                this.cols = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.recordsTotal;
            this.countRecord.totalRecord = results.recordsTotal;
            this.countRecord.currentRecordStart = this.model.offset + 1;
            if ((results.recordsTotal - this.model.offset) > this.model.pageSize) {
                this.countRecord.currentRecordEnd = this.model.offset + Number(this.model.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.recordsTotal;
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.editElevatorfloor.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_1__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_0__.MENUACTIONROLEAPI.GetElevatorFloorPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_0__.ACTIONS.VIEW)
                },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: 'Mã',
                cellClass: ['border-right'],
                field: 'id',
            },
            {
                headerName: 'Mã dự án',
                cellClass: ['border-right'],
                field: 'projectCd',
            },
            {
                headerName: 'Tên dự án',
                cellClass: ['border-right'],
                field: 'projectName',
            },
            {
                headerName: 'Mã tòa',
                cellClass: ['border-right'],
                field: 'buildCd',
            },
            {
                headerName: 'Khu vực',
                cellClass: ['border-right'],
                field: 'buildZone',
            },
            {
                headerName: 'Tên tầng',
                cellClass: ['border-right'],
                field: 'floorName',
            },
            {
                headerName: 'Loại tầng',
                cellClass: ['border-right'],
                field: 'floorType',
            },
            {
                headerName: 'Số tầng',
                cellClass: ['border-right'],
                field: 'floorNumber',
            },
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    findproject(projectCd, type) {
        this.builds = [];
        this.buildzones = [];
        this.apiService.getBuildByProjectCd(projectCd).subscribe((results) => {
            this.builds = results.data;
        }, error => { });
    }
    findbuild(buildCd, type) {
        this.buildzones = [];
        this.apiService.getBuildZoneByBuildCd('', buildCd).subscribe((results) => {
            this.buildzones = results.data;
        }, error => { });
    }
    //api create
    getBuilding(projectCd) {
        this.apiService.getBuildByProjectCd(projectCd).subscribe((results) => {
            this.buidings = results.data;
        }, error => { });
    }
    //api create
    getBuildingzonesAndFloors(buildCd) {
        this.buildingZones = [];
        this.apiService.getBuildZoneByBuildCd('', buildCd).subscribe((results) => {
            this.buildingZones = results.data;
        }, error => { });
        this.apiService.GetBuildFloorByProjectCdBuildCd('', this.elevatorfloorModel.projectCd, buildCd).subscribe((results) => {
            this.floorsCreate = results.data;
        }, error => { });
        this.apiService.getFloorTypeByBuildCd(buildCd).subscribe((results) => {
            this.floorsTypes = results.data;
        }, error => { });
    }
    addThietLapTang() {
        this.elevatorfloorModel = src_app_models_elevatorfloor_model__WEBPACK_IMPORTED_MODULE_2__.ElevatorFloor.createDefault();
        this.isDialog = true;
    }
    onSave() {
        const floors = this.floorsCreate.filter(res => res.floorNumber === this.elevatorfloorModel.floorNumber);
        const params = {
            id: this.elevatorfloorModel.id,
            projectCd: this.elevatorfloorModel.projectCd,
            buildCd: this.elevatorfloorModel.buildCd,
            buildZone: this.elevatorfloorModel.buildZone,
            floorNumber: floors.length > 0 ? parseInt(floors[0].floorNumber) : 0,
            floorName: floors.length > 0 ? floors[0].floorName : '',
            floorType: this.elevatorfloorModel.floorType,
            sysDate: this.elevatorfloorModel.sysDate
        };
        this.apiService.setMasElevatorFloor(params).subscribe((result) => {
            if (result.status === 'success') {
                this.isDialog = false;
                this.load();
            }
        });
    }
    editElevatorfloor(event, idx) {
        const item = event.rowData;
        this.titleModal = "Sửa thiết lập";
        this.elevatorfloorModel.projectCd = item.projectCd;
        this.getBuilding(item.projectCd);
        this.getBuildingzonesAndFloors(item.buildCd);
        this.elevatorfloorModel = item;
        this.isDialog = true;
    }
    changebuildName(event) {
        this.getBuildingzonesAndFloors(event.target.value);
    }
    changeBuilding(event) {
        this.getBuilding(event.target.value);
    }
    paginate(event) {
        this.model.offset = event.first;
        this.first = event.first;
        this.model.pageSize = event.rows === 4 ? 100000000 : event.rows;
        this.load();
    }
    cancel() {
        this.load();
    }
}
ThietLapTangThangMayComponent.ɵfac = function ThietLapTangThangMayComponent_Factory(t) { return new (t || ThietLapTangThangMayComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_8__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router)); };
ThietLapTangThangMayComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: ThietLapTangThangMayComponent, selectors: [["app-thiet-lap-tang-thang-may"]], decls: 82, vars: 29, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-4", "pd-0"], [3, "items"], [1, "d-flex", "end", "bottom", "gap-12", "col-8", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "header-filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm mr-1 height-56", "icon", "pi pi-plus", "label", "Th\u00EAm m\u1EDBi", 3, "click"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], [3, "visible", "header", "visibleChange"], [1, "form-horizontal", "ng-pristine", "ng-valid", "ng-scope"], ["createElevatorfloor", "ngForm"], [1, "box-body", 2, "padding", "10px"], [1, "field-group", "select", "label-8"], [1, "control-label"], [2, "color", "red"], ["name", "projectCd", "id", "projectCd", 1, "form-control", 3, "ngModel", "change", "ngModelChange"], ["projectCd", "ngModel"], ["value", ""], [3, "value", 4, "ngFor", "ngForOf"], ["name", "buildCd", "id", "buildCd", 1, "form-control", 3, "ngModel", "change", "ngModelChange"], ["buildCd", "ngModel"], ["name", "buildZone", "id", "buildZone", 1, "form-control", 3, "ngModel", "ngModelChange"], ["buildZone", "ngModel"], ["name", "floorNumber", "id", "floorNumber", 1, "form-control", 3, "ngModel", "ngModelChange"], ["floorNumber", "ngModel"], ["name", "floorType", "id", "floorType", 1, "form-control", 3, "ngModel", "ngModelChange"], ["floorType", "ngModel"], [1, "form-row", "text-right"], ["label", "L\u01B0u l\u1EA1i", "styleClass", "mr-2", 3, "click"], ["label", "\u0110\u00F3ng", "styleClass", "p-button-danger", 3, "click"], [3, "listsData", "height", "columnDefs"], [3, "value"]], template: function ThietLapTangThangMayComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](8, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "input", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("keydown.enter", function ThietLapTangThangMayComponent_Template_input_keydown_enter_9_listener() { ctx.model.offset = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function ThietLapTangThangMayComponent_Template_input_ngModelChange_9_listener($event) { return ctx.model.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ThietLapTangThangMayComponent_Template_span_click_10_listener() { ctx.model.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "svg", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](12, "path", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](13, "p-button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ThietLapTangThangMayComponent_Template_p_button_click_13_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "svg", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](15, "path", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](16, "p-button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ThietLapTangThangMayComponent_Template_p_button_click_16_listener() { return ctx.addThietLapTang(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](17, "section", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](18, "div", 18, 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](20, ThietLapTangThangMayComponent_app_list_grid_angular_20_Template, 1, 3, "app-list-grid-angular", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](21, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](22, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](24, "p-paginator", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("onPageChange", function ThietLapTangThangMayComponent_Template_p_paginator_onPageChange_24_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](25, "p-dialog", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("visibleChange", function ThietLapTangThangMayComponent_Template_p_dialog_visibleChange_25_listener($event) { return ctx.isDialog = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](26, "form", 24, 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](28, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](29, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](30, "label", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](31, "M\u00E3 d\u1EF1 \u00E1n ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](32, "span", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](33, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](34, "select", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function ThietLapTangThangMayComponent_Template_select_change_34_listener($event) { return ctx.changeBuilding($event); })("ngModelChange", function ThietLapTangThangMayComponent_Template_select_ngModelChange_34_listener($event) { return ctx.elevatorfloorModel.projectCd = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](36, "option", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](37, "Ch\u1ECDn d\u1EF1 \u00E1n");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](38, ThietLapTangThangMayComponent_option_38_Template, 2, 2, "option", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](39, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](40, "label", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](41, "T\u00F2a");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](42, "span", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](43, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](44, "select", 34, 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function ThietLapTangThangMayComponent_Template_select_change_44_listener($event) { return ctx.changebuildName($event); })("ngModelChange", function ThietLapTangThangMayComponent_Template_select_ngModelChange_44_listener($event) { return ctx.elevatorfloorModel.buildCd = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](46, "option", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](47, "Ch\u1ECDn t\u00F2a");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](48, ThietLapTangThangMayComponent_option_48_Template, 2, 2, "option", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](49, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](50, "label", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](51, "Khu v\u1EF1c");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](52, "span", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](53, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](54, "select", 36, 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function ThietLapTangThangMayComponent_Template_select_ngModelChange_54_listener($event) { return ctx.elevatorfloorModel.buildZone = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](56, "option", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](57, "Ch\u1ECDn khu v\u1EF1c");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](58, ThietLapTangThangMayComponent_option_58_Template, 2, 2, "option", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](59, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](60, "label", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](61, "T\u1EA7ng ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](62, "span", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](63, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](64, "select", 38, 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function ThietLapTangThangMayComponent_Template_select_ngModelChange_64_listener($event) { return ctx.elevatorfloorModel.floorNumber = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](66, "option", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](67, "Ch\u1ECDn t\u1EA7ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](68, ThietLapTangThangMayComponent_option_68_Template, 2, 2, "option", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](69, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](70, "label", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](71, "Lo\u1EA1i t\u1EA7ng ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](72, "span", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](73, "*");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](74, "select", 40, 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function ThietLapTangThangMayComponent_Template_select_ngModelChange_74_listener($event) { return ctx.elevatorfloorModel.floorType = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](76, "option", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](77, "Ch\u1ECDn lo\u1EA1i t\u1EA7ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](78, ThietLapTangThangMayComponent_option_78_Template, 2, 2, "option", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](79, "div", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](80, "p-button", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ThietLapTangThangMayComponent_Template_p_button_click_80_listener() { return ctx.onSave(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](81, "p-button", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ThietLapTangThangMayComponent_Template_p_button_click_81_listener() { return ctx.isDialog = !ctx.isDialog; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", ctx.model.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.model.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("rows", ctx.model.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](26, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction0"](25, _c0)));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction0"](28, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpropertyInterpolate"]("header", ctx.titleModal);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("visible", ctx.isDialog);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.elevatorfloorModel.projectCd);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.projects);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.elevatorfloorModel.buildCd);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.buidings);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.elevatorfloorModel.buildZone);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.buildingZones);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.elevatorfloorModel.floorNumber);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.floorsCreate);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.elevatorfloorModel.floorType);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.floorsTypes);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_11__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_12__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_13__.Dialog, _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgForm, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ɵNgSelectMultipleOption"], _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgForOf, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_5__.ListGridAngularComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0aGlldC1sYXAtdGFuZy10aGFuZy1tYXkuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 97449:
/*!******************************************!*\
  !*** ./src/app/models/cardinfo.model.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchInfo": () => (/* binding */ SearchInfo),
/* harmony export */   "CardInfo": () => (/* binding */ CardInfo),
/* harmony export */   "TypeCard": () => (/* binding */ TypeCard),
/* harmony export */   "Project": () => (/* binding */ Project),
/* harmony export */   "EmployeeCardList": () => (/* binding */ EmployeeCardList),
/* harmony export */   "Vehicle": () => (/* binding */ Vehicle),
/* harmony export */   "VehicleType": () => (/* binding */ VehicleType)
/* harmony export */ });
class SearchInfo {
    constructor(cardCode, phoneNumber, hardwareId) {
        this.cardCode = cardCode;
        this.phoneNumber = phoneNumber;
        this.hardwareId = hardwareId;
    }
}
class CardInfo {
    constructor(id, cardId, fullName, cardRole, cardType, hardwareId, elevatorBank, elevatorShaftNumber, elevatorShaftName, issueDate, expireDate, projectName, buildName, floorName, cardNumber, roleId, roleName, cardTypeName, note, projectCd, buildCd, floorNumber, filter) {
        this.id = id;
        this.cardId = cardId;
        this.fullName = fullName;
        this.cardRole = cardRole;
        this.cardType = cardType;
        this.hardwareId = hardwareId;
        this.elevatorBank = elevatorBank;
        this.elevatorShaftNumber = elevatorShaftNumber;
        this.elevatorShaftName = elevatorShaftName;
        this.issueDate = issueDate;
        this.expireDate = expireDate;
        this.projectName = projectName;
        this.buildName = buildName;
        this.floorName = floorName;
        this.cardNumber = cardNumber;
        this.roleId = roleId;
        this.roleName = roleName;
        this.cardTypeName = cardTypeName;
        this.note = note;
        this.projectCd = projectCd;
        this.buildCd = buildCd;
        this.floorNumber = floorNumber;
        this.filter = filter;
    }
}
class TypeCard {
    constructor(imageUrl, cardTypeId, cardTypeName) {
        this.imageUrl = imageUrl;
        this.cardTypeId = cardTypeId;
        this.cardTypeName = cardTypeName;
    }
    // tslint:disable-next-line:member-ordering
    static createDefault() {
        return new TypeCard('', 0, '');
    }
}
class Project {
    constructor(projectCd, projectName) {
        this.projectCd = projectCd;
        this.projectName = projectName;
    }
    // tslint:disable-next-line:member-ordering
    static createDefault() {
        return new Project('', '');
    }
}
class EmployeeCardList {
    constructor(cardId, cardCd, fullName, phone, email, position, status, statusName, isClose, closeDate, isVihecle, departmentName) {
        this.cardId = cardId;
        this.cardCd = cardCd;
        this.fullName = fullName;
        this.phone = phone;
        this.email = email;
        this.position = position;
        this.status = status;
        this.statusName = statusName;
        this.isClose = isClose;
        this.closeDate = closeDate;
        this.isVihecle = isVihecle;
        this.departmentName = departmentName;
    }
    static createDefault() {
        return new EmployeeCardList(0, '', '', '', '', '', 0, '', false, '', false, '');
    }
}
class Vehicle {
    constructor(assignDate, vehicleTypeName, serviceName, statusName, isLock, cardVehicleId, cardCd, vehicleTypeId, vehicleNo, vehicleName, isVehicleNone, serviceId, startTime, endTime, status, reason, cardName, fullName, departmentName, cardImage) {
        this.assignDate = assignDate;
        this.vehicleTypeName = vehicleTypeName;
        this.serviceName = serviceName;
        this.statusName = statusName;
        this.isLock = isLock;
        this.cardVehicleId = cardVehicleId;
        this.cardCd = cardCd;
        this.vehicleTypeId = vehicleTypeId;
        this.vehicleNo = vehicleNo;
        this.vehicleName = vehicleName;
        this.isVehicleNone = isVehicleNone;
        this.serviceId = serviceId;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = status;
        this.reason = reason;
        this.cardName = cardName;
        this.fullName = fullName;
        this.departmentName = departmentName;
        this.cardImage = cardImage;
    }
    // tslint:disable-next-line:member-ordering
    static createDefault() {
        return new Vehicle('', '', '', '', false, 0, '', 0, '', '', false, 0, '', '', 0, '', '', '', '', '');
    }
}
class VehicleType {
    constructor(vehicleTypeId, vehicleTypeName) {
        this.vehicleTypeId = vehicleTypeId;
        this.vehicleTypeName = vehicleTypeName;
    }
    // tslint:disable-next-line:member-ordering
    static createDefault() {
        return new VehicleType('', '');
    }
}


/***/ }),

/***/ 13266:
/*!***********************************************!*\
  !*** ./src/app/models/elevatorfloor.model.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ElevatorFloor": () => (/* binding */ ElevatorFloor),
/* harmony export */   "SetElevatorFloor": () => (/* binding */ SetElevatorFloor)
/* harmony export */ });
class ElevatorFloor {
    constructor(id, projectCd, projectName, buildCd, buildZone, floorName, floorType, floorNumber, sysDate) {
        this.id = id;
        this.projectCd = projectCd;
        this.projectName = projectName;
        this.buildCd = buildCd;
        this.buildZone = buildZone;
        this.floorName = floorName;
        this.floorType = floorType;
        this.floorNumber = floorNumber;
        this.sysDate = sysDate;
    }
    // tslint:disable-next-line:member-ordering
    static createDefault() {
        return new ElevatorFloor(0, '', '', '', '', '', '', null, new Date());
    }
}
class SetElevatorFloor {
    constructor(id, hardwareId, floorNumber, floorName, elevatorBank, elevatorShaftName, elevatorShaftNumber, projectCd, buildZone, isActived, sysDate) {
        this.id = id;
        this.hardwareId = hardwareId;
        this.floorNumber = floorNumber;
        this.floorName = floorName;
        this.elevatorBank = elevatorBank;
        this.elevatorShaftName = elevatorShaftName;
        this.elevatorShaftNumber = elevatorShaftNumber;
        this.projectCd = projectCd;
        this.buildZone = buildZone;
        this.isActived = isActived;
        this.sysDate = sysDate;
    }
    // tslint:disable-next-line:member-ordering
    static createDefault() {
        return new SetElevatorFloor(0, '', '', '', '', '', 0, '', '', true, new Date());
    }
}


/***/ }),

/***/ 32403:
/*!***************************************************************!*\
  !*** ./src/app/pages/phan-quyen/phan-quyen-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhanQuyenRoutingModule": () => (/* binding */ PhanQuyenRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var src_app_components_pq_quyen_nguoi_dung_pq_quyen_nguoi_dung_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/components/pq-quyen-nguoi-dung/pq-quyen-nguoi-dung.component */ 99161);
/* harmony import */ var src_app_components_pq_thang_may_pq_thang_may_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/components/pq-thang-may/pq-thang-may.component */ 44731);
/* harmony import */ var src_app_components_pq_the_nhan_vien_pq_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/pq-the-nhan-vien/pq-the-nhan-vien.component */ 94440);
/* harmony import */ var src_app_components_pq_xe_nhan_vien_pq_xe_nhan_vien_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/components/pq-xe-nhan-vien/pq-xe-nhan-vien.component */ 23063);
/* harmony import */ var src_app_components_thiet_bi_thang_may_thiet_bi_thang_may_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/components/thiet-bi-thang-may/thiet-bi-thang-may.component */ 3319);
/* harmony import */ var src_app_components_thiet_lap_tang_thang_may_thiet_lap_tang_thang_may_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/components/thiet-lap-tang-thang-may/thiet-lap-tang-thang-may.component */ 88466);
/* harmony import */ var src_app_components_pq_the_nhan_vien_chi_tiet_the_nhan_vien_chi_tiet_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/pq-the-nhan-vien/chi-tiet-the-nhan-vien/chi-tiet-the-nhan-vien.component */ 63602);
/* harmony import */ var src_app_components_pq_xe_nhan_vien_import_xe_nhan_vien_import_xe_nhan_vien_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/pq-xe-nhan-vien/import-xe-nhan-vien/import-xe-nhan-vien.component */ 28219);
/* harmony import */ var src_app_components_pq_the_nhan_vien_import_the_nhan_vien_import_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/components/pq-the-nhan-vien/import-the-nhan-vien/import-the-nhan-vien.component */ 73019);
/* harmony import */ var src_app_components_pq_quyen_nguoi_dung_chi_tiet_cai_dat_quyen_chi_tiet_cai_dat_quyen_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/components/pq-quyen-nguoi-dung/chi-tiet-cai-dat-quyen/chi-tiet-cai-dat-quyen.component */ 38118);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 14001);













const routes = [
    {
        path: "",
        redirectTo: "thong-bao",
        pathMatch: 'full'
    },
    //Quyền thang máy
    {
        path: 'phan-quyen-thang-may',
        component: src_app_components_pq_thang_may_pq_thang_may_component__WEBPACK_IMPORTED_MODULE_1__.PqThangMayComponent,
        data: {
            title: 'Phân quyền thang máy',
            url: 'phan-quyen-thang-may',
        },
    },
    //Quyền thang máy
    {
        path: 'the-nhan-vien',
        component: src_app_components_pq_the_nhan_vien_pq_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_2__.PqTheNhanVienComponent,
        data: {
            title: 'Danh sách thẻ nhân viên',
            url: 'the-nhan-vien',
        },
    },
    //Import the nhan vien
    {
        path: 'the-nhan-vien/import',
        component: src_app_components_pq_the_nhan_vien_import_the_nhan_vien_import_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_8__.ImportTheNhanVienComponent,
        data: {
            title: 'Import thẻ nhân viên',
            url: 'import-the-nhan-vien',
        },
    },
    // thêm mới thẻ nhân viên
    {
        path: 'the-nhan-vien/them-moi-the-nhan-vien',
        component: src_app_components_pq_the_nhan_vien_chi_tiet_the_nhan_vien_chi_tiet_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_6__.ChiTietTheNhanVienComponent,
        data: {
            title: 'Thêm mới thẻ nhân viên',
            url: 'them-moi-nhan-vien',
        },
    },
    //Thiết bị thang máy
    {
        path: 'thiet-bi-thang-may',
        component: src_app_components_thiet_bi_thang_may_thiet_bi_thang_may_component__WEBPACK_IMPORTED_MODULE_4__.ThietBiThangMayComponent,
        data: {
            title: 'Danh sách thẻ nhân viên',
            url: 'thiet-bi-thang-may',
        },
    },
    //Thiết bị thang máy
    {
        path: 'thiet-lap-tang-thang-may',
        component: src_app_components_thiet_lap_tang_thang_may_thiet_lap_tang_thang_may_component__WEBPACK_IMPORTED_MODULE_5__.ThietLapTangThangMayComponent,
        data: {
            title: 'Danh sách thiết lập tầng thang máy',
            url: 'thiet-lap-tang-thang-may',
        },
    },
    //Quyền thang máy
    {
        path: 'xe-nhan-vien',
        component: src_app_components_pq_xe_nhan_vien_pq_xe_nhan_vien_component__WEBPACK_IMPORTED_MODULE_3__.PqXeNhanVienComponent,
        data: {
            title: 'Danh sách xe nhân viên',
            url: 'xe-nhan-vien',
        },
    },
    //Import xe nhan vien
    {
        path: 'xe-nhan-vien/import',
        component: src_app_components_pq_xe_nhan_vien_import_xe_nhan_vien_import_xe_nhan_vien_component__WEBPACK_IMPORTED_MODULE_7__.ImportXeNhanVienComponent,
        data: {
            title: 'Import xe nhân viên',
            url: 'import-xe-nhan-vien',
        },
    },
    //Quyền người dùng
    {
        path: 'quyen-nguoi-dung',
        component: src_app_components_pq_quyen_nguoi_dung_pq_quyen_nguoi_dung_component__WEBPACK_IMPORTED_MODULE_0__.PqQuyenNguoiDungComponent,
        data: {
            title: 'Danh sách quyền người dùng',
            url: 'quyen-nguoi-dung',
        },
    },
    // chi tiet quyen nguoi dung
    {
        path: 'quyen-nguoi-dung/chi-tiet-quyen-nguoi-dung',
        component: src_app_components_pq_quyen_nguoi_dung_chi_tiet_cai_dat_quyen_chi_tiet_cai_dat_quyen_component__WEBPACK_IMPORTED_MODULE_9__.ChiTietCaiDatQuyenComponent,
        data: {
            title: 'Chi tiết quyền người dùng',
            url: 'chi-tiet-quyen-nguoi-dung',
        },
    },
];
class PhanQuyenRoutingModule {
}
PhanQuyenRoutingModule.ɵfac = function PhanQuyenRoutingModule_Factory(t) { return new (t || PhanQuyenRoutingModule)(); };
PhanQuyenRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineNgModule"]({ type: PhanQuyenRoutingModule });
PhanQuyenRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_11__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_11__.RouterModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsetNgModuleScope"](PhanQuyenRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_11__.RouterModule], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_11__.RouterModule] }); })();


/***/ }),

/***/ 5973:
/*!*******************************************************!*\
  !*** ./src/app/pages/phan-quyen/phan-quyen.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhanQuyenModule": () => (/* binding */ PhanQuyenModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_tree__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/tree */ 35295);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! primeng/table */ 43750);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! primeng/multiselect */ 92487);
/* harmony import */ var src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/list-grid-angular/list-grid-angular.module */ 8145);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! primeng/splitbutton */ 71494);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! primeng/autocomplete */ 17611);
/* harmony import */ var src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/edit-detail/edit-detail.module */ 38160);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! primeng/fileupload */ 83735);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_card__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! primeng/card */ 33506);
/* harmony import */ var primeng_badge__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! primeng/badge */ 62051);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! primeng/tooltip */ 39243);
/* harmony import */ var primeng_slider__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! primeng/slider */ 52340);
/* harmony import */ var src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/pipe/currency-pipe.module */ 44093);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! @ag-grid-community/angular */ 11775);
/* harmony import */ var src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component */ 75137);
/* harmony import */ var src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component-1 */ 90457);
/* harmony import */ var primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! primeng/confirmdialog */ 71849);
/* harmony import */ var primeng_sidebar__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! primeng/sidebar */ 65357);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var primeng_messages__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/messages */ 93713);
/* harmony import */ var primeng_message__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/message */ 15357);
/* harmony import */ var src_app_components_page_notify_page_notify_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/components/page-notify/page-notify.module */ 47186);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! primeng/organizationchart */ 87051);
/* harmony import */ var primeng_panel__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! primeng/panel */ 53581);
/* harmony import */ var _phan_quyen_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./phan-quyen-routing.module */ 32403);
/* harmony import */ var src_app_components_pq_thang_may_pq_thang_may_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/pq-thang-may/pq-thang-may.component */ 44731);
/* harmony import */ var src_app_components_pq_the_nhan_vien_pq_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/components/pq-the-nhan-vien/pq-the-nhan-vien.component */ 94440);
/* harmony import */ var src_app_components_pq_xe_nhan_vien_pq_xe_nhan_vien_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/components/pq-xe-nhan-vien/pq-xe-nhan-vien.component */ 23063);
/* harmony import */ var src_app_components_pq_quyen_nguoi_dung_pq_quyen_nguoi_dung_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/components/pq-quyen-nguoi-dung/pq-quyen-nguoi-dung.component */ 99161);
/* harmony import */ var src_app_components_thiet_bi_thang_may_thiet_bi_thang_may_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/components/thiet-bi-thang-may/thiet-bi-thang-may.component */ 3319);
/* harmony import */ var src_app_components_thiet_lap_tang_thang_may_thiet_lap_tang_thang_may_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/components/thiet-lap-tang-thang-may/thiet-lap-tang-thang-may.component */ 88466);
/* harmony import */ var src_app_components_pq_the_nhan_vien_card_detail_card_detail_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/components/pq-the-nhan-vien/card-detail/card-detail.component */ 36980);
/* harmony import */ var src_app_components_pq_the_nhan_vien_chi_tiet_the_nhan_vien_chi_tiet_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/components/pq-the-nhan-vien/chi-tiet-the-nhan-vien/chi-tiet-the-nhan-vien.component */ 63602);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/common/hrm-breadcrumb/hrm-breadcrumb.module */ 38040);
/* harmony import */ var src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/common/config-grid-table-form/config-grid-table-form.module */ 45092);
/* harmony import */ var src_app_components_pq_xe_nhan_vien_import_xe_nhan_vien_import_xe_nhan_vien_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/components/pq-xe-nhan-vien/import-xe-nhan-vien/import-xe-nhan-vien.component */ 28219);
/* harmony import */ var src_app_components_pq_the_nhan_vien_import_the_nhan_vien_import_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/components/pq-the-nhan-vien/import-the-nhan-vien/import-the-nhan-vien.component */ 73019);
/* harmony import */ var primeng_image__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! primeng/image */ 98907);
/* harmony import */ var src_app_components_pq_quyen_nguoi_dung_chi_tiet_cai_dat_quyen_chi_tiet_cai_dat_quyen_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/components/pq-quyen-nguoi-dung/chi-tiet-cai-dat-quyen/chi-tiet-cai-dat-quyen.component */ 38118);
/* harmony import */ var src_app_components_pq_quyen_nguoi_dung_danh_sach_action_danh_sach_action_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/components/pq-quyen-nguoi-dung/danh-sach-action/danh-sach-action.component */ 57619);
/* harmony import */ var src_app_components_pq_quyen_nguoi_dung_danh_sach_menu_danh_sach_menu_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/components/pq-quyen-nguoi-dung/danh-sach-menu/danh-sach-menu.component */ 38309);
/* harmony import */ var src_app_components_pq_quyen_nguoi_dung_danh_sach_role_danh_sach_role_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/components/pq-quyen-nguoi-dung/danh-sach-role/danh-sach-role.component */ 17594);
/* harmony import */ var primeng_picklist__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! primeng/picklist */ 32536);
/* harmony import */ var primeng_checkbox__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! primeng/checkbox */ 77588);
/* harmony import */ var src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! src/app/directive/check-action.module */ 69389);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/core */ 14001);


























































class PhanQuyenModule {
}
PhanQuyenModule.ɵfac = function PhanQuyenModule_Factory(t) { return new (t || PhanQuyenModule)(); };
PhanQuyenModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdefineNgModule"]({ type: PhanQuyenModule });
PhanQuyenModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdefineInjector"]({ providers: [], imports: [[
            primeng_messages__WEBPACK_IMPORTED_MODULE_25__.MessagesModule,
            primeng_message__WEBPACK_IMPORTED_MODULE_26__.MessageModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_27__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_27__.ReactiveFormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_28__.CommonModule,
            primeng_tree__WEBPACK_IMPORTED_MODULE_29__.TreeModule,
            primeng_table__WEBPACK_IMPORTED_MODULE_30__.TableModule,
            primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_31__.BreadcrumbModule,
            primeng_multiselect__WEBPACK_IMPORTED_MODULE_32__.MultiSelectModule,
            src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularModule,
            primeng_button__WEBPACK_IMPORTED_MODULE_33__.ButtonModule,
            primeng_splitbutton__WEBPACK_IMPORTED_MODULE_34__.SplitButtonModule,
            primeng_calendar__WEBPACK_IMPORTED_MODULE_35__.CalendarModule,
            primeng_autocomplete__WEBPACK_IMPORTED_MODULE_36__.AutoCompleteModule,
            src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__.EditDetailModule,
            src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_16__.ConfigGridTableFormModule,
            primeng_fileupload__WEBPACK_IMPORTED_MODULE_37__.FileUploadModule,
            primeng_organizationchart__WEBPACK_IMPORTED_MODULE_38__.OrganizationChartModule,
            primeng_treeselect__WEBPACK_IMPORTED_MODULE_39__.TreeSelectModule,
            primeng_menu__WEBPACK_IMPORTED_MODULE_40__.MenuModule,
            primeng_card__WEBPACK_IMPORTED_MODULE_41__.CardModule,
            primeng_badge__WEBPACK_IMPORTED_MODULE_42__.BadgeModule,
            primeng_tooltip__WEBPACK_IMPORTED_MODULE_43__.TooltipModule,
            primeng_slider__WEBPACK_IMPORTED_MODULE_44__.SliderModule,
            primeng_sidebar__WEBPACK_IMPORTED_MODULE_45__.SidebarModule,
            _phan_quyen_routing_module__WEBPACK_IMPORTED_MODULE_6__.PhanQuyenRoutingModule,
            src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__.CurrencyFormatPipeModule,
            primeng_dialog__WEBPACK_IMPORTED_MODULE_46__.DialogModule,
            primeng_dropdown__WEBPACK_IMPORTED_MODULE_47__.DropdownModule,
            src_app_components_page_notify_page_notify_module__WEBPACK_IMPORTED_MODULE_5__.PageNotifyModule,
            primeng_tabview__WEBPACK_IMPORTED_MODULE_48__.TabViewModule,
            primeng_paginator__WEBPACK_IMPORTED_MODULE_49__.PaginatorModule,
            primeng_panel__WEBPACK_IMPORTED_MODULE_50__.PanelModule,
            primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_51__.ConfirmDialogModule,
            primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_52__.OverlayPanelModule,
            src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_15__.HrmBreadCrumbModule,
            primeng_image__WEBPACK_IMPORTED_MODULE_53__.ImageModule,
            primeng_picklist__WEBPACK_IMPORTED_MODULE_54__.PickListModule,
            primeng_checkbox__WEBPACK_IMPORTED_MODULE_55__.CheckboxModule,
            src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_23__.CheckHideActionsDirectiveModule,
            _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_56__.AgGridModule.withComponents([
                src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_3__.ButtonRendererComponent,
                src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_4__.ButtonRendererComponent1
            ]),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵsetNgModuleScope"](PhanQuyenModule, { declarations: [src_app_components_pq_thang_may_pq_thang_may_component__WEBPACK_IMPORTED_MODULE_7__.PqThangMayComponent,
        src_app_components_pq_the_nhan_vien_pq_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_8__.PqTheNhanVienComponent,
        src_app_components_pq_xe_nhan_vien_pq_xe_nhan_vien_component__WEBPACK_IMPORTED_MODULE_9__.PqXeNhanVienComponent,
        src_app_components_pq_quyen_nguoi_dung_pq_quyen_nguoi_dung_component__WEBPACK_IMPORTED_MODULE_10__.PqQuyenNguoiDungComponent,
        src_app_components_thiet_bi_thang_may_thiet_bi_thang_may_component__WEBPACK_IMPORTED_MODULE_11__.ThietBiThangMayComponent,
        src_app_components_thiet_lap_tang_thang_may_thiet_lap_tang_thang_may_component__WEBPACK_IMPORTED_MODULE_12__.ThietLapTangThangMayComponent,
        src_app_components_pq_the_nhan_vien_card_detail_card_detail_component__WEBPACK_IMPORTED_MODULE_13__.CardDetailComponent,
        src_app_components_pq_the_nhan_vien_chi_tiet_the_nhan_vien_chi_tiet_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_14__.ChiTietTheNhanVienComponent,
        src_app_components_pq_xe_nhan_vien_import_xe_nhan_vien_import_xe_nhan_vien_component__WEBPACK_IMPORTED_MODULE_17__.ImportXeNhanVienComponent,
        src_app_components_pq_the_nhan_vien_import_the_nhan_vien_import_the_nhan_vien_component__WEBPACK_IMPORTED_MODULE_18__.ImportTheNhanVienComponent,
        src_app_components_pq_quyen_nguoi_dung_chi_tiet_cai_dat_quyen_chi_tiet_cai_dat_quyen_component__WEBPACK_IMPORTED_MODULE_19__.ChiTietCaiDatQuyenComponent,
        src_app_components_pq_quyen_nguoi_dung_danh_sach_action_danh_sach_action_component__WEBPACK_IMPORTED_MODULE_20__.DanhSachActionComponent,
        src_app_components_pq_quyen_nguoi_dung_danh_sach_menu_danh_sach_menu_component__WEBPACK_IMPORTED_MODULE_21__.DanhSachMenuComponent,
        src_app_components_pq_quyen_nguoi_dung_danh_sach_role_danh_sach_role_component__WEBPACK_IMPORTED_MODULE_22__.DanhSachRoleComponent], imports: [primeng_messages__WEBPACK_IMPORTED_MODULE_25__.MessagesModule,
        primeng_message__WEBPACK_IMPORTED_MODULE_26__.MessageModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_27__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_27__.ReactiveFormsModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_28__.CommonModule,
        primeng_tree__WEBPACK_IMPORTED_MODULE_29__.TreeModule,
        primeng_table__WEBPACK_IMPORTED_MODULE_30__.TableModule,
        primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_31__.BreadcrumbModule,
        primeng_multiselect__WEBPACK_IMPORTED_MODULE_32__.MultiSelectModule,
        src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularModule,
        primeng_button__WEBPACK_IMPORTED_MODULE_33__.ButtonModule,
        primeng_splitbutton__WEBPACK_IMPORTED_MODULE_34__.SplitButtonModule,
        primeng_calendar__WEBPACK_IMPORTED_MODULE_35__.CalendarModule,
        primeng_autocomplete__WEBPACK_IMPORTED_MODULE_36__.AutoCompleteModule,
        src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__.EditDetailModule,
        src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_16__.ConfigGridTableFormModule,
        primeng_fileupload__WEBPACK_IMPORTED_MODULE_37__.FileUploadModule,
        primeng_organizationchart__WEBPACK_IMPORTED_MODULE_38__.OrganizationChartModule,
        primeng_treeselect__WEBPACK_IMPORTED_MODULE_39__.TreeSelectModule,
        primeng_menu__WEBPACK_IMPORTED_MODULE_40__.MenuModule,
        primeng_card__WEBPACK_IMPORTED_MODULE_41__.CardModule,
        primeng_badge__WEBPACK_IMPORTED_MODULE_42__.BadgeModule,
        primeng_tooltip__WEBPACK_IMPORTED_MODULE_43__.TooltipModule,
        primeng_slider__WEBPACK_IMPORTED_MODULE_44__.SliderModule,
        primeng_sidebar__WEBPACK_IMPORTED_MODULE_45__.SidebarModule,
        _phan_quyen_routing_module__WEBPACK_IMPORTED_MODULE_6__.PhanQuyenRoutingModule,
        src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__.CurrencyFormatPipeModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_46__.DialogModule,
        primeng_dropdown__WEBPACK_IMPORTED_MODULE_47__.DropdownModule,
        src_app_components_page_notify_page_notify_module__WEBPACK_IMPORTED_MODULE_5__.PageNotifyModule,
        primeng_tabview__WEBPACK_IMPORTED_MODULE_48__.TabViewModule,
        primeng_paginator__WEBPACK_IMPORTED_MODULE_49__.PaginatorModule,
        primeng_panel__WEBPACK_IMPORTED_MODULE_50__.PanelModule,
        primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_51__.ConfirmDialogModule,
        primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_52__.OverlayPanelModule,
        src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_15__.HrmBreadCrumbModule,
        primeng_image__WEBPACK_IMPORTED_MODULE_53__.ImageModule,
        primeng_picklist__WEBPACK_IMPORTED_MODULE_54__.PickListModule,
        primeng_checkbox__WEBPACK_IMPORTED_MODULE_55__.CheckboxModule,
        src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_23__.CheckHideActionsDirectiveModule, _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_56__.AgGridModule] }); })();


/***/ }),

/***/ 54956:
/*!**********************************!*\
  !*** ./src/app/types/addUser.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "addUser": () => (/* binding */ addUser)
/* harmony export */ });
class addUser {
}


/***/ })

}]);
//# sourceMappingURL=src_app_pages_phan-quyen_phan-quyen_module_ts.9a1c76fd372d5cef.js.map