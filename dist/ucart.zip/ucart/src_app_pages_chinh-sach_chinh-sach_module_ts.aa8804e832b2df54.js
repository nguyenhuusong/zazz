"use strict";
(self["webpackChunkucart"] = self["webpackChunkucart"] || []).push([["src_app_pages_chinh-sach_chinh-sach_module_ts"],{

/***/ 2329:
/*!********************************************************************************!*\
  !*** ./src/app/components/cs-an-ca/chi-tiet-an-ca/chi-tiet-an-ca.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietAnCaComponent": () => (/* binding */ ChiTietAnCaComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var primeng_checkbox__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/checkbox */ 77588);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/forms */ 18346);





















function ChiTietAnCaComponent_app_edit_detail_7_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "app-edit-detail", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("callback", function ChiTietAnCaComponent_app_edit_detail_7_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r2.setCompanyInfo($event); })("callbackcancel", function ChiTietAnCaComponent_app_edit_detail_7_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r3); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r4.cancelUpdate($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
function ChiTietAnCaComponent_div_13_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "p-checkbox", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function ChiTietAnCaComponent_div_13_Template_p_checkbox_ngModelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return ctx_r7.selectedDates = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "label", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r5 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("value", item_r5)("disabled", true)("ngModel", ctx_r1.selectedDates)("inputId", item_r5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("for", item_r5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](item_r5);
} }
class ChiTietAnCaComponent {
    constructor(apiService, activatedRoute, messageService, confirmationService, spinner, router) {
        this.apiService = apiService;
        this.activatedRoute = activatedRoute;
        this.messageService = messageService;
        this.confirmationService = confirmationService;
        this.spinner = spinner;
        this.router = router;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_8__.Subject();
        this.manhinh = 'View';
        this.indexTab = 0;
        this.optionsButtonsView = [{ label: 'Sửa', value: 'Edit' }, { label: 'Quay lại', value: 'Back' }];
        this.optionsButon = [
            { label: 'Hủy', value: 'Back', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI.GetFormsTypePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS.EDIT) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.displayScreemForm = false;
        this.displaysearchUserMaster = false;
        this.listViewsForm = [];
        this.detailComAuthorizeInfo = null;
        this.custId = null;
        this.listViews = [];
        this.imagesUrl = [];
        this.paramsObject = null;
        this.displayUserInfo = false;
        this.titleForm = {
            label: 'Cập nhật thông tin khách hàng',
            value: 'Edit'
        };
        this.titlePage = '';
        this.url = '';
        this.dataRouter = null;
        this.back = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter();
        this.items = [];
        this.detailInfo = null;
        this.menuDate = [];
        this.selectedDates = [];
        this.listDates = [];
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnChanges() {
    }
    ngOnInit() {
        // const toDate= moment(new Date()).add(45,'days').format('DD');
        const thanghientai = moment__WEBPACK_IMPORTED_MODULE_3__(new Date()).endOf('month').format('DD');
        const a = [];
        const b = [];
        for (let i = 0; i < 45; i++) {
            if (i + 1 <= parseInt(thanghientai)) {
                a.push(`${i + 1 < 10 ? 0 : ''}${i + 1}/${new Date().getMonth() + 1 < 10 ? 0 : ''}${new Date().getMonth() + 1}/${new Date().getFullYear()}`);
            }
            else {
                let newDay = 45 - i;
                b.push(`${newDay < 10 ? 0 : ''}${newDay}/${new Date().getMonth() + 2 < 10 ? 0 : ''}${new Date().getMonth() + 2}/${new Date().getFullYear()}`);
            }
            this.listDates = [...a, ...b.sort()];
        }
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Danh sách ăn ca', routerLink: '/chinh-sach/an-ca' },
            { label: this.titlePage },
        ];
        this.url = this.activatedRoute.data['_value'].url;
        this.manhinh = 'Edit';
        this.handleParams();
    }
    checkdisableddate(day) {
        if (day < parseInt(moment__WEBPACK_IMPORTED_MODULE_3__(new Date()).format('DD'))) {
            return true;
        }
        return false;
    }
    handleParams() {
        this.activatedRoute.queryParamMap.subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.dataRouter = this.paramsObject.params;
            this.custId = this.paramsObject.params.custId;
            this.getEatingList();
        });
    }
    ;
    getAnCaInfo() {
        this.listViews = [];
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ cusId: this.custId });
        this.apiService.getEatingInfo(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(results.data.group_fields);
                this.detailInfo = results.data;
                this.menuDate = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(this.detailInfo.menuDate);
            }
        });
    }
    getEatingList() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({
            cusId: this.custId,
            fromDate: moment__WEBPACK_IMPORTED_MODULE_3__(new Date()).startOf('month').format('DD/MM/YYYY'),
            toDate: moment__WEBPACK_IMPORTED_MODULE_3__(new Date()).endOf('month').format('DD/MM/YYYY'),
        });
        this.apiService.getEatingList(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.selectedDates = results.data.result.dataList.data.map(d => d.menu_date);
                this.getAnCaInfo();
            }
        });
    }
    showButton() {
        return {
            buttons: [
                {
                    onClick: this.OnClick.bind(this),
                    label: 'Chỉnh sửa',
                    icon: 'fa fa-edit',
                    key: 'CHINHSUA',
                    class: 'btn-primary mr-1',
                },
                {
                    onClick: this.OnClick.bind(this),
                    label: 'Xóa',
                    key: 'DELETE',
                    icon: 'pi pi-trash',
                    class: 'btn-danger',
                },
            ]
        };
    }
    OnClick(event) {
        // if (event.event.item.key === 'CHINHSUA') {  
        //   this.modelComAuthorizeInfo = {
        //     auth_id : event.rowData.auth_id,
        //     id: this.custId,
        //     cif_no: ''
        //   }
        //   this.getComAuthorizeInfo();
        //  }else {
        //  }
    }
    handleChange(index) {
        this.indexTab = index;
    }
    setCompanyInfo(data) {
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data, menuDate: this.selectedDates });
        this.apiService.setEatingInfo(params).subscribe((results) => {
            if (results.status === 'success') {
                this.displayUserInfo = false;
                if (this.url === 'them-moi-nghi-phep') {
                    this.goBack();
                }
                else {
                    this.manhinh = 'Edit';
                    this.getAnCaInfo();
                }
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Cập nhật thông tin thành công' });
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo', detail: results.message
                });
            }
        }, error => {
        });
    }
    onChangeButtonView(event) {
        this.manhinh = event.value;
        if (event.value === 'Back') {
            this.goBack();
        }
    }
    goBack() {
        if (this.titlePage) {
            this.router.navigate(['/chinh-sach/an-ca']);
        }
        else {
            this.back.emit();
        }
    }
    cancelUpdate(data) {
        if (data === 'CauHinh') {
            this.getAnCaInfo();
        }
        else if (data === "Back") {
            this.router.navigate(['/chinh-sach/an-ca']);
        }
        else {
            this.manhinh = 'Edit';
            this.getAnCaInfo();
        }
    }
}
ChiTietAnCaComponent.ɵfac = function ChiTietAnCaComponent_Factory(t) { return new (t || ChiTietAnCaComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_11__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router)); };
ChiTietAnCaComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({ type: ChiTietAnCaComponent, selectors: [["app-chi-tiet-an-ca"]], inputs: { dataRouter: "dataRouter" }, outputs: { back: "back" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵNgOnChangesFeature"]], decls: 15, vars: 4, consts: [[1, "main-grid", "product-detail"], [1, "breadcrumb"], [3, "model"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [1, "panel-heading"], [1, "panel-title"], [1, "row", "mt-2"], [1, "col-md-8"], ["class", "field-checkbox col-md-4 justify-content-center", 4, "ngFor", "ngForOf"], [1, "col-md-2"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"], [1, "field-checkbox", "col-md-4", "justify-content-center"], ["name", "group1", 3, "value", "disabled", "ngModel", "inputId", "ngModelChange"], [3, "for"]], template: function ChiTietAnCaComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](3, "p-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](6, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](7, ChiTietAnCaComponent_app_edit_detail_7_Template, 1, 4, "app-edit-detail", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](8, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](9, "h3", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](10, " Danh s\u00E1ch \u0103n ca ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](11, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](12, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](13, ChiTietAnCaComponent_div_13_Template, 4, 6, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](14, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("model", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](ctx.titlePage);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.listDates);
    } }, directives: [primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_12__.Breadcrumb, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgForOf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_6__.EditDetailComponent, primeng_checkbox__WEBPACK_IMPORTED_MODULE_14__.Checkbox, _angular_forms__WEBPACK_IMPORTED_MODULE_15__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_15__.NgModel], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC1hbi1jYS5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 47936:
/*!***********************************************************!*\
  !*** ./src/app/components/cs-an-ca/cs-an-ca.component.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CsAnCaComponent": () => (/* binding */ CsAnCaComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! file-saver */ 68178);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/common/form-filter/form-filter.component */ 83844);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/dynamicdialog */ 56427);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../common/edit-detail/edit-detail.component */ 58638);







































function CsAnCaComponent_app_list_grid_angular_31_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "app-list-grid-angular", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("callback", function CsAnCaComponent_app_list_grid_angular_31_Template_app_list_grid_angular_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r6.rowSelected($event); })("showConfig", function CsAnCaComponent_app_list_grid_angular_31_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r7); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r8.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
const _c0 = function (a0) { return [a0]; };
function CsAnCaComponent_ng_template_38_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](3, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](4, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](5, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](6, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](8, "C\u00F4ng ty tr\u1EA3 l\u01B0\u01A1ng");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](9, "p-dropdown", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function CsAnCaComponent_ng_template_38_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r9.query.companyIds = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](10, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](11, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](12, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](13, "T\u1EEB ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](14, "p-calendar", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function CsAnCaComponent_ng_template_38_Template_p_calendar_ngModelChange_14_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r10); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r11.query.fromdate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](15, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](16, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](17, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](18, "\u0110\u1EBFn ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](19, "p-calendar", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function CsAnCaComponent_ng_template_38_Template_p_calendar_ngModelChange_19_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r10); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r12.query.todate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](20, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](21, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](22, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](23, "B\u1ED9 ph\u1EADn");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](24, "p-treeSelect", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function CsAnCaComponent_ng_template_38_Template_p_treeSelect_ngModelChange_24_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r10); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r13.selectedValue = $event; })("onNodeSelect", function CsAnCaComponent_ng_template_38_Template_p_treeSelect_onNodeSelect_24_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r10); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r14.getOrgPositions(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](25, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](26, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](27, "label", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](28, "Ch\u1EE9c v\u1EE5");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](29, "p-dropdown", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function CsAnCaComponent_ng_template_38_Template_p_dropdown_ngModelChange_29_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r10); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r15.query.position = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](30, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](31, "label", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](32, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](33, "span", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](34, "p-button", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsAnCaComponent_ng_template_38_Template_p_button_click_34_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r10); const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r16.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](35, "p-button", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsAnCaComponent_ng_template_38_Template_p_button_click_35_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r10); const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r17.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("baseZIndex", 100)("options", ctx_r3.companies)("ngModel", ctx_r3.query.companyIds)("filter", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r3.query.fromdate)("monthNavigator", true)("yearNavigator", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r3.query.todate)("monthNavigator", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngModel", ctx_r3.selectedValue)("filterInputAutoFocus", true)("metaKeySelection", true)("filter", true)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction1"](24, _c0, ctx_r3.departmentFiltes.length <= 0 ? "tree-empty" : ""))("options", ctx_r3.departmentFiltes);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngClass", ctx_r3.query.position ? "valid" : "invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r3.positions)("ngModel", ctx_r3.query.position);
} }
function CsAnCaComponent_app_config_grid_table_form_40_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](0, "app-config-grid-table-form", 59);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r4.gridKey);
} }
function CsAnCaComponent_app_edit_detail_42_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "app-edit-detail", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("callback", function CsAnCaComponent_app_edit_detail_42_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r19); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r18.setChitiet($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("detail", ctx_r5.detailInfo)("manhinh", "Edit")("dataView", ctx_r5.listViews);
} }
const _c1 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c2 = function () { return { showAll: "ALL" }; };
const _c3 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c4 = function () { return { width: "700px" }; };
const _c5 = function () { return { width: "50vw" }; };
class CsAnCaComponent {
    constructor(spinner, apiService, route, changeDetector, confirmationService, messageService, organizeInfoService, dialogService, router) {
        this.spinner = spinner;
        this.apiService = apiService;
        this.route = route;
        this.changeDetector = changeDetector;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.dialogService = dialogService;
        this.router = router;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.ACTIONS;
        this.rowDataSelected = [];
        this.listStatus = [];
        this.listOrgRoots = [];
        this.displayFrom = false;
        this.pagingComponent = {
            total: 0
        };
        this.detailInfo = null;
        this.listViews = [];
        this.isDetail = false;
        this.titleForm = {
            label: 'Thêm mới tài khoản',
            value: 'Add'
        };
        this.listViewsFilter = [];
        this.detailInfoFilter = null;
        this.optionsButonFilter = [
            { label: 'Tìm kiếm', value: 'Search', class: 'p-button-sm height-56 addNew', icon: 'pi pi-search' },
            { label: 'Làm mới', value: 'Reset', class: 'p-button-sm p-button-danger height-56 addNew', icon: 'pi pi-times' },
        ];
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.selectedValue = null;
        this.query = {
            orgId: null,
            // request_status: '',
            filter: '',
            offSet: 0,
            pageSize: 15,
            fromdate: new Date(moment__WEBPACK_IMPORTED_MODULE_2__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            todate: new Date(moment__WEBPACK_IMPORTED_MODULE_2__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
            organizeIds: '',
            position: '',
            companyIds: []
        };
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.companies = [];
        this.listsData = [];
        this.displaySetting = false;
        this.gridKey = '';
        this.loadjs = 0;
        this.heightGrid = 0;
        this.departmentFiltes = [];
        this.positions = [];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__.AvatarFullComponent,
        };
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    cancel() {
        this.selectedValue = null;
        this.query = {
            orgId: null,
            // request_status: '',
            filter: '',
            offSet: 0,
            pageSize: 15,
            fromdate: new Date(moment__WEBPACK_IMPORTED_MODULE_2__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            todate: new Date(moment__WEBPACK_IMPORTED_MODULE_2__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
            organizeIds: this.query.organizeIds,
            companyIds: this.query.companyIds
        };
        if (this.companies.length > 0) {
            this.query.companyIds = this.companies[0].value;
        }
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        let params = Object.assign({}, this.query);
        let companyIds = this.query.companyIds.toString();
        params.companyIds = companyIds;
        delete params.fromdate;
        delete params.todate;
        params.FromDate = moment__WEBPACK_IMPORTED_MODULE_2__(new Date(this.query.fromdate)).format('YYYY-MM-DD');
        params.ToDate = moment__WEBPACK_IMPORTED_MODULE_2__(new Date(this.query.todate)).format('YYYY-MM-DD');
        params.orgId = this.selectedValue ? this.selectedValue.orgId : null;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.apiService.getEatingPage(queryParams).subscribe((results) => {
            this.listsData = results.data.result.dataList.data;
            this.gridKey = results.data.result.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.result.gridflexs;
                // this.colsDetail =  results.data.result.gridflexdetails ?  results.data.result.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.result.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.result.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.result.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.result.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.result.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.listDetail.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.MENUACTIONROLEAPI.GetEatingPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_8__.ACTIONS.VIEW)
                },
                // {
                //   onClick: this.xoaTienLuong.bind(this),
                //   label: 'Xóa',
                //   icon: 'pi pi-trash',
                //   class: 'btn-primary mr5',
                // },
                // {
                //   onClick: this.CloseAccount.bind(this),
                //   label: 'Đóng tài khoản',
                //   icon: 'pi pi-trash',
                //   class: 'btn-primary mr5',
                // },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: '',
                filter: '',
                width: 60,
                pinned: 'left',
                cellClass: ['border-right', 'no-auto'],
                field: 'checkbox2',
                headerCheckboxSelection: false,
                suppressSizeToFit: true,
                suppressRowClickSelection: true,
                showDisabledCheckboxes: true,
                checkboxSelection: true,
                rowSelection: 'single'
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    xoaTienLuong(event) {
        // this.confirmationService.confirm({
        //   message: 'Bạn có chắc chắn muốn thực hiện mở tài khoản?',
        //   accept: () => {
        //     const queryParams = queryString.stringify({ companyId: event.rowData.companyId });
        //     this.apiService.delCompanyInfo(queryParams).subscribe(results => {
        //       if (results.status === 'success') {
        //         this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa công ty thành công' });
        //         this.load();
        //       } else {
        //         this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
        //       }
        //     });
        //   }
        // });
    }
    XemChiTiet(event) {
        const params = {
            custId: event.rowData.custId
        };
        this.router.navigate(['/chinh-sach/an-ca/chi-tiet-an-ca'], { queryParams: params });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        let b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                const totalHeight = a.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.loadjs = 0;
            }
        }
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.rowDataSelected = [];
                this.getCompany();
                this.getOrganizeTree();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Danh sách ăn ca' },
        ];
        this.getOrgRoots();
        this.getFilter();
    }
    getOrgRoots() {
        this.apiService.getOrgRoots().subscribe(results => {
            if (results.status === 'success') {
                this.listOrgRoots = results.data.map(d => {
                    return {
                        label: d.org_name + '-' + d.org_cd,
                        value: `${d.orgId}`
                    };
                });
                this.listOrgRoots = [{ label: 'Tất cả', value: null }, ...this.listOrgRoots];
            }
        });
    }
    getOrganizeTree() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ parentId: this.query.organizeIds });
        this.apiService.getOrganizeTree(queryParams)
            .subscribe((results) => {
            if (results && results.status === 'success') {
                this.departmentFiltes = results.data;
            }
        }, error => { });
    }
    onNodeSelect(event) {
    }
    sizeToFit() {
        if (this.gridApi) {
            let allColumnIds = [];
            this.gridColumnApi.getAllColumns()
                .forEach((column) => {
                if (column.colDef.cellClass.indexOf('no-auto') < 0) {
                    allColumnIds.push(column);
                }
                else {
                    column.colDef.suppressSizeToFit = true;
                    allColumnIds.push(column);
                }
            });
            this.gridApi.sizeColumnsToFit(allColumnIds);
        }
    }
    autoSizeAll() {
        if (this.gridColumnApi) {
            if (this.gridColumnApi.columnController.bodyWidth < this.gridColumnApi.columnController.scrollWidth) {
                this.sizeToFit();
            }
            else {
                let allColumnIds = [];
                this.gridColumnApi.getAllColumns()
                    .forEach((column) => {
                    if (column.colDef.cellClass.indexOf('no-auto') < 0) {
                        allColumnIds.push(column);
                    }
                });
                this.gridColumnApi.autoSizeColumns(allColumnIds, false);
            }
        }
    }
    // list ăn ca
    listDetail(event = null) {
        const params = {
            cusId: ''
        };
        if (event) {
            params.cusId = event.rowData.custId;
        }
        this.router.navigate(['/chinh-sach/an-ca/chi-tiet-danh-sach-an-ca'], { queryParams: params });
    }
    rowSelected(event) {
        this.rowDataSelected = event;
    }
    handAddNew() {
        this.detailInfo = [];
        this.listViews = [];
        const params = { cusId: null };
        this.isDetail = true;
        this.apiService.getEatingForCreateInfo(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params)).subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_10__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.detailInfo = results.data;
            }
        });
    }
    getOrgPositions() {
        this.positions = [];
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ orgId: this.selectedValue.data });
        this.apiService.getOrgPositions(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.positions = results.data.map(d => {
                    return { label: d.positionName, value: d.positionCd };
                });
                this.positions = [{ label: 'Tất cả', value: null }, ...this.positions];
            }
        });
    }
    getCompany() {
        const query = { organizeIds: this.query.organizeIds };
        this.apiService.getUserCompanies(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query)).subscribe((results) => {
            if (results.status === "success") {
                this.companies = results.data
                    .map(d => {
                    return {
                        label: d.name,
                        value: d.value
                    };
                });
                if (this.companies.length > 0) {
                    this.query.companyIds = this.companies[0].value;
                }
                this.load();
            }
        }),
            error => { };
    }
    setChitiet(data) {
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setEatingInfo(params).subscribe((results) => {
            if (results.status === 'success') {
                this.isDetail = false;
                this.load();
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Cập nhật thông tin thành công' });
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo', detail: results.message
                });
            }
        }, error => {
        });
    }
    exportData() {
        this.spinner.show();
        let params = Object.assign({}, this.query);
        let companyIds = this.query.companyIds.toString();
        params.companyIds = companyIds;
        delete params.fromdate;
        delete params.todate;
        params.FromDate = moment__WEBPACK_IMPORTED_MODULE_2__(new Date(this.query.fromdate)).format('YYYY-MM-DD');
        params.ToDate = moment__WEBPACK_IMPORTED_MODULE_2__(new Date(this.query.todate)).format('YYYY-MM-DD');
        params.orgId = this.selectedValue ? this.selectedValue.orgId : null;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.apiService.gxportEatingPage(queryParams).subscribe(results => {
            if (results.type === 'application/json') {
                this.spinner.hide();
            }
            else {
                var blob = new Blob([results], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                file_saver__WEBPACK_IMPORTED_MODULE_11__.saveAs(blob, `Danh sách ăn ca` + ".xlsx");
                this.spinner.hide();
            }
        });
    }
    //filter 
    getFilter() {
        this.apiService.getFilter('/api/v1/eating/GetEatingFilter').subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_10__.cloneDeep)(results.data.group_fields);
                this.listViewsFilter = [...listViews];
                this.detailInfoFilter = results.data;
            }
        });
    }
    showFilter() {
        const ref = this.dialogService.open(src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_12__.FormFilterComponent, {
            header: 'Tìm kiếm nâng cao',
            width: '40%',
            contentStyle: "",
            data: {
                listViews: this.listViewsFilter,
                detailInfoFilter: this.detailInfoFilter,
                buttons: this.optionsButonFilter
            }
        });
        ref.onClose.subscribe((event) => {
            if (event) {
                this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_10__.cloneDeep)(event.listViewsFilter);
                if (event.type === 'Search') {
                    this.query = Object.assign(Object.assign({}, this.query), event.data);
                    this.load();
                }
                else if (event.type === 'CauHinh') {
                    this.apiService.getEmpFilter().subscribe(results => {
                        if (results.status === 'success') {
                            const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_10__.cloneDeep)(results.data.group_fields);
                            this.listViewsFilter = [...listViews];
                            this.detailInfoFilter = results.data;
                            this.showFilter();
                        }
                    });
                }
                else if (event.type === 'Reset') {
                    const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_10__.cloneDeep)(this.detailInfoFilter.group_fields);
                    this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_10__.cloneDeep)(listViews);
                    this.cancel();
                }
            }
        });
    }
}
CsAnCaComponent.ɵfac = function CsAnCaComponent_Factory(t) { return new (t || CsAnCaComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_19__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_7__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_20__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_18__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_21__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_21__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_9__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_22__.DialogService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_20__.Router)); };
CsAnCaComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdefineComponent"]({ type: CsAnCaComponent, selectors: [["app-cs-an-ca"]], decls: 43, vars: 41, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "end", "mid", "bottom", "gap-12", "col-9", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["_ngcontent-xmj-c197", "", "width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["_ngcontent-xmj-c197", "", "fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "height-56", "label", "Th\u00EAm m\u1EDBi", "styleClass", "height-56", "icon", "pi pi-plus ", 3, "CheckHideActions", "click"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "14", "height", "20", "viewBox", "0 0 14 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M0.333008 18.333C0.333008 18.7932 0.706104 19.1663 1.16634 19.1663H12.833C13.2932 19.1663 13.6663 18.7932 13.6663 18.333V1.66634C13.6663 1.2061 13.2932 0.833008 12.833 0.833008H1.16634C0.706104 0.833008 0.333008 1.2061 0.333008 1.66634V18.333ZM1.99967 2.49967H11.9997V17.4997H1.99967V2.49967Z", "fill", "#F6FBFF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M4.49982 15.3097C4.49982 14.9083 4.82181 14.583 5.219 14.583H8.78064C9.17783 14.583 9.49982 14.9083 9.49982 15.3097C9.49982 15.711 9.17783 16.0364 8.78064 16.0364H5.219C4.82181 16.0364 4.49982 15.711 4.49982 15.3097Z", "fill", "#F6FBFF"], ["styleClass", "p-button-sm height-56", "icon", "pi pi-file-excel", "label", "Export", 3, "CheckHideActions", "click"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "callback", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["header", "Chi ti\u1EBFt", 3, "visible", "modal", "visibleChange"], [3, "detail", "manhinh", "dataView", "callback", 4, "ngIf"], [3, "listsData", "height", "columnDefs", "callback", "showConfig"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select"], ["appendTo", "body", "name", "companyIds", 3, "baseZIndex", "options", "ngModel", "filter", "ngModelChange"], [1, "field-group", "date", "valid"], ["panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "fromdate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "yearNavigator", "ngModelChange"], ["panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "todate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "ngModelChange"], [1, "field-group", "select", "mb-0", "label-8"], ["selectionMode", "single", "name", "selectedValue", "placeholder", "Ch\u1ECDn ph\u00F2ng ban", 3, "ngModel", "filterInputAutoFocus", "metaKeySelection", "filter", "ngClass", "options", "ngModelChange", "onNodeSelect"], [1, "field-group", "select", "label-8", 3, "ngClass"], ["for", ""], ["appendTo", "body", "name", "position", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [3, "typeConfig", "gridKey"], [3, "detail", "manhinh", "dataView", "callback"]], template: function CsAnCaComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("keydown.enter", function CsAnCaComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function CsAnCaComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsAnCaComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsAnCaComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsAnCaComponent_Template_p_button_click_15_listener() { return ctx.showFilter(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](21, "p-button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsAnCaComponent_Template_p_button_click_21_listener() { return ctx.handAddNew(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](22, "p-button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsAnCaComponent_Template_p_button_click_22_listener() { return ctx.listDetail(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](23, "svg", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](24, "path", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](25, "path", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](26, "\u00A0\u00A0 Xem chi ti\u1EBFt ");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](27, "p-button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsAnCaComponent_Template_p_button_click_27_listener() { return ctx.exportData(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](28, "section", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](29, "div", 27, 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](31, CsAnCaComponent_app_list_grid_angular_31_Template, 1, 3, "app-list-grid-angular", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](32, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](33, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](34);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](35, "p-paginator", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("onPageChange", function CsAnCaComponent_Template_p_paginator_onPageChange_35_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](36, "p-overlayPanel", 32, 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](38, CsAnCaComponent_ng_template_38_Template, 36, 26, "ng-template", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](39, "p-dialog", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("visibleChange", function CsAnCaComponent_Template_p_dialog_visibleChange_39_listener($event) { return ctx.displaySetting = $event; })("onHide", function CsAnCaComponent_Template_p_dialog_onHide_39_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](40, CsAnCaComponent_app_config_grid_table_form_40_Template, 1, 2, "app-config-grid-table-form", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](41, "p-dialog", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("visibleChange", function CsAnCaComponent_Template_p_dialog_visibleChange_41_listener($event) { return ctx.isDetail = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](42, CsAnCaComponent_app_edit_detail_42_Template, 1, 3, "app-edit-detail", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction2"](29, _c1, ctx.MENUACTIONROLEAPI.GetEatingPage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction2"](32, _c1, ctx.MENUACTIONROLEAPI.GetEatingPage.url, ctx.ACTIONS.EXPORT));
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction1"](36, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](35, _c2)));
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](38, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](39, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](40, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("visible", ctx.isDetail)("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_13__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_23__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_25__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_14__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_23__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_26__.Paginator, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_27__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_21__.PrimeTemplate, primeng_dialog__WEBPACK_IMPORTED_MODULE_28__.Dialog, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_15__.ListGridAngularComponent, primeng_dropdown__WEBPACK_IMPORTED_MODULE_29__.Dropdown, primeng_calendar__WEBPACK_IMPORTED_MODULE_30__.Calendar, primeng_treeselect__WEBPACK_IMPORTED_MODULE_31__.TreeSelect, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_16__.ConfigGridTableFormComponent, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_17__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjcy1hbi1jYS5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 82901:
/*!**************************************************************************!*\
  !*** ./src/app/components/cs-an-ca/eating-list/eating-list.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EatingListComponent": () => (/* binding */ EatingListComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! file-saver */ 68178);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);






























function EatingListComponent_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](7, "T\u1EEB ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "p-calendar", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function EatingListComponent_ng_template_11_Template_p_calendar_ngModelChange_8_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r6.query.fromdate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](11, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](12, "\u0110\u1EBFn ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "p-calendar", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function EatingListComponent_ng_template_11_Template_p_calendar_ngModelChange_13_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r7); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r8.query.todate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r1.query.fromdate)("monthNavigator", true)("yearNavigator", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r1.query.todate)("monthNavigator", true)("yearNavigator", true);
} }
function EatingListComponent_app_list_grid_angular_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-list-grid-angular", 29);
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("listsData", ctx_r3.listsData)("height", ctx_r3.heightGrid)("columnDefs", ctx_r3.columnDefs);
} }
function EatingListComponent_app_config_grid_table_form_23_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-config-grid-table-form", 30);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r4.gridKey);
} }
function EatingListComponent_app_edit_detail_25_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-edit-detail", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("callback", function EatingListComponent_app_edit_detail_25_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r9.setChitiet($event); })("callbackcancel", function EatingListComponent_app_edit_detail_25_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r10); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r11.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("detail", ctx_r5.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r5.optionsButon)("dataView", ctx_r5.listViews);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { width: "400px" }; };
const _c2 = function () { return { showAll: "ALL" }; };
const _c3 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c4 = function () { return { width: "50vw" }; };
class EatingListComponent {
    constructor(spinner, apiService, activatedRoute, changeDetector, confirmationService, messageService, organizeInfoService, router) {
        this.spinner = spinner;
        this.apiService = apiService;
        this.activatedRoute = activatedRoute;
        this.changeDetector = changeDetector;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS;
        this.rowDataSelected = [];
        this.detailInfo = null;
        this.listViews = [];
        this.listStatus = [];
        this.listOrgRoots = [];
        this.displayFrom = false;
        this.pagingComponent = {
            total: 0
        };
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.paramsObject = null;
        this.query = {
            cusId: null,
            offSet: 0,
            pageSize: 15,
            fromdate: new Date(moment__WEBPACK_IMPORTED_MODULE_1__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            todate: new Date(moment__WEBPACK_IMPORTED_MODULE_1__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
        };
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.listsData = [];
        this.displaySetting = false;
        this.gridKey = '';
        this.isDetail = false;
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', icon: 'pi pi-check' }
        ];
        this.loadjs = 0;
        this.heightGrid = 0;
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Danh sách ăn ca', routerLink: '/chinh-sach/an-ca/' },
            { label: 'Chi tiết danh sách ăn ca' },
        ];
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap.subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.query.cusId = this.paramsObject.params.cusId;
            this.load();
        });
    }
    ;
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    cancel() {
        this.query = {
            cusId: this.query.cusId,
            offSet: 0,
            pageSize: 15,
            fromdate: new Date(moment__WEBPACK_IMPORTED_MODULE_1__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            todate: new Date(moment__WEBPACK_IMPORTED_MODULE_1__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
        };
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        let params = Object.assign({}, this.query);
        delete params.fromdate;
        delete params.todate;
        params.FromDate = moment__WEBPACK_IMPORTED_MODULE_1__(new Date(this.query.fromdate)).format('YYYY-MM-DD');
        params.ToDate = moment__WEBPACK_IMPORTED_MODULE_1__(new Date(this.query.todate)).format('YYYY-MM-DD');
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.apiService.getEatingList(queryParams).subscribe((results) => {
            this.listsData = results.data.result.dataList.data;
            this.gridKey = results.data.result.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.result.gridflexs;
                // this.colsDetail =  results.data.result.gridflexdetails ?  results.data.result.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.result.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.result.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.result.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.result.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.result.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.xoaAnca.bind(this),
                    label: 'Xóa',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI.GetEatingPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS.DELETE)
                },
            ]
        };
    }
    xoaAnca(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa?',
            accept: () => {
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ EatingId: event.rowData.id });
                this.apiService.delEatingInfo(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    XemChiTiet(event) {
        const params = {
            custId: event.rowData.custId
        };
        this.router.navigate(['/chinh-sach/an-ca/chi-tiet-an-ca'], { queryParams: params });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    addNew() {
        this.detailInfo = [];
        this.listViews = [];
        this.isDetail = true;
        const params = { cusId: null };
        this.apiService.getEatingForCreateInfo(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params)).subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_6__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.detailInfo = results.data;
            }
        });
    }
    setChitiet(data) {
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setEatingInfo(params).subscribe((results) => {
            if (results.status === 'success') {
                this.isDetail = false;
                this.load();
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Cập nhật thông tin thành công' });
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo', detail: results.message
                });
            }
        }, error => {
        });
    }
    exportData() {
        this.spinner.show();
        let params = Object.assign({}, this.query);
        delete params.fromdate;
        delete params.todate;
        params.FromDate = moment__WEBPACK_IMPORTED_MODULE_1__(new Date(this.query.fromdate)).format('YYYY-MM-DD');
        params.ToDate = moment__WEBPACK_IMPORTED_MODULE_1__(new Date(this.query.todate)).format('YYYY-MM-DD');
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.apiService.exportEatingInfo(queryParams).subscribe(results => {
            if (results.type === 'application/json') {
                this.spinner.hide();
            }
            else {
                var blob = new Blob([results], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                file_saver__WEBPACK_IMPORTED_MODULE_7__.saveAs(blob, `Chi tiết danh sách ăn ca` + ".xlsx");
                this.spinner.hide();
            }
        });
    }
    goBack() {
        this.router.navigate(['/chinh-sach/cham-cong']);
    }
    quaylai(event) {
    }
}
EatingListComponent.ɵfac = function EatingListComponent_Factory(t) { return new (t || EatingListComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_14__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_15__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_16__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_16__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_5__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_15__.Router)); };
EatingListComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({ type: EatingListComponent, selectors: [["app-eating-list"]], decls: 26, vars: 35, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [3, "items"], ["styleClass", "p-button-sm height-56", "icon", "pi pi-file-excel", "label", "Export", 3, "CheckHideActions", "click"], [1, "bread-filter"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "col-item"], [1, "filter", "filter-search"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [1, "d-flex", "align-items-center", "gap-16"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["header", "Chi ti\u1EBFt", 3, "visible", "modal", "visibleChange"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "col-12"], [1, "field-group", "date", "mb-0", "valid"], ["dateFormat", "dd/mm/yy", "panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "yearRange", "2010:2030", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "fromdate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "yearNavigator", "ngModelChange"], ["dateFormat", "dd/mm/yy", "panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "yearRange", "2010:2030", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "todate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "yearNavigator", "ngModelChange"], [3, "listsData", "height", "columnDefs"], [3, "typeConfig", "gridKey"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function EatingListComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "p-button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function EatingListComponent_Template_p_button_click_4_listener() { return ctx.exportData(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "section", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "p-overlayPanel", 9, 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](11, EatingListComponent_ng_template_11_Template, 14, 10, "ng-template", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](13, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](14, "section", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "div", 14, 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](17, EatingListComponent_app_list_grid_angular_17_Template, 1, 3, "app-list-grid-angular", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](18, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](21, "p-paginator", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onPageChange", function EatingListComponent_Template_p_paginator_onPageChange_21_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](22, "p-dialog", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("visibleChange", function EatingListComponent_Template_p_dialog_visibleChange_22_listener($event) { return ctx.displaySetting = $event; })("onHide", function EatingListComponent_Template_p_dialog_onHide_22_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](23, EatingListComponent_app_config_grid_table_form_23_Template, 1, 2, "app-config-grid-table-form", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](24, "p-dialog", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("visibleChange", function EatingListComponent_Template_p_dialog_visibleChange_24_listener($event) { return ctx.isDetail = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](25, EatingListComponent_app_edit_detail_25_Template, 1, 4, "app-edit-detail", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](26, _c0, ctx.MENUACTIONROLEAPI.GetEatingPage.url, ctx.ACTIONS.EXPORT));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](29, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](31, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](30, _c2)));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](33, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](34, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("visible", ctx.isDetail)("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_17__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_9__.CheckHideActionsDirective, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_18__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_16__.PrimeTemplate, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_20__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.Dialog, primeng_calendar__WEBPACK_IMPORTED_MODULE_22__.Calendar, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgModel, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_11__.ConfigGridTableFormComponent, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_12__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlYXRpbmctbGlzdC5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 13265:
/*!********************************************************************************************!*\
  !*** ./src/app/components/cs-cham-cong/chi-tiet-cham-cong/chi-tiet-cham-cong.component.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietChamCongComponent": () => (/* binding */ ChiTietChamCongComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);


















function ChiTietChamCongComponent_app_edit_detail_7_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "app-edit-detail", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("callback", function ChiTietChamCongComponent_app_edit_detail_7_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r2.setCompanyInfo($event); })("callbackcancel", function ChiTietChamCongComponent_app_edit_detail_7_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r3); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r4.cancelUpdate($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("optionsButtonsEdit", ctx_r0.optionsButtonsView)("detail", ctx_r0.detailInfo)("manhinh", "Edit")("dataView", ctx_r0.listViews);
} }
function ChiTietChamCongComponent_app_list_grid_angular_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "app-list-grid-angular", 7);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("height", 480)("listsData", ctx_r1.listsData)("columnDefs", ctx_r1.columnDefs);
} }
class ChiTietChamCongComponent {
    constructor(apiService, activatedRoute, messageService, confirmationService, spinner, router) {
        this.apiService = apiService;
        this.activatedRoute = activatedRoute;
        this.messageService = messageService;
        this.confirmationService = confirmationService;
        this.spinner = spinner;
        this.router = router;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
        this.manhinh = 'Edit';
        this.indexTab = 0;
        this.optionsButtonsView = [{ label: 'Quay lại', value: 'Cancel', icon: 'pi pi-arrow-left' }];
        this.displayScreemForm = false;
        this.displaysearchUserMaster = false;
        this.listViewsForm = [];
        this.detailComAuthorizeInfo = null;
        this.recordId = null;
        this.listViews = [];
        this.imagesUrl = [];
        this.paramsObject = null;
        this.displayUserInfo = false;
        this.titleForm = {
            label: 'Cập nhật thông tin khách hàng',
            value: 'Edit'
        };
        this.titlePage = '';
        this.url = '';
        this.detailInfo = null;
        this.listsData = [];
        this.dataRouter = null;
        this.back = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
        this.items = [];
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Danh sách chấm công', routerLink: '/chinh-sach/cham-cong' },
            { label: this.titlePage },
        ];
        this.url = this.activatedRoute.data['_value'].url;
        this.manhinh = 'Edit';
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap.subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.dataRouter = this.paramsObject.params;
            // this.recordId = this.paramsObject.params.recordId;
            this.getChamCongInfo();
        });
    }
    ;
    getChamCongInfo() {
        this.listViews = [];
        this.listsData = [];
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.paramsObject.params);
        this.apiService.getTimekeepingInfo(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(results.data.group_fields);
                this.detailInfo = results.data;
                this.listsData = results.data.checkinouts;
                this.columnDefs = [...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.AgGridFn)(results.data.gridflexcheckinout.filter((d) => !d.isHide))];
            }
        });
    }
    handleChange(index) {
        this.indexTab = index;
    }
    setCompanyInfo(data) {
        // const params = {
        //   ...this.detailInfo, group_fields: data
        // };
        // this.apiService.setCompanyInfo(params).subscribe((results: any) => {
        //   if (results.status === 'success') {
        //     this.displayUserInfo = false;
        //     if(this.url === 'them-moi-nghi-phep') {
        //       this.goBack()
        //     }else {
        //       this.manhinh = 'Edit';
        //       this.getCompanyInfo();
        //     }
        //     this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Cập nhật thông tin thành công' });
        //   } else {
        //     this.messageService.add({
        //       severity: 'error', summary: 'Thông báo', detail: results.message
        //     });
        //   }
        // }, error => {
        // });
    }
    initGrid() {
    }
    onChangeButtonView(event) {
        this.manhinh = event.value;
        if (event.value === 'Back') {
            this.goBack();
        }
    }
    goBack() {
        if (this.titlePage) {
            this.router.navigate(['/chinh-sach/cham-cong']);
        }
        else {
            this.back.emit();
        }
    }
    cancelUpdate(data) {
        if (data === 'CauHinh') {
            this.getChamCongInfo();
        }
        else {
            this.router.navigate(['/chinh-sach/cham-cong']);
        }
    }
}
ChiTietChamCongComponent.ɵfac = function ChiTietChamCongComponent_Factory(t) { return new (t || ChiTietChamCongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router)); };
ChiTietChamCongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: ChiTietChamCongComponent, selectors: [["app-chi-tiet-cham-cong"]], inputs: { dataRouter: "dataRouter" }, outputs: { back: "back" }, decls: 11, vars: 4, consts: [[1, "main-grid", "product-detail"], [1, "breadcrumb"], [3, "model"], [3, "optionsButtonsEdit", "detail", "manhinh", "dataView", "callback", "callbackcancel", 4, "ngIf"], [1, "grid-default", "border"], [3, "height", "listsData", "columnDefs", 4, "ngIf"], [3, "optionsButtonsEdit", "detail", "manhinh", "dataView", "callback", "callbackcancel"], [3, "height", "listsData", "columnDefs"]], template: function ChiTietChamCongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "p-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](7, ChiTietChamCongComponent_app_edit_detail_7_Template, 1, 4, "app-edit-detail", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](8, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](10, ChiTietChamCongComponent_app_list_grid_angular_10_Template, 1, 3, "app-list-grid-angular", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("model", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.titlePage);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", (ctx.columnDefs == null ? null : ctx.columnDefs.length) > 0);
    } }, directives: [primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_11__.Breadcrumb, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_4__.EditDetailComponent, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_5__.ListGridAngularComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC1jaGFtLWNvbmcuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 59221:
/*!*******************************************************************!*\
  !*** ./src/app/components/cs-cham-cong/cs-cham-cong.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CsChamCongComponent": () => (/* binding */ CsChamCongComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! file-saver */ 68178);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/common/form-filter/form-filter.component */ 83844);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dynamicdialog */ 56427);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);




































function CsChamCongComponent_app_list_grid_angular_26_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "app-list-grid-angular", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("showConfig", function CsChamCongComponent_app_list_grid_angular_26_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r5.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function CsChamCongComponent_ng_template_33_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](4, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](5, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](6, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](8, "C\u00F4ng ty tr\u1EA3 l\u01B0\u01A1ng");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](9, "p-dropdown", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("ngModelChange", function CsChamCongComponent_ng_template_33_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r7.query.companyIds = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](10, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](11, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](12, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](13, "Th\u00E1ng");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](14, "input", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("ngModelChange", function CsChamCongComponent_ng_template_33_Template_input_ngModelChange_14_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r8); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r9.query.month = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](15, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](16, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](17, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](18, "N\u0103m");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](19, "input", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("ngModelChange", function CsChamCongComponent_ng_template_33_Template_input_ngModelChange_19_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r8); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r10.query.year = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](20, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](21, "label", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](22, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](23, "span", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](24, "p-button", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function CsChamCongComponent_ng_template_33_Template_p_button_click_24_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r8); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r11.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](25, "p-button", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function CsChamCongComponent_ng_template_33_Template_p_button_click_25_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r8); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](); return ctx_r12.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("baseZIndex", 100)("options", ctx_r3.companies)("ngModel", ctx_r3.query.companyIds)("filter", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngModel", ctx_r3.query.month);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngModel", ctx_r3.query.year);
} }
function CsChamCongComponent_app_config_grid_table_form_35_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](0, "app-config-grid-table-form", 48);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r4.gridKey);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { showAll: "ALL" }; };
const _c2 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c3 = function () { return { width: "700px" }; };
const _c4 = function () { return { width: "50vw" }; };
class CsChamCongComponent {
    constructor(spinner, apiService, route, changeDetector, confirmationService, messageService, organizeInfoService, dialogService, router) {
        this.spinner = spinner;
        this.apiService = apiService;
        this.route = route;
        this.changeDetector = changeDetector;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.dialogService = dialogService;
        this.router = router;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS;
        this.modelAdd = {
            date: new Date(),
            organizeId: ''
        };
        this.listOrgRoots = [];
        this.displayFrom = false;
        this.pagingComponent = {
            total: 0
        };
        this.titleForm = {
            label: 'Thêm mới tài khoản',
            value: 'Add'
        };
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.query = {
            organizeId: null,
            // fromDate: new Date(moment(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1,'months').format()),
            // toDate: new Date(moment(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
            filter: '',
            offSet: 0,
            pageSize: 15,
            month: new Date().getMonth() + 1,
            year: new Date().getFullYear(),
            organizeIds: '',
            companyIds: [],
        };
        this.queryCheckInOut = {
            filter: '',
            pageSize: 15,
            fromdate: new Date(moment__WEBPACK_IMPORTED_MODULE_7__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            todate: new Date(moment__WEBPACK_IMPORTED_MODULE_7__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
            offSet: 0,
        };
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.loadjs = 0;
        this.heightGrid = 0;
        this.itemsToolOfGrid = [];
        this.companies = [];
        this.listViewsFilter = [];
        this.detailInfoFilter = null;
        this.optionsButonFilter = [
            { label: 'Tìm kiếm', value: 'Search', class: 'p-button-sm height-56 addNew', icon: 'pi pi-search' },
            { label: 'Làm mới', value: 'Reset', class: 'p-button-sm p-button-danger height-56 addNew', icon: 'pi pi-times' },
        ];
        this.displaySetting = false;
        this.gridKey = '';
        this.listsData = [];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_3__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_4__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_5__.AvatarFullComponent,
        };
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    cancel() {
        this.query = {
            organizeId: null,
            // fromDate: new Date(moment(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1,'months').format()),
            // toDate: new Date(moment(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).format()),
            filter: '',
            offSet: 0,
            pageSize: 15,
            month: new Date().getMonth() + 1,
            year: new Date().getFullYear(),
            organizeIds: this.query.organizeIds,
            companyIds: this.query.companyIds,
        };
        if (this.companies.length > 0) {
            this.query.companyIds = this.companies[0].value;
        }
        this.load();
    }
    Export() {
        let params = Object.assign({}, this.query);
        // delete params.organizeId
        delete params.fromDate;
        delete params.toDate;
        // params.FromDate = moment(new Date(this.query.fromDate)).format('YYYY-MM-DD')
        // params.ToDate = moment(new Date(this.query.toDate)).format('YYYY-MM-DD')
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.spinner.show();
        this.apiService.getExportReport('ExportBangLuongThang', queryParams).subscribe(results => {
            if (results.type === 'application/json') {
                this.spinner.hide();
            }
            else {
                var blob = new Blob([results], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                file_saver__WEBPACK_IMPORTED_MODULE_8__.saveAs(blob, `Danh sách chấm công tháng ${this.query.month}` + ".xlsx");
                this.spinner.hide();
            }
        });
    }
    ExportCheckInOut() {
        this.router.navigate(['/chinh-sach/cham-cong/xem-cong']);
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        let params = Object.assign({}, this.query);
        let companyIds = this.query.companyIds.toString();
        params.companyIds = companyIds;
        // params.fromDate = moment(new Date(this.query.fromDate)).format('YYYY-MM-DD')
        // params.toDate = moment(new Date(this.query.toDate)).format('YYYY-MM-DD')
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.apiService.getEmployeeSalaryMonthPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.XemChiTiet.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetEmployeeSalaryMonthPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.VIEW)
                },
            ]
        };
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                maxWidth: 90,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    XemChiTiet(event) {
        const params = {
            empId: event.rowData.empId,
            salary_month: this.query.month,
            salary_year: this.query.year
        };
        this.router.navigate(['/chinh-sach/cham-cong/chi-tiet-cham-cong'], { queryParams: params });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                // this.load();
                // this.getOrgRoots();
                this.getCompany();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Danh sách chấm công' },
        ];
        this.itemsToolOfGrid = [
            {
                label: 'Check in/out',
                code: 'Import',
                icon: 'pi pi-sign-in',
                disabled: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetEmployeeSalaryMonthPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.IMPORT),
                command: () => {
                    this.ExportCheckInOut();
                }
            },
            {
                label: 'Export chấm công',
                code: 'Import',
                icon: 'pi pi-download',
                disabled: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_6__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.MENUACTIONROLEAPI.GetEmployeeSalaryMonthPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_9__.ACTIONS.EXPORT),
                command: () => {
                    this.Export();
                }
            },
        ];
        this.getFilter();
    }
    getCompany() {
        const query = { organizeIds: this.query.organizeIds };
        this.apiService.getUserCompanies(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query)).subscribe((results) => {
            if (results.status === "success") {
                this.companies = results.data
                    .map(d => {
                    return {
                        label: d.name,
                        value: d.value
                    };
                });
                if (this.companies.length > 0) {
                    this.query.companyIds = this.companies[0].value;
                }
                this.load();
            }
        }),
            error => { };
    }
    //filter 
    getFilter() {
        this.apiService.getFilter('/api/v1/timekeeping/GetTimekeepingFilter').subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_11__.cloneDeep)(results.data.group_fields);
                this.listViewsFilter = [...listViews];
                this.detailInfoFilter = results.data;
            }
        });
    }
    showFilter() {
        const ref = this.dialogService.open(src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_12__.FormFilterComponent, {
            header: 'Tìm kiếm nâng cao',
            width: '40%',
            contentStyle: "",
            data: {
                listViews: this.listViewsFilter,
                detailInfoFilter: this.detailInfoFilter,
                buttons: this.optionsButonFilter
            }
        });
        ref.onClose.subscribe((event) => {
            if (event) {
                this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_11__.cloneDeep)(event.listViewsFilter);
                if (event.type === 'Search') {
                    this.query = Object.assign(Object.assign({}, this.query), event.data);
                    this.load();
                }
                else if (event.type === 'CauHinh') {
                    this.apiService.getEmpFilter().subscribe(results => {
                        if (results.status === 'success') {
                            const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_11__.cloneDeep)(results.data.group_fields);
                            this.listViewsFilter = [...listViews];
                            this.detailInfoFilter = results.data;
                            this.showFilter();
                        }
                    });
                }
                else if (event.type === 'Reset') {
                    const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_11__.cloneDeep)(this.detailInfoFilter.group_fields);
                    this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_11__.cloneDeep)(listViews);
                    this.cancel();
                }
            }
        });
    }
    getOrgRoots() {
        this.apiService.getOrgRoots().subscribe(results => {
            if (results.status === 'success') {
                this.listOrgRoots = results.data.map(d => {
                    return {
                        label: d.org_name,
                        value: `${d.orgId}`
                    };
                });
                this.listOrgRoots = [{ label: 'Tất cả', value: null }, ...this.listOrgRoots];
                // this.query.organizeId = this.listOrgRoots[0].value
                this.load();
            }
        });
    }
}
CsChamCongComponent.ɵfac = function CsChamCongComponent_Factory(t) { return new (t || CsChamCongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_18__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_19__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_17__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_20__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_20__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_10__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_21__.DialogService), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_19__.Router)); };
CsChamCongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdefineComponent"]({ type: CsChamCongComponent, selectors: [["app-cs-cham-cong"]], decls: 36, vars: 31, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "end", "mid", "bottom", "gap-12", "col-9", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["_ngcontent-xmj-c197", "", "width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["_ngcontent-xmj-c197", "", "fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", "icon", "pi pi-sign-in", "label", "Check In/Out", 3, "click"], ["styleClass", "p-button-sm height-56", "icon", "pi pi-cloud-download", "label", "Export", 3, "CheckHideActions", "click"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [3, "listsData", "height", "columnDefs", "showConfig"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select"], ["appendTo", "body", "name", "companyIds", 3, "baseZIndex", "options", "ngModel", "filter", "ngModelChange"], [1, "field-group", "text", "label-8", "mb-0"], ["type", "number", "id", "", "placeholder", "Th\u00E1ng", 1, "input-default", 3, "ngModel", "ngModelChange"], ["type", "number", "id", "", "placeholder", "N\u0103m", 1, "input-default", 3, "ngModel", "ngModelChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [3, "typeConfig", "gridKey"]], template: function CsChamCongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("keydown.enter", function CsChamCongComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function CsChamCongComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function CsChamCongComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function CsChamCongComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function CsChamCongComponent_Template_p_button_click_15_listener() { return ctx.showFilter(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](21, "p-button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function CsChamCongComponent_Template_p_button_click_21_listener() { return ctx.ExportCheckInOut(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](22, "p-button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function CsChamCongComponent_Template_p_button_click_22_listener() { return ctx.Export(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](23, "section", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](24, "div", 23, 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](26, CsChamCongComponent_app_list_grid_angular_26_Template, 1, 3, "app-list-grid-angular", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](27, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](28, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](30, "p-paginator", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("onPageChange", function CsChamCongComponent_Template_p_paginator_onPageChange_30_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](31, "p-overlayPanel", 28, 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](33, CsChamCongComponent_ng_template_33_Template, 26, 6, "ng-template", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](34, "p-dialog", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("visibleChange", function CsChamCongComponent_Template_p_dialog_visibleChange_34_listener($event) { return ctx.displaySetting = $event; })("onHide", function CsChamCongComponent_Template_p_dialog_onHide_34_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](35, CsChamCongComponent_app_config_grid_table_form_35_Template, 1, 2, "app-config-grid-table-form", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction2"](23, _c0, ctx.MENUACTIONROLEAPI.GetEmployeeSalaryMonthPage.url, ctx.ACTIONS.EXPORT));
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](27, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](26, _c1)));
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](29, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](30, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_13__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_24__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_14__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_25__.Paginator, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_26__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_20__.PrimeTemplate, primeng_dialog__WEBPACK_IMPORTED_MODULE_27__.Dialog, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_15__.ListGridAngularComponent, primeng_dropdown__WEBPACK_IMPORTED_MODULE_28__.Dropdown, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NumberValueAccessor, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_16__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjcy1jaGFtLWNvbmcuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 22832:
/*!************************************************************************!*\
  !*** ./src/app/components/cs-cham-cong/xem-cong/xem-cong.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "XemCongComponent": () => (/* binding */ XemCongComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! file-saver */ 68178);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../common/config-grid-table-form/config-grid-table-form.component */ 39805);































const _c0 = function (a0) { return [a0]; };
function XemCongComponent_ng_template_26_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](4, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](6, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](8, "B\u1ED9 ph\u1EADn");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](9, "p-treeSelect", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngModelChange", function XemCongComponent_ng_template_26_Template_p_treeSelect_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r4.query.orgId = $event; })("onNodeSelect", function XemCongComponent_ng_template_26_Template_p_treeSelect_onNodeSelect_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r5); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r6.onChangeTree(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](10, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](11, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](12, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](13, "T\u1EEB ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](14, "p-calendar", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngModelChange", function XemCongComponent_ng_template_26_Template_p_calendar_ngModelChange_14_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r5); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r7.query.fromdate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](15, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](16, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](17, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](18, "\u0110\u1EBFn ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](19, "p-calendar", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngModelChange", function XemCongComponent_ng_template_26_Template_p_calendar_ngModelChange_19_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r5); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r8.query.todate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](20, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](21, "label", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](22, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](23, "span", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](24, "p-button", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function XemCongComponent_ng_template_26_Template_p_button_click_24_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r5); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r9.getXemCongInfo(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](25, "p-button", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function XemCongComponent_ng_template_26_Template_p_button_click_25_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r5); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](); return ctx_r10.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngModel", ctx_r1.query.orgId)("filterInputAutoFocus", true)("filter", true)("metaKeySelection", false)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](15, _c0, ctx_r1.departmentFiltes.length <= 0 ? "tree-empty" : ""))("options", ctx_r1.departmentFiltes);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r1.query.fromdate)("monthNavigator", true)("yearNavigator", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r1.query.todate)("monthNavigator", true);
} }
function XemCongComponent_app_list_grid_angular_29_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "app-list-grid-angular", 46);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("height", ctx_r2.heightGrid)("listsData", ctx_r2.listsData)("columnDefs", ctx_r2.columnDefs);
} }
function XemCongComponent_app_config_grid_table_form_35_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "app-config-grid-table-form", 47);
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r3.gridKey);
} }
const _c1 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c2 = function () { return { width: "700px" }; };
const _c3 = function () { return { showAll: "ALL" }; };
const _c4 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c5 = function () { return { width: "50vw" }; };
class XemCongComponent {
    constructor(apiService, activatedRoute, messageService, confirmationService, spinner, router, changeDetector, organizeInfoService) {
        this.apiService = apiService;
        this.activatedRoute = activatedRoute;
        this.messageService = messageService;
        this.confirmationService = confirmationService;
        this.spinner = spinner;
        this.router = router;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_13__.Subject();
        this.manhinh = 'Edit';
        this.indexTab = 0;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS;
        this.optionsButtonsView = [{ label: 'Quay lại', value: 'Cancel', icon: 'pi pi-arrow-left' }];
        this.listViews = [];
        this.paramsObject = null;
        this.titlePage = '';
        this.url = '';
        this.detailInfo = null;
        this.listsData = [];
        this.columnDefs = [];
        this.query = {
            orgId: '',
            filter: '',
            organizeId: '',
            pageSize: 15,
            fromdate: new Date(moment__WEBPACK_IMPORTED_MODULE_4__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            todate: new Date(moment__WEBPACK_IMPORTED_MODULE_4__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
            offSet: 0,
            organizeIds: '',
        };
        this.departmentFiltes = [];
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.first = 0;
        this.displaySetting = false;
        this.gridKey = '';
        this.items = [];
        this.listOrgRoots = [];
        this.loadjs = 0;
        this.heightGrid = 0;
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.getOrganizeTree();
                this.getXemCongInfo();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Danh sách chấm công', routerLink: '/chinh-sach/cham-cong' },
            { label: this.titlePage },
        ];
        this.url = this.activatedRoute.data['_value'].url;
        this.manhinh = 'Edit';
        // this.getOrgRoots();
        // this.handleParams()
    }
    handleParams() {
        this.activatedRoute.queryParamMap.subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.getXemCongInfo();
        });
    }
    ;
    getXemCongInfo() {
        this.listViews = [];
        this.listsData = [];
        let params = Object.assign({}, this.query);
        params.orgId = typeof params.orgId === 'string' ? params.orgId : params.orgId.orgId;
        delete params.fromdate;
        delete params.todate;
        params.FromDate = moment__WEBPACK_IMPORTED_MODULE_4__(new Date(this.query.fromdate)).format('YYYY-MM-DD');
        params.ToDate = moment__WEBPACK_IMPORTED_MODULE_4__(new Date(this.query.todate)).format('YYYY-MM-DD');
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.spinner.show();
        this.apiService.getTimekeepingDetail(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.gridKey = results.data.dataList.gridKey;
                this.spinner.hide();
                this.columnDefs = results.data.gridflexs;
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(results.data.group_fields);
                this.listsData = results.data.dataList.data;
                this.initGrid();
                this.countRecord.totalRecord = results.data.dataList.recordsTotal;
                this.countRecord.totalRecord = results.data.dataList.recordsTotal;
                this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
                if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                    this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
                }
                else {
                    this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                    setTimeout(() => {
                        const noData = document.querySelector('.ag-overlay-no-rows-center');
                        if (noData) {
                            noData.innerHTML = 'Không có kết quả phù hợp';
                        }
                    }, 100);
                }
            }
        });
    }
    getOrgRoots() {
        // this.apiService.getOrgRoots().subscribe(results => {
        //   if (results.status === 'success') {
        //     this.listOrgRoots = results.data.map(d => {
        //       return {
        //         label: d.org_name,
        //         value: `${d.orgId}`
        //       }
        //     });
        //     this.query.orgId = this.listOrgRoots[0].value
        //     this.getXemCongInfo();
        //   }
        // })
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams)
            .subscribe((results) => {
            this.listOrgRoots = results.data
                .map(d => {
                return {
                    label: d.organizationName || d.organizationCd,
                    value: d.organizeId
                };
            });
            this.getXemCongInfo();
            this.listOrgRoots = [{ label: 'Chọn tổ chức', value: '' }, ...this.listOrgRoots];
        }),
            error => { };
    }
    changeOrgani() {
        // this.getXemCongInfo();
        this.getOrganizeTree();
    }
    onChangeTree() {
        // this.getXemCongInfo();
    }
    getOrganizeTree() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ parentId: this.query.organizeIds });
        this.apiService.getOrganizeTree(queryParams)
            .subscribe((results) => {
            if (results && results.status === 'success') {
                this.departmentFiltes = results.data;
            }
        }, error => { });
    }
    cancel() {
        this.query = {
            orgId: '',
            filter: '',
            organizeId: '',
            pageSize: 15,
            fromdate: new Date(moment__WEBPACK_IMPORTED_MODULE_4__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            todate: new Date(moment__WEBPACK_IMPORTED_MODULE_4__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
            offSet: 0,
            organizeIds: this.query.organizeIds,
        };
        this.getXemCongInfo();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.getXemCongInfo();
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    handleChange(index) {
        this.indexTab = index;
    }
    setCompanyInfo(data) {
    }
    // listOrgRoots = []
    // getOrgRoots() {
    //   this.apiService.getOrgRoots().subscribe(results => {
    //     if (results.status === 'success') {
    //       this.listOrgRoots = results.data.map(d => {
    //         return {
    //           label: d.org_name,
    //           value: `${d.orgId}`
    //         }
    //       });
    //       this.query.orgId = this.listOrgRoots[0].value
    //       this.getXemCongInfo();
    //     }
    //   })
    // }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.AgGridFn)(this.columnDefs.filter((d) => !d.isHide)),
            // {
            //   headerName: 'Thao tác',
            //   filter: '',
            //   maxWidth: 90,
            //   pinned: 'right',
            //   cellRenderer: 'buttonAgGridComponent',
            //   cellClass: ['border-right', 'no-auto'],
            //   // cellRendererParams: (params: any) => this.showButtons(params),
            //   checkboxSelection: false,
            //   field: 'checkbox'
            // }
        ];
    }
    Export() {
        let params = Object.assign({}, this.query);
        params.orgId = typeof params.orgId === 'string' ? params.orgId : params.orgId.orgId;
        delete params.fromdate;
        delete params.todate;
        params.FromDate = moment__WEBPACK_IMPORTED_MODULE_4__(new Date(this.query.fromdate)).format('YYYY-MM-DD');
        params.ToDate = moment__WEBPACK_IMPORTED_MODULE_4__(new Date(this.query.todate)).format('YYYY-MM-DD');
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.spinner.show();
        this.apiService.exportTimekeeping(queryParams).subscribe(results => {
            if (results.type === 'application/json') {
                this.spinner.hide();
            }
            else {
                var blob = new Blob([results], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                file_saver__WEBPACK_IMPORTED_MODULE_5__.saveAs(blob, `Danh sách xem công tháng ${params.FromDate} - ${params.ToDate}` + ".xlsx");
                this.spinner.hide();
            }
        });
    }
    cauhinh() {
        this.displaySetting = true;
    }
}
XemCongComponent.ɵfac = function XemCongComponent_Factory(t) { return new (t || XemCongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_16__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_12__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__.OrganizeInfoService)); };
XemCongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({ type: XemCongComponent, selectors: [["app-xem-cong"]], decls: 36, vars: 31, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bottom", "bet"], [3, "items"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "20", "height", "17", "viewBox", "0 0 20 17", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M19.5 17V0H0.50855L0.5 17H19.5ZM6.675 15.3187H2.21V6.81868H6.675V15.3187ZM8.575 15.3187V6.81868H17.79V15.3187H8.575ZM2.21 1.68132V5.13736H17.79V1.68132H2.21Z", "fill", "#F3F8FF"], [1, "bread-filter"], [1, "d-flex", "end", "bottom", "gap-16"], [1, "col-item"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "16", "height", "16", "viewBox", "0 0 16 16", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M10.1305 11.2619C9.28558 11.8771 8.24518 12.24 7.12002 12.24C4.29231 12.24 2 9.94772 2 7.12002C2 4.29231 4.29231 2 7.12002 2C9.94772 2 12.24 4.29231 12.24 7.12002C12.24 8.24518 11.8771 9.28558 11.2619 10.1305L13.7657 12.6343C14.0781 12.9467 14.0781 13.4533 13.7657 13.7657C13.4533 14.0781 12.9467 14.0781 12.6343 13.7657L10.1305 11.2619ZM11.28 7.12002C11.28 9.41753 9.41753 11.28 7.12002 11.28C4.8225 11.28 2.96 9.41753 2.96 7.12002C2.96 4.8225 4.8225 2.96 7.12002 2.96C9.41753 2.96 11.28 4.8225 11.28 7.12002Z", "fill", "#808AA6"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", "icon", "pi pi-cloud-download", "label", "Export", 3, "CheckHideActions", "click"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [1, "content", "pb-0"], [1, "grid-default", "border"], [3, "height", "listsData", "columnDefs", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", "mb-0", "label-8"], ["selectionMode", "single", "name", "orgId", "placeholder", "Ch\u1ECDn ph\u00F2ng ban", 3, "ngModel", "filterInputAutoFocus", "filter", "metaKeySelection", "ngClass", "options", "ngModelChange", "onNodeSelect"], [1, "field-group", "date", "mb-0", "valid"], ["panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "fromdate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "yearNavigator", "ngModelChange"], ["panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "todate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "ngModelChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [3, "height", "listsData", "columnDefs"], [3, "typeConfig", "gridKey"]], template: function XemCongComponent_Template(rf, ctx) { if (rf & 1) {
        const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](4, "p-button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function XemCongComponent_Template_p_button_click_4_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "svg", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](6, "path", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](7, " \u00A0 C\u1EA5u h\u00ECnh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "section", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](9, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](10, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](11, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](12, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](13, "input", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("keydown.enter", function XemCongComponent_Template_input_keydown_enter_13_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.getXemCongInfo(); })("ngModelChange", function XemCongComponent_Template_input_ngModelChange_13_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](14, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function XemCongComponent_Template_span_click_14_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.getXemCongInfo(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](15, "svg", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](16, "path", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](17, "p-button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function XemCongComponent_Template_p_button_click_17_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r11); const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵreference"](25); return _r0.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](18, "svg", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](19, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](20, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](21, "path", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](22, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](23, "p-button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function XemCongComponent_Template_p_button_click_23_listener() { return ctx.Export(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](24, "p-overlayPanel", 22, 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](26, XemCongComponent_ng_template_26_Template, 26, 17, "ng-template", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](27, "section", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](28, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](29, XemCongComponent_app_list_grid_angular_29_Template, 1, 3, "app-list-grid-angular", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](30, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](31, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](32);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](33, "p-paginator", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("onPageChange", function XemCongComponent_Template_p_paginator_onPageChange_33_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](34, "p-dialog", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("visibleChange", function XemCongComponent_Template_p_dialog_visibleChange_34_listener($event) { return ctx.displaySetting = $event; })("onHide", function XemCongComponent_Template_p_dialog_onHide_34_listener() { return ctx.getXemCongInfo(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](35, XemCongComponent_app_config_grid_table_form_35_Template, 1, 2, "app-config-grid-table-form", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction2"](23, _c1, ctx.MENUACTIONROLEAPI.GetTimekeepingDetail.url, ctx.ACTIONS.EXPORT));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](26, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", (ctx.columnDefs == null ? null : ctx.columnDefs.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](28, _c4, _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](27, _c3)));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](30, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_8__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_17__.Button, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgModel, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_9__.CheckHideActionsDirective, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_20__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_15__.PrimeTemplate, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_21__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_22__.Dialog, primeng_treeselect__WEBPACK_IMPORTED_MODULE_23__.TreeSelect, primeng_calendar__WEBPACK_IMPORTED_MODULE_24__.Calendar, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_10__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_11__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ4ZW0tY29uZy5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 29904:
/*!********************************************************************************************!*\
  !*** ./src/app/components/cs-nghi-phep/chi-tiet-nghi-phep/chi-tiet-nghi-phep.component.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietNghiPhepComponent": () => (/* binding */ ChiTietNghiPhepComponent)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);
















function ChiTietNghiPhepComponent_app_edit_detail_7_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "app-edit-detail", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("callback", function ChiTietNghiPhepComponent_app_edit_detail_7_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return ctx_r1.setLeaveInfo($event); })("callbackcancel", function ChiTietNghiPhepComponent_app_edit_detail_7_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return ctx_r3.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
const queryString = __webpack_require__(/*! query-string */ 31808);
class ChiTietNghiPhepComponent {
    constructor(activatedRoute, apiService, spinner, confirmationService, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.MENUACTIONROLEAPI.GetLeavePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.ACTIONS.EDIT) ? 'hidden' : '',
                icon: 'pi pi-check' }
        ];
        this.url = '';
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this.id = null;
        this.titlePage = '';
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Danh sách nghỉ phép', routerLink: '/chinh-sach/nghi-phep' },
            { label: `${this.titlePage}` },
        ];
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this.unsubscribe$))
            .subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.id = this.paramsObject.params.id;
            this.getLeaveInfo();
        });
    }
    ;
    getLeaveInfo() {
        const queryParams = queryString.stringify({ id: this.id });
        this.apiService.getLeaveInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.detailInfo = results.data;
            }
        });
    }
    setLeaveInfo(data) {
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setLeaveInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    // setCandidateInfo(data) {
    //   this.spinner.show();
    //   const params = {
    //     ...this.detailInfo, group_fields: data
    //   }
    //   this.apiService.setCandidateInfo(params)
    //     .pipe(takeUntil(this.unsubscribe$))
    //     .subscribe((results: any) => {
    //       if (results.status === 'success') {
    //         this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
    //         this.spinner.hide();
    //       } else {
    //         this.messageService.add({
    //           severity: 'error', summary: 'Thông báo',
    //           detail: results.message
    //         });
    //         this.spinner.hide();
    //       }
    //     }), error => {
    //       this.spinner.hide();
    //     };
    // }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getLeaveInfo();
        }
        else {
            this.router.navigate(['/chinh-sach/nghi-phep']);
        }
    }
}
ChiTietNghiPhepComponent.ɵfac = function ChiTietNghiPhepComponent_Factory(t) { return new (t || ChiTietNghiPhepComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_9__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router)); };
ChiTietNghiPhepComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: ChiTietNghiPhepComponent, selectors: [["app-chi-tiet-nghi-phep"]], decls: 8, vars: 3, consts: [[1, "main-grid", "product-detail"], [1, "breadcrumb"], [3, "model"], [1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function ChiTietNghiPhepComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "p-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, ChiTietNghiPhepComponent_app_edit_detail_7_Template, 1, 4, "app-edit-detail", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("model", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx.titlePage);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_11__.Breadcrumb, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_4__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC1uZ2hpLXBoZXAuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 2369:
/*!*******************************************************************!*\
  !*** ./src/app/components/cs-nghi-phep/cs-nghi-phep.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CsNghiPhepComponent": () => (/* binding */ CsNghiPhepComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api.service */ 67118);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/common/form-filter/form-filter.component */ 83844);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/dynamicdialog */ 56427);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! primeng/dropdown */ 45596);








































function CsNghiPhepComponent_app_list_grid_angular_28_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "app-list-grid-angular", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("showConfig", function CsNghiPhepComponent_app_list_grid_angular_28_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r7.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function CsNghiPhepComponent_app_edit_detail_34_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "app-edit-detail", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("callback", function CsNghiPhepComponent_app_edit_detail_34_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r9.setLeaveInfo($event); })("callbackcancel", function CsNghiPhepComponent_app_edit_detail_34_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r10); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r11.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("detail", ctx_r2.detailInfo)("manhinh", "Edit")("dataView", ctx_r2.listViews)("optionsButtonsEdit", ctx_r2.optionsButon);
} }
function CsNghiPhepComponent_app_config_grid_table_form_36_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](0, "app-config-grid-table-form", 44);
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r3.gridKey);
} }
function CsNghiPhepComponent_ng_template_45_Template(rf, ctx) { if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "button", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsNghiPhepComponent_ng_template_45_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r13); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r12.isReason = !ctx_r12.isReason; });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "p-button", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsNghiPhepComponent_ng_template_45_Template_p_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r13); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r14.huyDuyet(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](2, " Th\u1EF1c hi\u1EC7n ");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
} }
function CsNghiPhepComponent_ng_template_48_ng_template_25_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "span", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r19 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](item_r19.name);
} }
function CsNghiPhepComponent_ng_template_48_ng_template_26_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r20 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](car_r20.name);
} }
function CsNghiPhepComponent_ng_template_48_ng_template_32_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "span", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](item_r21.name);
} }
function CsNghiPhepComponent_ng_template_48_ng_template_33_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r22 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](car_r22.name);
} }
function CsNghiPhepComponent_ng_template_48_Template(rf, ctx) { if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](3, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](4, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](5, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](6, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](8, "T\u1EEB ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](9, "p-calendar", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function CsNghiPhepComponent_ng_template_48_Template_p_calendar_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r24); const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r23.query.fromdate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](10, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](11, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](12, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](13, "\u0110\u1EBFn ng\u00E0y");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](14, "p-calendar", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function CsNghiPhepComponent_ng_template_48_Template_p_calendar_ngModelChange_14_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r24); const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r25.query.todate = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](15, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](16, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](17, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](18, "C\u00F4ng ty tr\u1EA3 l\u01B0\u01A1ng");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](19, "p-dropdown", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function CsNghiPhepComponent_ng_template_48_Template_p_dropdown_ngModelChange_19_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r24); const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r26.query.companyIds = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](20, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](21, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](22, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](23, "Tr\u1EA1ng th\u00E1i");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](24, "p-dropdown", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function CsNghiPhepComponent_ng_template_48_Template_p_dropdown_ngModelChange_24_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r24); const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r27.query.request_status = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](25, CsNghiPhepComponent_ng_template_48_ng_template_25_Template, 2, 1, "ng-template", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](26, CsNghiPhepComponent_ng_template_48_ng_template_26_Template, 3, 1, "ng-template", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](27, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](28, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](29, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](30, "L\u00ED do");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](31, "p-dropdown", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function CsNghiPhepComponent_ng_template_48_Template_p_dropdown_ngModelChange_31_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r24); const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r28.query.reason_code = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](32, CsNghiPhepComponent_ng_template_48_ng_template_32_Template, 2, 1, "ng-template", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](33, CsNghiPhepComponent_ng_template_48_ng_template_33_Template, 3, 1, "ng-template", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](34, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](35, "label", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](36, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](37, "span", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](38, "p-button", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsNghiPhepComponent_ng_template_48_Template_p_button_click_38_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r24); const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r29.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](39, "p-button", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsNghiPhepComponent_ng_template_48_Template_p_button_click_39_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r24); const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](); return ctx_r30.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r6.query.fromdate)("monthNavigator", true)("yearNavigator", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("appendTo", "body")("baseZIndex", 101)("ngModel", ctx_r6.query.todate)("monthNavigator", true)("yearNavigator", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("baseZIndex", 100)("options", ctx_r6.companies)("ngModel", ctx_r6.query.companyIds)("filter", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r6.listStatus)("ngModel", ctx_r6.query.request_status)("filter", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r6.leaveReasons)("ngModel", ctx_r6.query.reason_code)("filter", true);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { showAll: "ALL" }; };
const _c2 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c3 = function () { return { width: "50vw" }; };
const _c4 = function () { return { width: "600px" }; };
const _c5 = function () { return { width: "700px" }; };
class CsNghiPhepComponent {
    constructor(spinner, apiService, route, confirmationService, changeDetector, messageService, organizeInfoService, router, dialogService, apiBaseService) {
        this.spinner = spinner;
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.changeDetector = changeDetector;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.dialogService = dialogService;
        this.apiBaseService = apiBaseService;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.ACTIONS;
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_7__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.MENUACTIONROLEAPI.GetLeavePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.ACTIONS.EDIT) ? 'hidden' : '',
                icon: 'pi pi-check' }
        ];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_19__.Subject();
        this.addEdit = false;
        this.leaveId = '';
        this.listStatus = [];
        this.listOrgRoots = [];
        this.displayFrom = false;
        this.pagingComponent = {
            total: 0
        };
        this.leaveReasons = [];
        this.titleForm = {
            label: 'Thêm mới tài khoản',
            value: 'Add'
        };
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_2__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_7__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        // time = null;
        this.query = {
            organizeId: null,
            request_status: '',
            reason_code: '',
            filter: '',
            year: '',
            month: '',
            offSet: 0,
            pageSize: 15,
            fromdate: new Date(moment__WEBPACK_IMPORTED_MODULE_3__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            todate: new Date(moment__WEBPACK_IMPORTED_MODULE_3__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
            organizeIds: '',
            companyIds: '',
        };
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.companies = [];
        this.loadjs = 0;
        this.heightGrid = 0;
        this.displaySetting = false;
        this.gridKey = '';
        this.listsData = [];
        this.reason_cancel = '';
        this.isReason = false;
        this.queryHuyDuyet = {
            gd: '',
            status: 0,
            comment: '',
        };
        this.listViews = [];
        this.detailInfo = [];
        this.listViewsFilter = [];
        this.detailInfoFilter = null;
        this.optionsButonFilter = [
            { label: 'Tìm kiếm', value: 'Search', class: 'p-button-sm height-56 addNew', icon: 'pi pi-search' },
            { label: 'Làm mới', value: 'Reset', class: 'p-button-sm p-button-danger height-56 addNew', icon: 'pi pi-times' },
        ];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_4__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_5__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_6__.AvatarFullComponent,
        };
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cancel() {
        // this.time = null;
        this.query = {
            organizeId: null,
            request_status: '',
            reason_code: '',
            filter: '',
            year: '',
            month: '',
            offSet: 0,
            pageSize: 15,
            fromdate: new Date(moment__WEBPACK_IMPORTED_MODULE_3__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).add(-1, 'months').format()),
            todate: new Date(moment__WEBPACK_IMPORTED_MODULE_3__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).format()),
            organizeIds: this.query.organizeIds,
            companyIds: this.query.companyIds,
        };
        if (this.companies.length > 0) {
            this.query.companyIds = this.companies[0].value;
        }
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = Object.assign({}, this.query);
        queryParams.fromdate = typeof this.query.fromdate === 'object' ? moment__WEBPACK_IMPORTED_MODULE_3__(new Date(this.query.fromdate)).format('YYYY-MM-DD') : this.query.fromdate;
        queryParams.todate = typeof this.query.todate === 'object' ? moment__WEBPACK_IMPORTED_MODULE_3__(new Date(this.query.todate)).format('YYYY-MM-DD') : this.query.todate;
        // if (this.time) {
        //   queryParams.year = this.time.getFullYear();
        //   queryParams.month = this.time.getMonth() + 1;
        // }
        if (typeof queryParams.request_status !== 'string') {
            queryParams.request_status = queryParams.request_status.code;
        }
        if (typeof queryParams.reason_code !== 'string') {
            queryParams.reason_code = queryParams.reason_code.code;
        }
        const queryStrings = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(queryParams);
        this.apiService.getLeavePage(queryStrings).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    // set kỳ công
    defauDateFilter() {
        let currentDay = new Date().getDate();
        if (currentDay >= 25 && currentDay <= 31) {
            this.query.month = this.query.month + 1;
            this.query.fromdate = new Date(moment__WEBPACK_IMPORTED_MODULE_3__(new Date(new Date().getFullYear(), new Date().getMonth(), 25)).format());
            this.query.todate = new Date(moment__WEBPACK_IMPORTED_MODULE_3__(new Date(new Date().getFullYear(), new Date().getMonth(), 24)).add(+1, 'months').format());
        }
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.XemChiTiet.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_7__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.MENUACTIONROLEAPI.GetLeavePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.ACTIONS.VIEW)
                },
                {
                    onClick: this.showHuyDuyet.bind(this),
                    label: 'Hủy duyệt',
                    icon: 'pi pi-times',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_7__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.MENUACTIONROLEAPI.GetLeavePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.ACTIONS.HUY_DUYET)
                },
                // {
                //   onClick: this.xoaTienLuong.bind(this),
                //   label: 'Xóa',
                //   icon: 'pi pi-trash',
                //   class: 'btn-primary mr5',
                // },
                // {
                //   onClick: this.CloseAccount.bind(this),
                //   label: 'Đóng tài khoản',
                //   icon: 'pi pi-trash',
                //   class: 'btn-primary mr5',
                // },
            ]
        };
    }
    showHuyDuyet(event) {
        this.isReason = true;
        this.queryHuyDuyet.gd = event.rowData.id;
        this.queryHuyDuyet.status = 0;
    }
    huyDuyet() {
        this.queryHuyDuyet.comment = this.reason_cancel;
        if (!this.queryHuyDuyet.comment) {
            this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Vui lòng nhập lý do' });
            return;
        }
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn hủy duyệt?',
            accept: () => {
                this.apiService.cancelLeaveStatuses(this.queryHuyDuyet).subscribe(results => {
                    if (results.status === 'success') {
                        this.isReason = false;
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Hủy duyệt thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_7__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
        this.detailCellRendererParams = {
            detailGridOptions: {
                frameworkComponents: {},
                getRowHeight: (params) => {
                    return 40;
                },
                columnDefs: [
                    ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_7__.AgGridFn)(this.colsDetail),
                ],
                enableCellTextSelection: true,
                onFirstDataRendered(params) {
                    let allColumnIds = [];
                    params.columnApi.getAllColumns()
                        .forEach((column) => {
                        if (column.colDef.cellClass.indexOf('auto') < 0) {
                            allColumnIds.push(column);
                        }
                        else {
                            column.colDef.suppressSizeToFit = true;
                            allColumnIds.push(column);
                        }
                    });
                    params.api.sizeColumnsToFit(allColumnIds);
                },
            },
            getDetailRowData(params) {
                params.successCallback(params.data.Owns);
            },
            excelStyles: [
                {
                    id: 'stringType',
                    dataType: 'string'
                }
            ],
            template: function (params) {
                var personName = params.data.theme;
                return ('<div style="height: 100%; background-color: #EDF6FF; padding: 20px; box-sizing: border-box;">' +
                    `  <div style="height: 10%; padding: 2px; font-weight: bold;">###### Danh sách (${params.data.Owns.length}) : [` +
                    personName + ']' +
                    '</div>' +
                    '  <div ref="eDetailGrid" style="height: 90%;"></div>' +
                    '</div>');
            },
        };
    }
    xoaTienLuong(event) {
        // this.confirmationService.confirm({
        //   message: 'Bạn có chắc chắn muốn thực hiện mở tài khoản?',
        //   accept: () => {
        //     const queryParams = queryString.stringify({ companyId: event.rowData.companyId });
        //     this.apiService.delCompanyInfo(queryParams).subscribe(results => {
        //       if (results.status === 'success') {
        //         this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa công ty thành công' });
        //         this.load();
        //       } else {
        //         this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
        //       }
        //     });
        //   }
        // });
    }
    XemChiTiet(event) {
        // const params = {
        //   id: event.rowData.id
        // }
        // this.router.navigate(['/chinh-sach/nghi-phep/chi-tiet-nghi-phep'], { queryParams: params });
        this.getLeaveInfo(event.rowData.id);
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.defauDateFilter();
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.query.organizeId = results;
                this.getLeaveReasons();
                this.getCompany();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Giải trình công' },
        ];
        this.getOrgRoots();
        this.getRequestStatus();
        this.getFilter();
    }
    getLeaveReasons() {
        this.apiBaseService.getLeaveReasons()
            .subscribe(response => {
            if (response.status === 'success') {
                this.leaveReasons = response.data.map(d => {
                    return {
                        name: d.name,
                        code: d.code
                    };
                });
                this.leaveReasons = [{ name: 'Tất cả', code: '' }, ...this.leaveReasons];
                if (this.leaveReasons.length) {
                    this.query.reason_code = this.leaveReasons[0];
                    this.load();
                }
            }
        });
    }
    getRequestStatus() {
        this.apiBaseService.getObjectList('hrm_leave_status')
            .subscribe(response => {
            this.listStatus = response.data;
            // if (this.listStatus.length) {
            //   this.query.request_status = this.listStatus[0];
            //   this.load();
            // }
            if (response.status === 'success') {
                this.listStatus = response.data.map(d => {
                    return {
                        name: d.objName,
                        code: d.objCode
                    };
                });
                this.listStatus = [{ name: 'Tất cả', code: '' }, ...this.listStatus];
                this.query.request_status = this.listStatus[0];
                this.load();
            }
        });
    }
    getOrgRoots() {
        this.apiService.getOrgRoots().subscribe(results => {
            if (results.status === 'success') {
                this.listOrgRoots = results.data.map(d => {
                    return {
                        label: d.org_name,
                        value: `${d.orgId}`
                    };
                });
                this.listOrgRoots = [{ label: 'Tất cả', value: null }, ...this.listOrgRoots];
            }
        });
    }
    addNewNghiPhep() {
        // const params = {
        //   id: ''
        // }
        // this.router.navigate(['/chinh-sach/nghi-phep/chi-tiet-nghi-phep'], { queryParams: params });
        this.getLeaveInfo();
    }
    getLeaveInfo(id = null) {
        this.listViews = [];
        this.addEdit = true;
        this.leaveId = id;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ id: id });
        this.apiService.getLeaveInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_20__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_9__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.detailInfo = results.data;
            }
        });
    }
    setLeaveInfo(data) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.checkLeaveOverLap(params);
    }
    checkLeaveOverLap(params) {
        this.apiService.checkLeaveOverLap(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_20__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                // this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data });
                this.confirmationService.confirm({
                    message: results.message,
                    accept: () => {
                        this.setLeaveInfoOver(params);
                    }
                });
                this.spinner.hide();
            }
            else {
                // set immediately
                this.spinner.hide();
                this.setLeaveInfoWhenCheckNoOk(params);
            }
        }), error => {
            this.spinner.hide();
        };
    }
    // lưu khi check 'checkLeaveOverLap' status !== 'success'
    setLeaveInfoWhenCheckNoOk(params) {
        this.apiService.setLeaveInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_20__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.addEdit = false;
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    setLeaveInfoOver(params) {
        this.apiService.setLeaveHrmInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_20__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.addEdit = false;
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    getCompany() {
        const query = { organizeIds: this.query.organizeIds };
        this.apiService.getUserCompanies(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query)).subscribe((results) => {
            if (results.status === "success") {
                this.companies = results.data
                    .map(d => {
                    return {
                        label: d.name,
                        value: d.value
                    };
                });
                if (this.companies.length > 0) {
                    this.query.companyIds = this.companies[0].value;
                }
                this.load();
            }
        }),
            error => { };
    }
    //filter 
    getFilter() {
        this.apiService.getFilter('/api/v2/leave/GetLeaveFilter').subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_9__.cloneDeep)(results.data.group_fields);
                this.listViewsFilter = [...listViews];
                this.detailInfoFilter = results.data;
            }
        });
    }
    showFilter() {
        const ref = this.dialogService.open(src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_12__.FormFilterComponent, {
            header: 'Tìm kiếm nâng cao',
            width: '40%',
            contentStyle: "",
            data: {
                listViews: this.listViewsFilter,
                detailInfoFilter: this.detailInfoFilter,
                buttons: this.optionsButonFilter
            }
        });
        ref.onClose.subscribe((event) => {
            if (event) {
                this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_9__.cloneDeep)(event.listViewsFilter);
                if (event.type === 'Search') {
                    this.query = Object.assign(Object.assign({}, this.query), event.data);
                    this.load();
                }
                else if (event.type === 'CauHinh') {
                    this.apiService.getEmpFilter().subscribe(results => {
                        if (results.status === 'success') {
                            const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_9__.cloneDeep)(results.data.group_fields);
                            this.listViewsFilter = [...listViews];
                            this.detailInfoFilter = results.data;
                            this.showFilter();
                        }
                    });
                }
                else if (event.type === 'Reset') {
                    const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_9__.cloneDeep)(this.detailInfoFilter.group_fields);
                    this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_9__.cloneDeep)(listViews);
                    this.cancel();
                }
            }
        });
    }
    quaylai(event) {
        this.addEdit = false;
    }
}
CsNghiPhepComponent.ɵfac = function CsNghiPhepComponent_Factory(t) { return new (t || CsNghiPhepComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_21__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_8__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_22__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_23__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_18__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_23__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_11__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_22__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_24__.DialogService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](src_app_services_api_service__WEBPACK_IMPORTED_MODULE_1__.ApiService)); };
CsNghiPhepComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdefineComponent"]({ type: CsNghiPhepComponent, selectors: [["app-cs-nghi-phep"]], decls: 49, vars: 47, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "end", "mid", "bottom", "gap-12", "col-9", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["_ngcontent-xmj-c197", "", "width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["_ngcontent-xmj-c197", "", "fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", 3, "CheckHideActions", "click"], ["d", "M11 5H9V9H5V11H9V15H11V11H15V9H11V5ZM10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM10 18C5.59 18 2 14.41 2 10C2 5.59 5.59 2 10 2C14.41 2 18 5.59 18 10C18 14.41 14.41 18 10 18Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["styleClass", "popup-setting", 3, "header", "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "detail", "manhinh", "dataView", "optionsButtonsEdit", "callback", "callbackcancel", 4, "ngIf"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["header", "L\u00FD do h\u1EE7y", 3, "visible", "visibleChange"], [1, "warm-cool", "d-flex"], [1, "pi", "pi-bookmark-fill"], [1, ""], [1, "field-group", "textarea"], ["placeholder", "L\u00FD do h\u1EE7y duy\u1EC7t", "required", "", 3, "ngModel", "ngModelChange"], ["pTemplate", "footer"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [3, "listsData", "height", "columnDefs", "showConfig"], [3, "detail", "manhinh", "dataView", "optionsButtonsEdit", "callback", "callbackcancel"], [3, "typeConfig", "gridKey"], ["type", "button", "pButton", "", "icon", "pi pi-times", "label", "H\u1EE7y b\u1ECF", 1, "p-button-secondary", "btn-cancel", 3, "click"], ["styleClass", "p-button-sm mr-1 height-56", 3, "click"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "date", "valid"], ["panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "yearRange", "2010:2030", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "fromdate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "yearNavigator", "ngModelChange"], ["panelStyleClass", "datepicker-default", "placeholder", "DD/MM/YYYY", "yearRange", "2010:2030", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "todate", 3, "appendTo", "baseZIndex", "ngModel", "monthNavigator", "yearNavigator", "ngModelChange"], [1, "field-group", "select", "mb-0"], ["appendTo", "body", "name", "companyIds", 3, "baseZIndex", "options", "ngModel", "filter", "ngModelChange"], [1, "field-group", "select", "label-8", "valid"], ["appendTo", "body", "name", "request_status", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], ["appendTo", "body", "name", "reason_code", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [2, "vertical-align", "middle"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "left", "margin-top", "4px"]], template: function CsNghiPhepComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("keydown.enter", function CsNghiPhepComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function CsNghiPhepComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsNghiPhepComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsNghiPhepComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsNghiPhepComponent_Template_p_button_click_15_listener() { return ctx.showFilter(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](21, "p-button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function CsNghiPhepComponent_Template_p_button_click_21_listener() { return ctx.addNewNghiPhep(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](22, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](23, "path", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](24, " \u00A0 Th\u00EAm m\u1EDBi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](25, "section", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](26, "div", 23, 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](28, CsNghiPhepComponent_app_list_grid_angular_28_Template, 1, 3, "app-list-grid-angular", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](29, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](30, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](31);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](32, "p-paginator", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("onPageChange", function CsNghiPhepComponent_Template_p_paginator_onPageChange_32_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](33, "p-dialog", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("visibleChange", function CsNghiPhepComponent_Template_p_dialog_visibleChange_33_listener($event) { return ctx.addEdit = $event; })("onHide", function CsNghiPhepComponent_Template_p_dialog_onHide_33_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](34, CsNghiPhepComponent_app_edit_detail_34_Template, 1, 4, "app-edit-detail", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](35, "p-dialog", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("visibleChange", function CsNghiPhepComponent_Template_p_dialog_visibleChange_35_listener($event) { return ctx.displaySetting = $event; })("onHide", function CsNghiPhepComponent_Template_p_dialog_onHide_35_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](36, CsNghiPhepComponent_app_config_grid_table_form_36_Template, 1, 2, "app-config-grid-table-form", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](37, "p-dialog", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("visibleChange", function CsNghiPhepComponent_Template_p_dialog_visibleChange_37_listener($event) { return ctx.isReason = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](38, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](39, "span", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](40, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](41, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](42, "Cho bi\u1EBFt l\u00FD do b\u1EA1n mu\u1ED1n h\u1EE7y duy\u1EC7t");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](43, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](44, "textarea", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function CsNghiPhepComponent_Template_textarea_ngModelChange_44_listener($event) { return ctx.reason_cancel = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](45, CsNghiPhepComponent_ng_template_45_Template, 3, 0, "ng-template", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](46, "p-overlayPanel", 39, 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](48, CsNghiPhepComponent_ng_template_48_Template, 40, 24, "ng-template", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction2"](37, _c0, ctx.MENUACTIONROLEAPI.GetLeavePage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction1"](41, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](40, _c1)));
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](43, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpropertyInterpolate"]("header", ctx.leaveId ? "S\u1EEDa ng\u00E0y ngh\u1EC9 ph\u00E9p" : "Th\u00EAm ng\u00E0y ngh\u1EC9 ph\u00E9p");
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("visible", ctx.addEdit)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](44, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](45, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("visible", ctx.isReason);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngModel", ctx.reason_cancel);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](46, _c5));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_13__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_27__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_14__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_28__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_29__.Dialog, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.RequiredValidator, primeng_api__WEBPACK_IMPORTED_MODULE_23__.PrimeTemplate, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_30__.OverlayPanel, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_15__.ListGridAngularComponent, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_16__.EditDetailComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_17__.ConfigGridTableFormComponent, primeng_button__WEBPACK_IMPORTED_MODULE_27__.ButtonDirective, primeng_calendar__WEBPACK_IMPORTED_MODULE_31__.Calendar, primeng_dropdown__WEBPACK_IMPORTED_MODULE_32__.Dropdown], styles: ["[_nghost-%COMP%]  .table-tool .p-button {\n  height: 100%;\n  width: 56px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNzLW5naGktcGhlcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLFlBQUE7RUFDQSxXQUFBO0FBQVIiLCJmaWxlIjoiY3MtbmdoaS1waGVwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Q6Om5nLWRlZXAgLnRhYmxlLXRvb2x7XHJcbiAgICAucC1idXR0b257XHJcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgIHdpZHRoOiA1NnB4O1xyXG4gICAgfVxyXG59Il19 */"] });


/***/ }),

/***/ 29095:
/*!********************************************************************************************************!*\
  !*** ./src/app/components/cs-thue-thu-nhap/chi-tiet-thue-thu-nhap/chi-tiet-thue-thu-nhap.component.ts ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietThueThuNhapComponent": () => (/* binding */ ChiTietThueThuNhapComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);

















function ChiTietThueThuNhapComponent_app_edit_detail_7_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "app-edit-detail", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("callback", function ChiTietThueThuNhapComponent_app_edit_detail_7_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return ctx_r1.setAccountInfo($event); })("callbackcancel", function ChiTietThueThuNhapComponent_app_edit_detail_7_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return ctx_r3.cancelUpdate($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("dataView", ctx_r0.listViews)("optionsButtonsEdit", ctx_r0.optionsButtonsView);
} }
class ChiTietThueThuNhapComponent {
    constructor(apiService, activatedRoute, messageService, confirmationService, spinner, router) {
        this.apiService = apiService;
        this.activatedRoute = activatedRoute;
        this.messageService = messageService;
        this.confirmationService = confirmationService;
        this.spinner = spinner;
        this.router = router;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this.manhinh = 'Edit';
        this.indexTab = 0;
        this.optionsButtonsView = [{ label: 'Sửa', value: 'Edit', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_2__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.MENUACTIONROLEAPI.GetIncomeTaxPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_3__.ACTIONS.EDIT) ? 'hidden' : ''
            }, { label: 'Quay lại', value: 'Back' }];
        this.displayScreemForm = false;
        this.displaysearchUserMaster = false;
        this.listViewsForm = [];
        this.detailComAuthorizeInfo = null;
        this.id = null;
        this.listViews = [];
        this.imagesUrl = [];
        this.paramsObject = null;
        this.displayUserInfo = false;
        this.titleForm = {
            label: 'Cập nhật thông tin khách hàng',
            value: 'Edit'
        };
        this.titlePage = '';
        this.url = '';
        this.detailInfo = null;
        this.listsData = [];
        this.dataRouter = null;
        this.back = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.items = [];
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Danh sách thuế thu nhập', routerLink: '/chinh-sach/thue-thu-nhap' },
            { label: this.titlePage },
        ];
        this.url = this.activatedRoute.data['_value'].url;
        this.manhinh = 'Edit';
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap.subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.dataRouter = this.paramsObject.params;
            this.id = this.paramsObject.params.id;
            this.getIncomeTaxInfo();
        });
    }
    ;
    getIncomeTaxInfo() {
        this.listViews = [];
        this.listsData = [];
        this.apiService.getIncomeTaxInfo(this.id).subscribe(results => {
            if (results.status === 'success') {
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.detailInfo = results.data;
            }
        });
    }
    handleChange(index) {
        this.indexTab = index;
    }
    setAccountInfo(data) {
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setIncomTaxInfo(params).subscribe((results) => {
            if (results.status === 'success') {
                this.goBack();
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo', detail: results.message
                });
            }
        }, error => {
            this.messageService.add({
                severity: 'error', summary: 'Thông báo', detail: error
            });
        });
    }
    onChangeButtonView(event) {
        this.manhinh = event.value;
        if (event.value === 'Back') {
            this.goBack();
        }
    }
    goBack() {
        if (this.titlePage) {
            this.router.navigate(['/chinh-sach/thue-thu-nhap']);
        }
        else {
            this.back.emit();
        }
    }
    cancelUpdate(data) {
        if (data === 'CauHinh') {
            this.getIncomeTaxInfo();
        }
        else {
            this.router.navigate(['/chinh-sach/thue-thu-nhap']);
        }
    }
}
ChiTietThueThuNhapComponent.ɵfac = function ChiTietThueThuNhapComponent_Factory(t) { return new (t || ChiTietThueThuNhapComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_9__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router)); };
ChiTietThueThuNhapComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: ChiTietThueThuNhapComponent, selectors: [["app-chi-tiet-thue-thu-nhap"]], inputs: { dataRouter: "dataRouter" }, outputs: { back: "back" }, decls: 8, vars: 3, consts: [[1, "main-grid", "product-detail"], [1, "breadcrumb"], [3, "model"], [3, "detail", "manhinh", "dataView", "optionsButtonsEdit", "callback", "callbackcancel", 4, "ngIf"], [3, "detail", "manhinh", "dataView", "optionsButtonsEdit", "callback", "callbackcancel"]], template: function ChiTietThueThuNhapComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "p-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, ChiTietThueThuNhapComponent_app_edit_detail_7_Template, 1, 4, "app-edit-detail", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("model", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx.titlePage);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_10__.Breadcrumb, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_4__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC10aHVlLXRodS1uaGFwLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 72602:
/*!***************************************************************************!*\
  !*** ./src/app/components/cs-thue-thu-nhap/cs-thue-thu-nhap.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CsThueThuNhapComponent": () => (/* binding */ CsThueThuNhapComponent)
/* harmony export */ });
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/api.service */ 67118);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var src_app_services_notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/notification.service */ 48410);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! file-saver */ 68178);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/common/form-filter/form-filter.component */ 83844);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/dynamicdialog */ 56427);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var src_app_components_cs_thue_thu_nhap_import_excel_import_excel_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/components/cs-thue-thu-nhap/import-excel/import-excel.component */ 97641);
/* harmony import */ var src_app_components_cs_thue_thu_nhap_delete_tax_delete_tax_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/components/cs-thue-thu-nhap/delete-tax/delete-tax.component */ 83307);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! primeng/dropdown */ 45596);










































function CsThueThuNhapComponent_app_list_grid_angular_27_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "app-list-grid-angular", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("showConfig", function CsThueThuNhapComponent_app_list_grid_angular_27_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](); return ctx_r7.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function CsThueThuNhapComponent_app_import_excel_33_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "app-import-excel", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("reloadData", function CsThueThuNhapComponent_app_import_excel_33_Template_app_import_excel_reloadData_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](); return ctx_r9.importSuccess(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
} }
function CsThueThuNhapComponent_app_delete_tax_35_Template(rf, ctx) { if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "app-delete-tax", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("reloadData", function CsThueThuNhapComponent_app_delete_tax_35_Template_app_delete_tax_reloadData_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r12); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](); return ctx_r11.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("companies", ctx_r3.companies);
} }
function CsThueThuNhapComponent_app_config_grid_table_form_37_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](0, "app-config-grid-table-form", 41);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r4.gridKey);
} }
function CsThueThuNhapComponent_ng_template_40_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](item_r15 == null ? null : item_r15.label);
} }
function CsThueThuNhapComponent_ng_template_40_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](1, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](car_r16 == null ? null : car_r16.label);
} }
function CsThueThuNhapComponent_ng_template_40_Template(rf, ctx) { if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](3, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](4, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](5, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](6, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](8, "C\u00F4ng ty");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](9, "p-dropdown", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("ngModelChange", function CsThueThuNhapComponent_ng_template_40_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r18); const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](); return ctx_r17.query.companyId = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](10, CsThueThuNhapComponent_ng_template_40_ng_template_10_Template, 2, 1, "ng-template", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](11, CsThueThuNhapComponent_ng_template_40_ng_template_11_Template, 3, 1, "ng-template", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](12, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](13, "label", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](14, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](15, "span", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](16, "p-button", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function CsThueThuNhapComponent_ng_template_40_Template_p_button_click_16_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r18); const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](); return ctx_r19.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](17, "p-button", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function CsThueThuNhapComponent_ng_template_40_Template_p_button_click_17_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r18); const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](); return ctx_r20.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r6.companies)("ngModel", ctx_r6.query.companyId)("filter", true);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { showAll: "ALL" }; };
const _c2 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c3 = function () { return { width: "600px" }; };
const _c4 = function () { return { width: "50vw" }; };
const _c5 = function () { return { width: "700px" }; };
class CsThueThuNhapComponent {
    constructor(apiService, apiBaseService, fileService, spinner, changeDetector, router, notificationService, confirmationService, messageService, organizeInfoService, dialogService) {
        this.apiService = apiService;
        this.apiBaseService = apiBaseService;
        this.fileService = fileService;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.router = router;
        this.notificationService = notificationService;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.organizeInfoService = organizeInfoService;
        this.dialogService = dialogService;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.ACTIONS;
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_4__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_8__.AgGridFn;
        this.loading = false;
        this.cards = [];
        this.first = 0;
        this.query = {
            companyId: '',
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: ''
        };
        this.totalRecord = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.companies = [];
        this.pagingComponent = {
            total: 0
        };
        this.items = [];
        this.showDeleteTax = false;
        this.showImportExcel = false;
        this.listViewsFilter = [];
        this.detailInfoFilter = null;
        this.optionsButonFilter = [
            { label: 'Tìm kiếm', value: 'Search', class: 'p-button-sm height-56 addNew', icon: 'pi pi-search' },
            { label: 'Làm mới', value: 'Reset', class: 'p-button-sm p-button-danger height-56 addNew', icon: 'pi pi-times' },
        ];
        this.displaySetting = false;
        this.gridKey = '';
        this.listsData = [];
        // handleDelete(e): void {
        //   this.confirmationService.confirm({
        //     message: 'Bạn có chắc chắn muốn xóa không?',
        //     accept: () => {
        //       this.apiService.deleteIncomeTaxStatus(e.rowData.id)
        //         .subscribe(response => {
        //           if (response.status === 'success') {
        //             this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: `Xóa thành công` });
        //           } else {
        //             this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: `Xóa thất bại` });
        //           }
        //         }, error => {
        //           this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: `Xóa thất bại` });
        //         });
        //     }
        //   });
        // }
        this.loadjs = 0;
        this.heightGrid = 0;
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 38;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_5__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_6__.ButtonAgGridComponent,
        };
        this.initFilter();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
                this.getCompanies();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Danh sách thuế thu nhập' },
        ];
        this.getFilter();
    }
    initFilter() {
        this.query = {
            companyId: '',
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds
        };
    }
    exportExcel() {
        const query = Object.assign({}, this.query);
        query.offSet = 0;
        query.pageSize = 1000000;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify(query);
        this.apiService.getIncomeTaxPage(queryParams)
            .subscribe((results) => {
            const dataExport = [];
            results.data.dataList.data.forEach(element => {
                const data = {};
                data['Mã thẻ'] = element.cardCd || '';
                data['Tên nhân viên'] = element.fullName || '';
                data['Tổ chức'] = element.orgName || '';
                data['Phòng'] = element.departmentName || '';
                data['Số điện thoại'] = element.phone || '';
                data['Ngày tạo thẻ'] = element.issueDate || '';
                data['Tài khoản tạo thẻ'] = element.created_by || '';
                data['Trạng thái'] = element.status === 3 ? 'Khóa' : (element.status === 1 ? 'Hoạt động' : '');
                data['Số lượng xe'] = element.countVehicle || '0';
                dataExport.push(data);
            });
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách thu nhập thuế ' + new Date());
        }, error => {
            console.error(error);
        });
    }
    dowloadTemplate() {
        this.apiService.exportReportLocalhost('assets/mau-thue-thu-nhap.xlsx').subscribe((data) => {
            this.createImageFromBlob(data);
        });
    }
    createImageFromBlob(image) {
        var blob = new Blob([image]);
        var url = window.URL.createObjectURL(blob);
        var anchor = document.createElement("a");
        anchor.download = "mau-thue-thu-nhap.xlsx";
        anchor.href = url;
        anchor.click();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify(this.query);
        this.apiService.getIncomeTaxPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.gridflexs = results.data.gridflexs;
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.handleEdit.bind(this),
                    label: 'Sửa',
                    icon: 'fa fa-pencil-square-o',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_8__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.MENUACTIONROLEAPI.GetIncomeTaxPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.ACTIONS.VIEW)
                    // hide: (params.data.status === 3)
                },
                {
                    onClick: this.handleExportTax.bind(this),
                    label: 'Xuất chứng từ thuế mẫu 1',
                    icon: 'fa fa-trash',
                    class: 'btn-danger mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_8__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.MENUACTIONROLEAPI.GetIncomeTaxPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.ACTIONS.XUAT_CHUNG_TU_THUE_1)
                },
                {
                    onClick: this.handleExportTax2.bind(this),
                    label: 'Xuất chứng từ thuế mẫu 2',
                    icon: 'fa fa-trash',
                    class: 'btn-danger mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_8__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.MENUACTIONROLEAPI.GetIncomeTaxPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.ACTIONS.XUAT_CHUNG_TU_THUE_2)
                },
                {
                    onClick: this.handleExportApproveTax.bind(this),
                    label: 'Xuất thư xác nhận thuế',
                    icon: 'fa fa-trash',
                    class: 'btn-danger mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_8__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.MENUACTIONROLEAPI.GetIncomeTaxPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_10__.ACTIONS.XUAT_THU_XAC_NHAN_THUE)
                },
            ]
        };
    }
    handleExportTax(data) {
        this.spinner.show();
        this.apiBaseService.getCTThueThuNhapCN(data.rowData.id, 1)
            .subscribe(response => {
            var blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            file_saver__WEBPACK_IMPORTED_MODULE_9__.saveAs(blob, 'Chứng từ thuế mẫu 1' + ".xlsx");
            this.spinner.hide();
        });
    }
    handleExportTax2(data) {
        this.spinner.show();
        this.apiBaseService.getCTThueThuNhapCN(data.rowData.id, 2)
            .subscribe(response => {
            var blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            file_saver__WEBPACK_IMPORTED_MODULE_9__.saveAs(blob, 'Chứng từ thuế mẫu 2' + ".xlsx");
            this.spinner.hide();
        });
    }
    handleExportApproveTax(data) {
        this.spinner.show();
        this.apiBaseService.getThuXacNhanThuNhaptype(data.rowData.id)
            .subscribe(response => {
            var blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            file_saver__WEBPACK_IMPORTED_MODULE_9__.saveAs(blob, 'Thư xác nhận thuế' + ".xlsx");
            this.spinner.hide();
        });
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_8__.AgGridFn)(this.gridflexs.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    handleEdit(e) {
        this.router.navigate(['/chinh-sach/thue-thu-nhap/chi-tiet-thue-thu-nhap'], { queryParams: { id: e.rowData.id } });
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    getCompanies() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_1__.stringify({});
        this.apiService.getCompanyList(queryParams)
            .subscribe((results) => {
            this.companies = results.data
                .map(d => {
                return { label: d.companyName, value: d.companyId };
            });
            this.companies = [{ label: 'Tất cả', value: '' }, ...this.companies];
        });
    }
    handlerError(error) {
        console.log(error);
        if (error.status === 401) {
            this.router.navigate(['/home']);
        }
    }
    find() {
        this.load();
    }
    cancel() {
        this.initFilter();
        this.load();
    }
    changePageSize() {
        this.load();
    }
    handleAdd() {
        this.router.navigateByUrl('/chinh-sach/bao-cao-thue/create');
    }
    importSuccess() {
        this.load();
        this.showImportExcel = false;
    }
    handleDelete() {
        this.showDeleteTax = true;
    }
    //filter 
    getFilter() {
        this.apiService.getFilter('/api/v2/incometax/GetIncomeTaxFilter').subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_12__.cloneDeep)(results.data.group_fields);
                this.listViewsFilter = [...listViews];
                this.detailInfoFilter = results.data;
            }
        });
    }
    showFilter() {
        const ref = this.dialogService.open(src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_13__.FormFilterComponent, {
            header: 'Tìm kiếm nâng cao',
            width: '40%',
            contentStyle: "",
            data: {
                listViews: this.listViewsFilter,
                detailInfoFilter: this.detailInfoFilter,
                buttons: this.optionsButonFilter
            }
        });
        ref.onClose.subscribe((event) => {
            if (event) {
                this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_12__.cloneDeep)(event.listViewsFilter);
                if (event.type === 'Search') {
                    this.query = Object.assign(Object.assign({}, this.query), event.data);
                    this.load();
                }
                else if (event.type === 'CauHinh') {
                    this.apiService.getEmpFilter().subscribe(results => {
                        if (results.status === 'success') {
                            const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_12__.cloneDeep)(results.data.group_fields);
                            this.listViewsFilter = [...listViews];
                            this.detailInfoFilter = results.data;
                            this.showFilter();
                        }
                    });
                }
                else if (event.type === 'Reset') {
                    const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_12__.cloneDeep)(this.detailInfoFilter.group_fields);
                    this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_12__.cloneDeep)(listViews);
                    this.cancel();
                }
            }
        });
    }
}
CsThueThuNhapComponent.ɵfac = function CsThueThuNhapComponent_Factory(t) { return new (t || CsThueThuNhapComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_7__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdirectiveInject"](_services_api_service__WEBPACK_IMPORTED_MODULE_0__.ApiService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_2__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_21__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_20__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_22__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdirectiveInject"](src_app_services_notification_service__WEBPACK_IMPORTED_MODULE_3__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_23__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_23__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_11__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_24__.DialogService)); };
CsThueThuNhapComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdefineComponent"]({ type: CsThueThuNhapComponent, selectors: [["app-cs-thue-thu-nhap"]], decls: 41, vars: 49, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "end", "mid", "bottom", "gap-12", "col-9", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["_ngcontent-xmj-c197", "", "width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["_ngcontent-xmj-c197", "", "fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["label", "Nh\u1EADp Excel", "icon", "fa fa-upload", "styleClass", "p-button-sm height-56", 3, "CheckHideActions", "click"], ["label", "T\u1EA3i file m\u1EABu", "icon", "fa fa-download", "styleClass", "p-button-sm height-56", 3, "CheckHideActions", "click"], ["label", "X\u00F3a", "icon", "fa fa-trash", "styleClass", "p-button-sm p-button-danger height-56", 3, "CheckHideActions", "click"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "Import excel", 3, "visible", "visibleChange"], [3, "reloadData", 4, "ngIf"], ["header", "X\u00F3a ch\u1EE9ng t\u1EEB thu\u1EBF", 3, "visible", "visibleChange"], [3, "companies", "reloadData", 4, "ngIf"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [3, "listsData", "height", "columnDefs", "showConfig"], [3, "reloadData"], [3, "companies", "reloadData"], [3, "typeConfig", "gridKey"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", "valid"], ["appendTo", "body", "name", "companyId", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"]], template: function CsThueThuNhapComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("keydown.enter", function CsThueThuNhapComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function CsThueThuNhapComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function CsThueThuNhapComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function CsThueThuNhapComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function CsThueThuNhapComponent_Template_p_button_click_15_listener() { return ctx.showFilter(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](21, "p-button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function CsThueThuNhapComponent_Template_p_button_click_21_listener() { return ctx.showImportExcel = true; });
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](22, "p-button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function CsThueThuNhapComponent_Template_p_button_click_22_listener() { return ctx.dowloadTemplate(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](23, "p-button", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function CsThueThuNhapComponent_Template_p_button_click_23_listener() { return ctx.handleDelete(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](24, "section", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](25, "div", 24, 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](27, CsThueThuNhapComponent_app_list_grid_angular_27_Template, 1, 3, "app-list-grid-angular", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](28, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](29, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](30);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](31, "p-paginator", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("onPageChange", function CsThueThuNhapComponent_Template_p_paginator_onPageChange_31_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](32, "p-dialog", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("visibleChange", function CsThueThuNhapComponent_Template_p_dialog_visibleChange_32_listener($event) { return ctx.showImportExcel = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](33, CsThueThuNhapComponent_app_import_excel_33_Template, 1, 0, "app-import-excel", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](34, "p-dialog", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("visibleChange", function CsThueThuNhapComponent_Template_p_dialog_visibleChange_34_listener($event) { return ctx.showDeleteTax = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](35, CsThueThuNhapComponent_app_delete_tax_35_Template, 1, 1, "app-delete-tax", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](36, "p-dialog", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("visibleChange", function CsThueThuNhapComponent_Template_p_dialog_visibleChange_36_listener($event) { return ctx.displaySetting = $event; })("onHide", function CsThueThuNhapComponent_Template_p_dialog_onHide_36_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](37, CsThueThuNhapComponent_app_config_grid_table_form_37_Template, 1, 2, "app-config-grid-table-form", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](38, "p-overlayPanel", 35, 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](40, CsThueThuNhapComponent_ng_template_40_Template, 18, 5, "ng-template", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction2"](33, _c0, ctx.MENUACTIONROLEAPI.GetIncomeTaxPage.url, ctx.ACTIONS.IMPORT));
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction2"](36, _c0, ctx.MENUACTIONROLEAPI.GetIncomeTaxPage.url, ctx.ACTIONS.TAI_FILE_MAU));
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction2"](39, _c0, ctx.MENUACTIONROLEAPI.GetIncomeTaxPage.url, ctx.ACTIONS.DELETE));
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction1"](43, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](42, _c1)));
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](45, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("visible", ctx.showImportExcel);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", ctx.showImportExcel);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](46, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("visible", ctx.showDeleteTax);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", ctx.showDeleteTax);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](47, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](48, _c5));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_14__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_27__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_15__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_28__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_29__.Dialog, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_30__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_23__.PrimeTemplate, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_16__.ListGridAngularComponent, src_app_components_cs_thue_thu_nhap_import_excel_import_excel_component__WEBPACK_IMPORTED_MODULE_17__.ImportExcelComponent, src_app_components_cs_thue_thu_nhap_delete_tax_delete_tax_component__WEBPACK_IMPORTED_MODULE_18__.DeleteTaxComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_19__.ConfigGridTableFormComponent, primeng_dropdown__WEBPACK_IMPORTED_MODULE_31__.Dropdown], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjcy10aHVlLXRodS1uaGFwLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 83307:
/*!********************************************************************************!*\
  !*** ./src/app/components/cs-thue-thu-nhap/delete-tax/delete-tax.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteTaxComponent": () => (/* binding */ DeleteTaxComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/button */ 62150);












function DeleteTaxComponent_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](item_r2 == null ? null : item_r2.label);
} }
function DeleteTaxComponent_ng_template_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](car_r3 == null ? null : car_r3.label);
} }
const _c0 = function () { return { "width": "100%" }; };
class DeleteTaxComponent {
    constructor(apiService, confirmationService, messageService) {
        this.apiService = apiService;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.reloadData = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.companies = [];
        this.datereport = null;
        this.loading = false;
        this.companyId = '';
    }
    ngOnInit() {
    }
    handleSave() {
        if (!this.companyId) {
            this.messageService.add({
                severity: 'error',
                summary: 'Thông báo', detail: 'Vui lòng chọn công ty'
            });
            return;
        }
        if (!this.datereport) {
            this.messageService.add({
                severity: 'error',
                summary: 'Thông báo', detail: 'Vui lòng chọn ngày'
            });
            return;
        }
        const date = moment__WEBPACK_IMPORTED_MODULE_0__(this.datereport).format('DD/MM/YYYY');
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa tất cả thuế thu nhập của công ty không?',
            accept: () => {
                this.apiService.deleteReportIncomeTaxs(querystring__WEBPACK_IMPORTED_MODULE_1__.stringify({ datereport: date, companyId: this.companyId }))
                    .subscribe(response => {
                    if (response.status === 'success') {
                        this.messageService.add({
                            severity: 'success', summary: 'Thông báo', detail: 'Xóa thành công'
                        });
                        this.reloadData.emit();
                    }
                    else {
                        this.messageService.add({
                            severity: 'error', summary: 'Thông báo', detail: response.message || 'Xóa thất bại'
                        });
                    }
                }, error => {
                    this.messageService.add({
                        severity: 'error', summary: 'Thông báo', detail: 'Xóa thất bại'
                    });
                });
            }
        });
    }
}
DeleteTaxComponent.ɵfac = function DeleteTaxComponent_Factory(t) { return new (t || DeleteTaxComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_4__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_4__.MessageService)); };
DeleteTaxComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: DeleteTaxComponent, selectors: [["app-delete-tax"]], inputs: { companies: "companies" }, outputs: { reloadData: "reloadData" }, decls: 15, vars: 9, consts: [[1, "row"], [1, "col-sm-12"], [1, "field-group", "date"], ["for", ""], ["appendTo", "body", "name", "datereport", "placeholder", "dd/mm/yyyy", "dateFormat", "dd/mm/yy", 3, "ngModel", "ngModelChange"], [1, "col-sm-12", "form-group"], [1, "field-group", "select", "label-8"], ["appendTo", "body", "name", "companyId", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "col-sm-12", "form-group", "text-right", "mt-2"], ["label", "X\u00F3a", "icon", "fa fa-plus", "styleClass", "p-button-sm ml-1", 3, "click"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"]], template: function DeleteTaxComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, "Ch\u1ECDn ng\u00E0y");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "p-calendar", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function DeleteTaxComponent_Template_p_calendar_ngModelChange_5_listener($event) { return ctx.datereport = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9, "C\u00F4ng ty");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "p-dropdown", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function DeleteTaxComponent_Template_p_dropdown_ngModelChange_10_listener($event) { return ctx.companyId = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](11, DeleteTaxComponent_ng_template_11_Template, 2, 1, "ng-template", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, DeleteTaxComponent_ng_template_12_Template, 3, 1, "ng-template", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "p-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function DeleteTaxComponent_Template_p_button_click_14_listener() { return ctx.handleSave(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](8, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ctx.datereport);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.companies)("ngModel", ctx.companyId)("filter", true);
    } }, directives: [primeng_calendar__WEBPACK_IMPORTED_MODULE_5__.Calendar, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, primeng_dropdown__WEBPACK_IMPORTED_MODULE_7__.Dropdown, primeng_api__WEBPACK_IMPORTED_MODULE_4__.PrimeTemplate, primeng_button__WEBPACK_IMPORTED_MODULE_8__.Button], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZWxldGUtdGF4LmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 97641:
/*!************************************************************************************!*\
  !*** ./src/app/components/cs-thue-thu-nhap/import-excel/import-excel.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ImportExcelComponent": () => (/* binding */ ImportExcelComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 53951);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/button */ 62150);











const _c0 = function () { return { "width": "100%" }; };
class ImportExcelComponent {
    constructor(apiService, messageService) {
        this.apiService = apiService;
        this.messageService = messageService;
        this.reloadData = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        this.date = null;
        this.file = null;
        this.loading = false;
    }
    ngOnInit() {
    }
    handleSave() {
        if (!this.file) {
            this.messageService.add({
                severity: 'error',
                summary: 'Thông báo', detail: 'Vui lòng chọn file'
            });
            return;
        }
        if (!this.date) {
            this.messageService.add({
                severity: 'error',
                summary: 'Thông báo', detail: 'Vui lòng chọn ngày'
            });
            return;
        }
        const date = moment__WEBPACK_IMPORTED_MODULE_0__(this.date).format('MM/DD/YYYY');
        this.loading = true;
        this.apiService.setIncomTaxImport(this.file, date)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.finalize)(() => this.loading = false))
            .subscribe(response => {
            if (response.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Import file thành công' });
                this.reloadData.emit();
            }
            else {
                this.messageService.add({
                    severity: 'error',
                    summary: 'Thông báo', detail: response ? response.message : 'Import file bị lỗi'
                });
            }
        });
    }
    importExcel(event) {
        if (event.target.files.length > 0) {
            this.file = event.target.files[0];
        }
    }
}
ImportExcelComponent.ɵfac = function ImportExcelComponent_Factory(t) { return new (t || ImportExcelComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_4__.MessageService)); };
ImportExcelComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: ImportExcelComponent, selectors: [["app-import-excel"]], outputs: { reloadData: "reloadData" }, decls: 15, vars: 4, consts: [[1, "row"], [1, "col-sm-12", "form-group"], [1, "field-group", "date"], ["for", ""], ["appendTo", "body", "placeholder", "dd/mm/yyyy", "name", "date", "dateFormat", "dd/mm/yy", 3, "ngModel", "ngModelChange"], [1, "field-group", "attach-file", "label-8"], [1, "upload_file"], ["type", "file", "placeholder", "Ch\u1ECDn file", 1, "form-control", 3, "change"], ["importEx", ""], [1, "col-sm-12", "form-group", "text-right", "mt-2"], ["label", "L\u01B0u l\u1EA1i", "icon", "fa fa-plus", "styleClass", "p-button-sm ml-1", 3, "click"]], template: function ImportExcelComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4, "Ch\u1ECDn ng\u00E0y");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "p-calendar", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function ImportExcelComponent_Template_p_calendar_ngModelChange_5_listener($event) { return ctx.date = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](9, " Ch\u1ECDn file ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "input", 7, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("change", function ImportExcelComponent_Template_input_change_11_listener($event) { return ctx.importExcel($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "p-button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ImportExcelComponent_Template_p_button_click_14_listener() { return ctx.handleSave(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](3, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx.date);
    } }, directives: [primeng_calendar__WEBPACK_IMPORTED_MODULE_5__.Calendar, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_7__.Button], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpbXBvcnQtZXhjZWwuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 77589:
/*!***********************************************************************************************!*\
  !*** ./src/app/components/cs-tien-luong/chi-tiet-tien-luong/chi-tiet-tien-luong.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietTienLuongComponent": () => (/* binding */ ChiTietTienLuongComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_card__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/card */ 33506);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);
/* harmony import */ var primeng_badge__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/badge */ 62051);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);






















function ChiTietTienLuongComponent_div_6_app_edit_detail_1_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-edit-detail", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("callback", function ChiTietTienLuongComponent_div_6_app_edit_detail_1_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2); return ctx_r5.setSalaryRecordInfo($event); })("callbackcancel", function ChiTietTienLuongComponent_div_6_app_edit_detail_1_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r6); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2); return ctx_r7.cancelUpdate($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("thongtinnhanvienNew", true)("optionsButtonsEdit", ctx_r2.optionsButtonsView)("manhinh", ctx_r2.manhinh)("dataView", ctx_r2.listViews);
} }
function ChiTietTienLuongComponent_div_6_ng_template_3_p_badge_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "p-badge", 16);
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpropertyInterpolate"]("value", ctx_r8.listsData.length);
} }
function ChiTietTienLuongComponent_div_6_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "h5", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2, " Ng\u00E0y c\u00F4ng ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](3, ChiTietTienLuongComponent_div_6_ng_template_3_p_badge_3_Template, 1, 1, "p-badge", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx_r3.listsData.length > 0);
} }
function ChiTietTienLuongComponent_div_6_app_list_grid_angular_5_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-list-grid-angular", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("FnClick", function ChiTietTienLuongComponent_div_6_app_list_grid_angular_5_Template_app_list_grid_angular_FnClick_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2); return ctx_r9.OnClick($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("domLayout", "autoHeight")("heightRow", 40)("title", "Danh s\u00E1ch li\u00EAn h\u1EC7")("listsData", ctx_r4.listsData)("floatingFilter", true)("columnDefs", ctx_r4.columnDefs);
} }
function ChiTietTienLuongComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](1, ChiTietTienLuongComponent_div_6_app_edit_detail_1_Template, 1, 4, "app-edit-detail", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "p-card", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](3, ChiTietTienLuongComponent_div_6_ng_template_3_Template, 4, 1, "ng-template", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](4, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](5, ChiTietTienLuongComponent_div_6_app_list_grid_angular_5_Template, 1, 6, "app-list-grid-angular", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx_r0.listViews.length > 0 && ctx_r0.manhinh === "Edit");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx_r0.listsData.length > 0);
} }
function ChiTietTienLuongComponent_p_tabPanel_7_ng_template_2_p_badge_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "p-badge", 16);
} if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpropertyInterpolate"]("value", ctx_r13.listsData.length);
} }
function ChiTietTienLuongComponent_p_tabPanel_7_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "h5", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](4, "Danh s\u00E1ch nh\u00E2n vi\u00EAn");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](5, ChiTietTienLuongComponent_p_tabPanel_7_ng_template_2_p_badge_5_Template, 1, 1, "p-badge", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx_r11.listsData.length > 0);
} }
function ChiTietTienLuongComponent_p_tabPanel_7_app_list_grid_angular_4_Template(rf, ctx) { if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-list-grid-angular", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("FnClick", function ChiTietTienLuongComponent_p_tabPanel_7_app_list_grid_angular_4_Template_app_list_grid_angular_FnClick_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r15); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2); return ctx_r14.OnClick($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("domLayout", "autoHeight")("title", "Ch\u1EE9ng ch\u1EC9")("listsData", ctx_r12.listsData)("columnDefs", ctx_r12.columnDefs);
} }
function ChiTietTienLuongComponent_p_tabPanel_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "p-tabPanel", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "p-card", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](2, ChiTietTienLuongComponent_p_tabPanel_7_ng_template_2_Template, 6, 1, "ng-template", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](4, ChiTietTienLuongComponent_p_tabPanel_7_app_list_grid_angular_4_Template, 1, 4, "app-list-grid-angular", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx_r1.indexTab === 1);
} }
class ChiTietTienLuongComponent {
    constructor(apiService, activatedRoute, messageService, confirmationService, spinner, router) {
        this.apiService = apiService;
        this.activatedRoute = activatedRoute;
        this.messageService = messageService;
        this.confirmationService = confirmationService;
        this.spinner = spinner;
        this.router = router;
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subject();
        this.manhinh = 'Edit';
        this.indexTab = 0;
        this.optionsButtonsView = [
            { label: 'Lưu', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI.GetSalaryRecordPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS.EDIT) ? 'hidden' : '' },
            { label: 'Quay lại', value: 'Back' }
        ];
        this.displayScreemForm = false;
        this.displaysearchUserMaster = false;
        this.listViewsForm = [];
        this.detailComAuthorizeInfo = null;
        this.recordId = null;
        this.listViews = [];
        this.imagesUrl = [];
        this.paramsObject = null;
        this.displayUserInfo = false;
        this.titleForm = {
            label: 'Cập nhật thông tin khách hàng',
            value: 'Edit'
        };
        this.titlePage = '';
        this.url = '';
        this.items = [];
        this.detailInfo = null;
        this.listsData = [];
        this.columnDefs = [];
        this.dataRouter = null;
        this.back = new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter();
        this.listDataNew = [];
        this.cellRendererSanPham = (params) => {
            console.log(params);
            let rowData = [];
            if (!params.value || params.value === '(Select All)') {
                return params.value;
            }
            setTimeout(() => {
                params.api.forEachNodeAfterFilter(node => {
                    console.log(node.data);
                    rowData.push(node.data);
                });
                this.listDataNew = rowData;
            }, 500);
            return params.value;
        };
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnChanges() {
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Danh sách tiền lương', routerLink: '/chinh-sach/tien-luong' },
            { label: this.titlePage },
        ];
        this.url = this.activatedRoute.data['_value'].url;
        this.manhinh = 'Edit';
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap.subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.dataRouter = this.paramsObject.params;
            this.recordId = this.paramsObject.params.recordId || null;
            if (this.url === 'them-moi-tien-luong') {
                this.setSalaryCreateDraft();
            }
            else {
                this.getSalaryRecordInfo();
            }
        });
    }
    ;
    setSalaryCreateDraft() {
        this.apiService.setSalaryCreateDraft(this.paramsObject.params).subscribe(results => {
            if (results.status === 'success') {
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(results.data.group_fields);
                this.detailInfo = results.data;
                this.listsData = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(this.detailInfo.monthdays);
                this.columnDefs = [...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.AgGridFn)(this.detailInfo.gridflexs1 || [])
                ];
            }
        });
    }
    getSalaryRecordInfo() {
        this.listViews = [];
        this.listsData = [];
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ recordId: this.recordId });
        this.apiService.getSalaryRecordInfo(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(results.data.group_fields);
                this.detailInfo = results.data;
                this.listsData = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(this.detailInfo.monthdays);
                this.listDataNew = this.listsData;
                this.columnDefs = [...this.agGridFnCustomer(this.detailInfo.gridflexs1 || [])
                    // , {
                    //   headerName: '',
                    //   field: 'button',
                    //   filter: '',
                    //   pinned: 'right',
                    //   width: 60,
                    //   cellRenderer: 'buttonRendererMutiComponent',
                    //   cellClass: ['border-right'],
                    //   // cellRendererParams: params => this.showButton()
                    // }
                ];
            }
        });
    }
    OnClick(e) {
    }
    handleChange(index) {
        this.columnDefs = [];
        this.indexTab = index;
        if (this.indexTab === 1) {
            this.getSalaryEmployeePage();
        }
        else {
            this.listsData = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(this.detailInfo.monthdays);
            this.listDataNew = this.listsData;
            this.columnDefs = [...this.agGridFnCustomer(this.detailInfo.gridflexs1 || [])];
        }
    }
    getSalaryEmployeePage() {
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ recordId: this.recordId });
        this.apiService.getSalaryEmployeePage(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.listsData = results.data.dataList.data;
                this.columnDefs = [
                    ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.AgGridFn)(results.data.gridflexs),
                ];
                this.spinner.hide();
            }
            else {
                this.spinner.hide();
            }
        });
    }
    setSalaryRecordInfo(data) {
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setSalaryRecordInfo(params).subscribe((results) => {
            if (results.status === 'success') {
                this.displayUserInfo = false;
                if (this.url === 'them-moi-tien-luong') {
                    this.goBack();
                }
                else {
                    this.manhinh = 'Edit';
                    this.getSalaryRecordInfo();
                }
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Cập nhật thông tin thành công' });
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo', detail: results.message
                });
            }
        }, error => {
        });
    }
    onChangeButtonView(event) {
        this.manhinh = event.value;
        if (event.value === 'Back') {
            this.goBack();
        }
    }
    goBack() {
        if (this.titlePage) {
            this.router.navigate(['/chinh-sach/tien-luong']);
        }
        else {
            this.back.emit();
        }
    }
    cancelUpdate(data) {
        if (data === 'CauHinh') {
            this.getSalaryRecordInfo();
        }
        else {
            this.router.navigate(['/chinh-sach/tien-luong']);
        }
    }
    agGridFnCustomer(lists) {
        let arrAgGrids = [];
        for (let value of lists) {
            let row = {
                headerName: value.columnCaption,
                field: value.columnField,
                cellClass: value.cellClass,
                filter: value.isFilter ? 'agSetColumnFilter' : '',
                sortable: false,
                filterParams: {
                    caseSensitive: true,
                    textFormatter: (r) => (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.TextFormatter)(r),
                    cellRenderer: this.cellRendererSanPham,
                },
                cellRenderer: value.isMasterDetail ? 'agGroupCellRenderer' : '',
                hide: value.isHide ? true : false,
                pinned: value.pinned,
                tooltipField: value.columnField,
                headerTooltip: value.columnCaption
                // valueFormatter: value.fieldType == 'decimal' ? ""
            };
            arrAgGrids.push(row);
        }
        return arrAgGrids;
    }
}
ChiTietTienLuongComponent.ɵfac = function ChiTietTienLuongComponent_Factory(t) { return new (t || ChiTietTienLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_2__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_12__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.Router)); };
ChiTietTienLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({ type: ChiTietTienLuongComponent, selectors: [["app-chi-tiet-tien-luong"]], inputs: { dataRouter: "dataRouter" }, outputs: { back: "back" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵNgOnChangesFeature"]], decls: 8, vars: 4, consts: [[1, "main-grid", "product-detail"], [3, "items"], [3, "activeIndex", "activeIndexChange", "onChange"], ["header", "Th\u00F4ng tin chung"], ["class", "", 4, "ngIf"], ["header", "Nh\u00E2n vi\u00EAn", 4, "ngIf"], [1, ""], [3, "thongtinnhanvienNew", "optionsButtonsEdit", "manhinh", "dataView", "callback", "callbackcancel", 4, "ngIf"], ["styleClass", "fields-section border-section"], ["pTemplate", "header"], [1, "grid-default", 2, "max-height", "600px", "overflow", "auto"], [3, "domLayout", "heightRow", "title", "listsData", "floatingFilter", "columnDefs", "FnClick", 4, "ngIf"], [3, "thongtinnhanvienNew", "optionsButtonsEdit", "manhinh", "dataView", "callback", "callbackcancel"], [1, "panel-heading"], [2, "font-size", "20px !important", "font-weight", "500", "color", "#2F3E62", "font-family", "SFProTextMedium", "position", "relative", "margin-bottom", "10px", "padding-left", "0px", "padding-top", "3px"], ["styleClass", "p-mr-2", 3, "value", 4, "ngIf"], ["styleClass", "p-mr-2", 3, "value"], [3, "domLayout", "heightRow", "title", "listsData", "floatingFilter", "columnDefs", "FnClick"], ["header", "Nh\u00E2n vi\u00EAn"], [1, "grid-default"], [3, "domLayout", "title", "listsData", "columnDefs", "FnClick", 4, "ngIf"], [1, "row", "d-flex"], [1, "col-md-6"], [1, "panel-heading", 2, "padding", "10px"], [1, "panel-title", 2, "font-size", "20px !important", "font-weight", "500", "color", "#2F3E62", "font-family", "SFProTextMedium", "position", "relative", "margin-bottom", "10px", "padding-left", "0px", "padding-top", "3px"], [3, "domLayout", "title", "listsData", "columnDefs", "FnClick"]], template: function ChiTietTienLuongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "app-hrm-breadcrumb", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](4, "p-tabView", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("activeIndexChange", function ChiTietTienLuongComponent_Template_p_tabView_activeIndexChange_4_listener($event) { return ctx.indexTab = $event; })("onChange", function ChiTietTienLuongComponent_Template_p_tabView_onChange_4_listener($event) { return ctx.handleChange($event.index); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "p-tabPanel", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](6, ChiTietTienLuongComponent_div_6_Template, 6, 2, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](7, ChiTietTienLuongComponent_p_tabPanel_7_Template, 5, 1, "p-tabPanel", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("activeIndex", ctx.indexTab);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.detailInfo);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.recordId);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_5__.HrmBreadCrumbComponent, primeng_tabview__WEBPACK_IMPORTED_MODULE_13__.TabView, primeng_tabview__WEBPACK_IMPORTED_MODULE_13__.TabPanel, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, primeng_card__WEBPACK_IMPORTED_MODULE_15__.Card, primeng_api__WEBPACK_IMPORTED_MODULE_11__.PrimeTemplate, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_6__.EditDetailComponent, primeng_badge__WEBPACK_IMPORTED_MODULE_16__.Badge, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_7__.ListGridAngularComponent], styles: ["[_nghost-%COMP%]  .p-tabview .p-tabview-panels {\n  padding-left: 0px;\n  padding-right: 0px;\n}\n\n.max-h-600[_ngcontent-%COMP%] {\n  max-height: 600px;\n  overflow: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoaS10aWV0LXRpZW4tbHVvbmcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBQ0E7RUFDSSxpQkFBQTtFQUNBLGNBQUE7QUFFSiIsImZpbGUiOiJjaGktdGlldC10aWVuLWx1b25nLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Q6Om5nLWRlZXAgLnAtdGFidmlldyAucC10YWJ2aWV3LXBhbmVsc3tcclxuICAgIHBhZGRpbmctbGVmdDogMHB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMHB4XHJcbn1cclxuLm1heC1oLTYwMHtcclxuICAgIG1heC1oZWlnaHQ6IDYwMHB4O1xyXG4gICAgb3ZlcmZsb3c6IGF1dG87XHJcbn0iXX0= */"] });


/***/ }),

/***/ 19871:
/*!*********************************************************************!*\
  !*** ./src/app/components/cs-tien-luong/cs-tien-luong.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CsTienLuongComponent": () => (/* binding */ CsTienLuongComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ag-grid-enterprise/all-modules */ 19690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/common/form-filter/form-filter.component */ 83844);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/dynamicdialog */ 56427);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);



































function CsTienLuongComponent_app_list_grid_angular_28_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-list-grid-angular", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("showConfig", function CsTienLuongComponent_app_list_grid_angular_28_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r7.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function CsTienLuongComponent_ng_template_39_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r9.label);
} }
function CsTienLuongComponent_ng_template_40_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](car_r10.label);
} }
function CsTienLuongComponent_app_config_grid_table_form_51_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "app-config-grid-table-form", 49);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r4.gridKey);
} }
function CsTienLuongComponent_ng_template_54_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "span", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r13.label);
} }
function CsTienLuongComponent_ng_template_54_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r14 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](car_r14.label);
} }
function CsTienLuongComponent_ng_template_54_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](8, "Tr\u1EA1ng th\u00E1i");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "p-dropdown", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function CsTienLuongComponent_ng_template_54_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r15.query.record_st = $event; })("onChange", function CsTienLuongComponent_ng_template_54_Template_p_dropdown_onChange_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r16); const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r17.find(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](10, CsTienLuongComponent_ng_template_54_ng_template_10_Template, 2, 1, "ng-template", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](11, CsTienLuongComponent_ng_template_54_ng_template_11_Template, 3, 1, "ng-template", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](12, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](13, "label", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](14, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](15, "span", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](16, "p-button", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function CsTienLuongComponent_ng_template_54_Template_p_button_click_16_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r16); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r18.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](17, "p-button", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function CsTienLuongComponent_ng_template_54_Template_p_button_click_17_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r16); const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r19.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx_r6.listRecordStatus)("ngModel", ctx_r6.query.record_st)("filter", true);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { showAll: "ALL" }; };
const _c2 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c3 = function () { return { width: "600px" }; };
const _c4 = function () { return { width: "50vw" }; };
const _c5 = function () { return { width: "700px" }; };
class CsTienLuongComponent {
    constructor(spinner, apiService, route, confirmationService, messageService, changeDetector, organizeInfoService, dialogService, router) {
        this.spinner = spinner;
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.dialogService = dialogService;
        this.router = router;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS;
        this.modelAdd = {
            date: new Date(),
            organizeId: ''
        };
        this.listOrgRoots = [];
        this.listRecordStatus = [];
        this.displayFrom = false;
        this.pagingComponent = {
            total: 0
        };
        this.titleForm = {
            label: 'Thêm mới tài khoản',
            value: 'Add'
        };
        this.modules = _ag_grid_enterprise_all_modules__WEBPACK_IMPORTED_MODULE_1__.AllModules;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.AgGridFn;
        this.items = [];
        this.columnDefs = [];
        this.query = {
            organizeId: null,
            record_st: '',
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: '',
        };
        this.totalRecord = 0;
        this.DriverId = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.organizeIds = '';
        this.displaySetting = false;
        this.gridKey = '';
        this.listsData = [];
        this.loadjs = 0;
        this.heightGrid = 0;
        this.listViewsFilter = [];
        this.detailInfoFilter = null;
        this.optionsButonFilter = [
            { label: 'Tìm kiếm', value: 'Search', class: 'p-button-sm height-56 addNew', icon: 'pi pi-search' },
            { label: 'Làm mới', value: 'Reset', class: 'p-button-sm p-button-danger height-56 addNew', icon: 'pi pi-times' },
        ];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.getRowHeight = (params) => {
            return 40;
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_2__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_3__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_4__.AvatarFullComponent,
        };
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }
    cancel() {
        this.query = {
            organizeId: null,
            record_st: '',
            filter: '',
            offSet: 0,
            pageSize: 15,
            organizeIds: this.query.organizeIds
        };
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getSalaryRecordPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.XemChiTiet.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetSalaryRecordPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.VIEW)
                },
                {
                    onClick: this.pheDuyet.bind(this),
                    label: 'Phê duyệt',
                    icon: 'pi pi-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetSalaryRecordPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.PHE_DUYET)
                },
                // {
                //   onClick: this.CloseAccount.bind(this),
                //   label: 'Đóng tài khoản',
                //   icon: 'pi pi-trash',
                //   class: 'btn-primary mr5',
                // },
            ]
        };
    }
    pheDuyet(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn thực hiện phê duyệt?',
            accept: () => {
                this.apiService.setSalaryRecordApprove({ recordId: event.rowData.recordId }).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa công ty thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_5__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    xoaTienLuong(event) {
        // this.confirmationService.confirm({
        //   message: 'Bạn có chắc chắn muốn thực hiện mở tài khoản?',
        //   accept: () => {
        //     const queryParams = queryString.stringify({ companyId: event.rowData.companyId });
        //     this.apiService.delCompanyInfo(queryParams).subscribe(results => {
        //       if (results.status === 'success') {
        //         this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa công ty thành công' });
        //         this.load();
        //       } else {
        //         this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
        //       }
        //     });
        //   }
        // });
    }
    XemChiTiet(event) {
        const params = {
            recordId: event.rowData.recordId
        };
        this.router.navigate(['/chinh-sach/tien-luong/chi-tiet-tien-luong'], { queryParams: params });
    }
    addTienLuong() {
        this.displayFrom = true;
        this.modelAdd = {
            date: new Date(),
            organizeId: this.organizeIds
        };
        // const params = {
        //   companyId: 0
        // }
        // this.router.navigate(['/tien-luong/them-moi-tien-luong'], { queryParams: params });
    }
    themmoi() {
        console.log(this.modelAdd);
        let data = Object.assign({}, this.modelAdd);
        data.salary_year = new Date(this.modelAdd.date).getFullYear();
        data.salary_month = new Date(this.modelAdd.date).getMonth() + 1;
        delete data.date;
        this.router.navigate(['/chinh-sach/tien-luong/them-moi-tien-luong'], { queryParams: data });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.query.organizeId = results;
                this.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Danh sách tiền lương' },
        ];
        this.getOrgRoots();
        this.getFilter();
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    getOrgRoots() {
        this.apiService.getOrgRoots().subscribe(results => {
            if (results.status === 'success') {
                this.listOrgRoots = results.data.map(d => {
                    return {
                        label: d.name,
                        value: `${d.value}`
                    };
                });
                this.listOrgRoots = [{ label: 'Chọn tổ chức', value: null }, ...this.listOrgRoots];
            }
        });
    }
    quanlyloaihopdong() {
        this.router.navigate(['/company/danh-sach-quan-ly-hd']);
    }
    //filter 
    getFilter() {
        this.apiService.getFilter('/api/v1/salary/GetSalaryFilter').subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_9__.cloneDeep)(results.data.group_fields);
                this.listViewsFilter = [...listViews];
                this.detailInfoFilter = results.data;
            }
        });
    }
    showFilter() {
        const ref = this.dialogService.open(src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_10__.FormFilterComponent, {
            header: 'Tìm kiếm nâng cao',
            width: '40%',
            contentStyle: "",
            data: {
                listViews: this.listViewsFilter,
                detailInfoFilter: this.detailInfoFilter,
                buttons: this.optionsButonFilter
            }
        });
        ref.onClose.subscribe((event) => {
            if (event) {
                this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_9__.cloneDeep)(event.listViewsFilter);
                if (event.type === 'Search') {
                    this.query = Object.assign(Object.assign({}, this.query), event.data);
                    this.load();
                }
                else if (event.type === 'CauHinh') {
                    this.apiService.getEmpFilter().subscribe(results => {
                        if (results.status === 'success') {
                            const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_9__.cloneDeep)(results.data.group_fields);
                            this.listViewsFilter = [...listViews];
                            this.detailInfoFilter = results.data;
                            this.showFilter();
                        }
                    });
                }
                else if (event.type === 'Reset') {
                    const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_9__.cloneDeep)(this.detailInfoFilter.group_fields);
                    this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_9__.cloneDeep)(listViews);
                    this.cancel();
                }
            }
        });
    }
}
CsTienLuongComponent.ɵfac = function CsTienLuongComponent_Factory(t) { return new (t || CsTienLuongComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_16__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_6__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_17__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_18__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_18__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_15__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_19__.DialogService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_17__.Router)); };
CsTienLuongComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({ type: CsTienLuongComponent, selectors: [["app-cs-tien-luong"]], decls: 55, vars: 50, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "middle"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "end", "mid", "bottom", "gap-12", "col-9", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["_ngcontent-xmj-c197", "", "width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["_ngcontent-xmj-c197", "", "fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", 3, "CheckHideActions", "click"], ["d", "M11 5H9V9H5V11H9V15H11V11H15V9H11V5ZM10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM10 18C5.59 18 2 14.41 2 10C2 5.59 5.59 2 10 2C14.41 2 18 5.59 18 10C18 14.41 14.41 18 10 18Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "Th\u00EAm m\u1EDBi ti\u1EC1n l\u01B0\u01A1ng", 3, "visible", "modal", "draggable", "resizable", "autoZIndex", "visibleChange"], [1, "col-md-12", "p-0"], [1, "field-group", "select", 3, "ngClass"], ["for", ""], ["appendTo", "body", "appendTo", "body", "name", "organizeId", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "disabled", "filter", "ngModelChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "col-md-12", "p-0", "mt-1"], [1, "field-group", "date"], ["name", "date", "view", "month", "appendTo", "body", "dateFormat", "mm/yy", "inputId", "monthpicker", 3, "ngModel", "readonlyInput", "ngModelChange"], [1, "col-md-6"], [1, "col-md-6", "text-right", "pr-0"], ["label", "G\u1EEDi", "icon", "pi pi-check", "styleClass", "p-button-sm", 3, "click"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [3, "listsData", "height", "columnDefs", "showConfig"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"], [3, "typeConfig", "gridKey"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", "label-8", "valid"], ["appendTo", "body", "name", "record_st", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "ngModelChange", "onChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [2, "vertical-align", "middle", "margin-left", ".5em"], [2, "font-size", "14px", "float", "left", "margin-top", "4px"]], template: function CsTienLuongComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("keydown.enter", function CsTienLuongComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function CsTienLuongComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function CsTienLuongComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function CsTienLuongComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function CsTienLuongComponent_Template_p_button_click_15_listener() { return ctx.showFilter(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](21, "p-button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function CsTienLuongComponent_Template_p_button_click_21_listener() { return ctx.addTienLuong(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](22, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](23, "path", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](24, " \u00A0 Th\u00EAm m\u1EDBi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](25, "section", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](26, "div", 23, 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](28, CsTienLuongComponent_app_list_grid_angular_28_Template, 1, 3, "app-list-grid-angular", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](29, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](30, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](32, "p-paginator", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("onPageChange", function CsTienLuongComponent_Template_p_paginator_onPageChange_32_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](33, "p-dialog", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function CsTienLuongComponent_Template_p_dialog_visibleChange_33_listener($event) { return ctx.displayFrom = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](34, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](35, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](36, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](37, "Ch\u1ECDn t\u1ED5 ch\u1EE9c");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](38, "p-dropdown", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function CsTienLuongComponent_Template_p_dropdown_ngModelChange_38_listener($event) { return ctx.modelAdd.organizeId = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](39, CsTienLuongComponent_ng_template_39_Template, 2, 1, "ng-template", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](40, CsTienLuongComponent_ng_template_40_Template, 3, 1, "ng-template", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](41, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](42, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](43, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](44, "Th\u00E1ng");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](45, "p-calendar", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function CsTienLuongComponent_Template_p_calendar_ngModelChange_45_listener($event) { return ctx.modelAdd.date = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](46, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](47, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](48, "div", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](49, "p-button", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function CsTienLuongComponent_Template_p_button_click_49_listener() { return ctx.themmoi(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](50, "p-dialog", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function CsTienLuongComponent_Template_p_dialog_visibleChange_50_listener($event) { return ctx.displaySetting = $event; })("onHide", function CsTienLuongComponent_Template_p_dialog_onHide_50_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](51, CsTienLuongComponent_app_config_grid_table_form_51_Template, 1, 2, "app-config-grid-table-form", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](52, "p-overlayPanel", 43, 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](54, CsTienLuongComponent_ng_template_54_Template, 18, 5, "ng-template", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction2"](41, _c0, ctx.MENUACTIONROLEAPI.GetSalaryRecordPage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](45, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](44, _c1)));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](47, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.displayFrom)("modal", true)("draggable", false)("resizable", false)("autoZIndex", true)("draggable", false)("resizable", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", ctx.modelAdd.organizeId ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.listOrgRoots)("ngModel", ctx.modelAdd.organizeId)("disabled", true)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.modelAdd.date)("readonlyInput", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](48, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](49, _c5));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_11__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_22__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_12__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_23__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_24__.Dialog, primeng_dropdown__WEBPACK_IMPORTED_MODULE_25__.Dropdown, primeng_api__WEBPACK_IMPORTED_MODULE_18__.PrimeTemplate, primeng_calendar__WEBPACK_IMPORTED_MODULE_26__.Calendar, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_27__.OverlayPanel, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_13__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_14__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjcy10aWVuLWx1b25nLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 52865:
/*!***********************************************************************************!*\
  !*** ./src/app/components/phep-bu/chi-tiet-phep-bu/chi-tiet-phep-bu.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietPhepBuComponent": () => (/* binding */ ChiTietPhepBuComponent)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);
















function ChiTietPhepBuComponent_app_edit_detail_4_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "app-edit-detail", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("callback", function ChiTietPhepBuComponent_app_edit_detail_4_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r1.setAnnualAddInfo($event); })("callbackcancel", function ChiTietPhepBuComponent_app_edit_detail_4_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r3.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
const queryString = __webpack_require__(/*! query-string */ 31808);
class ChiTietPhepBuComponent {
    constructor(activatedRoute, apiService, spinner, confirmationService, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_2__.MENUACTIONROLEAPI.GetAnnualAddPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_2__.ACTIONS.EDIT) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
        this.modelEdit = {
            annualId: "",
        };
        this.titlePage = '';
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.titlePage = this.activatedRoute.data['_value'].title;
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Phép bù', routerLink: '/chinh-sach/phep-bu' },
            { label: `${this.titlePage}` },
        ];
        this.handleParams();
    }
    handleParams() {
        this.activatedRoute.queryParamMap
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe((params) => {
            this.paramsObject = Object.assign(Object.assign({}, params.keys), params);
            this.modelEdit.annualId = this.paramsObject.params.annualId || "";
            this.getAnnualAddInfo();
        });
    }
    ;
    getAnnualAddInfo() {
        const queryParams = queryString.stringify(this.modelEdit);
        this.apiService.getAnnualAddInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = [...listViews];
                this.detailInfo = results.data;
            }
        });
    }
    setAnnualAddInfo(data) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: data });
        this.apiService.setAnnualAddInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.router.navigate(['/chinh-sach/phep-bu']);
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            this.spinner.hide();
        };
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getAnnualAddInfo();
        }
        else {
            this.router.navigate(['/chinh-sach/phep-bu']);
        }
    }
}
ChiTietPhepBuComponent.ɵfac = function ChiTietPhepBuComponent_Factory(t) { return new (t || ChiTietPhepBuComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router)); };
ChiTietPhepBuComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: ChiTietPhepBuComponent, selectors: [["app-chi-tiet-phep-bu"]], decls: 5, vars: 2, consts: [[1, "main-grid", "product-detail"], [3, "items"], [1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function ChiTietPhepBuComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](2, "app-hrm-breadcrumb", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, ChiTietPhepBuComponent_app_edit_detail_4_Template, 1, 4, "app-edit-detail", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGktdGlldC1waGVwLWJ1LmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 54278:
/*!*******************************************************************************!*\
  !*** ./src/app/components/phep-bu/import-phep-bu/import-phep-bu.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ImportPhepBuComponent": () => (/* binding */ ImportPhepBuComponent)
/* harmony export */ });
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/tooltip */ 39243);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/fileupload */ 83735);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);



















function ImportPhepBuComponent_p_button_8_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportPhepBuComponent_p_button_8_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r5.getTemfileImport(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportPhepBuComponent_p_fileUpload_9_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-fileUpload", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onSelect", function ImportPhepBuComponent_p_fileUpload_9_Template_p_fileUpload_onSelect_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r7.onSelectFile($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("showCancelButton", true);
} }
function ImportPhepBuComponent_p_button_10_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportPhepBuComponent_p_button_10_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r9.back(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportPhepBuComponent_p_button_11_Template(rf, ctx) { if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "p-button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportPhepBuComponent_p_button_11_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r12); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r11.refetchFile(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ImportPhepBuComponent_div_13_app_list_grid_angular_2_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "app-list-grid-angular", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("firstDataRendered", function ImportPhepBuComponent_div_13_app_list_grid_angular_2_Template_app_list_grid_angular_firstDataRendered_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2); return ctx_r15.onFirstDataRendered($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("listsData", ctx_r14.listsData)("height", ctx_r14.heightGrid)("getContextMenuItems", ctx_r14.getContextMenuItems)("columnDefs", ctx_r14.columnDefs);
} }
function ImportPhepBuComponent_div_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 17, 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, ImportPhepBuComponent_div_13_app_list_grid_angular_2_Template, 1, 4, "app-list-grid-angular", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r4.columnDefs.length > 0 && ctx_r4.heightGrid > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" T\u1ED5ng s\u1ED1 ", ctx_r4.listsData.length, " ");
} }
class ImportPhepBuComponent {
    constructor(spinner, apiService, changeDetector, router, messageService) {
        this.spinner = spinner;
        this.apiService = apiService;
        this.changeDetector = changeDetector;
        this.router = router;
        this.messageService = messageService;
        this.items = [];
        this.isFullScreen = false;
        this.heightGrid = 0;
        this.isShowUpload = true;
        this.listsData = [];
        this.columnDefs = [];
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Phép bù', routerLink: '/chinh-sach/phep-bu' },
        ];
    }
    toggleGrid() {
        this.isFullScreen = !this.isFullScreen;
        if (this.isFullScreen) {
            this.heightGrid = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.ShowFullScreen)();
        }
        else {
            this.heightGrid = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.HideFullScreen)();
        }
    }
    onSelectFile(event) {
        if (event.currentFiles.length > 0) {
            this.spinner.show();
            this.isShowUpload = false;
            let fomrData = new FormData();
            fomrData.append('formFile', event.currentFiles[0]);
            this.apiService.annualleaveImport(fomrData)
                .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.takeUntil)(this.unsubscribe$))
                .subscribe(results => {
                if (results.status === 'success') {
                    if (results.data && results.data.dataList && results.data.dataList.data) {
                        this.cols = results.data.gridflexs;
                        this.initGrid();
                        const a = document.querySelector(".header");
                        const b = document.querySelector(".sidebarBody");
                        const c = document.querySelector(".bread-filter");
                        // const d: any = document.querySelector(".filterInput");
                        const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + 80;
                        this.heightGrid = window.innerHeight - totalHeight;
                        this.changeDetector.detectChanges();
                        // this.onInitAgGrid();
                        this.listsData = results.data.dataList.data;
                    }
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                    this.spinner.hide();
                }
                else {
                    this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    this.spinner.hide();
                }
            });
        }
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_0__.AgGridFn)(this.cols.filter((d) => !d.isHide))
        ];
    }
    back() {
        const main = document.querySelector(".main");
        main.className = 'main';
        this.router.navigate(['/chinh-sach/phep-bu']);
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    getContextMenuItems(params) {
        var result = [
            'copy',
            'paste',
            'separator',
            'excelExport'
        ];
        return result;
    }
    refetchFile() {
        this.isShowUpload = true;
        this.listsData = [];
        this.columnDefs = [];
    }
    getTemfileImport() {
        this.apiService.exportReportLocalhost('assets/tpl-import-file/file_mau_import_phep_bu.xlsx').subscribe((data) => {
            this.createImageFromBlob(data);
        });
    }
    createImageFromBlob(image) {
        var blob = new Blob([image]);
        var url = window.URL.createObjectURL(blob);
        var anchor = document.createElement("a");
        anchor.download = "file_mau_import_phep_bu.xlsx";
        anchor.href = url;
        anchor.click();
    }
    onFirstDataRendered(params) {
        params.api.sizeColumnsToFit();
    }
}
ImportPhepBuComponent.ɵfac = function ImportPhepBuComponent_Factory(t) { return new (t || ImportPhepBuComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_7__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService)); };
ImportPhepBuComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: ImportPhepBuComponent, selectors: [["app-import-phep-bu"]], decls: 14, vars: 7, consts: [[1, "main-grid"], [1, "bread-crumb"], [3, "items"], [1, "bread-filter"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "col-item"], [1, "d-flex", "align-items-center", "gap-16"], ["type", "button", "icon", "pi pi-th-large", "tooltipPosition", "top", 1, "p-button-sm", 3, "pTooltip", "click"], ["styleClass", "p-button-sm", "icon", "pi pi-download", "label", "T\u1EA3i file m\u1EABu", 3, "click", 4, "ngIf"], ["mode", "basic", "name", "demo[]", "chooseLabel", "T\u1EA1o m\u1EDBi import", "accept", ".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel", 3, "showCancelButton", "onSelect", 4, "ngIf"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "Quay l\u1EA1i", 3, "click", 4, "ngIf"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "l\u00E0m m\u1EDBi", 3, "click", 4, "ngIf"], ["class", "grid-default", 4, "ngIf"], ["styleClass", "p-button-sm", "icon", "pi pi-download", "label", "T\u1EA3i file m\u1EABu", 3, "click"], ["mode", "basic", "name", "demo[]", "chooseLabel", "T\u1EA1o m\u1EDBi import", "accept", ".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel", 3, "showCancelButton", "onSelect"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "Quay l\u1EA1i", 3, "click"], ["styleClass", "p-button-sm p-button-secondary", "icon", "pi pi-times", "label", "l\u00E0m m\u1EDBi", 3, "click"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "getContextMenuItems", "columnDefs", "firstDataRendered", 4, "ngIf"], [1, "paginator", 2, "margin-top", "10px", "text-align", "right", "margin-right", "25px", "font-weight", "600"], [3, "listsData", "height", "getContextMenuItems", "columnDefs", "firstDataRendered"]], template: function ImportPhepBuComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "app-hrm-breadcrumb", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "section", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "p-button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ImportPhepBuComponent_Template_p_button_click_7_listener() { return ctx.toggleGrid(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, ImportPhepBuComponent_p_button_8_Template, 1, 0, "p-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, ImportPhepBuComponent_p_fileUpload_9_Template, 1, 1, "p-fileUpload", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, ImportPhepBuComponent_p_button_10_Template, 1, 0, "p-button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, ImportPhepBuComponent_p_button_11_Template, 1, 0, "p-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, ImportPhepBuComponent_div_13_Template, 5, 2, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("pTooltip", ctx.isFullScreen ? "\u1EA8n to\u00E0n m\u00E0n h\u00ECnh" : "Hi\u1EC3n th\u1ECB to\u00E0n m\u00E0n h\u00ECnh");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.isShowUpload);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_2__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_10__.Button, primeng_tooltip__WEBPACK_IMPORTED_MODULE_11__.Tooltip, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, primeng_fileupload__WEBPACK_IMPORTED_MODULE_13__.FileUpload, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_3__.ListGridAngularComponent], styles: ["[_nghost-%COMP%]  .bg-red {\n  background: red;\n  color: #fff;\n  padding: 4px;\n  overflow: auto;\n  display: block;\n}\n[_nghost-%COMP%]  p-fileupload .p-messages {\n  position: fixed;\n  top: auto;\n  margin-top: 30px;\n  left: 50%;\n  transform: translateX(-50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImltcG9ydC1waGVwLWJ1LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7QUFBUjtBQUlRO0VBQ0ksZUFBQTtFQUNBLFNBQUE7RUFDQSxnQkFBQTtFQUNBLFNBQUE7RUFDQSwyQkFBQTtBQUZaIiwiZmlsZSI6ImltcG9ydC1waGVwLWJ1LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Q6Om5nLWRlZXB7XHJcbiAgICAuYmctcmVke1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHJlZDtcclxuICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICBwYWRkaW5nOiA0cHg7XHJcbiAgICAgICAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB9XHJcblxyXG4gICAgcC1maWxldXBsb2Fke1xyXG4gICAgICAgIC5wLW1lc3NhZ2Vze1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICAgICAgICAgIHRvcDogYXV0bztcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMzBweDtcclxuICAgICAgICAgICAgbGVmdDogNTAlO1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */"] });


/***/ }),

/***/ 28128:
/*!*********************************************************!*\
  !*** ./src/app/components/phep-bu/phep-bu.component.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhepBuComponent": () => (/* binding */ PhepBuComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);































function PhepBuComponent_ng_template_21_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](8, "Th\u00E1ng");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "input", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function PhepBuComponent_ng_template_21_Template_input_change_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r9.changeMonth($event); })("ngModelChange", function PhepBuComponent_ng_template_21_Template_input_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r10); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r11.query.month = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](11, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](13, "N\u0103m");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](14, "input", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function PhepBuComponent_ng_template_21_Template_input_ngModelChange_14_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r10); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r12.query.year = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](16, "label", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](17, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](18, "span", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "p-button", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PhepBuComponent_ng_template_21_Template_p_button_click_19_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r10); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r13.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](20, "p-button", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PhepBuComponent_ng_template_21_Template_p_button_click_20_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r10); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](); return ctx_r14.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx_r1.query.month);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx_r1.query.year);
} }
function PhepBuComponent_app_list_grid_angular_41_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-list-grid-angular", 70);
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("listsData", ctx_r3.listsData)("height", ctx_r3.heightGrid)("columnDefs", ctx_r3.columnDefs);
} }
function PhepBuComponent_ng_template_55_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "span", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](item_r15.label);
} }
function PhepBuComponent_ng_template_56_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](car_r16.label);
} }
function PhepBuComponent_ng_template_72_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](item_r17.label);
} }
function PhepBuComponent_ng_template_73_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r18 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](car_r18.label);
} }
function PhepBuComponent_app_config_grid_table_form_77_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-config-grid-table-form", 74);
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r8.gridKey);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { width: "700px" }; };
const _c2 = function () { return { showAll: "ALL" }; };
const _c3 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c4 = function () { return { width: "800px", height: "auto" }; };
const _c5 = function () { return { maxHeight: "300px" }; };
const _c6 = function () { return { width: "50vw" }; };
const MAX_SIZE = 100000000;
class PhepBuComponent {
    constructor(apiService, route, confirmationService, messageService, spinner, changeDetector, organizeInfoService, router) {
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS;
        this.listsData = [];
        this.items = [];
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn;
        this.columnDefs = [];
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            year: moment__WEBPACK_IMPORTED_MODULE_6__().year(),
            month: moment__WEBPACK_IMPORTED_MODULE_6__().month() + 1,
            organizeId: '',
            organizeIds: '',
        };
        this.totalRecord = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.loading = false;
        this.loadjs = 0;
        this.heightGrid = 0;
        this.isShowAddPhepBuDep = false;
        this.querAddNewPhepBuDep = {
            orgId: '',
            annualAdd: '',
            annualMonth: ''
        };
        this.annulOptions = [];
        this.departments = [];
        this.organizeIdForDep = '';
        this.months = [];
        this.displaySetting = false;
        this.gridKey = '';
        this.organizeId = '';
        this.orgRoots = [];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_2__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__.AvatarFullComponent,
        };
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cancel() {
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            year: moment__WEBPACK_IMPORTED_MODULE_6__().year(),
            month: moment__WEBPACK_IMPORTED_MODULE_6__().month(),
            organizeId: this.query.organizeIds,
            organizeIds: this.query.organizeIds
        };
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(this.query);
        this.apiService.getAnnualAddPage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.XemChiTiet.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetAnnualAddPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.VIEW)
                },
                {
                    onClick: this.delRecord.bind(this),
                    label: 'Xóa',
                    icon: 'pi pi-trash',
                    class: 'btn-primary mr5',
                    hide: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.MENUACTIONROLEAPI.GetAnnualAddPage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_7__.ACTIONS.DELETE)
                },
            ]
        };
    }
    XemChiTiet(event) {
        const params = {
            annualId: event.rowData.annualId
        };
        this.router.navigate(['/chinh-sach/phep-bu/chi-tiet-phep-bu'], { queryParams: params });
    }
    delRecord(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa phép bù?',
            accept: () => {
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ annualId: event.rowData.annualId });
                this.apiService.delAnnualAddInfo(queryParams).subscribe(results => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa phép bù thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows === 4 ? 100000000 : event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.organizeIdForDep = results;
                this.getDepartments(this.query.organizeIds);
                this.load();
            }
        });
        let currentDay = new Date().getDate();
        if (currentDay >= 25 && currentDay <= 31) {
            this.query.month = this.query.month + 1;
        }
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Phép bù' },
        ];
        this.getOrgRoots();
        this.months = [
            { label: 'Tháng 1', value: 1 },
            { label: 'Tháng 2', value: 2 },
            { label: 'Tháng 3', value: 3 },
            { label: 'Tháng 4', value: 4 },
            { label: 'Tháng 5', value: 5 },
            { label: 'Tháng 6', value: 6 },
            { label: 'Tháng 7', value: 7 },
            { label: 'Tháng 8', value: 8 },
            { label: 'Tháng 9', value: 9 },
            { label: 'Tháng 10', value: 10 },
            { label: 'Tháng 11', value: 11 },
            { label: 'Tháng 12', value: 12 },
        ];
    }
    getOrgRoots() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.orgRoots = results.data.map(d => {
                    return {
                        label: d.organizationName + '-' + d.organizationCd,
                        value: `${d.organizeId}`
                    };
                });
                this.orgRoots = [{ label: 'Tất cả', value: null }, ...this.orgRoots];
            }
        });
    }
    addNewPhepBu() {
        const params = {
            annualId: ""
        };
        this.router.navigate(['/chinh-sach/phep-bu/them-moi-phep-bu'], { queryParams: params });
    }
    addNewPhepBuDep() {
        this.isShowAddPhepBuDep = true;
    }
    // thêm mới Phép bù phòng ban
    setPhepBuDep() {
        let params = Object.assign({}, this.querAddNewPhepBuDep);
        params.orgId = params.orgId.orgId;
        this.apiService.setAnnualAddOrgInfo(params).subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: 'Thêm mới thành công' });
                this.isShowAddPhepBuDep = false;
            }
            else {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
            }
        });
    }
    chonToChuc() {
        // this.querAddNewPhepBuDep.orgId = '';
        // if (this.organizeIdForDep) {
        //   this.getDepartments(this.organizeIdForDep);
        // }
    }
    getDepartments(parentId) {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ parentId: parentId });
        this.apiService.getOrganizeTree(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.departments = results.data;
            }
        });
    }
    changeMonth(event) {
        if (this.query.month > 12) {
            this.query.month = 12;
        }
        else if (this.query.month < 1) {
            this.query.month = 1;
        }
    }
    importFileExel() {
        this.router.navigate(['/chinh-sach/phep-bu/import']);
    }
}
PhepBuComponent.ɵfac = function PhepBuComponent_Factory(t) { return new (t || PhepBuComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_16__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_8__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.Router)); };
PhepBuComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({ type: PhepBuComponent, selectors: [["app-phep-bu"]], decls: 78, vars: 66, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [3, "items"], [1, "d-flex", "gap-16"], ["styleClass", "p-button-sm height-56", "label", "Import", "icon", "pi pi-file-excel", 3, "CheckHideActions", "click"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "20", "height", "17", "viewBox", "0 0 20 17", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M19.5 17V0H0.50855L0.5 17H19.5ZM6.675 15.3187H2.21V6.81868H6.675V15.3187ZM8.575 15.3187V6.81868H17.79V15.3187H8.575ZM2.21 1.68132V5.13736H17.79V1.68132H2.21Z", "fill", "#F3F8FF"], [1, "bread-filter"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "col-item"], [1, "filter", "filter-search"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [1, "d-flex", "align-items-center", "gap-16"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm mr-1 height-56", 3, "CheckHideActions", "click"], ["d", "M11 5H9V9H5V11H9V15H11V11H15V9H11V5ZM10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM10 18C5.59 18 2 14.41 2 10C2 5.59 5.59 2 10 2C14.41 2 18 5.59 18 10C18 14.41 14.41 18 10 18Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm mr-1 height-56", "icon", "pi pi-plus", "label", "Th\u00EAm m\u1EDBi ph\u00E9p b\u00F9 ph\u00F2ng ban", 3, "CheckHideActions", "click"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], [3, "visible", "draggable", "resizable", "autoZIndex", "modal", "visibleChange"], [1, "grid"], [1, "col-6"], [1, "field-group", "select", "mb-0", "valid"], ["for", ""], ["panelStyleClass", "mh-300", "placeholder", "Ch\u1ECDn t\u1ED5 ch\u1EE9c", "appendTo", "body", "name", "organizeIdForDep", 3, "disabled", "baseZIndex", "autoDisplayFirst", "options", "required", "ngModel", "ngModelChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "col-6", "mb-0"], [1, "field-group", "select", "treeselect", "label-8"], ["placeholder", "Ch\u1ECDn Ph\u00F2ng ban", "appendTo", "body", "selectionMode", "single", "placeholder", "Select Item", 3, "filterInputAutoFocus", "filter", "metaKeySelection", "ngModel", "options", "ngModelChange"], [1, "col-6", "pt-0"], [1, "field-group", "label-8"], ["min", "1", "type", "number", "placeholder", "Nh\u1EADp s\u1ED1 ph\u00E9p \u0111\u01B0\u1EE3c b\u00F9", "name", "annualAdd", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "field-group", "select", "label-8"], ["placeholder", "Nh\u1EADp s\u1ED1 ph\u00E9p \u0111\u01B0\u1EE3c b\u00F9", "appendTo", "body", "name", "annualMonth", 3, "baseZIndex", "autoDisplayFirst", "options", "required", "ngModel", "filter", "ngModelChange"], [1, "col-12", "text-right"], ["styleClass", "p-button-sm mr-1 h-56", "icon", "pi pi-plus", "label", "Th\u00EAm", 3, "click"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "field-group", "text", "label-8"], ["type", "number", "id", "", "placeholder", "Th\u00E1ng", 1, "input-default", 3, "ngModel", "change", "ngModelChange"], ["type", "number", "id", "", "placeholder", "N\u0103m", 1, "input-default", 3, "ngModel", "ngModelChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [3, "listsData", "height", "columnDefs"], [2, "vertical-align", "middle"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [2, "font-size", "14px", "float", "right", "margin-top", "4px"], [3, "typeConfig", "gridKey"]], template: function PhepBuComponent_Template(rf, ctx) { if (rf & 1) {
        const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PhepBuComponent_Template_p_button_click_5_listener() { return ctx.importFileExel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "p-button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PhepBuComponent_Template_p_button_click_6_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "svg", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](8, "path", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](9, " \u00A0 C\u1EA5u h\u00ECnh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "section", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](11, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](14, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("keydown.enter", function PhepBuComponent_Template_input_keydown_enter_15_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function PhepBuComponent_Template_input_ngModelChange_15_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](16, "span", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PhepBuComponent_Template_span_click_16_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](18, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "p-overlayPanel", 18, 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](21, PhepBuComponent_ng_template_21_Template, 21, 2, "ng-template", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](22, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](23, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](24, "p-button", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PhepBuComponent_Template_p_button_click_24_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](25, "svg", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](26, "path", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](27, "p-button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PhepBuComponent_Template_p_button_click_27_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r19); const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](20); return _r0.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](28, "svg", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](29, "path", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](30, "path", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](31, "path", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](32, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](33, "p-button", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PhepBuComponent_Template_p_button_click_33_listener() { return ctx.addNewPhepBu(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](34, "svg", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](35, "path", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](36, " \u00A0 Th\u00EAm m\u1EDBi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](37, "p-button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PhepBuComponent_Template_p_button_click_37_listener() { return ctx.addNewPhepBuDep(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](38, "section", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](39, "div", 34, 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](41, PhepBuComponent_app_list_grid_angular_41_Template, 1, 3, "app-list-grid-angular", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](42, "div", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](43, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](44);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](45, "p-paginator", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("onPageChange", function PhepBuComponent_Template_p_paginator_onPageChange_45_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](46, "p-dialog", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("visibleChange", function PhepBuComponent_Template_p_dialog_visibleChange_46_listener($event) { return ctx.isShowAddPhepBuDep = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](47, "p-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](48, " Th\u00EAm m\u1EDBi Ph\u00E9p b\u00F9 ph\u00F2ng ban ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](49, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](50, "div", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](51, "div", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](52, "label", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](53, " T\u1ED5 ch\u1EE9c: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](54, "p-dropdown", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function PhepBuComponent_Template_p_dropdown_ngModelChange_54_listener($event) { return ctx.organizeIdForDep = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](55, PhepBuComponent_ng_template_55_Template, 2, 1, "ng-template", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](56, PhepBuComponent_ng_template_56_Template, 3, 1, "ng-template", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](57, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](58, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](59, "label", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](60, "Ph\u00F2ng ban");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](61, "p-treeSelect", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function PhepBuComponent_Template_p_treeSelect_ngModelChange_61_listener($event) { return ctx.querAddNewPhepBuDep.orgId = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](62, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](63, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](64, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](65, "S\u1ED1 ph\u00E9p \u0111\u01B0\u1EE3c b\u00F9");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](66, "input", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function PhepBuComponent_Template_input_ngModelChange_66_listener($event) { return ctx.querAddNewPhepBuDep.annualAdd = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](67, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](68, "div", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](69, "label", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](70, "Th\u00E1ng th\u00EAm ph\u00E9p b\u00F9");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](71, "p-dropdown", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function PhepBuComponent_Template_p_dropdown_ngModelChange_71_listener($event) { return ctx.querAddNewPhepBuDep.annualMonth = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](72, PhepBuComponent_ng_template_72_Template, 2, 1, "ng-template", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](73, PhepBuComponent_ng_template_73_Template, 3, 1, "ng-template", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](74, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](75, "p-button", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PhepBuComponent_Template_p_button_click_75_listener() { return ctx.setPhepBuDep(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](76, "p-dialog", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("visibleChange", function PhepBuComponent_Template_p_dialog_visibleChange_76_listener($event) { return ctx.displaySetting = $event; })("onHide", function PhepBuComponent_Template_p_dialog_onHide_76_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](77, PhepBuComponent_app_config_grid_table_form_77_Template, 1, 2, "app-config-grid-table-form", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](50, _c0, ctx.MENUACTIONROLEAPI.GetAnnualAddPage.url, ctx.ACTIONS.IMPORT));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](53, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](54, _c0, ctx.MENUACTIONROLEAPI.GetAnnualAddPage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](57, _c0, ctx.MENUACTIONROLEAPI.GetAnnualAddPage.url, ctx.ACTIONS.ADD_PHEP_BU_PHONG_BAN));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](61, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](60, _c2)));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](63, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("visible", ctx.isShowAddPhepBuDep)("draggable", false)("resizable", false)("autoZIndex", true)("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](64, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("disabled", true)("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.orgRoots)("ngModel", ctx.organizeIdForDep);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("filterInputAutoFocus", true)("filter", true)("metaKeySelection", false)("ngModel", ctx.querAddNewPhepBuDep.orgId)("options", ctx.departments);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.querAddNewPhepBuDep.annualAdd);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.months)("ngModel", ctx.querAddNewPhepBuDep.annualMonth)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](65, _c6));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_17__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_10__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgModel, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_20__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_15__.PrimeTemplate, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_21__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_22__.Dialog, primeng_api__WEBPACK_IMPORTED_MODULE_15__.Header, primeng_dropdown__WEBPACK_IMPORTED_MODULE_23__.Dropdown, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.RequiredValidator, primeng_treeselect__WEBPACK_IMPORTED_MODULE_24__.TreeSelect, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.MinValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NumberValueAccessor, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__.ConfigGridTableFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwaGVwLWJ1LmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 87215:
/*!***********************************************************!*\
  !*** ./src/app/components/phep-nam/phep-nam.component.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhepNamComponent": () => (/* binding */ PhepNamComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/ag-component/customtooltip.component */ 73964);
/* harmony import */ var src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/ag-component/button-renderermutibuttons.component */ 23609);
/* harmony import */ var src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/ag-component/avatarFull.component */ 68909);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! file-saver */ 68178);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/common/form-filter/form-filter.component */ 83844);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/dynamicdialog */ 56427);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/dropdown */ 45596);




































function PhepNamComponent_app_list_grid_angular_26_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "app-list-grid-angular", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("showConfig", function PhepNamComponent_app_list_grid_angular_26_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](); return ctx_r6.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("listsData", ctx_r1.listsData)("height", ctx_r1.heightGrid)("columnDefs", ctx_r1.columnDefs);
} }
function PhepNamComponent_app_config_grid_table_form_32_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](0, "app-config-grid-table-form", 41);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r2.gridKey);
} }
function PhepNamComponent_div_56_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "label", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](3, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](4, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
} if (rf & 2) {
    const info_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](info_r9.month);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](info_r9.numLeave);
} }
function PhepNamComponent_div_56_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](1, PhepNamComponent_div_56_div_1_Template, 6, 2, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", ctx_r3.dataInfo.lstMonth);
} }
function PhepNamComponent_ng_template_59_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](3, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](4, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](5, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](6, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](8, "C\u00F4ng ty tr\u1EA3 l\u01B0\u01A1ng");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](9, "p-dropdown", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ngModelChange", function PhepNamComponent_ng_template_59_Template_p_dropdown_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r11); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](); return ctx_r10.query.companyIds = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](10, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](11, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](12, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](13, "Th\u00E1ng");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](14, "p-dropdown", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ngModelChange", function PhepNamComponent_ng_template_59_Template_p_dropdown_ngModelChange_14_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r11); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](); return ctx_r12.query.month = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](15, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](16, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](17, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](18, "N\u0103m");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](19, "p-dropdown", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ngModelChange", function PhepNamComponent_ng_template_59_Template_p_dropdown_ngModelChange_19_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r11); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](); return ctx_r13.query.year = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](20, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](21, "label", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](22, "Classid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](23, "span", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](24, "p-button", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function PhepNamComponent_ng_template_59_Template_p_button_click_24_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r11); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](); return ctx_r14.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](25, "p-button", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function PhepNamComponent_ng_template_59_Template_p_button_click_25_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r11); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](); return ctx_r15.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("baseZIndex", 100)("options", ctx_r5.companies)("ngModel", ctx_r5.query.companyIds)("filter", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("baseZIndex", 100)("options", ctx_r5.months)("ngModel", ctx_r5.query.month)("filter", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("baseZIndex", 100)("options", ctx_r5.years)("ngModel", ctx_r5.query.year)("filter", true);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { showAll: "ALL" }; };
const _c2 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c3 = function () { return { width: "50vw" }; };
const _c4 = function () { return { width: "800px" }; };
const _c5 = function () { return { width: "700px" }; };
const MAX_SIZE = 100000000;
class PhepNamComponent {
    constructor(apiService, route, confirmationService, messageService, spinner, changeDetector, organizeInfoService, fileService, dialogService, router) {
        this.apiService = apiService;
        this.route = route;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.spinner = spinner;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.fileService = fileService;
        this.dialogService = dialogService;
        this.router = router;
        this.listsData = [];
        this.items = [];
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS;
        this.agGridFn = src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn;
        this.columnDefs = [];
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            year: new Date().getFullYear(),
            month: new Date().getMonth() + 1,
            organizeId: '',
            organizeIds: '',
            companyIds: [],
        };
        this.totalRecord = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.loading = false;
        this.loadjs = 0;
        this.heightGrid = 0;
        this.companies = [];
        this.months = [];
        this.years = [];
        this.displaySetting = false;
        this.gridKey = '';
        this.dataInfo = [];
        this.isShowInfo = false;
        this.organizeId = '';
        this.orgRoots = [];
        this.listViewsFilter = [];
        this.detailInfoFilter = null;
        this.optionsButonFilter = [
            { label: 'Tìm kiếm', value: 'Search', class: 'p-button-sm height-56 addNew', icon: 'pi pi-search' },
            { label: 'Làm mới', value: 'Reset', class: 'p-button-sm p-button-danger height-56 addNew', icon: 'pi pi-times' },
        ];
        this.defaultColDef = {
            tooltipComponent: 'customTooltip',
            resizable: true,
            filter: '',
            cellClass: ['border-right'],
        };
        this.frameworkComponents = {
            customTooltip: src_app_common_ag_component_customtooltip_component__WEBPACK_IMPORTED_MODULE_1__.CustomTooltipComponent,
            buttonAgGridComponent: src_app_common_ag_component_button_renderermutibuttons_component__WEBPACK_IMPORTED_MODULE_2__.ButtonAgGridComponent,
            avatarRendererFull: src_app_common_ag_component_avatarFull_component__WEBPACK_IMPORTED_MODULE_3__.AvatarFullComponent,
        };
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    cancel() {
        this.query = {
            filter: '',
            offSet: 0,
            pageSize: 15,
            year: new Date().getFullYear(),
            month: new Date().getMonth() + 1,
            organizeId: '',
            organizeIds: this.query.organizeIds,
            companyIds: this.query.companyIds,
        };
        if (this.companies.length > 0) {
            this.query.companyIds = this.companies[0].value;
        }
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const params = Object.assign({}, this.query);
        let companyIds = this.query.companyIds.toString();
        params.companyIds = companyIds;
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
        this.apiService.getAnnualLeavePage(queryParams).subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.XemChiTiet.bind(this),
                    label: 'Xem chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                },
            ]
        };
    }
    XemChiTiet(event) {
        this.spinner.show();
        this.isShowInfo = true;
        const query = {
            empId: event.rowData.empId,
            year: this.query.year,
            month: this.query.month,
        };
        this.apiService.getLeaveRequestMonthInfo(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query)).subscribe((results) => {
            if (results.status === "success") {
                this.spinner.hide();
                this.dataInfo = results.data;
            }
        }),
            error => { };
    }
    initGrid() {
        this.columnDefs = [
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_4__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                width: 100,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                checkboxSelection: false,
                field: 'checkbox'
            }
        ];
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows === 4 ? 100000000 : event.rows;
        this.load();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.query.organizeId = results;
                this.getCompany();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Chính sách' },
            { label: 'Phép năm' },
        ];
        this.getOrgRoots();
        let currentDay = new Date().getDate();
        if (currentDay >= 25 && currentDay <= 31) {
            this.query.month = this.query.month + 1;
        }
        this.getMonthYear();
        this.getFilter();
    }
    goToPhepBu() {
        this.router.navigate(['/chinh-sach/phep-bu']);
    }
    getOrgRoots() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.orgRoots = results.data.map(d => {
                    return {
                        label: d.organizationName + '-' + d.organizationCd,
                        value: `${d.organizeId}`
                    };
                });
                this.orgRoots = [{ label: 'Tất cả', value: null }, ...this.orgRoots];
            }
        });
    }
    getCompany() {
        const query = { organizeIds: this.query.organizeIds };
        this.apiService.getUserCompanies(querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query)).subscribe((results) => {
            if (results.status === "success") {
                this.companies = results.data
                    .map(d => {
                    return {
                        label: d.name,
                        value: d.value
                    };
                });
                if (this.companies.length > 0) {
                    this.query.companyIds = this.companies[0].value;
                }
                this.load();
            }
        }),
            error => { };
    }
    exportData() {
        this.spinner.show();
        this.query.pageSize = 1000000;
        const query = Object.assign({}, this.query);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(query);
        this.apiService.exportAnnualleave(queryParams).subscribe(results => {
            if (results.type === 'application/json') {
                this.spinner.hide();
            }
            else {
                var blob = new Blob([results], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                file_saver__WEBPACK_IMPORTED_MODULE_9__.saveAs(blob, `Danh sách phép năm` + ".xlsx");
                this.spinner.hide();
            }
        });
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    changeMonth(event) {
        if (this.query.month > 12) {
            this.query.month = 12;
        }
        else if (this.query.month < 1) {
            this.query.month = 1;
        }
    }
    getMonthYear() {
        this.months = [
            { label: 'Tháng 1', value: 1 },
            { label: 'Tháng 2', value: 2 },
            { label: 'Tháng 3', value: 3 },
            { label: 'Tháng 4', value: 4 },
            { label: 'Tháng 5', value: 5 },
            { label: 'Tháng 6', value: 6 },
            { label: 'Tháng 7', value: 7 },
            { label: 'Tháng 8', value: 8 },
            { label: 'Tháng 9', value: 9 },
            { label: 'Tháng 10', value: 10 },
            { label: 'Tháng 11', value: 11 },
            { label: 'Tháng 12', value: 12 },
        ];
        let minYear = 2000;
        let maxYear = 2040;
        for (let i = minYear; i <= maxYear; i++) {
            this.years.push({ label: 'Năm ' + i, value: i });
        }
    }
    //filter 
    getFilter() {
        this.apiService.getFilter('/api/v2/annualleave/GetAnnualLeaveFilter').subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_10__.cloneDeep)(results.data.group_fields);
                this.listViewsFilter = [...listViews];
                this.detailInfoFilter = results.data;
            }
        });
    }
    showFilter() {
        const ref = this.dialogService.open(src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_11__.FormFilterComponent, {
            header: 'Tìm kiếm nâng cao',
            width: '40%',
            contentStyle: "",
            data: {
                listViews: this.listViewsFilter,
                detailInfoFilter: this.detailInfoFilter,
                buttons: this.optionsButonFilter
            }
        });
        ref.onClose.subscribe((event) => {
            if (event) {
                this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_10__.cloneDeep)(event.listViewsFilter);
                if (event.type === 'Search') {
                    this.query = Object.assign(Object.assign({}, this.query), event.data);
                    this.load();
                }
                else if (event.type === 'CauHinh') {
                    this.apiService.getEmpFilter().subscribe(results => {
                        if (results.status === 'success') {
                            const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_10__.cloneDeep)(results.data.group_fields);
                            this.listViewsFilter = [...listViews];
                            this.detailInfoFilter = results.data;
                            this.showFilter();
                        }
                    });
                }
                else if (event.type === 'Reset') {
                    const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_10__.cloneDeep)(this.detailInfoFilter.group_fields);
                    this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_10__.cloneDeep)(listViews);
                    this.cancel();
                }
            }
        });
    }
}
PhepNamComponent.ɵfac = function PhepNamComponent_Factory(t) { return new (t || PhepNamComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_5__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_17__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_18__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_18__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_19__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_16__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_8__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_20__.DialogService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_17__.Router)); };
PhepNamComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineComponent"]({ type: PhepNamComponent, selectors: [["app-phep-nam"]], decls: 60, vars: 46, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [1, "col-3", "pd-0"], [3, "items"], [1, "d-flex", "end", "mid", "bottom", "gap-12", "col-9", "pd-0"], [1, "filter", "filter-search", "col-3", "pd-0"], [1, "field-group", "text", "search", "mb-0", 3, "ngClass"], ["placeholder", "T\u00ECm ki\u1EBFm", "type", "text", "autocomplete", "off", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["_ngcontent-shh-c197", "", "width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["_ngcontent-shh-c197", "", "fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn height-56", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", "icon", "pi pi-check", "label", "Ph\u00E9p b\u00F9", 3, "CheckHideActions", "click"], ["styleClass", "p-button-sm height-56", "icon", "pi pi-file-excel", "label", "Export", 3, "CheckHideActions", "click"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["header", "Chi ti\u1EBFt l\u1ECBch s\u1EED d\u00F9ng ph\u00E9p c\u00E1c k\u1EF3", 3, "visible", "modal", "maximizable", "visibleChange"], [1, "label-value", "d-flex", "wrap", "mb-2"], [1, "col-6", "d-flex", "gap-16"], [2, "color", "rgb(116 116 116 / 87%)"], [1, "col-12"], [2, "color", "#a1a1a1"], ["class", "d-flex table-info gap-16 wrap", 4, "ngIf"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [3, "listsData", "height", "columnDefs", "showConfig"], [3, "typeConfig", "gridKey"], [1, "d-flex", "table-info", "gap-16", "wrap"], ["class", "label-value", 4, "ngFor", "ngForOf"], [1, "label-value"], [1, "mb-2"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select"], ["appendTo", "body", "name", "companyIds", 3, "baseZIndex", "options", "ngModel", "filter", "ngModelChange"], ["appendTo", "body", "name", "month", 3, "baseZIndex", "options", "ngModel", "filter", "ngModelChange"], ["appendTo", "body", "name", "year", 3, "baseZIndex", "options", "ngModel", "filter", "ngModelChange"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["for", "", 2, "visibility", "hidden"], [1, "pi", "pi-info-circle", 2, "font-size", "13px", "color", "orange"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"]], template: function PhepNamComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](4, "app-hrm-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](8, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("keydown.enter", function PhepNamComponent_Template_input_keydown_enter_8_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function PhepNamComponent_Template_input_ngModelChange_8_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function PhepNamComponent_Template_span_click_9_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](10, "svg", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](11, "path", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](12, "p-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function PhepNamComponent_Template_p_button_click_12_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](13, "svg", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](14, "path", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](15, "p-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function PhepNamComponent_Template_p_button_click_15_listener() { return ctx.showFilter(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](16, "svg", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](17, "path", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](18, "path", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](19, "path", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](20, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](21, "p-button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function PhepNamComponent_Template_p_button_click_21_listener() { return ctx.goToPhepBu(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](22, "p-button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function PhepNamComponent_Template_p_button_click_22_listener() { return ctx.exportData(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](23, "section", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](24, "div", 23, 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](26, PhepNamComponent_app_list_grid_angular_26_Template, 1, 3, "app-list-grid-angular", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](27, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](28, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](30, "p-paginator", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("onPageChange", function PhepNamComponent_Template_p_paginator_onPageChange_30_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](31, "p-dialog", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("visibleChange", function PhepNamComponent_Template_p_dialog_visibleChange_31_listener($event) { return ctx.displaySetting = $event; })("onHide", function PhepNamComponent_Template_p_dialog_onHide_31_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](32, PhepNamComponent_app_config_grid_table_form_32_Template, 1, 2, "app-config-grid-table-form", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](33, "p-dialog", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("visibleChange", function PhepNamComponent_Template_p_dialog_visibleChange_33_listener($event) { return ctx.isShowInfo = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](34, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](35, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](36, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](37, "b", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](38, "B\u1ED9 ph\u1EADn:");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](39, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](40);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](41, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](42, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](43, "b", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](44, "M\u00E3 NV:");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](45, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](46);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](47, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](48, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](49, "b", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](50, "Ch\u1EE9c danh:");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](51, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](52);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](53, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](54, "h2", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](55);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](56, PhepNamComponent_div_56_Template, 2, 1, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](57, "p-overlayPanel", 37, 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](59, PhepNamComponent_ng_template_59_Template, 26, 12, "ng-template", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngClass", ctx.query.filter ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction2"](34, _c0, ctx.MENUACTIONROLEAPI.GetAnnualLeavePage.url, ctx.ACTIONS.PHEP_BU));
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction2"](37, _c0, ctx.MENUACTIONROLEAPI.GetAnnualLeavePage.url, ctx.ACTIONS.EXPORT));
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction1"](41, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](40, _c1)));
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](43, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](44, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("visible", ctx.isShowInfo)("modal", true)("maximizable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.dataInfo == null ? null : ctx.dataInfo.orgName);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.dataInfo == null ? null : ctx.dataInfo.code);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.dataInfo == null ? null : ctx.dataInfo.orgName);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"]("Ph\u00E9p n\u0103m \u0111\u00E3 d\u00F9ng c\u1EE7a n\u0103m ", ctx.query.year, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", ctx.dataInfo && ctx.dataInfo.lstMonth);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](45, _c5));
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_12__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_21__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgModel, primeng_button__WEBPACK_IMPORTED_MODULE_23__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_13__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_21__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_24__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_25__.Dialog, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_26__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_18__.PrimeTemplate, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_14__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_15__.ConfigGridTableFormComponent, _angular_common__WEBPACK_IMPORTED_MODULE_21__.NgForOf, primeng_dropdown__WEBPACK_IMPORTED_MODULE_27__.Dropdown], styles: [".table-info[_ngcontent-%COMP%] {\n  text-align: center;\n}\n.table-info[_ngcontent-%COMP%]   .label-value[_ngcontent-%COMP%] {\n  padding: 5px 10px;\n  background: #34669b;\n  color: #fff;\n  border-radius: 3px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBoZXAtbmFtLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7QUFDSjtBQUFJO0VBQ0ksaUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQUVSIiwiZmlsZSI6InBoZXAtbmFtLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRhYmxlLWluZm97XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAubGFiZWwtdmFsdWV7XHJcbiAgICAgICAgcGFkZGluZzogNXB4IDEwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogIzM0NjY5YjtcclxuICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAzcHg7XHJcbiAgICB9XHJcbn0iXX0= */"] });


/***/ }),

/***/ 69389:
/*!**************************************************!*\
  !*** ./src/app/directive/check-action.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CheckHideActionsDirectiveModule": () => (/* binding */ CheckHideActionsDirectiveModule)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _check_action_directive__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./check-action.directive */ 32475);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);




class CheckHideActionsDirectiveModule {
}
CheckHideActionsDirectiveModule.ɵfac = function CheckHideActionsDirectiveModule_Factory(t) { return new (t || CheckHideActionsDirectiveModule)(); };
CheckHideActionsDirectiveModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: CheckHideActionsDirectiveModule });
CheckHideActionsDirectiveModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            // BrowserModule,
            // BrowserAnimationsModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](CheckHideActionsDirectiveModule, { declarations: [_check_action_directive__WEBPACK_IMPORTED_MODULE_0__.CheckHideActionsDirective], imports: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__.ReactiveFormsModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule], exports: [_check_action_directive__WEBPACK_IMPORTED_MODULE_0__.CheckHideActionsDirective] }); })();


/***/ }),

/***/ 6095:
/*!***************************************************************!*\
  !*** ./src/app/pages/chinh-sach/chinh-sach-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChinhSachRoutingModule": () => (/* binding */ ChinhSachRoutingModule)
/* harmony export */ });
/* harmony import */ var _components_bieu_mau_loai_bieu_mau_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../components/bieu-mau/loai-bieu-mau/loai-bieu-mau.component */ 72521);
/* harmony import */ var _components_bieu_mau_loai_bieu_mau_chi_tiet_loai_bieu_mau_chi_tiet_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../components/bieu-mau/loai-bieu-mau/chi-tiet-loai-bieu-mau/chi-tiet-loai-bieu-mau.component */ 5140);
/* harmony import */ var _components_bieu_mau_bieu_mau_chi_tiet_bieu_mau_chi_tiet_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/bieu-mau/bieu-mau-chi-tiet/bieu-mau-chi-tiet.component */ 74589);
/* harmony import */ var _components_bieu_mau_bieu_mau_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../components/bieu-mau/bieu-mau.component */ 4795);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var src_app_components_cs_nghi_phep_cs_nghi_phep_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/components/cs-nghi-phep/cs-nghi-phep.component */ 2369);
/* harmony import */ var src_app_components_cs_cham_cong_cs_cham_cong_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/components/cs-cham-cong/cs-cham-cong.component */ 59221);
/* harmony import */ var src_app_components_cs_an_ca_cs_an_ca_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/cs-an-ca/cs-an-ca.component */ 47936);
/* harmony import */ var src_app_components_cs_tien_luong_cs_tien_luong_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/cs-tien-luong/cs-tien-luong.component */ 19871);
/* harmony import */ var src_app_components_cs_thue_thu_nhap_cs_thue_thu_nhap_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/components/cs-thue-thu-nhap/cs-thue-thu-nhap.component */ 72602);
/* harmony import */ var src_app_components_cs_nghi_phep_chi_tiet_nghi_phep_chi_tiet_nghi_phep_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/components/cs-nghi-phep/chi-tiet-nghi-phep/chi-tiet-nghi-phep.component */ 29904);
/* harmony import */ var src_app_components_cs_an_ca_chi_tiet_an_ca_chi_tiet_an_ca_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/components/cs-an-ca/chi-tiet-an-ca/chi-tiet-an-ca.component */ 2329);
/* harmony import */ var src_app_components_cs_cham_cong_chi_tiet_cham_cong_chi_tiet_cham_cong_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/components/cs-cham-cong/chi-tiet-cham-cong/chi-tiet-cham-cong.component */ 13265);
/* harmony import */ var src_app_components_cs_tien_luong_chi_tiet_tien_luong_chi_tiet_tien_luong_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/components/cs-tien-luong/chi-tiet-tien-luong/chi-tiet-tien-luong.component */ 77589);
/* harmony import */ var src_app_components_cs_thue_thu_nhap_chi_tiet_thue_thu_nhap_chi_tiet_thue_thu_nhap_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/components/cs-thue-thu-nhap/chi-tiet-thue-thu-nhap/chi-tiet-thue-thu-nhap.component */ 29095);
/* harmony import */ var src_app_components_phep_nam_phep_nam_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/components/phep-nam/phep-nam.component */ 87215);
/* harmony import */ var src_app_components_phep_bu_phep_bu_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/components/phep-bu/phep-bu.component */ 28128);
/* harmony import */ var src_app_components_phep_bu_chi_tiet_phep_bu_chi_tiet_phep_bu_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/components/phep-bu/chi-tiet-phep-bu/chi-tiet-phep-bu.component */ 52865);
/* harmony import */ var src_app_components_cs_cham_cong_xem_cong_xem_cong_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/components/cs-cham-cong/xem-cong/xem-cong.component */ 22832);
/* harmony import */ var src_app_components_cs_an_ca_eating_list_eating_list_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/components/cs-an-ca/eating-list/eating-list.component */ 82901);
/* harmony import */ var src_app_components_phep_bu_import_phep_bu_import_phep_bu_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/components/phep-bu/import-phep-bu/import-phep-bu.component */ 54278);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 14001);























const routes = [
    {
        path: "",
        redirectTo: "cham-cong",
        pathMatch: 'full'
    },
    // Phép năm
    {
        path: 'phep-nam',
        component: src_app_components_phep_nam_phep_nam_component__WEBPACK_IMPORTED_MODULE_14__.PhepNamComponent,
        data: {
            title: 'Phép năm',
            url: 'phep-nam',
        },
    },
    // phép bù
    {
        path: 'phep-bu',
        component: src_app_components_phep_bu_phep_bu_component__WEBPACK_IMPORTED_MODULE_15__.PhepBuComponent,
        data: {
            title: 'Phép bù',
            url: 'phep-bu',
        },
    },
    {
        path: 'phep-bu/import',
        component: src_app_components_phep_bu_import_phep_bu_import_phep_bu_component__WEBPACK_IMPORTED_MODULE_19__.ImportPhepBuComponent,
        data: {
            title: 'Import phép bù',
            url: 'import-phep-bu',
        },
    },
    {
        path: 'phep-bu/chi-tiet-phep-bu',
        component: src_app_components_phep_bu_chi_tiet_phep_bu_chi_tiet_phep_bu_component__WEBPACK_IMPORTED_MODULE_16__.ChiTietPhepBuComponent,
        data: {
            title: 'Chi tiết phép bù',
            url: 'chi-tiet-phep-bu',
        },
    },
    {
        path: 'phep-bu/them-moi-phep-bu',
        component: src_app_components_phep_bu_chi_tiet_phep_bu_chi_tiet_phep_bu_component__WEBPACK_IMPORTED_MODULE_16__.ChiTietPhepBuComponent,
        data: {
            title: 'Thêm mới phép bù',
            url: 'them-moi-phep-bu',
        },
    },
    //Chấm công
    {
        path: 'cham-cong',
        component: src_app_components_cs_cham_cong_cs_cham_cong_component__WEBPACK_IMPORTED_MODULE_5__.CsChamCongComponent,
        data: {
            title: 'Danh sách chấm công',
            url: 'cham-cong',
        },
    },
    {
        path: 'cham-cong/xem-cong',
        component: src_app_components_cs_cham_cong_xem_cong_xem_cong_component__WEBPACK_IMPORTED_MODULE_17__.XemCongComponent,
        data: {
            title: 'Xem công',
            url: 'cham-cong',
        },
    },
    {
        path: 'cham-cong/chi-tiet-cham-cong',
        component: src_app_components_cs_cham_cong_chi_tiet_cham_cong_chi_tiet_cham_cong_component__WEBPACK_IMPORTED_MODULE_11__.ChiTietChamCongComponent,
        data: {
            title: 'Chi tiết chấm công',
            url: 'chi-tiet-cham-cong',
        },
    },
    //nghỉ phép
    {
        path: 'giai-trinh-cong',
        component: src_app_components_cs_nghi_phep_cs_nghi_phep_component__WEBPACK_IMPORTED_MODULE_4__.CsNghiPhepComponent,
        data: {
            title: 'Giải trình công',
            url: 'giai-trinh-cong',
        },
    },
    {
        path: 'giai-trinh-cong/chi-tiet-giai-trinh-cong',
        component: src_app_components_cs_nghi_phep_chi_tiet_nghi_phep_chi_tiet_nghi_phep_component__WEBPACK_IMPORTED_MODULE_9__.ChiTietNghiPhepComponent,
        data: {
            title: 'Chi tiết nghỉ phép',
            url: 'giai-trinh-cong/chi-tiet-giai-trinh-cong',
        },
    },
    //tăng ca
    {
        path: 'an-ca',
        component: src_app_components_cs_an_ca_cs_an_ca_component__WEBPACK_IMPORTED_MODULE_6__.CsAnCaComponent,
        data: {
            title: 'Danh sách ăn ca',
            url: 'an-ca',
        },
    },
    {
        path: 'an-ca/chi-tiet-an-ca',
        component: src_app_components_cs_an_ca_chi_tiet_an_ca_chi_tiet_an_ca_component__WEBPACK_IMPORTED_MODULE_10__.ChiTietAnCaComponent,
        data: {
            title: 'Chi tiết ăn ca',
            url: 'chi-tiet-an-ca',
        },
    },
    {
        path: 'an-ca/chi-tiet-danh-sach-an-ca',
        component: src_app_components_cs_an_ca_eating_list_eating_list_component__WEBPACK_IMPORTED_MODULE_18__.EatingListComponent,
        data: {
            title: 'Chi tiết ăn ca',
            url: 'chi-tiet-danh-sach-an-ca',
        },
    },
    //Tiền lương
    {
        path: 'tien-luong',
        component: src_app_components_cs_tien_luong_cs_tien_luong_component__WEBPACK_IMPORTED_MODULE_7__.CsTienLuongComponent,
        data: {
            title: 'Danh sách tiền lương',
            url: 'tien-luong',
        },
    },
    {
        path: 'tien-luong/them-moi-tien-luong',
        component: src_app_components_cs_tien_luong_chi_tiet_tien_luong_chi_tiet_tien_luong_component__WEBPACK_IMPORTED_MODULE_12__.ChiTietTienLuongComponent,
        data: {
            title: 'Thêm mới tiền lương',
            url: 'them-moi-tien-luong',
        },
    },
    {
        path: 'tien-luong/chi-tiet-tien-luong',
        component: src_app_components_cs_tien_luong_chi_tiet_tien_luong_chi_tiet_tien_luong_component__WEBPACK_IMPORTED_MODULE_12__.ChiTietTienLuongComponent,
        data: {
            title: 'Chi tiết tiền lương',
            url: 'chi-tiet-tien-luong',
        },
    },
    //Thuế thu nhập
    {
        path: 'thue-thu-nhap',
        component: src_app_components_cs_thue_thu_nhap_cs_thue_thu_nhap_component__WEBPACK_IMPORTED_MODULE_8__.CsThueThuNhapComponent,
        data: {
            title: 'Danh sách thuế thu nhập',
            url: 'thue-thu-nhap',
        },
    },
    {
        path: 'thue-thu-nhap/chi-tiet-thue-thu-nhap',
        component: src_app_components_cs_thue_thu_nhap_chi_tiet_thue_thu_nhap_chi_tiet_thue_thu_nhap_component__WEBPACK_IMPORTED_MODULE_13__.ChiTietThueThuNhapComponent,
        data: {
            title: 'Chi tiết thuế thu nhập',
            url: 'chi-tiet-thue-thu-nhap',
        },
    },
    {
        path: 'tai-lieu-chung/:id',
        component: _components_bieu_mau_bieu_mau_chi_tiet_bieu_mau_chi_tiet_component__WEBPACK_IMPORTED_MODULE_2__.BieuMauChiTietComponent,
        data: {
            title: 'Tài liệu chung chi tiết',
            url: 'tai-lieu-chung/:id',
        },
    },
    {
        path: 'tai-lieu-chung',
        component: _components_bieu_mau_bieu_mau_component__WEBPACK_IMPORTED_MODULE_3__.BieuMauComponent,
        data: {
            title: 'Tài liệu chung',
            url: 'tai-lieu-chung',
        },
    },
    {
        path: 'tai-lieu-ca-nhan',
        component: _components_bieu_mau_bieu_mau_component__WEBPACK_IMPORTED_MODULE_3__.BieuMauComponent,
        data: {
            title: 'Tài liệu chung',
            url: 'tai-lieu-ca-nhan',
        },
    },
    {
        path: 'loai-tai-lieu/:id',
        component: _components_bieu_mau_loai_bieu_mau_chi_tiet_loai_bieu_mau_chi_tiet_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_1__.ChiTietLoaiBieuMauComponent,
        data: {
            title: 'Chi tiết loại Tài liệu',
            url: 'loai-tai-lieu/:id',
        },
    },
    {
        path: 'loai-tai-lieu',
        pathMatch: 'full',
        component: _components_bieu_mau_loai_bieu_mau_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_0__.LoaiBieuMauComponent,
        data: {
            title: 'Loại Tài liệu',
            url: 'loai-tai-lieu',
        },
    },
];
class ChinhSachRoutingModule {
}
ChinhSachRoutingModule.ɵfac = function ChinhSachRoutingModule_Factory(t) { return new (t || ChinhSachRoutingModule)(); };
ChinhSachRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdefineNgModule"]({ type: ChinhSachRoutingModule });
ChinhSachRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_21__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_21__.RouterModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵsetNgModuleScope"](ChinhSachRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_21__.RouterModule], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_21__.RouterModule] }); })();


/***/ }),

/***/ 76079:
/*!*******************************************************!*\
  !*** ./src/app/pages/chinh-sach/chinh-sach.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChinhSachModule": () => (/* binding */ ChinhSachModule)
/* harmony export */ });
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(/*! primeng/organizationchart */ 87051);
/* harmony import */ var _components_bieu_mau_bieu_mau_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../components/bieu-mau/bieu-mau.component */ 4795);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_tree__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! primeng/tree */ 35295);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! primeng/table */ 43750);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! primeng/multiselect */ 92487);
/* harmony import */ var src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/list-grid-angular/list-grid-angular.module */ 8145);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! primeng/splitbutton */ 71494);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! primeng/autocomplete */ 17611);
/* harmony import */ var src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/edit-detail/edit-detail.module */ 38160);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! primeng/fileupload */ 83735);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_card__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! primeng/card */ 33506);
/* harmony import */ var primeng_badge__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! primeng/badge */ 62051);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! primeng/tooltip */ 39243);
/* harmony import */ var primeng_slider__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! primeng/slider */ 52340);
/* harmony import */ var src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/pipe/currency-pipe.module */ 44093);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(/*! @ag-grid-community/angular */ 11775);
/* harmony import */ var src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component */ 75137);
/* harmony import */ var src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component-1 */ 90457);
/* harmony import */ var primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! primeng/confirmdialog */ 71849);
/* harmony import */ var primeng_sidebar__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! primeng/sidebar */ 65357);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var primeng_messages__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! primeng/messages */ 93713);
/* harmony import */ var primeng_message__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! primeng/message */ 15357);
/* harmony import */ var _chinh_sach_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./chinh-sach-routing.module */ 6095);
/* harmony import */ var src_app_components_cs_cham_cong_cs_cham_cong_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/cs-cham-cong/cs-cham-cong.component */ 59221);
/* harmony import */ var src_app_components_cs_nghi_phep_cs_nghi_phep_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/components/cs-nghi-phep/cs-nghi-phep.component */ 2369);
/* harmony import */ var src_app_components_cs_an_ca_cs_an_ca_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/components/cs-an-ca/cs-an-ca.component */ 47936);
/* harmony import */ var src_app_components_cs_tien_luong_cs_tien_luong_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/components/cs-tien-luong/cs-tien-luong.component */ 19871);
/* harmony import */ var src_app_components_cs_thue_thu_nhap_cs_thue_thu_nhap_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/components/cs-thue-thu-nhap/cs-thue-thu-nhap.component */ 72602);
/* harmony import */ var src_app_components_cs_nghi_phep_chi_tiet_nghi_phep_chi_tiet_nghi_phep_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/components/cs-nghi-phep/chi-tiet-nghi-phep/chi-tiet-nghi-phep.component */ 29904);
/* harmony import */ var src_app_components_cs_an_ca_chi_tiet_an_ca_chi_tiet_an_ca_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/components/cs-an-ca/chi-tiet-an-ca/chi-tiet-an-ca.component */ 2329);
/* harmony import */ var src_app_components_cs_cham_cong_chi_tiet_cham_cong_chi_tiet_cham_cong_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/components/cs-cham-cong/chi-tiet-cham-cong/chi-tiet-cham-cong.component */ 13265);
/* harmony import */ var src_app_components_cs_tien_luong_chi_tiet_tien_luong_chi_tiet_tien_luong_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/components/cs-tien-luong/chi-tiet-tien-luong/chi-tiet-tien-luong.component */ 77589);
/* harmony import */ var src_app_components_cs_thue_thu_nhap_import_excel_import_excel_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/components/cs-thue-thu-nhap/import-excel/import-excel.component */ 97641);
/* harmony import */ var src_app_components_cs_thue_thu_nhap_delete_tax_delete_tax_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/components/cs-thue-thu-nhap/delete-tax/delete-tax.component */ 83307);
/* harmony import */ var src_app_components_cs_thue_thu_nhap_chi_tiet_thue_thu_nhap_chi_tiet_thue_thu_nhap_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/components/cs-thue-thu-nhap/chi-tiet-thue-thu-nhap/chi-tiet-thue-thu-nhap.component */ 29095);
/* harmony import */ var src_app_components_phep_nam_phep_nam_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/components/phep-nam/phep-nam.component */ 87215);
/* harmony import */ var src_app_components_phep_bu_phep_bu_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/components/phep-bu/phep-bu.component */ 28128);
/* harmony import */ var src_app_components_phep_bu_chi_tiet_phep_bu_chi_tiet_phep_bu_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/components/phep-bu/chi-tiet-phep-bu/chi-tiet-phep-bu.component */ 52865);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/common/hrm-breadcrumb/hrm-breadcrumb.module */ 38040);
/* harmony import */ var primeng_checkbox__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! primeng/checkbox */ 77588);
/* harmony import */ var src_app_components_bieu_mau_bieu_mau_chi_tiet_bieu_mau_chi_tiet_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! src/app/components/bieu-mau/bieu-mau-chi-tiet/bieu-mau-chi-tiet.component */ 74589);
/* harmony import */ var src_app_components_bieu_mau_loai_bieu_mau_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! src/app/components/bieu-mau/loai-bieu-mau/loai-bieu-mau.component */ 72521);
/* harmony import */ var src_app_components_bieu_mau_loai_bieu_mau_chi_tiet_loai_bieu_mau_chi_tiet_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! src/app/components/bieu-mau/loai-bieu-mau/chi-tiet-loai-bieu-mau/chi-tiet-loai-bieu-mau.component */ 5140);
/* harmony import */ var src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! src/app/common/config-grid-table-form/config-grid-table-form.module */ 45092);
/* harmony import */ var src_app_components_cs_cham_cong_xem_cong_xem_cong_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! src/app/components/cs-cham-cong/xem-cong/xem-cong.component */ 22832);
/* harmony import */ var src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! src/app/directive/check-action.module */ 69389);
/* harmony import */ var src_app_components_cs_an_ca_eating_list_eating_list_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! src/app/components/cs-an-ca/eating-list/eating-list.component */ 82901);
/* harmony import */ var src_app_components_phep_bu_import_phep_bu_import_phep_bu_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! src/app/components/phep-bu/import-phep-bu/import-phep-bu.component */ 54278);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(/*! primeng/dynamicdialog */ 56427);
/* harmony import */ var src_app_common_form_filter_form_filter_module__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! src/app/common/form-filter/form-filter.module */ 1220);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/core */ 14001);
































































class ChinhSachModule {
}
ChinhSachModule.ɵfac = function ChinhSachModule_Factory(t) { return new (t || ChinhSachModule)(); };
ChinhSachModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_32__["ɵɵdefineNgModule"]({ type: ChinhSachModule });
ChinhSachModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_32__["ɵɵdefineInjector"]({ providers: [], imports: [[
            primeng_messages__WEBPACK_IMPORTED_MODULE_33__.MessagesModule,
            primeng_message__WEBPACK_IMPORTED_MODULE_34__.MessageModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_35__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_35__.ReactiveFormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_36__.CommonModule,
            primeng_tree__WEBPACK_IMPORTED_MODULE_37__.TreeModule,
            primeng_table__WEBPACK_IMPORTED_MODULE_38__.TableModule,
            primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_39__.BreadcrumbModule,
            primeng_checkbox__WEBPACK_IMPORTED_MODULE_40__.CheckboxModule,
            primeng_multiselect__WEBPACK_IMPORTED_MODULE_41__.MultiSelectModule,
            src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_1__.ListGridAngularModule,
            primeng_paginator__WEBPACK_IMPORTED_MODULE_42__.PaginatorModule,
            primeng_button__WEBPACK_IMPORTED_MODULE_43__.ButtonModule,
            primeng_splitbutton__WEBPACK_IMPORTED_MODULE_44__.SplitButtonModule,
            primeng_calendar__WEBPACK_IMPORTED_MODULE_45__.CalendarModule,
            primeng_autocomplete__WEBPACK_IMPORTED_MODULE_46__.AutoCompleteModule,
            src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_2__.EditDetailModule,
            primeng_fileupload__WEBPACK_IMPORTED_MODULE_47__.FileUploadModule,
            primeng_menu__WEBPACK_IMPORTED_MODULE_48__.MenuModule,
            primeng_card__WEBPACK_IMPORTED_MODULE_49__.CardModule,
            primeng_badge__WEBPACK_IMPORTED_MODULE_50__.BadgeModule,
            primeng_tooltip__WEBPACK_IMPORTED_MODULE_51__.TooltipModule,
            primeng_slider__WEBPACK_IMPORTED_MODULE_52__.SliderModule,
            primeng_sidebar__WEBPACK_IMPORTED_MODULE_53__.SidebarModule,
            _chinh_sach_routing_module__WEBPACK_IMPORTED_MODULE_6__.ChinhSachRoutingModule,
            src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_3__.CurrencyFormatPipeModule,
            primeng_dialog__WEBPACK_IMPORTED_MODULE_54__.DialogModule,
            primeng_dropdown__WEBPACK_IMPORTED_MODULE_55__.DropdownModule,
            primeng_tabview__WEBPACK_IMPORTED_MODULE_56__.TabViewModule,
            primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_57__.ConfirmDialogModule,
            primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_58__.OverlayPanelModule,
            primeng_treeselect__WEBPACK_IMPORTED_MODULE_59__.TreeSelectModule,
            src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_22__.HrmBreadCrumbModule,
            primeng_organizationchart__WEBPACK_IMPORTED_MODULE_60__.OrganizationChartModule,
            src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_26__.ConfigGridTableFormModule,
            src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_28__.CheckHideActionsDirectiveModule,
            _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_61__.AgGridModule.withComponents([
                src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_4__.ButtonRendererComponent,
                src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_5__.ButtonRendererComponent1,
            ]),
            src_app_common_form_filter_form_filter_module__WEBPACK_IMPORTED_MODULE_31__.FormFilterModule,
            primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_62__.DynamicDialogModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_32__["ɵɵsetNgModuleScope"](ChinhSachModule, { declarations: [src_app_components_cs_cham_cong_cs_cham_cong_component__WEBPACK_IMPORTED_MODULE_7__.CsChamCongComponent,
        src_app_components_cs_nghi_phep_cs_nghi_phep_component__WEBPACK_IMPORTED_MODULE_8__.CsNghiPhepComponent,
        src_app_components_cs_an_ca_cs_an_ca_component__WEBPACK_IMPORTED_MODULE_9__.CsAnCaComponent,
        src_app_components_cs_tien_luong_cs_tien_luong_component__WEBPACK_IMPORTED_MODULE_10__.CsTienLuongComponent,
        src_app_components_cs_thue_thu_nhap_cs_thue_thu_nhap_component__WEBPACK_IMPORTED_MODULE_11__.CsThueThuNhapComponent,
        src_app_components_cs_nghi_phep_chi_tiet_nghi_phep_chi_tiet_nghi_phep_component__WEBPACK_IMPORTED_MODULE_12__.ChiTietNghiPhepComponent,
        src_app_components_cs_an_ca_chi_tiet_an_ca_chi_tiet_an_ca_component__WEBPACK_IMPORTED_MODULE_13__.ChiTietAnCaComponent,
        src_app_components_cs_cham_cong_chi_tiet_cham_cong_chi_tiet_cham_cong_component__WEBPACK_IMPORTED_MODULE_14__.ChiTietChamCongComponent,
        src_app_components_cs_tien_luong_chi_tiet_tien_luong_chi_tiet_tien_luong_component__WEBPACK_IMPORTED_MODULE_15__.ChiTietTienLuongComponent,
        src_app_components_cs_thue_thu_nhap_import_excel_import_excel_component__WEBPACK_IMPORTED_MODULE_16__.ImportExcelComponent,
        src_app_components_cs_thue_thu_nhap_delete_tax_delete_tax_component__WEBPACK_IMPORTED_MODULE_17__.DeleteTaxComponent,
        src_app_components_cs_thue_thu_nhap_chi_tiet_thue_thu_nhap_chi_tiet_thue_thu_nhap_component__WEBPACK_IMPORTED_MODULE_18__.ChiTietThueThuNhapComponent,
        src_app_components_phep_nam_phep_nam_component__WEBPACK_IMPORTED_MODULE_19__.PhepNamComponent,
        src_app_components_phep_bu_phep_bu_component__WEBPACK_IMPORTED_MODULE_20__.PhepBuComponent,
        src_app_components_phep_bu_chi_tiet_phep_bu_chi_tiet_phep_bu_component__WEBPACK_IMPORTED_MODULE_21__.ChiTietPhepBuComponent,
        _components_bieu_mau_bieu_mau_component__WEBPACK_IMPORTED_MODULE_0__.BieuMauComponent,
        src_app_components_bieu_mau_bieu_mau_chi_tiet_bieu_mau_chi_tiet_component__WEBPACK_IMPORTED_MODULE_23__.BieuMauChiTietComponent,
        src_app_components_bieu_mau_loai_bieu_mau_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_24__.LoaiBieuMauComponent,
        src_app_components_bieu_mau_loai_bieu_mau_chi_tiet_loai_bieu_mau_chi_tiet_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_25__.ChiTietLoaiBieuMauComponent,
        src_app_components_cs_cham_cong_xem_cong_xem_cong_component__WEBPACK_IMPORTED_MODULE_27__.XemCongComponent,
        src_app_components_cs_an_ca_eating_list_eating_list_component__WEBPACK_IMPORTED_MODULE_29__.EatingListComponent,
        src_app_components_phep_bu_import_phep_bu_import_phep_bu_component__WEBPACK_IMPORTED_MODULE_30__.ImportPhepBuComponent], imports: [primeng_messages__WEBPACK_IMPORTED_MODULE_33__.MessagesModule,
        primeng_message__WEBPACK_IMPORTED_MODULE_34__.MessageModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_35__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_35__.ReactiveFormsModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_36__.CommonModule,
        primeng_tree__WEBPACK_IMPORTED_MODULE_37__.TreeModule,
        primeng_table__WEBPACK_IMPORTED_MODULE_38__.TableModule,
        primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_39__.BreadcrumbModule,
        primeng_checkbox__WEBPACK_IMPORTED_MODULE_40__.CheckboxModule,
        primeng_multiselect__WEBPACK_IMPORTED_MODULE_41__.MultiSelectModule,
        src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_1__.ListGridAngularModule,
        primeng_paginator__WEBPACK_IMPORTED_MODULE_42__.PaginatorModule,
        primeng_button__WEBPACK_IMPORTED_MODULE_43__.ButtonModule,
        primeng_splitbutton__WEBPACK_IMPORTED_MODULE_44__.SplitButtonModule,
        primeng_calendar__WEBPACK_IMPORTED_MODULE_45__.CalendarModule,
        primeng_autocomplete__WEBPACK_IMPORTED_MODULE_46__.AutoCompleteModule,
        src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_2__.EditDetailModule,
        primeng_fileupload__WEBPACK_IMPORTED_MODULE_47__.FileUploadModule,
        primeng_menu__WEBPACK_IMPORTED_MODULE_48__.MenuModule,
        primeng_card__WEBPACK_IMPORTED_MODULE_49__.CardModule,
        primeng_badge__WEBPACK_IMPORTED_MODULE_50__.BadgeModule,
        primeng_tooltip__WEBPACK_IMPORTED_MODULE_51__.TooltipModule,
        primeng_slider__WEBPACK_IMPORTED_MODULE_52__.SliderModule,
        primeng_sidebar__WEBPACK_IMPORTED_MODULE_53__.SidebarModule,
        _chinh_sach_routing_module__WEBPACK_IMPORTED_MODULE_6__.ChinhSachRoutingModule,
        src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_3__.CurrencyFormatPipeModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_54__.DialogModule,
        primeng_dropdown__WEBPACK_IMPORTED_MODULE_55__.DropdownModule,
        primeng_tabview__WEBPACK_IMPORTED_MODULE_56__.TabViewModule,
        primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_57__.ConfirmDialogModule,
        primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_58__.OverlayPanelModule,
        primeng_treeselect__WEBPACK_IMPORTED_MODULE_59__.TreeSelectModule,
        src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_22__.HrmBreadCrumbModule,
        primeng_organizationchart__WEBPACK_IMPORTED_MODULE_60__.OrganizationChartModule,
        src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_26__.ConfigGridTableFormModule,
        src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_28__.CheckHideActionsDirectiveModule, _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_61__.AgGridModule, src_app_common_form_filter_form_filter_module__WEBPACK_IMPORTED_MODULE_31__.FormFilterModule,
        primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_62__.DynamicDialogModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_pages_chinh-sach_chinh-sach_module_ts.aa8804e832b2df54.js.map