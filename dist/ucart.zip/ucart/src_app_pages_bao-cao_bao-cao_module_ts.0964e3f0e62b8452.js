"use strict";
(self["webpackChunkucart"] = self["webpackChunkucart"] || []).push([["src_app_pages_bao-cao_bao-cao_module_ts"],{

/***/ 17567:
/*!*********************************************************!*\
  !*** ./src/app/components/bao-cao/bao-cao.component.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BaoCaoComponent": () => (/* binding */ BaoCaoComponent)
/* harmony export */ });
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! file-saver */ 68178);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_card__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/card */ 33506);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/multiselect */ 92487);





















function BaoCaoComponent_ng_template_15_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](item_r4.label);
} }
function BaoCaoComponent_ng_template_16_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](car_r5.label);
} }
function BaoCaoComponent_div_17_ng_container_2_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "button", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function BaoCaoComponent_div_17_ng_container_2_div_1_Template_button_click_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r14); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3); return ctx_r13.ViewExcel("view"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function BaoCaoComponent_div_17_ng_container_2_div_1_Template_button_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r14); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3); return ctx_r15.exportExcel("xlsx"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", ctx_r8.query.report_type === null ? true : false);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", ctx_r8.query.report_type === null ? true : false);
} }
function BaoCaoComponent_div_17_ng_container_2_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "p-calendar", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function BaoCaoComponent_div_17_ng_container_2_div_2_Template_p_calendar_ngModelChange_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r18); const paramater_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit; return (paramater_r7[paramater_r7 == null ? null : paramater_r7.param_cd] = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const paramater_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", paramater_r7 == null ? null : paramater_r7.param_name, ": ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpropertyInterpolate"]("name", paramater_r7 == null ? null : paramater_r7.param_cd);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("baseZIndex", 101)("ngModel", paramater_r7[paramater_r7 == null ? null : paramater_r7.param_cd])("monthNavigator", true)("yearNavigator", true);
} }
function BaoCaoComponent_div_17_ng_container_2_div_3_ng_template_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r22 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](item_r22.label);
} }
function BaoCaoComponent_div_17_ng_container_2_div_3_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r23 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](car_r23.label);
} }
function BaoCaoComponent_div_17_ng_container_2_div_3_Template(rf, ctx) { if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "p-dropdown", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function BaoCaoComponent_div_17_ng_container_2_div_3_Template_p_dropdown_ngModelChange_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r26); const paramater_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit; return (paramater_r7[paramater_r7 == null ? null : paramater_r7.param_cd] = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, BaoCaoComponent_div_17_ng_container_2_div_3_ng_template_5_Template, 2, 1, "ng-template", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](6, BaoCaoComponent_div_17_ng_container_2_div_3_ng_template_6_Template, 3, 1, "ng-template", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const paramater_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngClass", paramater_r7[paramater_r7 == null ? null : paramater_r7.param_cd] ? "valid" : "invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", paramater_r7 == null ? null : paramater_r7.param_name, ": ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpropertyInterpolate"]("name", paramater_r7.param_cd);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", paramater_r7.options)("ngModel", paramater_r7[paramater_r7 == null ? null : paramater_r7.param_cd])("filter", true);
} }
function BaoCaoComponent_div_17_ng_container_2_div_4_ng_template_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const country_r29 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](country_r29.name);
} }
function BaoCaoComponent_div_17_ng_container_2_div_4_Template(rf, ctx) { if (rf & 1) {
    const _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "p-multiSelect", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("onChange", function BaoCaoComponent_div_17_ng_container_2_div_4_Template_p_multiSelect_onChange_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r32); const paramater_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit; const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2); return ctx_r30.selectChangeMultiSelect($event, paramater_r7.param_cd); })("ngModelChange", function BaoCaoComponent_div_17_ng_container_2_div_4_Template_p_multiSelect_ngModelChange_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r32); const paramater_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit; return (paramater_r7[paramater_r7 == null ? null : paramater_r7.param_cd] = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, BaoCaoComponent_div_17_ng_container_2_div_4_ng_template_5_Template, 3, 1, "ng-template", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const paramater_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngClass", paramater_r7[paramater_r7 == null ? null : paramater_r7.param_cd] ? "valid" : "invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", paramater_r7 == null ? null : paramater_r7.param_name, ": ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpropertyInterpolate"]("name", paramater_r7.param_cd);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("options", paramater_r7.options)("showToggleAll", true)("ngModel", paramater_r7[paramater_r7 == null ? null : paramater_r7.param_cd])("virtualScroll", true)("filter", true)("itemSize", 34);
} }
function BaoCaoComponent_div_17_ng_container_2_div_5_Template(rf, ctx) { if (rf & 1) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "input", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function BaoCaoComponent_div_17_ng_container_2_div_5_Template_input_ngModelChange_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r38); const paramater_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit; return (paramater_r7[paramater_r7 == null ? null : paramater_r7.param_cd] = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const paramater_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngClass", paramater_r7[paramater_r7 == null ? null : paramater_r7.param_cd] ? "valid" : "invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", paramater_r7 == null ? null : paramater_r7.param_name, ": ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpropertyInterpolate"]("name", paramater_r7.param_cd);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngModel", paramater_r7[paramater_r7 == null ? null : paramater_r7.param_cd]);
} }
function BaoCaoComponent_div_17_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, BaoCaoComponent_div_17_ng_container_2_div_1_Template, 4, 2, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, BaoCaoComponent_div_17_ng_container_2_div_2_Template, 5, 6, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](3, BaoCaoComponent_div_17_ng_container_2_div_3_Template, 7, 8, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](4, BaoCaoComponent_div_17_ng_container_2_div_4_Template, 6, 9, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, BaoCaoComponent_div_17_ng_container_2_div_5_Template, 5, 4, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const paramater_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (paramater_r7 == null ? null : paramater_r7.param_cd) === "exporttype");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (paramater_r7 == null ? null : paramater_r7.param_type) === "datetime");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (paramater_r7 == null ? null : paramater_r7.param_type) === "object");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (paramater_r7 == null ? null : paramater_r7.param_type) === "multiSelect");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (paramater_r7 == null ? null : paramater_r7.param_type) === "input");
} }
function BaoCaoComponent_div_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, BaoCaoComponent_div_17_ng_container_2_Template, 6, 5, "ng-container", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r3.chiTietThamSoBaoCao == null ? null : ctx_r3.chiTietThamSoBaoCao.paramaters);
} }
class BaoCaoComponent {
    constructor(spinner, apiService, changeDetector, router, messageService) {
        this.spinner = spinner;
        this.apiService = apiService;
        this.changeDetector = changeDetector;
        this.router = router;
        this.messageService = messageService;
        this.query = {
            report_type: -1
        };
        this.reports = [];
        this.listReports = [];
        this.chiTietThamSoBaoCao = null;
        this.items = [];
    }
    ngAfterViewChecked() {
        this.changeDetector.detectChanges();
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Báo cáo' },
        ];
        this.load();
    }
    load() {
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ report_type: -1 });
        this.apiService.getReportList(queryParams).subscribe((results) => {
            this.reports = results.data;
            this.listReports = results.data.map(d => {
                return {
                    label: `${d.report_group} - ${d.report_name}`,
                    value: d.report_id,
                    api: d.api_url,
                };
            });
            if (this.listReports.length > 0) {
                this.query.report_type = this.listReports[0].value;
                this.chiTietThamSoBaoCao = this.reports[0];
                this.chiTietThamSoBaoCao.paramaters.forEach(element => {
                    if (element.param_type === 'datetime') {
                        element[element.param_cd] = new Date();
                    }
                    else if (element.param_type === 'object') {
                        if (element.param_cd === 'companyId') {
                            this.getCompanyList(element);
                        }
                        if (element.param_cd === 'typeBM') {
                            this.getObjectList(element);
                        }
                    }
                    else if (element.param_type === 'multiSelect') {
                        if (element.param_cd === 'organizeId') {
                            this.getOrganizeParam(element);
                        }
                    }
                });
            }
            this.spinner.hide();
        }, error => { });
    }
    getDetailReport(event) {
        let items = this.reports.filter(d => d.report_id === this.query.report_type);
        this.chiTietThamSoBaoCao = items[0];
        // if(this.chiTietThamSoBaoCao.report_id == 7) {
        //   this.chiTietThamSoBaoCao.paramaters[1] = {...this.chiTietThamSoBaoCao.paramaters[1], param_type: 'multiSelect'};
        //   this.chiTietThamSoBaoCao.paramaters[2] = {...this.chiTietThamSoBaoCao.paramaters[2], param_type: 'multiSelect'};
        //   this.chiTietThamSoBaoCao.paramaters = [...this.chiTietThamSoBaoCao.paramaters];
        // }
        this.chiTietThamSoBaoCao.paramaters.forEach(element => {
            if (element.param_type === 'datetime') {
                element[element.param_cd] = new Date();
            }
            else if (element.param_type === 'object') {
                if (element.param_cd === 'companyId') {
                    this.getCompanyList(element);
                }
                if (element.param_cd === 'typeBM') {
                    this.getObjectList(element);
                }
            }
            else if (element.param_type === 'multiSelect') {
                if (element.param_cd === 'organizeId') {
                    this.getOrganizeParam(element);
                }
            }
        });
    }
    getCompanyList(element1) {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ orgId: 0 });
        this.apiService.getCompanyList(queryParams).subscribe(results => {
            if (results.status === 'success') {
                element1.options = results.data.map(res => {
                    return {
                        label: `${res.companyName}`,
                        value: `${res.companyId}`
                    };
                });
                element1[element1.param_cd] = element1.param_default;
            }
        });
    }
    getOrganizeParam(element1) {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ filter: '' });
        this.apiService.getOrganizeParam(queryParams).subscribe(results => {
            if (results.status === 'success') {
                element1.options = results.data.map(res => {
                    return {
                        name: `${res.organizationName}`,
                        code: `${res.organizeId}`
                    };
                });
                element1[element1.param_cd] = element1.param_default;
            }
        });
    }
    selectChangeMultiSelect(event, name) {
        if (name === 'organizeId') {
            this.getDepartmentParams(event.value.filter(d => d != 1));
        }
        else if (name === 'departmentId') {
        }
    }
    getDepartmentParams(organizeId) {
        console.log(organizeId.map(d => d.code));
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ organizeId: organizeId.map(d => d.code).toString() });
        this.apiService.getDepartmentParams(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.setValue(results.data, 'departmentId');
            }
        });
    }
    setValue(values, field_name) {
        this.chiTietThamSoBaoCao.paramaters.forEach(element => {
            if (element.param_cd === field_name) {
                element.options = values.map(res => {
                    return {
                        name: `${res.departmentName}`,
                        code: `${res.departmentId}`
                    };
                });
                element[element.param_cd] = element.param_default;
            }
        });
    }
    getObjectList(element1) {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify({ objKey: 'object_bm_st' });
        this.apiService.getCustObjectListNew(false, queryParams).subscribe(results => {
            if (results.status === 'success') {
                element1.options = results.data.map(res => {
                    return {
                        label: `${res.objName}`,
                        value: `${res.objValue}`
                    };
                });
                element1[element1.param_cd] = element1.param_default;
            }
        });
    }
    ViewExcel(type) {
        this.spinner.show();
        const params = this.getParams(type);
        const name = this.listReports.filter(t => t.value === this.query.report_type)[0].label;
        const api = this.listReports.filter(t => t.value === this.query.report_type)[0].api;
        if (api) {
            const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
            this.apiService.getReport(api, queryParams)
                .subscribe(response => {
                if (response.type === 'application/json') {
                    this.spinner.hide();
                }
                else {
                    var blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                    file_saver__WEBPACK_IMPORTED_MODULE_2__.saveAs(blob, name + ".xlsx");
                    this.spinner.hide();
                }
            }, error => {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Xuất báo cáo bị lỗi' });
            });
        }
    }
    exportExcel(type) {
        this.spinner.show();
        const params = this.getParams(type);
        const name = this.listReports.filter(t => t.value === this.query.report_type)[0].label;
        const api = this.listReports.filter(t => t.value === this.query.report_type)[0].api;
        if (api) {
            const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
            this.apiService.getReport(api, queryParams)
                .subscribe(response => {
                if (response.type === 'application/json') {
                    this.spinner.hide();
                }
                else {
                    var blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                    file_saver__WEBPACK_IMPORTED_MODULE_2__.saveAs(blob, name + ".xlsx");
                    this.spinner.hide();
                }
            }, error => {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Xuất báo cáo bị lỗi' });
            });
        }
    }
    exportPdf(type) {
        this.spinner.show();
        const params = this.getParams(type);
        const name = this.listReports.filter(t => t.value === this.query.report_type)[0].label;
        const api = this.listReports.filter(t => t.value === this.query.report_type)[0].api;
        if (api) {
            const queryParams = querystring__WEBPACK_IMPORTED_MODULE_0__.stringify(params);
            this.apiService.getReport(api, queryParams)
                .subscribe(response => {
                if (response.type === 'application/json') {
                    this.spinner.hide();
                }
                else {
                    var blob = new Blob([response], { type: 'application/pdf;charset=utf-8' });
                    file_saver__WEBPACK_IMPORTED_MODULE_2__.saveAs(blob, name + ".pdf");
                    this.spinner.hide();
                }
            }, error => {
                this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: 'Xuất báo cáo bị lỗi' });
            });
        }
    }
    getParams(type) {
        const params = {};
        params.type = type;
        this.chiTietThamSoBaoCao.paramaters.forEach(element => {
            if (element.param_type === 'datetime') {
                params[element.param_cd] = element[element.param_cd] ? moment__WEBPACK_IMPORTED_MODULE_1__(new Date(element[element.param_cd])).format('DD/MM/YYYY') : null;
            }
            else if (element.param_type === 'object') {
                params[element.param_cd] = element[element.param_cd];
            }
            else if (element.param_type === 'input') {
                params[element.param_cd] = element[element.param_cd];
            }
            else if (element.param_type === 'multiSelect') {
                console.log(element[element.param_cd] && (element[element.param_cd] != 1) && (element[element.param_cd].length > 0));
                if (element[element.param_cd] && (element[element.param_cd] != 1) && (element[element.param_cd].length > 0)) {
                    const param_cds = element[element.param_cd].filter(d => d != 1);
                    if (element.param_cd === 'departmentId') {
                        params[element.param_cd] = param_cds.map(d => d.code).toString();
                    }
                    else {
                        params[element.param_cd] = param_cds.map(d => d.code).toString();
                    }
                }
            }
        });
        return params;
    }
}
BaoCaoComponent.ɵfac = function BaoCaoComponent_Factory(t) { return new (t || BaoCaoComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_6__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_3__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.MessageService)); };
BaoCaoComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: BaoCaoComponent, selectors: [["app-bao-cao"]], decls: 18, vars: 8, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [3, "items"], [1, "grid", "main-grid"], [1, "col-12", "right", "max-w-full"], [1, "grid-default"], ["container", ""], ["styleClass", "mb-3"], [1, "row", "d-flex", "justify-content-center"], [1, "col-md-6"], [1, "field-group", "select", 3, "ngClass"], ["for", ""], ["appendTo", "body", "name", "report_type", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "filter", "onChange", "ngModelChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], ["class", "row d-flex justify-content-center mt-3 chiTietThamSoBaoCao", 4, "ngIf"], [1, "ui-helper-clearfix"], [2, "font-size", "14px", "float", "left", "margin-top", "4px"], [1, "row", "d-flex", "justify-content-center", "mt-3", "chiTietThamSoBaoCao"], [1, "col-md-6", 2, "padding-left", "0px", "padding-right", "0px"], [4, "ngFor", "ngForOf"], [4, "ngIf"], ["class", "col-md-6", 4, "ngIf"], ["class", "col-md-12", 4, "ngIf"], [1, "col-md-12", "d-flex", "mb-3"], ["pButton", "", "pRipple", "", "type", "button", "label", "Xem file Excel", "icon", "pi pi-eye", 1, "mr-2", 3, "disabled", "click"], ["pButton", "", "pRipple", "", "type", "button", "label", "Xu\u1EA5t file Excel", "icon", "pi pi-file-excel", 1, "mr-2", 3, "disabled", "click"], [1, "field-group", "date", "label-8"], ["placeholder", "DD/MM/YYYY", "appendTo", "body", "yearRange", "2000:2030", "inputId", "navigators", "dateFormat", "dd/mm/yy", "name", "datereport", 3, "baseZIndex", "ngModel", "name", "monthNavigator", "yearNavigator", "ngModelChange"], ["appendTo", "body", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "name", "filter", "ngModelChange"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [1, "col-md-12"], [1, "field-group", "multi-select", 3, "ngClass"], ["optionLabel", "name", 1, "multiselect-custom-virtual-scroll", 3, "options", "showToggleAll", "ngModel", "name", "virtualScroll", "filter", "itemSize", "onChange", "ngModelChange"], [1, "country-item"], [1, "field-group", "text", 3, "ngClass"], ["type", "text", 1, "form-control", 3, "ngModel", "name", "ngModelChange"]], template: function BaoCaoComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 6, 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "p-card", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, "Lo\u1EA1i b\u00E1o c\u00E1o");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "p-dropdown", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("onChange", function BaoCaoComponent_Template_p_dropdown_onChange_14_listener($event) { return ctx.getDetailReport($event); })("ngModelChange", function BaoCaoComponent_Template_p_dropdown_ngModelChange_14_listener($event) { return ctx.query.report_type = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](15, BaoCaoComponent_ng_template_15_Template, 2, 1, "ng-template", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](16, BaoCaoComponent_ng_template_16_Template, 3, 1, "ng-template", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, BaoCaoComponent_div_17_Template, 3, 1, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngClass", ctx.query.report_type ? "valid" : "invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.listReports)("ngModel", ctx.query.report_type)("filter", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.chiTietThamSoBaoCao);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__.HrmBreadCrumbComponent, primeng_card__WEBPACK_IMPORTED_MODULE_9__.Card, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgClass, primeng_dropdown__WEBPACK_IMPORTED_MODULE_11__.Dropdown, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgModel, primeng_api__WEBPACK_IMPORTED_MODULE_8__.PrimeTemplate, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, primeng_button__WEBPACK_IMPORTED_MODULE_13__.ButtonDirective, primeng_calendar__WEBPACK_IMPORTED_MODULE_14__.Calendar, primeng_multiselect__WEBPACK_IMPORTED_MODULE_15__.MultiSelect, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.DefaultValueAccessor], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJiYW8tY2FvLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 93468:
/*!*********************************************************!*\
  !*** ./src/app/pages/bao-cao/bao-cao-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BaoCaoRoutingModule": () => (/* binding */ BaoCaoRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var src_app_components_bao_cao_bao_cao_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/components/bao-cao/bao-cao.component */ 17567);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 14001);




const routes = [
    {
        path: 'bao-cao-tong-hop',
        component: src_app_components_bao_cao_bao_cao_component__WEBPACK_IMPORTED_MODULE_0__.BaoCaoComponent,
        data: {
            title: 'Báo cáo tổng hợp',
            url: 'bao-cao-tong-hop',
        },
    },
];
class BaoCaoRoutingModule {
}
BaoCaoRoutingModule.ɵfac = function BaoCaoRoutingModule_Factory(t) { return new (t || BaoCaoRoutingModule)(); };
BaoCaoRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: BaoCaoRoutingModule });
BaoCaoRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](BaoCaoRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule] }); })();


/***/ }),

/***/ 39619:
/*!*************************************************!*\
  !*** ./src/app/pages/bao-cao/bao-cao.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BaoCaoModule": () => (/* binding */ BaoCaoModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_tree__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/tree */ 35295);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/table */ 43750);
/* harmony import */ var primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/breadcrumb */ 48540);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/multiselect */ 92487);
/* harmony import */ var src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common/list-grid-angular/list-grid-angular.module */ 8145);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! primeng/splitbutton */ 71494);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! primeng/autocomplete */ 17611);
/* harmony import */ var src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/common/edit-detail/edit-detail.module */ 38160);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! primeng/fileupload */ 83735);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! primeng/menu */ 10543);
/* harmony import */ var primeng_card__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! primeng/card */ 33506);
/* harmony import */ var primeng_badge__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! primeng/badge */ 62051);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! primeng/tooltip */ 39243);
/* harmony import */ var primeng_slider__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! primeng/slider */ 52340);
/* harmony import */ var src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common/pipe/currency-pipe.module */ 44093);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! @ag-grid-community/angular */ 11775);
/* harmony import */ var src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component */ 75137);
/* harmony import */ var src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utils/common/button-renderer.component-1 */ 90457);
/* harmony import */ var primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! primeng/confirmdialog */ 71849);
/* harmony import */ var primeng_sidebar__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! primeng/sidebar */ 65357);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var primeng_messages__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/messages */ 93713);
/* harmony import */ var primeng_message__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/message */ 15357);
/* harmony import */ var primeng_image__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! primeng/image */ 98907);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! primeng/organizationchart */ 87051);
/* harmony import */ var primeng_listbox__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/listbox */ 61529);
/* harmony import */ var primeng_panel__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/panel */ 53581);
/* harmony import */ var primeng_selectbutton__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/selectbutton */ 22798);
/* harmony import */ var primeng_timeline__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/timeline */ 4679);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var src_app_components_ns_ho_so_nhan_su_user_detail_user_detail_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/components/ns-ho-so-nhan-su/user-detail/user-detail.module */ 41112);
/* harmony import */ var src_app_components_ns_ho_so_nhan_su_detail_account_detail_account_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/ns-ho-so-nhan-su/detail-account/detail-account.module */ 26153);
/* harmony import */ var src_app_common_upload_file_upload_file_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common/upload-file/upload-file.module */ 48290);
/* harmony import */ var src_app_components_ns_ho_so_nhan_su_emp_attach_file_emp_attach_file_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/components/ns-ho-so-nhan-su/emp-attach-file/emp-attach-file.module */ 40242);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var src_app_components_page_notify_store_notify_store_notify_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/components/page-notify/store-notify/store-notify.module */ 66505);
/* harmony import */ var primeng_steps__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! primeng/steps */ 56307);
/* harmony import */ var src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/common/hrm-breadcrumb/hrm-breadcrumb.module */ 38040);
/* harmony import */ var src_app_shared_components_excel_excel_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/components/excel/excel.module */ 51849);
/* harmony import */ var src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/common/config-grid-table-form/config-grid-table-form.module */ 45092);
/* harmony import */ var src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/directive/check-action.module */ 69389);
/* harmony import */ var src_app_components_bao_cao_bao_cao_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/components/bao-cao/bao-cao.component */ 17567);
/* harmony import */ var _bao_cao_routing_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./bao-cao-routing.module */ 93468);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 14001);




















































class BaoCaoModule {
}
BaoCaoModule.ɵfac = function BaoCaoModule_Factory(t) { return new (t || BaoCaoModule)(); };
BaoCaoModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineNgModule"]({ type: BaoCaoModule });
BaoCaoModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineInjector"]({ providers: [], imports: [[
            primeng_messages__WEBPACK_IMPORTED_MODULE_17__.MessagesModule,
            primeng_message__WEBPACK_IMPORTED_MODULE_18__.MessageModule,
            primeng_selectbutton__WEBPACK_IMPORTED_MODULE_19__.SelectButtonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_20__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_20__.ReactiveFormsModule,
            primeng_panel__WEBPACK_IMPORTED_MODULE_21__.PanelModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_22__.CommonModule,
            primeng_tree__WEBPACK_IMPORTED_MODULE_23__.TreeModule,
            primeng_timeline__WEBPACK_IMPORTED_MODULE_24__.TimelineModule,
            primeng_table__WEBPACK_IMPORTED_MODULE_25__.TableModule,
            primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_26__.OverlayPanelModule,
            primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_27__.BreadcrumbModule,
            src_app_components_ns_ho_so_nhan_su_detail_account_detail_account_module__WEBPACK_IMPORTED_MODULE_6__.DetailAccountModule,
            primeng_listbox__WEBPACK_IMPORTED_MODULE_28__.ListboxModule,
            src_app_components_ns_ho_so_nhan_su_user_detail_user_detail_module__WEBPACK_IMPORTED_MODULE_5__.UserDetailModule,
            primeng_multiselect__WEBPACK_IMPORTED_MODULE_29__.MultiSelectModule,
            src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularModule,
            primeng_paginator__WEBPACK_IMPORTED_MODULE_30__.PaginatorModule,
            primeng_button__WEBPACK_IMPORTED_MODULE_31__.ButtonModule,
            primeng_splitbutton__WEBPACK_IMPORTED_MODULE_32__.SplitButtonModule,
            primeng_calendar__WEBPACK_IMPORTED_MODULE_33__.CalendarModule,
            primeng_autocomplete__WEBPACK_IMPORTED_MODULE_34__.AutoCompleteModule,
            src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__.EditDetailModule,
            primeng_fileupload__WEBPACK_IMPORTED_MODULE_35__.FileUploadModule,
            primeng_menu__WEBPACK_IMPORTED_MODULE_36__.MenuModule,
            src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_12__.ConfigGridTableFormModule,
            primeng_card__WEBPACK_IMPORTED_MODULE_37__.CardModule,
            primeng_organizationchart__WEBPACK_IMPORTED_MODULE_38__.OrganizationChartModule,
            primeng_badge__WEBPACK_IMPORTED_MODULE_39__.BadgeModule,
            primeng_tooltip__WEBPACK_IMPORTED_MODULE_40__.TooltipModule,
            primeng_slider__WEBPACK_IMPORTED_MODULE_41__.SliderModule,
            primeng_sidebar__WEBPACK_IMPORTED_MODULE_42__.SidebarModule,
            src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__.CurrencyFormatPipeModule,
            primeng_dialog__WEBPACK_IMPORTED_MODULE_43__.DialogModule,
            primeng_image__WEBPACK_IMPORTED_MODULE_44__.ImageModule,
            primeng_dropdown__WEBPACK_IMPORTED_MODULE_45__.DropdownModule,
            primeng_tabview__WEBPACK_IMPORTED_MODULE_46__.TabViewModule,
            primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_47__.ConfirmDialogModule,
            src_app_common_upload_file_upload_file_module__WEBPACK_IMPORTED_MODULE_7__.UploadFileModule,
            src_app_components_ns_ho_so_nhan_su_emp_attach_file_emp_attach_file_module__WEBPACK_IMPORTED_MODULE_8__.EmpAttachFileModule,
            primeng_treeselect__WEBPACK_IMPORTED_MODULE_48__.TreeSelectModule,
            src_app_components_page_notify_store_notify_store_notify_module__WEBPACK_IMPORTED_MODULE_9__.StoreNotifyModule,
            primeng_steps__WEBPACK_IMPORTED_MODULE_49__.StepsModule,
            src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_10__.HrmBreadCrumbModule,
            _bao_cao_routing_module__WEBPACK_IMPORTED_MODULE_15__.BaoCaoRoutingModule,
            src_app_shared_components_excel_excel_module__WEBPACK_IMPORTED_MODULE_11__.ExcelModule,
            src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_13__.CheckHideActionsDirectiveModule,
            _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_50__.AgGridModule.withComponents([
                src_app_utils_common_button_renderer_component__WEBPACK_IMPORTED_MODULE_3__.ButtonRendererComponent,
                src_app_utils_common_button_renderer_component_1__WEBPACK_IMPORTED_MODULE_4__.ButtonRendererComponent1
            ]),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵsetNgModuleScope"](BaoCaoModule, { declarations: [src_app_components_bao_cao_bao_cao_component__WEBPACK_IMPORTED_MODULE_14__.BaoCaoComponent], imports: [primeng_messages__WEBPACK_IMPORTED_MODULE_17__.MessagesModule,
        primeng_message__WEBPACK_IMPORTED_MODULE_18__.MessageModule,
        primeng_selectbutton__WEBPACK_IMPORTED_MODULE_19__.SelectButtonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_20__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_20__.ReactiveFormsModule,
        primeng_panel__WEBPACK_IMPORTED_MODULE_21__.PanelModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_22__.CommonModule,
        primeng_tree__WEBPACK_IMPORTED_MODULE_23__.TreeModule,
        primeng_timeline__WEBPACK_IMPORTED_MODULE_24__.TimelineModule,
        primeng_table__WEBPACK_IMPORTED_MODULE_25__.TableModule,
        primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_26__.OverlayPanelModule,
        primeng_breadcrumb__WEBPACK_IMPORTED_MODULE_27__.BreadcrumbModule,
        src_app_components_ns_ho_so_nhan_su_detail_account_detail_account_module__WEBPACK_IMPORTED_MODULE_6__.DetailAccountModule,
        primeng_listbox__WEBPACK_IMPORTED_MODULE_28__.ListboxModule,
        src_app_components_ns_ho_so_nhan_su_user_detail_user_detail_module__WEBPACK_IMPORTED_MODULE_5__.UserDetailModule,
        primeng_multiselect__WEBPACK_IMPORTED_MODULE_29__.MultiSelectModule,
        src_app_common_list_grid_angular_list_grid_angular_module__WEBPACK_IMPORTED_MODULE_0__.ListGridAngularModule,
        primeng_paginator__WEBPACK_IMPORTED_MODULE_30__.PaginatorModule,
        primeng_button__WEBPACK_IMPORTED_MODULE_31__.ButtonModule,
        primeng_splitbutton__WEBPACK_IMPORTED_MODULE_32__.SplitButtonModule,
        primeng_calendar__WEBPACK_IMPORTED_MODULE_33__.CalendarModule,
        primeng_autocomplete__WEBPACK_IMPORTED_MODULE_34__.AutoCompleteModule,
        src_app_common_edit_detail_edit_detail_module__WEBPACK_IMPORTED_MODULE_1__.EditDetailModule,
        primeng_fileupload__WEBPACK_IMPORTED_MODULE_35__.FileUploadModule,
        primeng_menu__WEBPACK_IMPORTED_MODULE_36__.MenuModule,
        src_app_common_config_grid_table_form_config_grid_table_form_module__WEBPACK_IMPORTED_MODULE_12__.ConfigGridTableFormModule,
        primeng_card__WEBPACK_IMPORTED_MODULE_37__.CardModule,
        primeng_organizationchart__WEBPACK_IMPORTED_MODULE_38__.OrganizationChartModule,
        primeng_badge__WEBPACK_IMPORTED_MODULE_39__.BadgeModule,
        primeng_tooltip__WEBPACK_IMPORTED_MODULE_40__.TooltipModule,
        primeng_slider__WEBPACK_IMPORTED_MODULE_41__.SliderModule,
        primeng_sidebar__WEBPACK_IMPORTED_MODULE_42__.SidebarModule,
        src_app_common_pipe_currency_pipe_module__WEBPACK_IMPORTED_MODULE_2__.CurrencyFormatPipeModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_43__.DialogModule,
        primeng_image__WEBPACK_IMPORTED_MODULE_44__.ImageModule,
        primeng_dropdown__WEBPACK_IMPORTED_MODULE_45__.DropdownModule,
        primeng_tabview__WEBPACK_IMPORTED_MODULE_46__.TabViewModule,
        primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_47__.ConfirmDialogModule,
        src_app_common_upload_file_upload_file_module__WEBPACK_IMPORTED_MODULE_7__.UploadFileModule,
        src_app_components_ns_ho_so_nhan_su_emp_attach_file_emp_attach_file_module__WEBPACK_IMPORTED_MODULE_8__.EmpAttachFileModule,
        primeng_treeselect__WEBPACK_IMPORTED_MODULE_48__.TreeSelectModule,
        src_app_components_page_notify_store_notify_store_notify_module__WEBPACK_IMPORTED_MODULE_9__.StoreNotifyModule,
        primeng_steps__WEBPACK_IMPORTED_MODULE_49__.StepsModule,
        src_app_common_hrm_breadcrumb_hrm_breadcrumb_module__WEBPACK_IMPORTED_MODULE_10__.HrmBreadCrumbModule,
        _bao_cao_routing_module__WEBPACK_IMPORTED_MODULE_15__.BaoCaoRoutingModule,
        src_app_shared_components_excel_excel_module__WEBPACK_IMPORTED_MODULE_11__.ExcelModule,
        src_app_directive_check_action_module__WEBPACK_IMPORTED_MODULE_13__.CheckHideActionsDirectiveModule, _ag_grid_community_angular__WEBPACK_IMPORTED_MODULE_50__.AgGridModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_pages_bao-cao_bao-cao_module_ts.0964e3f0e62b8452.js.map