"use strict";
(self["webpackChunkucart"] = self["webpackChunkucart"] || []).push([["default-src_app_components_bieu-mau_bieu-mau_component_ts-src_app_components_bieu-mau_loai-bi-2aadfb"],{

/***/ 74589:
/*!**************************************************************************************!*\
  !*** ./src/app/components/bieu-mau/bieu-mau-chi-tiet/bieu-mau-chi-tiet.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BieuMauChiTietComponent": () => (/* binding */ BieuMauChiTietComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../common/edit-detail/edit-detail.component */ 58638);















function BieuMauChiTietComponent_app_edit_detail_1_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "app-edit-detail", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("callback", function BieuMauChiTietComponent_app_edit_detail_1_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r1.handleSave($event); })("callbackcancel", function BieuMauChiTietComponent_app_edit_detail_1_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r3.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("isUploadMultiple", false)("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews);
} }
class BieuMauChiTietComponent {
    constructor(activatedRoute, apiService, spinner, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: '', icon: 'pi pi-check' }
        ];
        this.titlePage = '';
        this.formId = null;
        this.callback = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.spinner.show();
        this.getDetail();
    }
    getDetail() {
        this.listViews = [];
        this.detailInfo = [];
        this.spinner.show();
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ formId: this.formId });
        this.apiService.getFormsInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                this.spinner.hide();
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(results.data.group_fields);
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(listViews);
                this.detailInfo = results.data;
            }
        });
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getDetail();
        }
        else if (data === 'Cancel') {
            this.callback.emit('Cancel');
        }
    }
    handleSave(event) {
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: event });
        this.apiService.setFormsInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.callback.emit();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
}
BieuMauChiTietComponent.ɵfac = function BieuMauChiTietComponent_Factory(t) { return new (t || BieuMauChiTietComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_0__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_8__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router)); };
BieuMauChiTietComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: BieuMauChiTietComponent, selectors: [["app-bieu-mau-chi-tiet"]], inputs: { formId: "formId" }, outputs: { callback: "callback" }, decls: 2, vars: 1, consts: [[1, "content"], [3, "isUploadMultiple", "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel", 4, "ngIf"], [3, "isUploadMultiple", "detail", "manhinh", "optionsButtonsEdit", "dataView", "callback", "callbackcancel"]], template: function BieuMauChiTietComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, BieuMauChiTietComponent_app_edit_detail_1_Template, 1, 5, "app-edit-detail", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_3__.EditDetailComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJiaWV1LW1hdS1jaGktdGlldC5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 4795:
/*!***********************************************************!*\
  !*** ./src/app/components/bieu-mau/bieu-mau.component.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BieuMauComponent": () => (/* binding */ BieuMauComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 53951);
/* harmony import */ var _services_export_file_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/export-file.service */ 20046);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/organize-info.service */ 88585);
/* harmony import */ var src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/common/form-filter/form-filter.component */ 83844);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/dynamicdialog */ 56427);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/tabview */ 63397);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../directive/check-action.directive */ 32475);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../common/config-grid-table-form/config-grid-table-form.component */ 39805);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! primeng/organizationchart */ 87051);
/* harmony import */ var src_app_components_bieu_mau_bieu_mau_chi_tiet_bieu_mau_chi_tiet_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/components/bieu-mau/bieu-mau-chi-tiet/bieu-mau-chi-tiet.component */ 74589);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../common/edit-detail/edit-detail.component */ 58638);









































const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function (a0) { return { "active": a0 }; };
function BieuMauComponent_p_button_5_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "p-button", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function BieuMauComponent_p_button_5_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r19); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r18.pushToApp(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "svg", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](2, "path", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](3, "path", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](4, "\u00A0\u00A0 \u0110\u00E2\u0309y l\u00EAn app ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction2"](2, _c0, ctx_r0.MENUACTIONROLEAPI.GetFormGeneral.url, ctx_r0.ACTIONS.DAY_LEN_APP))("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](5, _c1, ctx_r0.listDataSelect.length > 0));
} }
function BieuMauComponent_p_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "p-button", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("onClick", function BieuMauComponent_p_button_6_Template_p_button_onClick_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r21); const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r20.handleFormType(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "svg", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](2, "path", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](3, " \u00A0\u00A0 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction2"](1, _c0, ctx_r1.MENUACTIONROLEAPI.GetFormGeneral.url, ctx_r1.ACTIONS.THIET_LAP_TAI_LIEU));
} }
function BieuMauComponent_p_button_7_Template(rf, ctx) { if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "p-button", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function BieuMauComponent_p_button_7_Template_p_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r23); const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r22.handleAdd(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction2"](1, _c0, ctx_r2.MENUACTIONROLEAPI.GetFormGeneral.url, ctx_r2.ACTIONS.ADD));
} }
function BieuMauComponent_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    const _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "div", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](8, "Lo\u1EA1i t\u00E0i li\u1EC7u");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "p-treeSelect", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function BieuMauComponent_ng_template_10_Template_p_treeSelect_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r25); const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r24.query.typeForm = $event; })("onNodeSelect", function BieuMauComponent_ng_template_10_Template_p_treeSelect_onNodeSelect_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r25); const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r26.selectedNode11($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](10, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](11, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](12, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](13, "Ng\u00E0y t\u1EA1o");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](14, "p-calendar", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function BieuMauComponent_ng_template_10_Template_p_calendar_ngModelChange_14_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r25); const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r27.query.createDate = $event; })("onSelect", function BieuMauComponent_ng_template_10_Template_p_calendar_onSelect_14_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r25); const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r28.find(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](15, "span", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](16, "svg", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](17, "path", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](18, "path", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](19, "path", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](20, "path", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](21, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](22, "p-button", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function BieuMauComponent_ng_template_10_Template_p_button_click_22_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r25); const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r29.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](23, "p-button", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function BieuMauComponent_ng_template_10_Template_p_button_click_23_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r25); const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r30.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx_r4.query.typeForm)("options", ctx_r4.formTypes);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", ctx_r4.query.createDate ? "valid" : "invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx_r4.query.createDate);
} }
function BieuMauComponent_ng_template_27_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r31 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r31.label);
} }
function BieuMauComponent_ng_template_28_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r32 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](car_r32.label);
} }
function BieuMauComponent_app_list_grid_angular_47_Template(rf, ctx) { if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-list-grid-angular", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("callback", function BieuMauComponent_app_list_grid_angular_47_Template_app_list_grid_angular_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r34); const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r33.rowSelected($event); })("onCellClicked", function BieuMauComponent_app_list_grid_angular_47_Template_app_list_grid_angular_onCellClicked_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r34); const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r35.onCellClicked($event); })("showConfig", function BieuMauComponent_app_list_grid_angular_47_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r34); const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r36.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("listsData", ctx_r8.listsData)("height", ctx_r8.heightGrid)("columnDefs", ctx_r8.columnDefs)("rowSelection", "multiple");
} }
function BieuMauComponent_ng_template_66_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r37 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r37.label);
} }
function BieuMauComponent_ng_template_67_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r38 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](car_r38.label);
} }
function BieuMauComponent_app_list_grid_angular_82_Template(rf, ctx) { if (rf & 1) {
    const _r40 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-list-grid-angular", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("callback", function BieuMauComponent_app_list_grid_angular_82_Template_app_list_grid_angular_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r40); const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r39.rowSelected($event); })("showConfig", function BieuMauComponent_app_list_grid_angular_82_Template_app_list_grid_angular_showConfig_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r40); const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r41.cauhinh(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("listsData", ctx_r12.listsData)("height", ctx_r12.heightGrid)("columnDefs", ctx_r12.columnDefs)("rowSelection", "multiple");
} }
function BieuMauComponent_app_config_grid_table_form_88_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "app-config-grid-table-form", 84);
} if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("typeConfig", "TableInfo")("gridKey", ctx_r13.gridKey);
} }
function BieuMauComponent_ng_template_90_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](0, " L\u1ECDc nh\u00E2n s\u1EF1 theo s\u01A1 \u0111\u1ED3 t\u1ED5 ch\u1EE9c ");
} }
function BieuMauComponent_p_organizationChart_91_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "div", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](3, "img", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const node_r44 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"]("", node_r44.data.position ? node_r44.data.position : "No position", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpropertyInterpolate"]("src", node_r44.data.avatarUrl ? node_r44.data.avatarUrl : "../../../../../assets/images/img_avatar.png", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](node_r44.data.full_name ? node_r44.data.full_name : "No name");
} }
function BieuMauComponent_p_organizationChart_91_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](0);
} if (rf & 2) {
    const node_r45 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", node_r45.label, " ");
} }
function BieuMauComponent_p_organizationChart_91_Template(rf, ctx) { if (rf & 1) {
    const _r47 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "p-organizationChart", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("selectionChange", function BieuMauComponent_p_organizationChart_91_Template_p_organizationChart_selectionChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r47); const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r46.selectedNode = $event; })("onNodeSelect", function BieuMauComponent_p_organizationChart_91_Template_p_organizationChart_onNodeSelect_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r47); const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r48.onNodeSelect($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, BieuMauComponent_p_organizationChart_91_ng_template_1_Template, 6, 3, "ng-template", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, BieuMauComponent_p_organizationChart_91_ng_template_2_Template, 1, 1, "ng-template", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", ctx_r15.listAgencyMap)("preserveSpace", false)("selection", ctx_r15.selectedNode);
} }
function BieuMauComponent_app_bieu_mau_chi_tiet_93_Template(rf, ctx) { if (rf & 1) {
    const _r50 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-bieu-mau-chi-tiet", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("callback", function BieuMauComponent_app_bieu_mau_chi_tiet_93_Template_app_bieu_mau_chi_tiet_callback_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r50); const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r49.handleCallbackForm(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("formId", ctx_r16.formId);
} }
function BieuMauComponent_app_edit_detail_95_Template(rf, ctx) { if (rf & 1) {
    const _r52 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "app-edit-detail", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("callback", function BieuMauComponent_app_edit_detail_95_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r52); const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r51.setWorkApprove($event); })("callbackcancel", function BieuMauComponent_app_edit_detail_95_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r52); const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](); return ctx_r53.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("detail", ctx_r17.detailInfo)("manhinh", "Edit")("dataView", ctx_r17.listViews);
} }
const _c2 = function () { return { width: "700px" }; };
const _c3 = function () { return { showAll: "ALL" }; };
const _c4 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c5 = function () { return { width: "50vw" }; };
const _c6 = function () { return { width: "90vw" }; };
const _c7 = function () { return { "1024": "95vw", "640px": "100vw" }; };
const _c8 = function () { return { width: "1000px" }; };
class BieuMauComponent {
    constructor(apiService, spinner, confirmationService, messageService, fileService, changeDetector, organizeInfoService, router, dialogService, route) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.changeDetector = changeDetector;
        this.organizeInfoService = organizeInfoService;
        this.router = router;
        this.dialogService = dialogService;
        this.route = route;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS;
        this.items = [];
        this.organs = [];
        this.loadjs = 0;
        this.heightGrid = 300;
        this.query = {
            filter: '',
            organizeId: '',
            typeForm: null,
            createDate: '',
            offSet: 0,
            pageSize: 15,
            form_status: null,
            organizeIds: '',
        };
        this.totalRecord = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.listsData = [];
        this.columnDefs = [];
        this.statusTaiLieu = [
            { label: 'Đang hoạt động', value: 1 },
            { label: 'Hết hạn', value: 2 },
            { label: 'Đã lên app', value: 3 }
        ];
        this.listDataSelect = [];
        this.isHrDiagram = false;
        this.organizeList = [];
        this.detailOrganizeMap = null;
        this.formTypes = [];
        this.data = [];
        this.formId = null;
        this.dataRouter = null;
        this.indexTab = 0;
        this.titleHeader = '';
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_16__.Subject();
        this.displaySetting = false;
        this.gridKey = '';
        this.addNewPopup = false;
        this.addNewPopup2 = false;
        this.listViews = [];
        this.detailInfo = [];
        this.isShareButton = false;
        this.listViewsFilter = [];
        this.detailInfoFilter = null;
        this.optionsButonFilter = [
            { label: 'Tìm kiếm', value: 'Search', class: 'p-button-sm height-56 addNew', icon: 'pi pi-search' },
            { label: 'Làm mới', value: 'Reset', class: 'p-button-sm p-button-danger height-56 addNew', icon: 'pi pi-times' },
        ];
        this.dataRouter = this.route.data['_value'];
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.organizeInfoService.organizeInfo$.subscribe((results) => {
            if (results && results.length > 0) {
                this.query.organizeIds = results;
                this.load();
            }
        });
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Hoạt động' },
            { label: 'Tài liệu' },
            { label: this.dataRouter.title },
        ];
        this.getAgencyOrganizeMap();
        this.getOrgan();
        this.getFormTypes();
    }
    getNode(item) {
        return {
            label: item.formTypeName || item.formTypeId,
            data: item.formTypeId,
            expandedIcon: "pi pi-folder-open",
            collapsedIcon: "pi pi-folder",
            children: item.children
        };
    }
    loopEveryNodeTree(list) {
        for (let i = 0; i < list.length; i++) {
            if (Array.isArray(list[i].children) && list[i].children.length) {
                list[i] = this.getNode(list[i]);
                this.loopEveryNodeTree(list[i].children);
            }
            else {
                list[i] = this.getNode(list[i]);
            }
        }
    }
    selectedNode11(event) {
        // this.query.typeForm = event.node.data
        // this.load();
    }
    getFormTypes() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ filter: '', form_type_id: '' });
        this.apiService.getFormsTypes(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.finalize)(() => this.spinner.hide()))
            .subscribe(response => {
            const data = response.data;
            this.loopEveryNodeTree(data);
            this.formTypes = data;
        });
    }
    hrDiagram() {
        this.selectedNode = null;
        this.listAgencyMap = [];
        this.getAgencyOrganizeMap(true);
    }
    getAgencyOrganizeMap(type = false) {
        this.apiService.getAgencyOrganizeMap().subscribe(results => {
            if (results.status === 'success') {
                this.listAgencyMap = [...results.data.root];
                if (localStorage.getItem("organize") === null || localStorage.getItem("organize") === 'undefined') {
                    this.selectedNode = this.listAgencyMap[0];
                    localStorage.setItem('organize', JSON.stringify(this.listAgencyMap[0]));
                    // this.query.organizeId = this.selectedNode.orgId;
                    this.load();
                }
                else {
                    this.selectedNode = JSON.parse(localStorage.getItem("organize"));
                    // this.query.organizeId = this.selectedNode?.orgId;
                    this.listAgencyMap = this.expanded(this.listAgencyMap, this.selectedNode.parentId);
                    this.selected(this.listAgencyMap, this.query.organizeId);
                    if (type) {
                        this.isHrDiagram = true;
                    }
                    this.load();
                }
            }
        });
    }
    onNodeSelect(event) {
        var _a;
        this.detailOrganizeMap = event.node;
        localStorage.setItem('organize', JSON.stringify(event.node));
        // this.query.orgId = this.selectedNode?.orgId;
        this.query.organizeId = (_a = this.detailOrganizeMap) === null || _a === void 0 ? void 0 : _a.orgId;
        this.isHrDiagram = false;
        this.load();
    }
    selected(datas = [], orgId = '') {
        datas.forEach(d => {
            if (d.orgId == orgId) {
                this.selectedNode = d;
                this.detailOrganizeMap = d;
            }
            else {
                if (d.children.length > 0)
                    this.selected(d.children, this.selectedNode.orgId);
            }
        });
    }
    expanded(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                d.expanded = true;
            }
            else {
                if (d.children.length > 0)
                    this.expanded(d.children, this.selectedNode.parentId);
            }
            d.children.forEach((elm) => {
                elm.children.forEach((e) => {
                    if (e.expanded === true) {
                        elm.expanded = true;
                    }
                });
            });
        });
        return datas;
    }
    getOrgan() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.organs = results.data.map(d => {
                    return {
                        label: d.organizationName,
                        value: `${d.organizeId}`
                    };
                });
                this.organs = [...this.organs];
            }
        });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.listDataSelect = [];
        this.columnDefs = [];
        this.spinner.show();
        const query = Object.assign({}, this.query);
        if (query.createDate && typeof query.createDate !== 'string') {
            query.createDate = moment__WEBPACK_IMPORTED_MODULE_4__(query.createDate).format('YYYY-MM-DD');
        }
        if (typeof this.query.typeForm === 'object' && this.query && this.query.typeForm) {
            query.typeForm = this.query.typeForm.data;
        }
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify(query);
        this.apiService.getFormGeneral(queryParams, this.indexTab === 0 ? 'GetFormGeneral' : 'GetFormPersonal').subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.EditEmployee.bind(this),
                    label: 'Thông tin chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: this.indexTab === 0 || (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetFormGeneral.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.VIEW)
                },
                {
                    onClick: this.handleDelete.bind(this),
                    label: 'Xóa tài liệu',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    hide: this.indexTab === 0 || (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.MENUACTIONROLEAPI.GetFormGeneral.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_6__.ACTIONS.DELETE)
                },
            ]
        };
    }
    handleDelete(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa tài liệu?',
            accept: () => {
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ formId: event.rowData.form_id });
                this.apiService.delFormsInfo(queryParams).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa tài liệu thành công!' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    EditEmployee(event) {
        // this.router.navigateByUrl(`/chinh-sach/tai-lieu-chung/${event.rowData.form_id}`);
        this.formId = event.rowData.form_id;
        this.addNewPopup = true;
        if (this.indexTab === 0) {
            this.titleHeader = 'Sửa tài liệu chung';
        }
        else {
            this.titleHeader = 'Sửa tài liệu cá nhân';
        }
    }
    initGrid() {
        if (this.indexTab === 0) {
            this.columnDef();
        }
        else {
            this.columnDef2();
        }
    }
    // chung
    columnDef() {
        this.columnDefs = [
            {
                headerName: 'STT',
                filter: '',
                maxWidth: 70,
                pinned: 'left',
                cellRenderer: params => {
                    return params.rowIndex + 1;
                },
                cellClass: ['border-right', 'no-auto', 'cell-options'],
                field: 'checkbox2',
                suppressSizeToFit: true,
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: '    ...',
                filter: '',
                maxWidth: 80,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto', 'cell-options'],
                cellRendererParams: (params) => this.showButtons(params),
                field: 'checkbox'
            }
        ];
    }
    //ca nhan
    columnDef2() {
        this.columnDefs = [
            {
                headerName: 'STT',
                filter: '',
                maxWidth: 120,
                pinned: 'left',
                cellRenderer: params => {
                    return params.rowIndex + 1;
                },
                cellClass: ['border-right', 'no-auto'],
                field: 'checkbox2',
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
                suppressSizeToFit: true,
                suppressRowClickSelection: true,
                checkboxSelection: (params) => {
                    return !!params.data && params.data.form_status !== 2;
                },
                showDisabledCheckboxes: true,
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: '    ...',
                filter: '',
                maxWidth: 80,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto', 'cell-options'],
                cellRendererParams: (params) => this.showButtons(params),
                field: 'checkbox'
            }
        ];
    }
    onFirstDataRendered(params) {
        params.api.forEachNode((node) => node.setSelected(!!node.data && node.data.form_status === 2));
    }
    exportExel() {
        this.spinner.show();
        this.query.pageSize = 1000000;
        const query = Object.assign({}, this.query);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify(query);
        this.apiService.getFormPage(queryParams).subscribe((results) => {
            const dataExport = [];
            let gridflexs = results.data.gridflexs;
            let arrKey = gridflexs.map(elementName => elementName.columnField);
            let dataList = results.data.dataList.data;
            for (let elementValue of dataList) {
                const data = {};
                for (let elementName of gridflexs) {
                    if (arrKey.indexOf(elementName.columnField) > -1 && !elementName.isHide && elementName.columnField !== 'statusName') {
                        let valueColumn = elementValue[elementName.columnField];
                        if (elementName.columnField == 'status_name' || elementName.columnField == 'isContacted' || elementName.columnField == 'isProfileFull' || elementName.columnField == 'lockName') {
                            valueColumn = this.replaceHtmlToText(valueColumn);
                        }
                        data[elementName.columnCaption] = valueColumn || '';
                    }
                }
                dataExport.push(data);
            }
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách hồ sơ nhân sự ' + new Date());
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    cancel() {
        this.query = {
            organizeId: '',
            filter: '',
            typeForm: '',
            createDate: '',
            offSet: 0,
            pageSize: 10,
            form_status: null,
            organizeIds: this.query.organizeIds
        };
        this.load();
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        // const d: any = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + e.clientHeight + 200;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
    }
    handleFormType() {
        this.router.navigateByUrl('/hoat-dong/loai-tai-lieu');
    }
    handleAdd() {
        this.formId = null;
        this.addNewPopup = true;
        this.titleHeader = 'Thêm mới tài liệu';
    }
    handleCallbackForm() {
        this.load();
        this.addNewPopup = false;
    }
    handleChange(event) {
        this.indexTab = event.index;
        this.load();
    }
    getDetail() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ formTypeId: this.formTypeId2 });
        this.apiService.getFormsInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_18__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_5__.cloneDeep)(results.data.group_fields);
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_5__.cloneDeep)(listViews);
                this.detailInfo = results.data;
            }
        });
    }
    setWorkApprove(event) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: event });
        this.apiService.setFormsTypeInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_18__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.addNewPopup2 = false;
                this.load();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
    quaylai(r) {
        this.addNewPopup2 = false;
    }
    pushToApp() {
        let form_id = String(this.listDataSelect);
        if (this.listDataSelect.length > 0) {
            const ids = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ form_id: form_id });
            this.apiService.shareToApp(ids)
                .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_18__.takeUntil)(this.unsubscribe$))
                .subscribe((results) => {
                if (results.status === 'success') {
                    this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                    this.spinner.hide();
                    this.load();
                }
                else {
                    this.messageService.add({
                        severity: 'error', summary: 'Thông báo',
                        detail: results.message
                    });
                    this.spinner.hide();
                }
            }), error => {
                console.error('Error:', error);
                this.spinner.hide();
            };
        }
    }
    onCellClicked(event) {
        if (event.colDef.field === "link_view") {
            if (event.data.link_view) {
                var url = event.data.link_view;
                var elem = document.createElement('a');
                elem.href = url;
                elem.target = 'hiddenIframe';
                elem.click();
            }
        }
    }
    rowSelected(data) {
        this.listDataSelect = [];
        if (this.indexTab === 1) {
            data.forEach(element => {
                if (element.form_status !== 2) {
                    this.listDataSelect.push(element.form_id);
                }
            });
        }
    }
    //filter 
    getFilter(value) {
        value === 1 ? '' : '';
        this.apiService.getFilter('/api/v1/eating/GetEatingFilter').subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_5__.cloneDeep)(results.data.group_fields);
                this.listViewsFilter = [...listViews];
                this.detailInfoFilter = results.data;
            }
        });
    }
    showFilter(value) {
        const ref = this.dialogService.open(src_app_common_form_filter_form_filter_component__WEBPACK_IMPORTED_MODULE_8__.FormFilterComponent, {
            header: 'Tìm kiếm nâng cao',
            width: '40%',
            contentStyle: "",
            data: {
                listViews: this.listViewsFilter,
                detailInfoFilter: this.detailInfoFilter,
                buttons: this.optionsButonFilter
            }
        });
        ref.onClose.subscribe((event) => {
            if (event) {
                this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_5__.cloneDeep)(event.listViewsFilter);
                if (event.type === 'Search') {
                    this.query = Object.assign(Object.assign({}, this.query), event.data);
                    this.load();
                }
                else if (event.type === 'CauHinh') {
                    this.apiService.getEmpFilter().subscribe(results => {
                        if (results.status === 'success') {
                            const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_5__.cloneDeep)(results.data.group_fields);
                            this.listViewsFilter = [...listViews];
                            this.detailInfoFilter = results.data;
                            this.showFilter(1);
                        }
                    });
                }
                else if (event.type === 'Reset') {
                    const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_5__.cloneDeep)(this.detailInfoFilter.group_fields);
                    this.listViewsFilter = (0,lodash__WEBPACK_IMPORTED_MODULE_5__.cloneDeep)(listViews);
                    this.cancel();
                }
            }
        });
    }
}
BieuMauComponent.ɵfac = function BieuMauComponent_Factory(t) { return new (t || BieuMauComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_19__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_20__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_20__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_services_export_file_service__WEBPACK_IMPORTED_MODULE_0__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_15__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_services_organize_info_service__WEBPACK_IMPORTED_MODULE_7__.OrganizeInfoService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_21__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_22__.DialogService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_21__.ActivatedRoute)); };
BieuMauComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({ type: BieuMauComponent, selectors: [["app-bieu-mau"]], decls: 96, vars: 79, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom", "pd-0"], [3, "items"], [1, "d-flex", "middle", "gap12"], ["styleClass", "height-56 btn-active-on-off", 3, "CheckHideActions", "ngClass", "click", 4, "ngIf"], ["label", "Thi\u00EA\u0301t l\u00E2\u0323p loa\u0323i ta\u0300i li\u00EA\u0323u", "styleClass", "height-56", "icon", "", 3, "CheckHideActions", "onClick", 4, "ngIf"], ["label", "Th\u00EAm m\u1EDBi", "styleClass", "height-56", "icon", "pi pi-plus ", 3, "CheckHideActions", "click", 4, "ngIf"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [3, "activeIndex", "activeIndexChange", "onChange"], ["header", "Ta\u0300i li\u00EA\u0323u chung"], [1, "bread-filter"], [1, "d-flex", "middle", "bet"], [1, "col-item"], [1, "filter", "filter-search"], [1, "field-group", "valid", "text", "search", "mb-0"], ["placeholder", "T\u00ECm ki\u1EBFm theo m\u00E3, t\u00EAn lo\u1EA1i t\u00E0i li\u1EC7u", "type", "text", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["_ngcontent-xmj-c197", "", "width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["_ngcontent-xmj-c197", "", "fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "field-group", "select", "mb-0"], ["appendTo", "body", "placeholder", "---Cho\u0323n tra\u0323ng tha\u0301i ---", "name", "form_status", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], [1, "col-item", "d-flex", "gap12"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "p-button-sm height-56", 3, "click"], ["width", "20", "height", "17", "viewBox", "0 0 20 17", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M19.5 17V0H0.50855L0.5 17H19.5ZM6.675 15.3187H2.21V6.81868H6.675V15.3187ZM8.575 15.3187V6.81868H17.79V15.3187H8.575ZM2.21 1.68132V5.13736H17.79V1.68132H2.21Z", "fill", "#F3F8FF"], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "rowSelection", "callback", "onCellClicked", "showConfig", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["header", "Ta\u0300i li\u00EA\u0323u ca\u0301 nh\u00E2n"], [3, "listsData", "height", "columnDefs", "rowSelection", "callback", "showConfig", 4, "ngIf"], ["header", "C\u00E0i \u0111\u1EB7t c\u1EA5u h\u00ECnh", "styleClass", "popup-setting", 3, "visible", "modal", "maximizable", "draggable", "resizable", "focusTrap", "visibleChange", "onHide"], [3, "typeConfig", "gridKey", 4, "ngIf"], ["styleClass", "hr-diagram", 3, "appendTo", "autoZIndex", "visible", "modal", "breakpoints", "visibleChange"], ["pTemplate", "header"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect", 4, "ngIf"], [3, "header", "visible", "modal", "draggable", "resizable", "focusTrap", "visibleChange"], [3, "formId", "callback", 4, "ngIf"], ["styleClass", "hideHeaderForm", "header", "T\u00E0i li\u1EC7u c\u00E1 nh\u00E2n", 3, "visible", "modal", "draggable", "resizable", "focusTrap", "visibleChange"], [3, "detail", "manhinh", "dataView", "callback", "callbackcancel", 4, "ngIf"], ["styleClass", "height-56 btn-active-on-off", 3, "CheckHideActions", "ngClass", "click"], ["width", "14", "height", "20", "viewBox", "0 0 14 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M0.333008 18.333C0.333008 18.7932 0.706104 19.1663 1.16634 19.1663H12.833C13.2932 19.1663 13.6663 18.7932 13.6663 18.333V1.66634C13.6663 1.2061 13.2932 0.833008 12.833 0.833008H1.16634C0.706104 0.833008 0.333008 1.2061 0.333008 1.66634V18.333ZM1.99967 2.49967H11.9997V17.4997H1.99967V2.49967Z", "fill", "#F6FBFF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M4.49982 15.3097C4.49982 14.9083 4.82181 14.583 5.219 14.583H8.78064C9.17783 14.583 9.49982 14.9083 9.49982 15.3097C9.49982 15.711 9.17783 16.0364 8.78064 16.0364H5.219C4.82181 16.0364 4.49982 15.711 4.49982 15.3097Z", "fill", "#F6FBFF"], ["label", "Thi\u00EA\u0301t l\u00E2\u0323p loa\u0323i ta\u0300i li\u00EA\u0323u", "styleClass", "height-56", "icon", "", 3, "CheckHideActions", "onClick"], ["width", "18", "height", "14", "viewBox", "0 0 18 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.19928 4.08301L6.53262 1.99967H2.33366V11.9997H15.667V4.08301H8.19928ZM17.3337 2.41634V13.6663H0.666992V0.333008H7.33366L9.00033 2.41634H17.3337Z", "fill", "#F6FBFF"], ["label", "Th\u00EAm m\u1EDBi", "styleClass", "height-56", "icon", "pi pi-plus ", 3, "CheckHideActions", "click"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", "valid"], [3, "ngModel", "options", "ngModelChange", "onNodeSelect"], [1, "field-group", "date", "mb-0", 3, "ngClass"], ["inputId", "icon", 3, "ngModel", "ngModelChange", "onSelect"], [1, "icon"], ["width", "18", "height", "20", "viewBox", "0 0 18 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M14.1143 1.89648C14.1143 1.3442 13.6665 0.896484 13.1143 0.896484C12.562 0.896484 12.1143 1.3442 12.1143 1.89648L12.1143 4.89648C12.1143 5.44877 12.562 5.89648 13.1143 5.89648C13.6665 5.89648 14.1143 5.44877 14.1143 4.89648L14.1143 1.89648Z", "fill", "#99A2BC"], ["d", "M6.11426 1.89649C6.11426 1.3442 5.66654 0.896488 5.11426 0.896488C4.56197 0.896488 4.11426 1.3442 4.11426 1.89649L4.11426 4.89648C4.11426 5.44877 4.56197 5.89648 5.11426 5.89648C5.66654 5.89648 6.11426 5.44877 6.11426 4.89648L6.11426 1.89649Z", "fill", "#99A2BC"], ["d", "M11.1143 2.83252H7.11426L7.11426 4.83252C7.11426 5.93709 6.21883 6.83252 5.11426 6.83252C4.00969 6.83252 3.11426 5.93709 3.11426 4.83252L3.11426 2.92088C2.27249 3.02253 1.72376 3.24112 1.25368 3.7112C0.463333 4.50155 0.38388 5.72516 0.375893 8.02148H17.6258C17.6257 5.26179 17.6172 4.58131 16.7471 3.7112C16.2978 3.26191 15.8362 3.04235 15.1143 2.93506L15.1143 4.83252C15.1143 5.93709 14.2188 6.83252 13.1143 6.83252C12.0097 6.83252 11.1143 5.93709 11.1143 4.83252L11.1143 2.83252Z", "fill", "#99A2BC"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.6258 9.77148H0.375V13.1036C0.375 15.932 0.375 17.3462 1.25368 18.2249C2.13236 19.1036 3.28587 19.1036 6.1143 19.1036H12.1143C14.9427 19.1036 15.8684 19.1036 16.7471 18.2249C17.6258 17.3462 17.6258 15.932 17.6258 13.1036V9.77148ZM3.625 12.459C3.625 12.1483 3.87684 11.8965 4.1875 11.8965H5.3125C5.62316 11.8965 5.875 12.1483 5.875 12.459V13.584C5.875 13.8946 5.62316 14.1465 5.3125 14.1465H4.1875C3.87684 14.1465 3.625 13.8946 3.625 13.584V12.459ZM8.125 12.459C8.125 12.1483 8.37684 11.8965 8.6875 11.8965H9.8125C10.1232 11.8965 10.375 12.1483 10.375 12.459V13.584C10.375 13.8946 10.1232 14.1465 9.8125 14.1465H8.6875C8.37684 14.1465 8.125 13.8946 8.125 13.584V12.459ZM13.1875 11.8965C12.8768 11.8965 12.625 12.1483 12.625 12.459V13.584C12.625 13.8946 12.8768 14.1465 13.1875 14.1465H14.3125C14.6232 14.1465 14.875 13.8946 14.875 13.584V12.459C14.875 12.1483 14.6232 11.8965 14.3125 11.8965H13.1875Z", "fill", "#99A2BC"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [3, "listsData", "height", "columnDefs", "rowSelection", "callback", "onCellClicked", "showConfig"], [3, "listsData", "height", "columnDefs", "rowSelection", "callback", "showConfig"], [3, "typeConfig", "gridKey"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect"], ["pTemplate", "person"], ["pTemplate", "department"], [1, "node-header", "p-corner-top"], [1, "node-content"], ["width", "32", 3, "src"], [3, "formId", "callback"], [3, "detail", "manhinh", "dataView", "callback", "callbackcancel"]], template: function BieuMauComponent_Template(rf, ctx) { if (rf & 1) {
        const _r54 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](5, BieuMauComponent_p_button_5_Template, 5, 7, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](6, BieuMauComponent_p_button_6_Template, 4, 4, "p-button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](7, BieuMauComponent_p_button_7_Template, 1, 4, "p-button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "p-overlayPanel", 8, 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](10, BieuMauComponent_ng_template_10_Template, 24, 4, "ng-template", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](11, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](12, "p-tabView", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("activeIndexChange", function BieuMauComponent_Template_p_tabView_activeIndexChange_12_listener($event) { return ctx.indexTab = $event; })("onChange", function BieuMauComponent_Template_p_tabView_onChange_12_listener($event) { return ctx.handleChange($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](13, "p-tabPanel", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](14, "section", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](15, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](16, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](17, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](18, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](19, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("keydown.enter", function BieuMauComponent_Template_input_keydown_enter_19_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function BieuMauComponent_Template_input_ngModelChange_19_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](20, "span", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function BieuMauComponent_Template_span_click_20_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](21, "svg", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](22, "path", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](23, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](24, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](25, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](26, "p-dropdown", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function BieuMauComponent_Template_p_dropdown_ngModelChange_26_listener($event) { return ctx.query.form_status = $event; })("onChange", function BieuMauComponent_Template_p_dropdown_onChange_26_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](27, BieuMauComponent_ng_template_27_Template, 2, 1, "ng-template", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](28, BieuMauComponent_ng_template_28_Template, 3, 1, "ng-template", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](29, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](30, "p-button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function BieuMauComponent_Template_p_button_click_30_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](31, "svg", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](32, "path", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](33, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](34, "p-button", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function BieuMauComponent_Template_p_button_click_34_listener() { return ctx.showFilter(1); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](35, "svg", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](36, "path", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](37, "path", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](38, "path", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](39, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](40, "p-button", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function BieuMauComponent_Template_p_button_click_40_listener() { return ctx.cauhinh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](41, "svg", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](42, "path", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](43, " \u00A0 C\u1EA5u h\u00ECnh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](44, "section", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](45, "div", 40, 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](47, BieuMauComponent_app_list_grid_angular_47_Template, 1, 4, "app-list-grid-angular", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](48, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](49, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](50);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](51, "p-paginator", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("onPageChange", function BieuMauComponent_Template_p_paginator_onPageChange_51_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](52, "p-tabPanel", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](53, "section", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](54, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](55, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](56, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](57, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](58, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("keydown.enter", function BieuMauComponent_Template_input_keydown_enter_58_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function BieuMauComponent_Template_input_ngModelChange_58_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](59, "span", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function BieuMauComponent_Template_span_click_59_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](60, "svg", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](61, "path", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](62, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](63, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](64, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](65, "p-dropdown", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function BieuMauComponent_Template_p_dropdown_ngModelChange_65_listener($event) { return ctx.query.form_status = $event; })("onChange", function BieuMauComponent_Template_p_dropdown_onChange_65_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](66, BieuMauComponent_ng_template_66_Template, 2, 1, "ng-template", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](67, BieuMauComponent_ng_template_67_Template, 3, 1, "ng-template", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](68, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](69, "p-button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function BieuMauComponent_Template_p_button_click_69_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](70, "svg", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](71, "path", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](72, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](73, "p-button", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function BieuMauComponent_Template_p_button_click_73_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r54); const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](9); return _r3.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](74, "svg", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](75, "path", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](76, "path", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](77, "path", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](78, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](79, "section", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](80, "div", 40, 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](82, BieuMauComponent_app_list_grid_angular_82_Template, 1, 4, "app-list-grid-angular", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](83, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](84, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](85);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](86, "p-paginator", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("onPageChange", function BieuMauComponent_Template_p_paginator_onPageChange_86_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](87, "p-dialog", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function BieuMauComponent_Template_p_dialog_visibleChange_87_listener($event) { return ctx.displaySetting = $event; })("onHide", function BieuMauComponent_Template_p_dialog_onHide_87_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](88, BieuMauComponent_app_config_grid_table_form_88_Template, 1, 2, "app-config-grid-table-form", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](89, "p-dialog", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function BieuMauComponent_Template_p_dialog_visibleChange_89_listener($event) { return ctx.isHrDiagram = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](90, BieuMauComponent_ng_template_90_Template, 1, 0, "ng-template", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](91, BieuMauComponent_p_organizationChart_91_Template, 3, 3, "p-organizationChart", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](92, "p-dialog", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function BieuMauComponent_Template_p_dialog_visibleChange_92_listener($event) { return ctx.addNewPopup = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](93, BieuMauComponent_app_bieu_mau_chi_tiet_93_Template, 1, 1, "app-bieu-mau-chi-tiet", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](94, "p-dialog", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("visibleChange", function BieuMauComponent_Template_p_dialog_visibleChange_94_listener($event) { return ctx.addNewPopup2 = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](95, BieuMauComponent_app_edit_detail_95_Template, 1, 3, "app-edit-detail", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.indexTab === 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.indexTab === 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.indexTab === 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](67, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("activeIndex", ctx.indexTab);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.statusTaiLieu)("ngModel", ctx.query.form_status);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](69, _c4, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](68, _c3)));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.statusTaiLieu)("ngModel", ctx.query.form_status);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](72, _c4, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](71, _c3)));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](74, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.displaySetting)("modal", true)("maximizable", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.displaySetting && ctx.gridKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](75, _c6));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("appendTo", "body")("autoZIndex", true)("visible", ctx.isHrDiagram)("modal", true)("breakpoints", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](76, _c7));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.isHrDiagram);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](77, _c8));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpropertyInterpolate"]("header", ctx.titleHeader);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.addNewPopup)("modal", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.addNewPopup);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](78, _c8));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("visible", ctx.addNewPopup2)("modal", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_9__.HrmBreadCrumbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_23__.NgIf, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_24__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_20__.PrimeTemplate, primeng_tabview__WEBPACK_IMPORTED_MODULE_25__.TabView, primeng_tabview__WEBPACK_IMPORTED_MODULE_25__.TabPanel, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.NgModel, primeng_dropdown__WEBPACK_IMPORTED_MODULE_27__.Dropdown, primeng_button__WEBPACK_IMPORTED_MODULE_28__.Button, primeng_paginator__WEBPACK_IMPORTED_MODULE_29__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_30__.Dialog, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_10__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_23__.NgClass, primeng_treeselect__WEBPACK_IMPORTED_MODULE_31__.TreeSelect, primeng_calendar__WEBPACK_IMPORTED_MODULE_32__.Calendar, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_11__.ListGridAngularComponent, _common_config_grid_table_form_config_grid_table_form_component__WEBPACK_IMPORTED_MODULE_12__.ConfigGridTableFormComponent, primeng_organizationchart__WEBPACK_IMPORTED_MODULE_33__.OrganizationChart, src_app_components_bieu_mau_bieu_mau_chi_tiet_bieu_mau_chi_tiet_component__WEBPACK_IMPORTED_MODULE_13__.BieuMauChiTietComponent, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_14__.EditDetailComponent], styles: ["[_nghost-%COMP%]  p-dialog .field-group.checkbox {\n  display: flex;\n  flex-direction: row-reverse;\n  justify-content: start;\n  align-items: center;\n  min-height: 0px;\n  grid-gap: 18px;\n  gap: 18px;\n}\n[_nghost-%COMP%]  p-dialog .field-group.checkbox .p-checkbox {\n  position: static;\n}\n[_nghost-%COMP%]  p-dialog .field-group.checkbox label {\n  position: static;\n  margin-bottom: 0px;\n}\n[_nghost-%COMP%]  .bg-primary.noti-number {\n  background: #34C759 !important;\n  border-radius: 2px !important;\n}\n[_nghost-%COMP%]  .noti-number.bg-dark {\n  background: #FF3B49 !important;\n  border-radius: 2px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJpZXUtbWF1LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdZO0VBQ0ksYUFBQTtFQUNBLDJCQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQUEsU0FBQTtBQUZoQjtBQUdnQjtFQUNJLGdCQUFBO0FBRHBCO0FBR2dCO0VBQ0ksZ0JBQUE7RUFDQSxrQkFBQTtBQURwQjtBQU1JO0VBQ0ksOEJBQUE7RUFDQSw2QkFBQTtBQUpSO0FBTUk7RUFDSSw4QkFBQTtFQUNBLDZCQUFBO0FBSlIiLCJmaWxlIjoiYmlldS1tYXUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdDo6bmctZGVlcHtcclxuICAgIHAtZGlhbG9ne1xyXG4gICAgICAgIC5maWVsZC1ncm91cHtcclxuICAgICAgICAgICAgJi5jaGVja2JveHtcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93LXJldmVyc2U7XHJcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xyXG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDBweDtcclxuICAgICAgICAgICAgICAgIGdhcDogMThweDtcclxuICAgICAgICAgICAgICAgIC5wLWNoZWNrYm94e1xyXG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBzdGF0aWM7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBsYWJlbHtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogc3RhdGljO1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5iZy1wcmltYXJ5Lm5vdGktbnVtYmVye1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICMzNEM3NTkgIWltcG9ydGFudDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAycHggIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgIC5ub3RpLW51bWJlci5iZy1kYXJre1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNGRjNCNDkgIWltcG9ydGFudDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAycHggIWltcG9ydGFudDtcclxuICAgIH1cclxufSJdfQ== */"] });


/***/ }),

/***/ 5140:
/*!**************************************************************************************************************!*\
  !*** ./src/app/components/bieu-mau/loai-bieu-mau/chi-tiet-loai-bieu-mau/chi-tiet-loai-bieu-mau.component.ts ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChiTietLoaiBieuMauComponent": () => (/* binding */ ChiTietLoaiBieuMauComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ 38127);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 24575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 76567);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../common/edit-detail/edit-detail.component */ 58638);

















function ChiTietLoaiBieuMauComponent_app_edit_detail_1_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "app-edit-detail", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("callback", function ChiTietLoaiBieuMauComponent_app_edit_detail_1_Template_app_edit_detail_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r1.setWorkApprove($event); })("callbackcancel", function ChiTietLoaiBieuMauComponent_app_edit_detail_1_Template_app_edit_detail_callbackcancel_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r3.quaylai($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("detail", ctx_r0.detailInfo)("manhinh", "Edit")("optionsButtonsEdit", ctx_r0.optionsButon)("dataView", ctx_r0.listViews)("formTypeId", ctx_r0.formTypeId);
} }
class ChiTietLoaiBieuMauComponent {
    constructor(activatedRoute, apiService, spinner, messageService, router) {
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.spinner = spinner;
        this.messageService = messageService;
        this.router = router;
        this.items = [];
        this.paramsObject = null;
        this.detailInfo = null;
        this.listViews = [];
        this.optionsButon = [
            { label: 'Hủy', value: 'Cancel', class: 'p-button-secondary', icon: 'pi pi-times' },
            { label: 'Lưu lại', value: 'Update', class: (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.MENUACTIONROLEAPI.GetFormsTypePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_4__.ACTIONS.EDIT) ? 'hidden' : '', icon: 'pi pi-check' }
        ];
        this.titlePage = '';
        this.formTypeId = null;
        this.callback = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
        this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
    }
    ngOnDestroy() {
        this.unsubscribe$.next();
        this.unsubscribe$.complete();
    }
    ngOnInit() {
        this.getDetail();
    }
    getDetail() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ formTypeId: this.formTypeId });
        this.apiService.getFormsTypeInfo(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe(results => {
            if (results.status === 'success') {
                const listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(results.data.group_fields);
                this.listViews = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.cloneDeep)(listViews);
                this.detailInfo = results.data;
            }
        });
    }
    quaylai(data) {
        if (data === 'CauHinh') {
            this.getDetail();
        }
        else {
            this.router.navigateByUrl('/chinh-sach/loai-tai-lieu');
            this.callback.emit();
        }
    }
    setWorkApprove(event) {
        this.spinner.show();
        const params = Object.assign(Object.assign({}, this.detailInfo), { group_fields: event });
        this.apiService.setFormsTypeInfo(params)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.unsubscribe$))
            .subscribe((results) => {
            if (results.status === 'success') {
                this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.message });
                this.spinner.hide();
                this.callback.emit();
            }
            else {
                this.messageService.add({
                    severity: 'error', summary: 'Thông báo',
                    detail: results.message
                });
                this.spinner.hide();
            }
        }), error => {
            console.error('Error:', error);
            this.spinner.hide();
        };
    }
}
ChiTietLoaiBieuMauComponent.ɵfac = function ChiTietLoaiBieuMauComponent_Factory(t) { return new (t || ChiTietLoaiBieuMauComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_1__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router)); };
ChiTietLoaiBieuMauComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: ChiTietLoaiBieuMauComponent, selectors: [["app-chi-tiet-loai-bieu-mau"]], inputs: { formTypeId: "formTypeId" }, outputs: { callback: "callback" }, decls: 2, vars: 1, consts: [[1, "content"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "formTypeId", "callback", "callbackcancel", 4, "ngIf"], [3, "detail", "manhinh", "optionsButtonsEdit", "dataView", "formTypeId", "callback", "callbackcancel"]], template: function ChiTietLoaiBieuMauComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, ChiTietLoaiBieuMauComponent_app_edit_detail_1_Template, 1, 5, "app-edit-detail", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.listViews.length > 0);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _common_edit_detail_edit_detail_component__WEBPACK_IMPORTED_MODULE_5__.EditDetailComponent], styles: ["[_nghost-%COMP%]  .p-treeselect-items-wrapper {\n  max-height: 200px !important;\n}\n[_nghost-%COMP%]  .field-group.checkbox {\n  display: flex;\n  min-height: 0px;\n  align-items: center;\n  grid-gap: 12px;\n  gap: 12px;\n}\n[_nghost-%COMP%]  .field-group.checkbox label {\n  margin-bottom: 0px;\n}\n[_nghost-%COMP%]  .field-group.checkbox .p-checkbox {\n  position: static;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoaS10aWV0LWxvYWktYmlldS1tYXUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSw0QkFBQTtBQUFSO0FBR1E7RUFDSSxhQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUFBLFNBQUE7QUFEWjtBQUVZO0VBQ0ksa0JBQUE7QUFBaEI7QUFFWTtFQUNJLGdCQUFBO0FBQWhCIiwiZmlsZSI6ImNoaS10aWV0LWxvYWktYmlldS1tYXUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdDo6bmctZGVlcHtcclxuICAgIC5wLXRyZWVzZWxlY3QtaXRlbXMtd3JhcHBlcntcclxuICAgICAgICBtYXgtaGVpZ2h0OiAyMDBweCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgLmZpZWxkLWdyb3Vwe1xyXG4gICAgICAgICYuY2hlY2tib3h7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDBweDtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAgZ2FwOiAxMnB4O1xyXG4gICAgICAgICAgICBsYWJlbHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAucC1jaGVja2JveHtcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBzdGF0aWM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iXX0= */"] });


/***/ }),

/***/ 72521:
/*!******************************************************************************!*\
  !*** ./src/app/components/bieu-mau/loai-bieu-mau/loai-bieu-mau.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoaiBieuMauComponent": () => (/* binding */ LoaiBieuMauComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 53951);
/* harmony import */ var src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/api-hrm/apihrm.service */ 52964);
/* harmony import */ var src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/export-file.service */ 20046);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! querystring */ 37690);
/* harmony import */ var src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common/function-common/common */ 87343);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ 29243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common/constants/constant */ 57566);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 14001);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ 33150);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/api */ 15132);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 13252);
/* harmony import */ var _common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../common/hrm-breadcrumb/hrm-breadcrumb.component */ 34184);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/button */ 62150);
/* harmony import */ var _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../directive/check-action.directive */ 32475);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 28267);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/dropdown */ 45596);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/forms */ 18346);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/overlaypanel */ 86155);
/* harmony import */ var primeng_paginator__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/paginator */ 5287);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 69812);
/* harmony import */ var primeng_treeselect__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/treeselect */ 90238);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/calendar */ 6582);
/* harmony import */ var _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../common/list-grid-angular/list-grid-angular.component */ 93555);
/* harmony import */ var primeng_organizationchart__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/organizationchart */ 87051);
/* harmony import */ var src_app_components_bieu_mau_loai_bieu_mau_chi_tiet_loai_bieu_mau_chi_tiet_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/components/bieu-mau/loai-bieu-mau/chi-tiet-loai-bieu-mau/chi-tiet-loai-bieu-mau.component */ 5140);































function LoaiBieuMauComponent_ng_template_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](item_r9.label);
} }
function LoaiBieuMauComponent_ng_template_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const car_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](car_r10.label);
} }
function LoaiBieuMauComponent_ng_template_39_Template(rf, ctx) { if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "T\u00ECm ki\u1EBFm n\u00E2ng cao");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](6, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](8, "C\u1EA5p cha");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "p-treeSelect", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function LoaiBieuMauComponent_ng_template_39_Template_p_treeSelect_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r12); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r11.query.typeForm = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](11, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](12, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](13, "Ng\u00E0y t\u1EA1o");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](14, "p-calendar", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function LoaiBieuMauComponent_ng_template_39_Template_p_calendar_ngModelChange_14_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r12); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r13.query.createDate = $event; })("onSelect", function LoaiBieuMauComponent_ng_template_39_Template_p_calendar_onSelect_14_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r12); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r14.find(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](15, "span", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](16, "svg", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](17, "path", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](18, "path", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](19, "path", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](20, "path", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](21, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](22, "p-button", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function LoaiBieuMauComponent_ng_template_39_Template_p_button_click_22_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r12); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r15.load(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](23, "p-button", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function LoaiBieuMauComponent_ng_template_39_Template_p_button_click_23_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r12); const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r16.cancel(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", ctx_r3.query.typeForm ? "valid" : "invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx_r3.query.typeForm)("options", ctx_r3.formTypes);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", ctx_r3.query.createDate ? "valid" : "invalid");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx_r3.query.createDate);
} }
function LoaiBieuMauComponent_app_list_grid_angular_43_Template(rf, ctx) { if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "app-list-grid-angular", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("callback", function LoaiBieuMauComponent_app_list_grid_angular_43_Template_app_list_grid_angular_callback_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r18); const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r17.rowSelected($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("listsData", ctx_r5.listsData)("height", ctx_r5.heightGrid)("columnDefs", ctx_r5.columnDefs)("rowSelection", "multiple");
} }
function LoaiBieuMauComponent_ng_template_49_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](0, " L\u1ECDc nh\u00E2n s\u1EF1 theo s\u01A1 \u0111\u1ED3 t\u1ED5 ch\u1EE9c ");
} }
function LoaiBieuMauComponent_p_organizationChart_50_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](3, "img", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const node_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"]("", node_r21.data.position ? node_r21.data.position : "No position", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpropertyInterpolate"]("src", node_r21.data.avatarUrl ? node_r21.data.avatarUrl : "../../../../../assets/images/img_avatar.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](node_r21.data.full_name ? node_r21.data.full_name : "No name");
} }
function LoaiBieuMauComponent_p_organizationChart_50_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](0);
} if (rf & 2) {
    const node_r22 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", node_r22.label, " ");
} }
function LoaiBieuMauComponent_p_organizationChart_50_Template(rf, ctx) { if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "p-organizationChart", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("selectionChange", function LoaiBieuMauComponent_p_organizationChart_50_Template_p_organizationChart_selectionChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r24); const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r23.selectedNode = $event; })("onNodeSelect", function LoaiBieuMauComponent_p_organizationChart_50_Template_p_organizationChart_onNodeSelect_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r24); const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r25.onNodeSelect($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, LoaiBieuMauComponent_p_organizationChart_50_ng_template_1_Template, 6, 3, "ng-template", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, LoaiBieuMauComponent_p_organizationChart_50_ng_template_2_Template, 1, 1, "ng-template", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", ctx_r7.listAgencyMap)("preserveSpace", false)("selection", ctx_r7.selectedNode);
} }
function LoaiBieuMauComponent_app_chi_tiet_loai_bieu_mau_52_Template(rf, ctx) { if (rf & 1) {
    const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "app-chi-tiet-loai-bieu-mau", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("callback", function LoaiBieuMauComponent_app_chi_tiet_loai_bieu_mau_52_Template_app_chi_tiet_loai_bieu_mau_callback_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r27); const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r26.handleCallbackForm(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formTypeId", ctx_r8.formTypeId);
} }
const _c0 = function (a0, a1) { return { url: a0, action: a1 }; };
const _c1 = function () { return { width: "700px" }; };
const _c2 = function () { return { showAll: "ALL" }; };
const _c3 = function (a5) { return [15, 30, 45, 100, 200, a5]; };
const _c4 = function () { return { width: "90vw" }; };
const _c5 = function () { return { "1024": "95vw", "640px": "100vw" }; };
const _c6 = function () { return { width: "600px" }; };
class LoaiBieuMauComponent {
    constructor(apiService, spinner, confirmationService, messageService, fileService, changeDetector, router) {
        this.apiService = apiService;
        this.spinner = spinner;
        this.confirmationService = confirmationService;
        this.messageService = messageService;
        this.fileService = fileService;
        this.changeDetector = changeDetector;
        this.router = router;
        this.MENUACTIONROLEAPI = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI;
        this.ACTIONS = src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS;
        this.items = [];
        this.organs = [];
        this.loadjs = 0;
        this.heightGrid = 0;
        this.query = {
            filter: '',
            organizeId: '',
            typeForm: null,
            createDate: '',
            offSet: 0,
            pageSize: 15
        };
        this.totalRecord = 0;
        this.first = 0;
        this.countRecord = {
            totalRecord: 0,
            currentRecordStart: 0,
            currentRecordEnd: 0
        };
        this.listsData = [];
        this.columnDefs = [];
        this.employeeStatus = [];
        this.listDataSelect = [];
        this.isHrDiagram = false;
        this.organizeList = [];
        this.detailOrganizeMap = null;
        this.formTypes = [];
        this.displaySetting = false;
        this.gridKey = '';
        this.addNewPopup = false;
        this.formTypeId = null;
    }
    ngOnInit() {
        this.items = [
            { label: 'Trang chủ', routerLink: '/home' },
            { label: 'Hoạt động' },
            { label: '...' },
            { label: 'Tài liệu', routerLink: '/chinh-sach/tai-lieu-chung' },
            { label: 'Thiết lập loại tài liệu' },
        ];
        this.getAgencyOrganizeMap();
        this.getOrgan();
        this.getFormTypes();
    }
    getNode(item) {
        return {
            label: item.formTypeName || item.formTypeId,
            data: item.formTypeId,
            expandedIcon: "pi pi-folder-open",
            collapsedIcon: "pi pi-folder",
            children: item.children
        };
    }
    loopEveryNodeTree(list) {
        for (let i = 0; i < list.length; i++) {
            if (Array.isArray(list[i].children) && list[i].children.length) {
                list[i] = this.getNode(list[i]);
                this.loopEveryNodeTree(list[i].children);
            }
            else {
                list[i] = this.getNode(list[i]);
            }
        }
    }
    getFormTypes() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ filter: '', form_type_id: '' });
        this.apiService.getFormsTypes(queryParams)
            .pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.finalize)(() => this.spinner.hide()))
            .subscribe(response => {
            if (response.status === 'success') {
                const data = response.data;
                this.loopEveryNodeTree(data);
                this.formTypes = data;
            }
            else {
                console.error(response.message);
            }
        });
    }
    hrDiagram() {
        this.selectedNode = null;
        this.listAgencyMap = [];
        this.getAgencyOrganizeMap(true);
    }
    getAgencyOrganizeMap(type = false) {
        this.apiService.getAgencyOrganizeMap().subscribe(results => {
            if (results.status === 'success') {
                this.listAgencyMap = [...results.data.root];
                if (localStorage.getItem("organize") === null) {
                    this.selectedNode = this.listAgencyMap[0];
                    localStorage.setItem('organize', JSON.stringify(this.listAgencyMap[0]));
                    // this.query.organizeId = this.selectedNode.orgId;
                    this.load();
                }
                else {
                    this.selectedNode = JSON.parse(localStorage.getItem("organize"));
                    // this.query.organizeId = this.selectedNode?.orgId;
                    this.listAgencyMap = this.expanded(this.listAgencyMap, this.selectedNode.parentId);
                    this.selected(this.listAgencyMap, this.query.organizeId);
                    if (type) {
                        this.isHrDiagram = true;
                    }
                    this.load();
                }
            }
        });
    }
    onNodeSelect(event) {
        var _a;
        this.detailOrganizeMap = event.node;
        localStorage.setItem('organize', JSON.stringify(event.node));
        // this.query.orgId = this.selectedNode?.orgId;
        this.query.organizeId = (_a = this.detailOrganizeMap) === null || _a === void 0 ? void 0 : _a.orgId;
        this.isHrDiagram = false;
        this.load();
    }
    selected(datas = [], orgId = '') {
        datas.forEach(d => {
            if (d.orgId == orgId) {
                this.selectedNode = d;
                this.detailOrganizeMap = d;
            }
            else {
                if (d.children.length > 0)
                    this.selected(d.children, this.selectedNode.orgId);
            }
        });
    }
    expanded(datas = [], orgId = 0) {
        datas.forEach(d => {
            if (d.orgId === orgId) {
                d.expanded = true;
            }
            else {
                if (d.children.length > 0)
                    this.expanded(d.children, this.selectedNode.parentId);
            }
            d.children.forEach((elm) => {
                elm.children.forEach((e) => {
                    if (e.expanded === true) {
                        elm.expanded = true;
                    }
                });
            });
        });
        return datas;
    }
    getOrgan() {
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ filter: '' });
        this.apiService.getOrganizations(queryParams).subscribe(results => {
            if (results.status === 'success') {
                this.organs = results.data.map(d => {
                    return {
                        label: d.organizationName,
                        value: `${d.organizeId}`
                    };
                });
                this.organs = [...this.organs];
            }
        });
    }
    find() {
        this.load();
    }
    changePageSize() {
        this.load();
    }
    paginate(event) {
        this.query.offSet = event.first;
        this.first = event.first;
        this.query.pageSize = event.rows;
        this.load();
    }
    cauhinh() {
        this.displaySetting = true;
    }
    load() {
        this.columnDefs = [];
        this.spinner.show();
        const query = Object.assign({}, this.query);
        if (query.createDate && typeof query.createDate !== 'string') {
            query.createDate = moment__WEBPACK_IMPORTED_MODULE_4__(query.createDate).format('YYYY-MM-DD');
        }
        if (typeof this.query.typeForm === 'object' && this.query && this.query.typeForm) {
            query.typeForm = this.query.typeForm.data;
        }
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify(query);
        this.apiService.getFormsTypePage(queryParams)
            .subscribe((results) => {
            this.listsData = results.data.dataList.data;
            this.gridKey = results.data.dataList.gridKey;
            if (this.query.offSet === 0) {
                this.cols = results.data.gridflexs;
                this.colsDetail = results.data.gridflexdetails ? results.data.gridflexdetails : [];
            }
            this.initGrid();
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.totalRecord = results.data.dataList.recordsTotal;
            this.countRecord.currentRecordStart = results.data.dataList.recordsTotal === 0 ? this.query.offSet = 0 : this.query.offSet + 1;
            if ((results.data.dataList.recordsTotal - this.query.offSet) > this.query.pageSize) {
                this.countRecord.currentRecordEnd = this.query.offSet + Number(this.query.pageSize);
            }
            else {
                this.countRecord.currentRecordEnd = results.data.dataList.recordsTotal;
                setTimeout(() => {
                    const noData = document.querySelector('.ag-overlay-no-rows-center');
                    if (noData) {
                        noData.innerHTML = 'Không có kết quả phù hợp';
                    }
                }, 100);
            }
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    showButtons(event) {
        return {
            buttons: [
                {
                    onClick: this.handleEdit.bind(this),
                    label: 'Thông tin chi tiết',
                    icon: 'fa fa-eye',
                    class: 'btn-primary mr5',
                    hide: this.CheckHideSua(event)
                },
                {
                    onClick: this.handleDelete.bind(this),
                    label: 'Xóa tài liệu',
                    icon: 'fa fa-trash',
                    class: 'btn-primary mr5',
                    hide: this.CheckHideXoa(event)
                },
            ]
        };
    }
    CheckHideSua(event) {
        let checkValue = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI.GetFormsTypePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS.VIEW);
        if (checkValue) {
            return true;
        }
        else {
            if (event.data.is_edit !== 1) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    CheckHideXoa(event) {
        let checkValue = (0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.CheckHideAction)(src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.MENUACTIONROLEAPI.GetFormsTypePage.url, src_app_common_constants_constant__WEBPACK_IMPORTED_MODULE_5__.ACTIONS.DELETE);
        if (checkValue) {
            return true;
        }
        else {
            if (event.data.is_edit !== 1) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    handleDelete(event) {
        this.confirmationService.confirm({
            message: 'Bạn có chắc chắn muốn xóa tài liệu?',
            accept: () => {
                const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify({ formId: event.rowData.form_type_id });
                this.apiService.delFormsTypeInfo(queryParams).subscribe((results) => {
                    if (results.status === 'success') {
                        this.messageService.add({ severity: 'success', summary: 'Thông báo', detail: results.data ? results.data : 'Xóa tài liệu thành công' });
                        this.load();
                    }
                    else {
                        this.messageService.add({ severity: 'error', summary: 'Thông báo', detail: results ? results.message : null });
                    }
                });
            }
        });
    }
    handleEdit(event) {
        this.formTypeId = event.rowData.form_type_id;
        this.addNewPopup = true;
    }
    handleAdd() {
        this.formTypeId = null;
        this.addNewPopup = true;
    }
    initGrid() {
        this.columnDefs = [
            {
                headerName: 'Stt',
                filter: '',
                maxWidth: 120,
                pinned: 'left',
                cellRenderer: params => {
                    return params.rowIndex + 1;
                },
                cellClass: ['border-right', 'no-auto'],
                checkboxSelection: true,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
                field: 'checkbox2',
                suppressSizeToFit: true,
            },
            ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.AgGridFn)(this.cols.filter((d) => !d.isHide)),
            {
                headerName: 'Thao tác',
                filter: '',
                maxWidth: 120,
                pinned: 'right',
                cellRenderer: 'buttonAgGridComponent',
                cellClass: ['border-right', 'no-auto'],
                cellRendererParams: (params) => this.showButtons(params),
                field: 'checkbox'
            }
        ];
        this.detailCellRendererParams = {
            detailGridOptions: {
                frameworkComponents: {},
                getRowHeight: (params) => {
                    return 40;
                },
                columnDefs: [
                    ...(0,src_app_common_function_common_common__WEBPACK_IMPORTED_MODULE_3__.AgGridFn)(this.colsDetail),
                ],
                enableCellTextSelection: true,
                onFirstDataRendered(params) {
                    let allColumnIds = [];
                    params.columnApi.getAllColumns()
                        .forEach((column) => {
                        if (column.colDef.cellClass.indexOf('auto') < 0) {
                            allColumnIds.push(column);
                        }
                        else {
                            column.colDef.suppressSizeToFit = true;
                            allColumnIds.push(column);
                        }
                    });
                    params.api.sizeColumnsToFit(allColumnIds);
                },
            },
            getDetailRowData(params) {
                params.successCallback(params.data.AgencyGenerals);
            },
            excelStyles: [
                {
                    id: 'stringType',
                    dataType: 'string'
                }
            ],
            template: function (params) {
                var personName = params.data.theme;
                return ('<div style="height: 100%; background-color: #EDF6FF; padding: 20px; box-sizing: border-box;">' +
                    `  <div style="height: 10%; padding: 2px; font-weight: bold;">###### Danh sách (${params.data.AgencyGenerals.length}) : [` +
                    personName + ']' +
                    '</div>' +
                    '  <div ref="eDetailGrid" style="height: 90%;"></div>' +
                    '</div>');
            },
        };
    }
    exportExel() {
        this.spinner.show();
        this.query.pageSize = 1000000;
        const query = Object.assign({}, this.query);
        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2__.stringify(query);
        this.apiService.getFormPage(queryParams).subscribe((results) => {
            const dataExport = [];
            let gridflexs = results.data.gridflexs;
            let arrKey = gridflexs.map(elementName => elementName.columnField);
            let dataList = results.data.dataList.data;
            for (let elementValue of dataList) {
                const data = {};
                for (let elementName of gridflexs) {
                    if (arrKey.indexOf(elementName.columnField) > -1 && !elementName.isHide && elementName.columnField !== 'statusName') {
                        let valueColumn = elementValue[elementName.columnField];
                        if (elementName.columnField == 'status_name' || elementName.columnField == 'isContacted' || elementName.columnField == 'isProfileFull' || elementName.columnField == 'lockName') {
                            valueColumn = this.replaceHtmlToText(valueColumn);
                        }
                        data[elementName.columnCaption] = valueColumn || '';
                    }
                }
                dataExport.push(data);
            }
            this.fileService.exportAsExcelFile(dataExport, 'Danh sách hồ sơ nhân sự ' + new Date());
            this.spinner.hide();
        }, error => {
            this.spinner.hide();
        });
    }
    replaceHtmlToText(string) {
        return string.replace(/(<([^>]+)>)/gi, "");
    }
    cancel() {
        this.query = {
            organizeId: '',
            filter: '',
            typeForm: '',
            createDate: '',
            offSet: 0,
            pageSize: 10
        };
        this.load();
    }
    ngAfterViewChecked() {
        const a = document.querySelector(".header");
        const b = document.querySelector(".sidebarBody");
        const c = document.querySelector(".bread-filter");
        const d = document.querySelector(".bread-crumb");
        const e = document.querySelector(".paginator");
        this.loadjs++;
        if (this.loadjs === 5) {
            if (b && b.clientHeight) {
                const totalHeight = a.clientHeight + b.clientHeight + c.clientHeight + d.clientHeight + e.clientHeight + 25;
                this.heightGrid = window.innerHeight - totalHeight;
                this.changeDetector.detectChanges();
            }
            else {
                this.loadjs = 0;
            }
        }
        this.changeDetector.detectChanges();
    }
    rowSelected(data) {
        this.listDataSelect = data;
    }
    handleCallbackForm() {
        this.load();
        this.addNewPopup = false;
    }
}
LoaiBieuMauComponent.ɵfac = function LoaiBieuMauComponent_Factory(t) { return new (t || LoaiBieuMauComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_services_api_hrm_apihrm_service__WEBPACK_IMPORTED_MODULE_0__.ApiHrmService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_12__.NgxSpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_13__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_13__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_services_export_file_service__WEBPACK_IMPORTED_MODULE_1__.ExportFileService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.Router)); };
LoaiBieuMauComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({ type: LoaiBieuMauComponent, selectors: [["app-loai-bieu-mau"]], decls: 53, vars: 43, consts: [[1, "main-grid"], [1, "bread-crumb"], [1, "d-flex", "bet", "bottom"], [3, "items"], [1, "d-flex", "gap12"], ["label", "Th\u00EAm m\u1EDBi", "styleClass", "", "icon", "", 3, "CheckHideActions", "click"], ["width", "18", "height", "18", "viewBox", "0 0 18 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg", 1, "mr-2"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9 0.875C9.62132 0.875 10.125 1.37868 10.125 2V7.875H16C16.6213 7.875 17.125 8.37868 17.125 9C17.125 9.62132 16.6213 10.125 16 10.125H10.125V16C10.125 16.6213 9.62132 17.125 9 17.125C8.37868 17.125 7.875 16.6213 7.875 16V10.125H2C1.37868 10.125 0.875 9.62132 0.875 9C0.875 8.37868 1.37868 7.875 2 7.875H7.875V2C7.875 1.37868 8.37868 0.875 9 0.875Z", "fill", "#E2EEFF"], [1, "select-ori"], [1, "name"], [1, "field-group", "select", "mb-0", "valid", 3, "ngClass"], ["panelStyleClass", "select-ori-panel", "placeholder", "Ch\u1ECDn t\u1ED5 ch\u1EE9c", "appendTo", "body", "name", "orgId", 3, "baseZIndex", "autoDisplayFirst", "options", "ngModel", "ngModelChange", "onChange"], ["pTemplate", "selectedItem"], ["pTemplate", "item"], [1, "dia", 3, "click"], ["width", "22", "height", "19", "viewBox", "0 0 22 19", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11 0C8.92893 0 7.25 1.67148 7.25 3.73335C7.25 5.54325 8.54366 7.05234 10.2606 7.39415V10.5496H4.49291C4.29682 10.5496 4.10876 10.6272 3.9701 10.7652C3.83144 10.9033 3.75354 11.0905 3.75354 11.2857V14.8684H1.23937C1.04328 14.8684 0.855215 14.946 0.716557 15.084C0.577898 15.2221 0.5 15.4093 0.5 15.6045V17.7639C0.5 17.9591 0.577898 18.1464 0.716557 18.2844C0.855215 18.4224 1.04328 18.5 1.23937 18.5C1.43546 18.5 1.62353 18.4224 1.76218 18.2844C1.90084 18.1464 1.97874 17.9591 1.97874 17.7639V16.3406H7.00709V17.7639C7.00709 17.9591 7.08498 18.1464 7.22364 18.2844C7.3623 18.4224 7.55036 18.5 7.74646 18.5C7.94255 18.5 8.13061 18.4224 8.26927 18.2844C8.40793 18.1464 8.48583 17.9591 8.48583 17.7639V15.6045C8.48583 15.4093 8.40793 15.2221 8.26927 15.084C8.13061 14.946 7.94255 14.8684 7.74646 14.8684H5.23229V12.0218H16.7677V14.8684H14.2535C14.0575 14.8684 13.8694 14.946 13.7307 15.084C13.5921 15.2221 13.5142 15.4093 13.5142 15.6045V17.7639C13.5142 17.9591 13.5921 18.1464 13.7307 18.2844C13.8694 18.4224 14.0575 18.5 14.2535 18.5C14.4496 18.5 14.6377 18.4224 14.7764 18.2844C14.915 18.1464 14.9929 17.9591 14.9929 17.7639V16.3406H20.0213V17.7639C20.0213 17.9591 20.0992 18.1464 20.2378 18.2844C20.3765 18.4224 20.5645 18.5 20.7606 18.5C20.9567 18.5 21.1448 18.4224 21.2834 18.2844C21.4221 18.1464 21.5 17.9591 21.5 17.7639V15.6045C21.5 15.4093 21.4221 15.2221 21.2834 15.084C21.1448 14.946 20.9567 14.8684 20.7606 14.8684H18.2465V11.2857C18.2465 11.0905 18.1686 10.9033 18.0299 10.7652C17.8912 10.6272 17.7032 10.5496 17.5071 10.5496H11.7394V7.39415C13.4563 7.05234 14.75 5.54325 14.75 3.73335C14.75 1.67148 13.0711 0 11 0Z", "fill", "#0979FD"], [1, "bread-filter"], [1, "d-flex", "bet", "end", "bottom", "gap-16"], [1, "col-item"], [1, "filter", "filter-search"], [1, "field-group", "valid", "text", "search", "mb-0"], ["placeholder", "T\u00ECm ki\u1EBFm theo m\u00E3, t\u00EAn lo\u1EA1i t\u00E0i li\u1EC7u", "type", "text", "id", "filter", 1, "input-default", 3, "ngModel", "keydown.enter", "ngModelChange"], [1, "placeholder-icon", 3, "click"], ["_ngcontent-xmj-c197", "", "width", "19", "height", "20", "viewBox", "0 0 19 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["_ngcontent-xmj-c197", "", "fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.02893 0.850098C4.51087 0.850098 0.849609 4.51552 0.849609 9.03539C0.849609 13.5553 4.51087 17.2207 9.02893 17.2207C10.8456 17.2207 12.5254 16.6271 13.8828 15.6241L17.1276 18.8716C17.4984 19.2427 18.0999 19.243 18.4711 18.8721C18.8422 18.5013 18.8425 17.8998 18.4716 17.5286L15.2709 14.3252C16.4787 12.8991 17.2083 11.0518 17.2083 9.03539C17.2083 4.51552 13.547 0.850098 9.02893 0.850098ZM2.74961 9.03539C2.74961 5.56338 5.56169 2.7501 9.02893 2.7501C12.4962 2.7501 15.3083 5.56338 15.3083 9.03539C15.3083 10.8568 14.5355 12.496 13.2976 13.645C12.1765 14.6858 10.6778 15.3207 9.02893 15.3207C5.56169 15.3207 2.74961 12.5074 2.74961 9.03539Z", "fill", "#2B2F33", "fill-opacity", "0.6"], ["styleClass", "reloadBtn", 3, "click"], ["width", "20", "height", "18", "viewBox", "0 0 20 18", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M8.89128 1.80952C5.00096 1.80952 1.81817 5.01267 1.81817 9C1.81817 12.9873 5.00096 16.1905 8.89128 16.1905C11.1061 16.1905 13.087 15.1561 14.3877 13.526C14.7 13.1346 15.2718 13.0693 15.665 13.3801C16.0582 13.6908 16.1238 14.2599 15.8116 14.6513C14.1855 16.6891 11.6915 18 8.89128 18C3.9647 18 0 13.9544 0 9C0 4.04557 3.9647 0 8.89128 0C12.8587 0 16.2024 2.62369 17.3539 6.23284L18.2926 4.51929C18.5329 4.08057 19.0851 3.91882 19.5259 4.15801C19.9667 4.39719 20.1292 4.94675 19.8889 5.38547L17.6716 9.43309C17.5446 9.66497 17.3221 9.83003 17.0626 9.88497C16.803 9.93991 16.5323 9.87923 16.3215 9.71886L12.7738 7.02045C12.3749 6.71703 12.2987 6.14921 12.6035 5.75219C12.9084 5.35518 13.4789 5.2793 13.8778 5.58273L15.6726 6.94784C14.8021 3.96847 12.0851 1.80952 8.89128 1.80952Z", "fill", "#BDC4D8"], ["styleClass", "p-button-sm height-56 ", 3, "click"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M11.2913 3.47726H0.769231C0.344396 3.47726 0 3.14148 0 2.72726C0 2.31305 0.344396 1.97726 0.769231 1.97726H11.4465C11.8523 0.96494 12.8427 0.25 14 0.25C15.1573 0.25 16.1477 0.96494 16.5535 1.97726H19.2309C19.6557 1.97726 20.0001 2.31305 20.0001 2.72726C20.0001 3.14148 19.6557 3.47726 19.2309 3.47726H16.7087C16.4828 4.76856 15.356 5.75 14 5.75C12.644 5.75 11.5172 4.76856 11.2913 3.47726ZM12.7587 2.85147C12.753 2.90017 12.75 2.94974 12.75 3C12.75 3.69036 13.3096 4.25 14 4.25C14.6904 4.25 15.25 3.69036 15.25 3C15.25 2.30964 14.6904 1.75 14 1.75C13.3762 1.75 12.8591 2.20697 12.7652 2.80443C12.7636 2.82026 12.7614 2.83594 12.7587 2.85147Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.64647 9.24997C9.32 8.09573 8.25877 7.25 7 7.25C5.74123 7.25 4.68 8.09573 4.35352 9.24997H0.769231C0.344396 9.24997 0 9.58576 0 9.99997C0 10.4142 0.344396 10.75 0.769231 10.75H4.35351C4.67996 11.9042 5.74121 12.75 7 12.75C8.25879 12.75 9.32004 11.9042 9.64649 10.75H19.2308C19.6557 10.75 20.0001 10.4142 20.0001 9.99997C20.0001 9.58576 19.6557 9.24997 19.2308 9.24997H9.64647ZM7 8.75C6.30964 8.75 5.75 9.30964 5.75 10C5.75 10.6904 6.30964 11.25 7 11.25C7.64529 11.25 8.17638 10.761 8.24297 10.1334C8.23499 10.0901 8.23083 10.0455 8.23083 9.99997C8.23083 9.95444 8.23499 9.90985 8.24296 9.86656C8.17636 9.23895 7.64528 8.75 7 8.75Z", "fill", "#F3F8FF"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M9.44645 18.0227H0.769231C0.344396 18.0227 0 17.6869 0 17.2727C0 16.8585 0.344396 16.5227 0.769231 16.5227H9.29127C9.51724 15.2314 10.644 14.25 12 14.25C13.356 14.25 14.4827 15.2314 14.7087 16.5227H19.2308C19.6557 16.5227 20.0001 16.8585 20.0001 17.2727C20.0001 17.6869 19.6557 18.0227 19.2308 18.0227H14.5536C14.1477 19.035 13.1574 19.75 12 19.75C10.8426 19.75 9.85227 19.035 9.44645 18.0227ZM10.75 17C10.75 16.3096 11.3096 15.75 12 15.75C12.6904 15.75 13.25 16.3096 13.25 17C13.25 17.6904 12.6904 18.25 12 18.25C11.3096 18.25 10.75 17.6904 10.75 17Z", "fill", "#F3F8FF"], ["styleClass", "advance-seach"], ["op", ""], ["pTemplate", ""], [1, "content", "pb-0"], [1, "grid-default"], ["container", ""], [3, "listsData", "height", "columnDefs", "rowSelection", "callback", 4, "ngIf"], [1, "paginator"], [3, "rows", "totalRecords", "first", "rowsPerPageOptions", "onPageChange"], ["styleClass", "hr-diagram", 3, "appendTo", "autoZIndex", "visible", "modal", "breakpoints", "visibleChange"], ["pTemplate", "header"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect", 4, "ngIf"], ["styleClass", "hideHeaderForm", "header", "Thi\u00EA\u0301t l\u00E2\u0323p loa\u0323i t\u00E0i li\u1EC7u", 3, "visible", "modal", "draggable", "resizable", "focusTrap", "visibleChange"], [3, "formTypeId", "callback", 4, "ngIf"], [2, "vertical-align", "middle"], [1, "ui-helper-clearfix", 2, "position", "relative", "height", "25px"], [1, "header-filter-search", "grid"], [1, "header-filter-search", "grid", "mt-1"], [1, "icon", "col-12", "pl-0", 2, "display", "flex", "flex-wrap", "wrap"], [1, "col-6"], [1, "field-group", "select", "mb-0", 3, "ngClass"], ["appendTo", "body", 3, "ngModel", "options", "ngModelChange"], [1, "field-group", "date", "mb-0", 3, "ngClass"], ["name", "createDate", "inputId", "icon", 3, "ngModel", "ngModelChange", "onSelect"], [1, "icon"], ["width", "18", "height", "20", "viewBox", "0 0 18 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M14.1143 1.89648C14.1143 1.3442 13.6665 0.896484 13.1143 0.896484C12.562 0.896484 12.1143 1.3442 12.1143 1.89648L12.1143 4.89648C12.1143 5.44877 12.562 5.89648 13.1143 5.89648C13.6665 5.89648 14.1143 5.44877 14.1143 4.89648L14.1143 1.89648Z", "fill", "#99A2BC"], ["d", "M6.11426 1.89649C6.11426 1.3442 5.66654 0.896488 5.11426 0.896488C4.56197 0.896488 4.11426 1.3442 4.11426 1.89649L4.11426 4.89648C4.11426 5.44877 4.56197 5.89648 5.11426 5.89648C5.66654 5.89648 6.11426 5.44877 6.11426 4.89648L6.11426 1.89649Z", "fill", "#99A2BC"], ["d", "M11.1143 2.83252H7.11426L7.11426 4.83252C7.11426 5.93709 6.21883 6.83252 5.11426 6.83252C4.00969 6.83252 3.11426 5.93709 3.11426 4.83252L3.11426 2.92088C2.27249 3.02253 1.72376 3.24112 1.25368 3.7112C0.463333 4.50155 0.38388 5.72516 0.375893 8.02148H17.6258C17.6257 5.26179 17.6172 4.58131 16.7471 3.7112C16.2978 3.26191 15.8362 3.04235 15.1143 2.93506L15.1143 4.83252C15.1143 5.93709 14.2188 6.83252 13.1143 6.83252C12.0097 6.83252 11.1143 5.93709 11.1143 4.83252L11.1143 2.83252Z", "fill", "#99A2BC"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M17.6258 9.77148H0.375V13.1036C0.375 15.932 0.375 17.3462 1.25368 18.2249C2.13236 19.1036 3.28587 19.1036 6.1143 19.1036H12.1143C14.9427 19.1036 15.8684 19.1036 16.7471 18.2249C17.6258 17.3462 17.6258 15.932 17.6258 13.1036V9.77148ZM3.625 12.459C3.625 12.1483 3.87684 11.8965 4.1875 11.8965H5.3125C5.62316 11.8965 5.875 12.1483 5.875 12.459V13.584C5.875 13.8946 5.62316 14.1465 5.3125 14.1465H4.1875C3.87684 14.1465 3.625 13.8946 3.625 13.584V12.459ZM8.125 12.459C8.125 12.1483 8.37684 11.8965 8.6875 11.8965H9.8125C10.1232 11.8965 10.375 12.1483 10.375 12.459V13.584C10.375 13.8946 10.1232 14.1465 9.8125 14.1465H8.6875C8.37684 14.1465 8.125 13.8946 8.125 13.584V12.459ZM13.1875 11.8965C12.8768 11.8965 12.625 12.1483 12.625 12.459V13.584C12.625 13.8946 12.8768 14.1465 13.1875 14.1465H14.3125C14.6232 14.1465 14.875 13.8946 14.875 13.584V12.459C14.875 12.1483 14.6232 11.8965 14.3125 11.8965H13.1875Z", "fill", "#99A2BC"], [1, "input-group", "icon", "col-12", "select-default", "text-right"], ["label", "T\u00ECm ki\u1EBFm", "styleClass", "mr-1", "icon", "pi pi-search", 3, "click"], ["label", "L\u00E0m m\u1EDBi", "icon", "pi pi-times", "styleClass", "p-button-secondary", 3, "click"], [3, "listsData", "height", "columnDefs", "rowSelection", "callback"], ["styleClass", "diagram-zindex", "selectionMode", "single", "styleClass", "company", 3, "value", "preserveSpace", "selection", "selectionChange", "onNodeSelect"], ["pTemplate", "person"], ["pTemplate", "department"], [1, "node-header", "p-corner-top"], [1, "node-content"], ["width", "32", 3, "src"], [3, "formTypeId", "callback"]], template: function LoaiBieuMauComponent_Template(rf, ctx) { if (rf & 1) {
        const _r28 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](3, "app-hrm-breadcrumb", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function LoaiBieuMauComponent_Template_p_button_click_5_listener() { return ctx.handleAdd(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](6, "svg", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](7, "path", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](8, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](11, "p-dropdown", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function LoaiBieuMauComponent_Template_p_dropdown_ngModelChange_11_listener($event) { return ctx.query.organizeId = $event; })("onChange", function LoaiBieuMauComponent_Template_p_dropdown_onChange_11_listener() { return ctx.find(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](12, LoaiBieuMauComponent_ng_template_12_Template, 2, 1, "ng-template", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](13, LoaiBieuMauComponent_ng_template_13_Template, 3, 1, "ng-template", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](14, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function LoaiBieuMauComponent_Template_div_click_14_listener() { return ctx.hrDiagram(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](15, "svg", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](16, "path", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](17, "section", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](18, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](19, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](20, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](21, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](22, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("keydown.enter", function LoaiBieuMauComponent_Template_input_keydown_enter_22_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); })("ngModelChange", function LoaiBieuMauComponent_Template_input_ngModelChange_22_listener($event) { return ctx.query.filter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](23, "span", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function LoaiBieuMauComponent_Template_span_click_23_listener() { ctx.query.offSet = 0; ctx.first = 0; return ctx.load(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](24, "svg", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](25, "path", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](26, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](27, "p-button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function LoaiBieuMauComponent_Template_p_button_click_27_listener() { return ctx.cancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](28, "svg", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](29, "path", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](30, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](31, "p-button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function LoaiBieuMauComponent_Template_p_button_click_31_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r28); const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](38); return _r2.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](32, "svg", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](33, "path", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](34, "path", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](35, "path", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](36, " \u00A0\u00A0 B\u1ED9 L\u1ECDc ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](37, "p-overlayPanel", 34, 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](39, LoaiBieuMauComponent_ng_template_39_Template, 24, 5, "ng-template", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](40, "section", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](41, "div", 38, 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](43, LoaiBieuMauComponent_app_list_grid_angular_43_Template, 1, 4, "app-list-grid-angular", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](44, "div", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](45, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](46);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](47, "p-paginator", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("onPageChange", function LoaiBieuMauComponent_Template_p_paginator_onPageChange_47_listener($event) { return ctx.paginate($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](48, "p-dialog", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("visibleChange", function LoaiBieuMauComponent_Template_p_dialog_visibleChange_48_listener($event) { return ctx.isHrDiagram = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](49, LoaiBieuMauComponent_ng_template_49_Template, 1, 0, "ng-template", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](50, LoaiBieuMauComponent_p_organizationChart_50_Template, 3, 3, "p-organizationChart", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](51, "p-dialog", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("visibleChange", function LoaiBieuMauComponent_Template_p_dialog_visibleChange_51_listener($event) { return ctx.addNewPopup = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](52, LoaiBieuMauComponent_app_chi_tiet_loai_bieu_mau_52_Template, 1, 1, "app-chi-tiet-loai-bieu-mau", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("items", ctx.items);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("CheckHideActions", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction2"](33, _c0, ctx.MENUACTIONROLEAPI.GetFormsTypePage.url, ctx.ACTIONS.ADD));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("baseZIndex", 100)("autoDisplayFirst", false)("options", ctx.organs)("ngModel", ctx.query.organizeId);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx.query.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](36, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.columnDefs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate3"]("T\u1EEB ", ctx.countRecord.currentRecordStart, " \u0111\u1EBFn ", ctx.countRecord.currentRecordEnd, " tr\u00EAn t\u1ED5ng s\u1ED1 ", ctx.countRecord.totalRecord, " k\u1EBFt qu\u1EA3");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("rows", ctx.query.pageSize)("totalRecords", ctx.countRecord.totalRecord)("first", ctx.first)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](38, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](37, _c2)));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](40, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("appendTo", "body")("autoZIndex", true)("visible", ctx.isHrDiagram)("modal", true)("breakpoints", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](41, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.isHrDiagram);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](42, _c6));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("visible", ctx.addNewPopup)("modal", true)("draggable", false)("resizable", false)("focusTrap", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.addNewPopup);
    } }, directives: [_common_hrm_breadcrumb_hrm_breadcrumb_component__WEBPACK_IMPORTED_MODULE_6__.HrmBreadCrumbComponent, primeng_button__WEBPACK_IMPORTED_MODULE_15__.Button, _directive_check_action_directive__WEBPACK_IMPORTED_MODULE_7__.CheckHideActionsDirective, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgClass, primeng_dropdown__WEBPACK_IMPORTED_MODULE_17__.Dropdown, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgModel, primeng_api__WEBPACK_IMPORTED_MODULE_13__.PrimeTemplate, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.DefaultValueAccessor, primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_19__.OverlayPanel, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, primeng_paginator__WEBPACK_IMPORTED_MODULE_20__.Paginator, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.Dialog, primeng_treeselect__WEBPACK_IMPORTED_MODULE_22__.TreeSelect, primeng_calendar__WEBPACK_IMPORTED_MODULE_23__.Calendar, _common_list_grid_angular_list_grid_angular_component__WEBPACK_IMPORTED_MODULE_8__.ListGridAngularComponent, primeng_organizationchart__WEBPACK_IMPORTED_MODULE_24__.OrganizationChart, src_app_components_bieu_mau_loai_bieu_mau_chi_tiet_loai_bieu_mau_chi_tiet_loai_bieu_mau_component__WEBPACK_IMPORTED_MODULE_9__.ChiTietLoaiBieuMauComponent], styles: ["[_nghost-%COMP%]  .hideHeaderForm .p-panel-header {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvYWktYmlldS1tYXUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRVE7RUFDSSxhQUFBO0FBRFoiLCJmaWxlIjoibG9haS1iaWV1LW1hdS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0OjpuZy1kZWVwe1xyXG4gICAgLmhpZGVIZWFkZXJGb3Jte1xyXG4gICAgICAgIC5wLXBhbmVsLWhlYWRlcntcclxuICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iXX0= */"] });


/***/ })

}]);
//# sourceMappingURL=default-src_app_components_bieu-mau_bieu-mau_component_ts-src_app_components_bieu-mau_loai-bi-2aadfb.8ffe9c4fc0aee102.js.map