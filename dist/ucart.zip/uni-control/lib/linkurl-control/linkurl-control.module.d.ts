import * as i0 from "@angular/core";
import * as i1 from "./linkurl-control.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "primeng/button";
import * as i5 from "primeng/fileupload";
export declare class LinkurlControlModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkurlControlModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LinkurlControlModule, [typeof i1.LinkurlControlComponent], [typeof i2.CommonModule, typeof i3.FormsModule, typeof i4.ButtonModule, typeof i5.FileUploadModule], [typeof i1.LinkurlControlComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LinkurlControlModule>;
}
