export declare class UniControlModule {
}
